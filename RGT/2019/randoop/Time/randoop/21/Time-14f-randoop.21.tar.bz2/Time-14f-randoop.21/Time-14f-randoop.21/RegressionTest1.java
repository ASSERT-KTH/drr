import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(43362L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        org.joda.time.DateTimeField dateTimeField4 = offsetDateTimeField3.getWrappedField();
//        int int6 = offsetDateTimeField3.getMinimumValue(1920010L);
//        java.lang.String str7 = offsetDateTimeField3.toString();
//        int int9 = offsetDateTimeField3.get((long) (short) 10);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str7.equals("DateTimeField[millisOfSecond]"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
//    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = julianChronology1.equals(obj2);
//        java.lang.String str4 = julianChronology1.toString();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.DateTimeFormat.fullTime();
//        boolean boolean6 = julianChronology1.equals((java.lang.Object) dateTimeFormatter5);
//        try {
//            org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.parse("��", dateTimeFormatter5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"��\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JulianChronology[--06-15]" + "'", str4.equals("JulianChronology[--06-15]"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.lang.Object obj0 = null;
        org.joda.time.Instant instant1 = new org.joda.time.Instant(obj0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, (int) (byte) 100);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) ' ');
        org.joda.time.DateTimeField dateTimeField5 = offsetDateTimeField4.getWrappedField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) gJChronology8);
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withChronology((org.joda.time.Chronology) gJChronology14);
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology14);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology14.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField17, 0);
        java.util.Locale locale21 = null;
        java.lang.String str22 = skipUndoDateTimeField19.getAsText((long) (byte) 1, locale21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter23.withChronology((org.joda.time.Chronology) gJChronology24);
        org.joda.time.DateTimeZone dateTimeZone26 = gJChronology24.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter28.withChronology((org.joda.time.Chronology) gJChronology29);
        org.joda.time.MonthDay monthDay31 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology29);
        int[] intArray33 = gJChronology24.get((org.joda.time.ReadablePartial) monthDay31, 0L);
        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology24);
        org.joda.time.MonthDay monthDay35 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology24);
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipUndoDateTimeField19.getAsText((org.joda.time.ReadablePartial) monthDay35, (int) (byte) 1, locale37);
        int int39 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay35);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = monthDay35.getFieldType(0);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1" + "'", str38.equals("1"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 32 + "'", int39 == 32);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        java.lang.String str1 = julianChronology0.toString();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[--06-15]" + "'", str1.equals("JulianChronology[--06-15]"));
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
        org.joda.time.MonthDay monthDay12 = monthDay8.minusMonths((int) '#');
        org.joda.time.MonthDay.Property property13 = monthDay8.dayOfMonth();
        org.joda.time.MonthDay monthDay15 = property13.addToCopy((int) (byte) 0);
        org.joda.time.MonthDay monthDay17 = property13.addWrapFieldToCopy((int) (short) 10);
        java.util.Locale locale18 = null;
        int int19 = property13.getMaximumTextLength(locale18);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter21.withChronology((org.joda.time.Chronology) gJChronology22);
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology22);
        org.joda.time.DateTimeField dateTimeField25 = gJChronology22.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) gJChronology28);
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology28);
        org.joda.time.DateTimeField dateTimeField31 = gJChronology28.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology22, dateTimeField31, 0);
        boolean boolean34 = property13.equals((java.lang.Object) gJChronology22);
        org.joda.time.DateTimeField dateTimeField35 = gJChronology22.millisOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dateTimeField35);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTime0.getZone();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) (short) 1);
        org.joda.time.DateMidnight dateMidnight4 = dateTime0.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateMidnight4);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField6.getAsText(0, locale8);
        int int11 = delegatedDateTimeField6.getMaximumValue((long) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 292278993 + "'", int11 == 292278993);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "DateTimeField[millisOfSecond]", "19");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "DateTimeField[minuteOfHour]", "BuddhistChronology[America/Los_Angeles]");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int6 = offsetDateTimeField3.getMinimumValue((long) 100);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "millisOfSecond" + "'", str4.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology3.year();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField7);
//        java.lang.String str10 = skipDateTimeField8.getAsText((long) (byte) 1);
//        long long13 = skipDateTimeField8.set(10001L, 292278993);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) gJChronology16);
//        org.joda.time.DateTimeZone dateTimeZone18 = gJChronology16.getZone();
//        org.joda.time.DurationField durationField19 = gJChronology16.halfdays();
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology16.secondOfDay();
//        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((long) 21, (org.joda.time.Chronology) gJChronology16);
//        int[] intArray29 = new int[] { 978, 1031, ' ', 24, 100, (-2) };
//        try {
//            int[] intArray31 = skipDateTimeField8.addWrapField((org.joda.time.ReadablePartial) monthDay21, 19, intArray29, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 19");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223371985593610001L + "'", long13 == 9223371985593610001L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(intArray29);
//    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.minuteOfHour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withChronology((org.joda.time.Chronology) gJChronology10);
//        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology10);
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology10.minuteOfHour();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField13, 0);
//        org.joda.time.DurationField durationField16 = skipUndoDateTimeField15.getDurationField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField15, (int) (short) -1);
//        boolean boolean19 = skipUndoDateTimeField18.isLenient();
//        long long21 = skipUndoDateTimeField18.roundFloor((long) 59);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("0");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("1");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) gJChronology9);
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology9);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology9.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withChronology((org.joda.time.Chronology) gJChronology15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology15);
        org.joda.time.DateTimeField dateTimeField18 = gJChronology15.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField18, 0);
        org.joda.time.DurationField durationField21 = skipUndoDateTimeField20.getDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology5, (org.joda.time.DateTimeField) skipUndoDateTimeField20, (int) (short) -1);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology5.clockhourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter25.withChronology((org.joda.time.Chronology) gJChronology26);
        org.joda.time.DateTimeField dateTimeField28 = gJChronology26.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField29 = gJChronology26.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29, dateTimeFieldType30);
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField29);
        jodaTimePermission3.checkGuard((java.lang.Object) gJChronology5);
        org.joda.time.DateTimeField dateTimeField34 = gJChronology5.clockhourOfHalfday();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField34);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYearOfCentury(59, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendTimeZoneName(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMonthOfYear(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendFractionOfDay(3, 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.lang.Object obj0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(obj0, chronology1);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
//        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.Chronology chronology12 = dateTime11.getChronology();
//        org.joda.time.DateTime.Property property13 = dateTime11.millisOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withChronology((org.joda.time.Chronology) gJChronology15);
//        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology15.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter19.withChronology((org.joda.time.Chronology) gJChronology20);
//        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology20);
//        int[] intArray24 = gJChronology15.get((org.joda.time.ReadablePartial) monthDay22, 0L);
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology15);
//        boolean boolean26 = dateTime25.isEqualNow();
//        org.joda.time.DateTime dateTime28 = dateTime25.plusDays((int) ' ');
//        org.joda.time.DateTime dateTime30 = dateTime25.minusYears((int) '4');
//        boolean boolean31 = dateTime25.isBeforeNow();
//        org.joda.time.ReadableDuration readableDuration32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime25.plus(readableDuration32);
//        boolean boolean34 = dateTime11.isBefore((org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.DateTime.Property property35 = dateTime33.yearOfEra();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(gJChronology20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertNotNull(property35);
//    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getShortName((long) '4', locale2);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
//        org.joda.time.DateTime dateTime9 = dateTime5.withYearOfCentury((int) '#');
//        org.joda.time.DateTime dateTime10 = dateTime5.toDateTime();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.010" + "'", str3.equals("+00:00:00.010"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        boolean boolean3 = dateTimeFormatter2.isPrinter();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYearOfCentury(59, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral("2019-06-15T14:02:46.976");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withChronology((org.joda.time.Chronology) gJChronology10);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology10);
        org.joda.time.DateTimeField dateTimeField13 = gJChronology10.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) gJChronology16);
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology16);
        org.joda.time.DateTimeField dateTimeField19 = gJChronology16.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField19, 0);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology24.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, (int) ' ');
        org.joda.time.DateTimeField dateTimeField28 = offsetDateTimeField27.getWrappedField();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField27.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder23.appendSignedDecimal(dateTimeFieldType29, 19, 0);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField22, dateTimeFieldType29, 4, 0, 838);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder2.appendFixedSignedDecimal(dateTimeFieldType29, (-292278993));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal number of digits: -292278993");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) gJChronology4);
//        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.minuteOfHour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withChronology((org.joda.time.Chronology) gJChronology10);
//        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology10);
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology10.minuteOfHour();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField13, 0);
//        org.joda.time.DurationField durationField16 = skipUndoDateTimeField15.getDurationField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField15, (int) (short) -1);
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology0.clockhourOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter20.withChronology((org.joda.time.Chronology) gJChronology21);
//        org.joda.time.DateTimeField dateTimeField23 = gJChronology21.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24, dateTimeFieldType25);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField24);
//        java.lang.String str29 = skipDateTimeField27.getAsText((long) 52);
//        org.joda.time.Chronology chronology30 = null;
//        org.joda.time.MonthDay monthDay31 = new org.joda.time.MonthDay(chronology30);
//        int int32 = skipDateTimeField27.getMinimumValue((org.joda.time.ReadablePartial) monthDay31);
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField34 = gJChronology33.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, (int) ' ');
//        org.joda.time.DateTimeField dateTimeField37 = offsetDateTimeField36.getWrappedField();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter39.withChronology((org.joda.time.Chronology) gJChronology40);
//        org.joda.time.MonthDay monthDay42 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology40);
//        org.joda.time.DateTimeField dateTimeField43 = gJChronology40.minuteOfHour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = dateTimeFormatter45.withChronology((org.joda.time.Chronology) gJChronology46);
//        org.joda.time.MonthDay monthDay48 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology46);
//        org.joda.time.DateTimeField dateTimeField49 = gJChronology46.minuteOfHour();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField51 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField49, 0);
//        java.util.Locale locale53 = null;
//        java.lang.String str54 = skipUndoDateTimeField51.getAsText((long) (byte) 1, locale53);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology56 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter57 = dateTimeFormatter55.withChronology((org.joda.time.Chronology) gJChronology56);
//        org.joda.time.DateTimeZone dateTimeZone58 = gJChronology56.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter60 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter62 = dateTimeFormatter60.withChronology((org.joda.time.Chronology) gJChronology61);
//        org.joda.time.MonthDay monthDay63 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology61);
//        int[] intArray65 = gJChronology56.get((org.joda.time.ReadablePartial) monthDay63, 0L);
//        org.joda.time.DateTime dateTime66 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology56);
//        org.joda.time.MonthDay monthDay67 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology56);
//        java.util.Locale locale69 = null;
//        java.lang.String str70 = skipUndoDateTimeField51.getAsText((org.joda.time.ReadablePartial) monthDay67, (int) (byte) 1, locale69);
//        int int71 = offsetDateTimeField36.getMinimumValue((org.joda.time.ReadablePartial) monthDay67);
//        org.joda.time.DateTimeFieldType dateTimeFieldType73 = monthDay67.getFieldType(0);
//        try {
//            org.joda.time.MonthDay monthDay75 = monthDay31.withField(dateTimeFieldType73, 1970);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1970" + "'", str29.equals("1970"));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(dateTimeFormatter39);
//        org.junit.Assert.assertNotNull(gJChronology40);
//        org.junit.Assert.assertNotNull(dateTimeFormatter41);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeFormatter45);
//        org.junit.Assert.assertNotNull(gJChronology46);
//        org.junit.Assert.assertNotNull(dateTimeFormatter47);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "0" + "'", str54.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter55);
//        org.junit.Assert.assertNotNull(gJChronology56);
//        org.junit.Assert.assertNotNull(dateTimeFormatter57);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(dateTimeFormatter60);
//        org.junit.Assert.assertNotNull(gJChronology61);
//        org.junit.Assert.assertNotNull(dateTimeFormatter62);
//        org.junit.Assert.assertNotNull(intArray65);
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "1" + "'", str70.equals("1"));
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 32 + "'", int71 == 32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType73);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology2);
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology2);
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) gJChronology8);
//        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology8);
//        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.minuteOfHour();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField11, 0);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField13);
//        long long16 = delegatedDateTimeField14.roundHalfFloor((long) 20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-10L) + "'", long16 == (-10L));
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology2);
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology2);
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) gJChronology8);
//        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology8);
//        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.minuteOfHour();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField11, 0);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField13);
//        long long16 = delegatedDateTimeField14.remainder(0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField4 = offsetDateTimeField3.getWrappedField();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = offsetDateTimeField3.getType();
        org.joda.time.ReadablePartial readablePartial6 = null;
        int int7 = offsetDateTimeField3.getMaximumValue(readablePartial6);
        long long9 = offsetDateTimeField3.roundHalfFloor((long) 'a');
        long long12 = offsetDateTimeField3.getDifferenceAsLong((long) (byte) 0, (long) 32);
        long long14 = offsetDateTimeField3.roundHalfEven((long) 817);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1031 + "'", int7 == 1031);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-32L) + "'", long12 == (-32L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 817L + "'", long14 == 817L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = gregorianChronology6.add(readablePeriod8, (long) 100, 1);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(1031, 59, 32, 899, (int) (byte) 1, 75786623, (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 899 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.years();
        org.joda.time.DurationField durationField2 = gJChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology0.year();
        org.joda.time.Instant instant5 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology0.weekyear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
//        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
//        org.joda.time.MonthDay monthDay12 = monthDay8.minusMonths((int) '#');
//        org.joda.time.MonthDay.Property property13 = monthDay8.dayOfMonth();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = new org.joda.time.tz.DateTimeZoneBuilder();
//        boolean boolean15 = property13.equals((java.lang.Object) dateTimeZoneBuilder14);
//        int int16 = property13.getMinimumValueOverall();
//        java.lang.String str17 = property13.toString();
//        org.joda.time.DateTimeField dateTimeField18 = property13.getField();
//        java.lang.String str19 = property13.getAsShortText();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Property[dayOfMonth]" + "'", str17.equals("Property[dayOfMonth]"));
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfMinute(842);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendSecondOfMinute(31);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) gJChronology8);
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withChronology((org.joda.time.Chronology) gJChronology14);
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology14);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology14.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField17, 0);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = gJChronology22.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (int) ' ');
        org.joda.time.DateTimeField dateTimeField26 = offsetDateTimeField25.getWrappedField();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField25.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder21.appendSignedDecimal(dateTimeFieldType27, 19, 0);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField20, dateTimeFieldType27, 4, 0, 838);
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType27, (java.lang.Number) (byte) -1, "GregorianChronology[UTC]");
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder2.appendSignedDecimal(dateTimeFieldType27, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.days();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
//        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
//        boolean boolean12 = dateTime11.isEqualNow();
//        org.joda.time.DateTime dateTime14 = dateTime11.plusDays((int) ' ');
//        org.joda.time.DateTime dateTime16 = dateTime11.minusYears((int) '4');
//        boolean boolean17 = dateTime11.isBeforeNow();
//        int int18 = dateTime11.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 33 + "'", int18 == 33);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) gJChronology8);
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField11, 0);
        long long16 = skipUndoDateTimeField13.getDifferenceAsLong(100L, 1920010L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter17.withChronology((org.joda.time.Chronology) gJChronology18);
        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology18.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter22.withChronology((org.joda.time.Chronology) gJChronology23);
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology23);
        int[] intArray27 = gJChronology18.get((org.joda.time.ReadablePartial) monthDay25, 0L);
        org.joda.time.MonthDay monthDay29 = monthDay25.minusMonths((int) '#');
        org.joda.time.MonthDay.Property property30 = monthDay25.dayOfMonth();
        org.joda.time.MonthDay monthDay32 = property30.addToCopy((int) (byte) 0);
        org.joda.time.DurationField durationField33 = property30.getRangeDurationField();
        org.joda.time.MonthDay monthDay35 = property30.setCopy(1);
        int int36 = skipUndoDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) monthDay35);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-31L) + "'", long16 == (-31L));
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 59 + "'", int36 == 59);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) gregorianChronology0);
        int int2 = monthDay1.size();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay4 = monthDay1.minus(readablePeriod3);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
        org.junit.Assert.assertNotNull(monthDay4);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("--06-15", "org.joda.time.IllegalFieldValueException: Value 100 for hi! must be in the range [0.0,0]", (int) (byte) 10, (int) '4');
        long long6 = fixedDateTimeZone4.nextTransition((long) (short) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.Object obj8 = null;
        boolean boolean9 = buddhistChronology7.equals(obj8);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.hourOfHalfday();
        org.joda.time.Chronology chronology3 = copticChronology1.withUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = copticChronology1.getZone();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
//        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
//        boolean boolean12 = dateTime11.isEqualNow();
//        org.joda.time.DateTime dateTime14 = dateTime11.plusDays((int) ' ');
//        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
//        org.joda.time.DateTime dateTime17 = dateTime14.minusHours(0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter18.withChronology((org.joda.time.Chronology) gJChronology19);
//        org.joda.time.DateTimeZone dateTimeZone21 = gJChronology19.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter23.withChronology((org.joda.time.Chronology) gJChronology24);
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology24);
//        int[] intArray28 = gJChronology19.get((org.joda.time.ReadablePartial) monthDay26, 0L);
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology19);
//        boolean boolean30 = dateTime29.isEqualNow();
//        org.joda.time.DateTime.Property property31 = dateTime29.yearOfCentury();
//        org.joda.time.DateTime dateTime33 = dateTime29.withMillis(100L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter34.withChronology((org.joda.time.Chronology) gJChronology35);
//        org.joda.time.DateTimeZone dateTimeZone37 = gJChronology35.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter39.withChronology((org.joda.time.Chronology) gJChronology40);
//        org.joda.time.MonthDay monthDay42 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology40);
//        int[] intArray44 = gJChronology35.get((org.joda.time.ReadablePartial) monthDay42, 0L);
//        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology35);
//        boolean boolean46 = dateTime45.isEqualNow();
//        org.joda.time.DateTime.Property property47 = dateTime45.yearOfCentury();
//        org.joda.time.DateTime.Property property48 = dateTime45.weekyear();
//        org.joda.time.DateTime dateTime49 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime51 = dateTime49.plusMinutes((int) ' ');
//        org.joda.time.DateTime dateTime53 = dateTime49.plus(100L);
//        long long54 = property48.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime49);
//        org.joda.time.ReadableDuration readableDuration55 = null;
//        org.joda.time.DateTime dateTime57 = dateTime49.withDurationAdded(readableDuration55, (int) (short) 100);
//        org.joda.time.MonthDay monthDay58 = org.joda.time.MonthDay.now();
//        int int59 = monthDay58.size();
//        org.joda.time.MonthDay monthDay60 = org.joda.time.MonthDay.now();
//        int int61 = monthDay60.size();
//        boolean boolean62 = monthDay58.isEqual((org.joda.time.ReadablePartial) monthDay60);
//        org.joda.time.DateTime dateTime63 = dateTime49.withFields((org.joda.time.ReadablePartial) monthDay60);
//        org.joda.time.DateTime dateTime64 = dateTime29.withFields((org.joda.time.ReadablePartial) monthDay60);
//        org.joda.time.Chronology chronology65 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime14, (org.joda.time.ReadableInstant) dateTime29);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTimeFormatter34);
//        org.junit.Assert.assertNotNull(gJChronology35);
//        org.junit.Assert.assertNotNull(dateTimeFormatter36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertNotNull(dateTimeFormatter39);
//        org.junit.Assert.assertNotNull(gJChronology40);
//        org.junit.Assert.assertNotNull(dateTimeFormatter41);
//        org.junit.Assert.assertNotNull(intArray44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(monthDay58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2 + "'", int59 == 2);
//        org.junit.Assert.assertNotNull(monthDay60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2 + "'", int61 == 2);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(chronology65);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.hourOfHalfday();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) copticChronology1);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfMinute(842);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral("0");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfHour((int) '#', 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder2.appendFractionOfMinute(0, 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = delegatedDateTimeField6.getAsShortText((int) (short) 1, locale8);
//        boolean boolean10 = delegatedDateTimeField6.isLenient();
//        org.joda.time.DurationField durationField11 = delegatedDateTimeField6.getLeapDurationField();
//        long long14 = delegatedDateTimeField6.addWrapField(1920010L, (int) (byte) 100);
//        java.lang.Class<?> wildcardClass15 = delegatedDateTimeField6.getClass();
//        long long17 = delegatedDateTimeField6.roundHalfFloor((long) 1263);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNull(durationField11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3155761920010L + "'", long14 == 3155761920010L);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-10L) + "'", long17 == (-10L));
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfMinute(842);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral("0");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.Object obj1 = null;
        boolean boolean2 = iSOChronology0.equals(obj1);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.clockhourOfHalfday();
        org.joda.time.DurationField durationField3 = copticChronology1.days();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Property[weekyear]", "(\"org.joda.time.JodaTimePermission\" \"1\")", 10, (int) (short) 1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withChronology((org.joda.time.Chronology) gJChronology10);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology10);
        org.joda.time.DateTimeField dateTimeField13 = gJChronology10.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField13, 0);
        org.joda.time.DurationField durationField16 = skipUndoDateTimeField15.getDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField15, (int) (short) -1);
        org.joda.time.DateTimeField dateTimeField19 = gJChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField20 = gJChronology0.secondOfDay();
        org.joda.time.DurationField durationField21 = gJChronology0.eras();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes((int) ' ');
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.plus(readableDuration5);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) gJChronology8);
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField11, 0);
        int int14 = skipUndoDateTimeField13.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withChronology((org.joda.time.Chronology) gJChronology10);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology10);
        org.joda.time.DateTimeField dateTimeField13 = gJChronology10.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField13, 0);
        org.joda.time.DurationField durationField16 = skipUndoDateTimeField15.getDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField15, (int) (short) -1);
        boolean boolean19 = skipUndoDateTimeField18.isLenient();
        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.parse("49");
        int[] intArray23 = null;
        try {
            int[] intArray25 = skipUndoDateTimeField18.add((org.joda.time.ReadablePartial) monthDay21, (int) (byte) 10, intArray23, 160);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(monthDay21);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) ' ');
        org.joda.time.DateTime dateTime4 = dateTime0.plus(100L);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.withChronology(chronology5);
        org.joda.time.DateTime dateTime8 = dateTime4.minusDays(32);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withChronology((org.joda.time.Chronology) gJChronology10);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology10);
        org.joda.time.DateTimeField dateTimeField13 = gJChronology10.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField13, 0);
        org.joda.time.DurationField durationField16 = skipUndoDateTimeField15.getDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField15, (int) (short) -1);
        org.joda.time.DateTimeField dateTimeField19 = gJChronology0.clockhourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter20.withChronology((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField23 = gJChronology21.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology21.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24, dateTimeFieldType25);
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField24);
        org.joda.time.DurationField durationField28 = gJChronology0.years();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(durationField28);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField4 = offsetDateTimeField3.getWrappedField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withChronology((org.joda.time.Chronology) gJChronology7);
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology7);
        org.joda.time.DateTimeField dateTimeField10 = gJChronology7.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter12.withChronology((org.joda.time.Chronology) gJChronology13);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
        org.joda.time.DateTimeField dateTimeField16 = gJChronology13.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology7, dateTimeField16, 0);
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipUndoDateTimeField18.getAsText((long) (byte) 1, locale20);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter22.withChronology((org.joda.time.Chronology) gJChronology23);
        org.joda.time.DateTimeZone dateTimeZone25 = gJChronology23.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) gJChronology28);
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology28);
        int[] intArray32 = gJChronology23.get((org.joda.time.ReadablePartial) monthDay30, 0L);
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology23);
        org.joda.time.MonthDay monthDay34 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology23);
        java.util.Locale locale36 = null;
        java.lang.String str37 = skipUndoDateTimeField18.getAsText((org.joda.time.ReadablePartial) monthDay34, (int) (byte) 1, locale36);
        int int38 = offsetDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) monthDay34);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.MonthDay monthDay40 = monthDay34.minus(readablePeriod39);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0" + "'", str21.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1" + "'", str37.equals("1"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 32 + "'", int38 == 32);
        org.junit.Assert.assertNotNull(monthDay40);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
//        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
//        boolean boolean12 = dateTime11.isEqualNow();
//        org.joda.time.DateTime.Property property13 = dateTime11.yearOfCentury();
//        boolean boolean14 = property13.isLeap();
//        org.joda.time.DateTime dateTime15 = property13.withMaximumValue();
//        boolean boolean17 = dateTime15.isAfter((long) (short) -1);
//        org.joda.time.DateTime.Property property18 = dateTime15.weekOfWeekyear();
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = property18.getAsShortText(locale19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "24" + "'", str20.equals("24"));
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField4 = offsetDateTimeField3.getWrappedField();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = offsetDateTimeField3.getType();
        org.joda.time.ReadablePartial readablePartial6 = null;
        int int7 = offsetDateTimeField3.getMaximumValue(readablePartial6);
        long long10 = offsetDateTimeField3.addWrapField((long) 1031, 75796);
        long long12 = offsetDateTimeField3.roundFloor((long) (byte) 0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1031 + "'", int7 == 1031);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1827L + "'", long10 == 1827L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("--06-15", "org.joda.time.IllegalFieldValueException: Value 100 for hi! must be in the range [0.0,0]", (int) (byte) 10, (int) '4');
        boolean boolean7 = jodaTimePermission1.equals((java.lang.Object) "org.joda.time.IllegalFieldValueException: Value 100 for hi! must be in the range [0.0,0]");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTime0.getZone();
        org.joda.time.DateTime dateTime3 = dateTime0.minusDays((int) (short) 1);
        int int4 = dateTime3.getWeekyear();
        org.joda.time.DateTime dateTime5 = dateTime3.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        org.joda.time.DateTime dateTime9 = dateTime6.minusDays((int) (short) 1);
        int int10 = dateTime9.getWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime9.withTimeAtStartOfDay();
        int int12 = dateTime11.getMinuteOfHour();
        int int13 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime11);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gJChronology0.centuries();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now();
//        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
//        long long5 = gJChronology0.set((org.joda.time.ReadablePartial) monthDay2, (-10L));
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-17193600010L) + "'", long5 == (-17193600010L));
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTimeZone dateTimeZone4 = gJChronology2.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withChronology((org.joda.time.Chronology) gJChronology7);
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology7);
        int[] intArray11 = gJChronology2.get((org.joda.time.ReadablePartial) monthDay9, 0L);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
        boolean boolean13 = dateTime12.isEqualNow();
        org.joda.time.DateTime.Property property14 = dateTime12.yearOfCentury();
        org.joda.time.DateTime dateTime16 = dateTime12.withMillis(100L);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("--06-15", "org.joda.time.IllegalFieldValueException: Value 100 for hi! must be in the range [0.0,0]", (int) (byte) 10, (int) '4');
        long long23 = fixedDateTimeZone21.nextTransition((long) (short) 1);
        long long27 = fixedDateTimeZone21.convertLocalToUTC(100L, true, 10L);
        org.joda.time.DateTime dateTime28 = dateTime16.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) '4', (org.joda.time.DateTimeZone) fixedDateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 90L + "'", long27 == 90L);
        org.junit.Assert.assertNotNull(dateTime28);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
//        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
//        org.joda.time.MonthDay monthDay12 = monthDay8.minusMonths((int) '#');
//        org.joda.time.MonthDay.Property property13 = monthDay8.dayOfMonth();
//        org.joda.time.MonthDay monthDay15 = property13.addToCopy((int) (byte) 0);
//        org.joda.time.MonthDay monthDay17 = property13.addWrapFieldToCopy((int) (short) 10);
//        java.lang.String str18 = property13.getAsShortText();
//        java.lang.String str19 = property13.getAsString();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(monthDay15);
//        org.junit.Assert.assertNotNull(monthDay17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("0");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.lang.String str3 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"0\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"0\")"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"0\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"0\")"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 100L, (java.lang.Number) 0.0f, (java.lang.Number) 0L);
        java.lang.String str5 = illegalFieldValueException4.getFieldName();
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("Property[dayOfMonth]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'Property[dayOfMonth]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField6.getAsShortText((int) (short) 1, locale8);
        boolean boolean10 = delegatedDateTimeField6.isLenient();
        org.joda.time.DurationField durationField11 = delegatedDateTimeField6.getLeapDurationField();
        long long14 = delegatedDateTimeField6.addWrapField(1920010L, (int) (byte) 100);
        boolean boolean15 = delegatedDateTimeField6.isSupported();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3155761920010L + "'", long14 == 3155761920010L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.year();
        long long6 = gregorianChronology1.add((long) (byte) 1, (long) (short) 100, (int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withChronology((org.joda.time.Chronology) gJChronology10);
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withChronology((org.joda.time.Chronology) gJChronology15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology15);
        int[] intArray19 = gJChronology10.get((org.joda.time.ReadablePartial) monthDay17, 0L);
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology10);
        boolean boolean21 = dateTime20.isEqualNow();
        org.joda.time.DateTime dateTime23 = dateTime20.plusDays((int) ' ');
        int int24 = dateTimeZone8.getOffset((org.joda.time.ReadableInstant) dateTime23);
        long long27 = dateTimeZone8.adjustOffset((long) (byte) 100, true);
        org.joda.time.Chronology chronology28 = gregorianChronology1.withZone(dateTimeZone8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone29 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        long long31 = cachedDateTimeZone29.convertUTCToLocal((long) 2);
        java.lang.String str33 = cachedDateTimeZone29.getNameKey((long) 1263);
        long long35 = cachedDateTimeZone29.previousTransition((long) 2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone29);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter36.withOffsetParsed();
        boolean boolean38 = dateTimeFormatter36.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10001L + "'", long6 == 10001L);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(cachedDateTimeZone29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2L + "'", long31 == 2L);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "UTC" + "'", str33.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2L + "'", long35 == 2L);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
        org.joda.time.MonthDay monthDay12 = monthDay8.minusMonths((int) '#');
        org.joda.time.MonthDay.Property property13 = monthDay8.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = new org.joda.time.tz.DateTimeZoneBuilder();
        boolean boolean15 = property13.equals((java.lang.Object) dateTimeZoneBuilder14);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder23 = dateTimeZoneBuilder14.addCutover(2, 'a', (-1), (int) 'a', (int) ' ', false, 2);
        java.io.DataOutput dataOutput25 = null;
        try {
            dateTimeZoneBuilder23.writeTo("+00:00:00.010", dataOutput25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder23);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
//        java.util.TimeZone timeZone4 = dateTimeZone3.toTimeZone();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone5.getShortName((long) '4', locale7);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        java.lang.String str11 = dateTimeZone5.getName((long) (short) 0);
//        long long13 = dateTimeZone3.getMillisKeepLocal(dateTimeZone5, (long) (byte) 1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.010" + "'", str8.equals("+00:00:00.010"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.010" + "'", str11.equals("+00:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYearOfCentury(59, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.append(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) ' ');
        org.joda.time.DateTime dateTime4 = dateTime0.plus(100L);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.withChronology(chronology5);
        org.joda.time.DateTime dateTime8 = dateTime4.plusHours(59);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) ' ');
//        org.joda.time.DateTime dateTime4 = dateTime0.plus(100L);
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.withChronology(chronology5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZoneRetainFields(dateTimeZone7);
//        java.lang.Object obj9 = null;
//        boolean boolean10 = dateTime8.equals(obj9);
//        org.joda.time.DateTime.Property property11 = dateTime8.dayOfMonth();
//        int int12 = dateTime8.getMillisOfSecond();
//        org.joda.time.DateTime dateTime14 = dateTime8.plusMinutes((int) (byte) 10);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 656 + "'", int12 == 656);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField4 = offsetDateTimeField3.getWrappedField();
        int int6 = offsetDateTimeField3.getMinimumValue(1920010L);
        java.lang.String str7 = offsetDateTimeField3.toString();
        org.joda.time.DateTimeField dateTimeField8 = offsetDateTimeField3.getWrappedField();
        org.joda.time.DurationField durationField9 = offsetDateTimeField3.getRangeDurationField();
        boolean boolean11 = offsetDateTimeField3.isLeap(9223371985593610001L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str7.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology2);
//        org.joda.time.DateTimeZone dateTimeZone4 = gJChronology2.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withChronology((org.joda.time.Chronology) gJChronology7);
//        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology7);
//        int[] intArray11 = gJChronology2.get((org.joda.time.ReadablePartial) monthDay9, 0L);
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology2);
//        boolean boolean13 = dateTime12.isEqualNow();
//        org.joda.time.DateTime.Property property14 = dateTime12.yearOfCentury();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) gJChronology16);
//        org.joda.time.DateTimeZone dateTimeZone18 = gJChronology16.getZone();
//        org.joda.time.DateTime dateTime19 = dateTime12.toDateTime(dateTimeZone18);
//        java.lang.String str20 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "21:04:37.648+00:00:00.010" + "'", str20.equals("21:04:37.648+00:00:00.010"));
//    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
//        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
//        boolean boolean12 = dateTime11.isEqualNow();
//        org.joda.time.DateTime.Property property13 = dateTime11.yearOfCentury();
//        org.joda.time.DateTime.Property property14 = dateTime11.minuteOfHour();
//        org.joda.time.DateTime dateTime16 = dateTime11.minusMinutes(2019);
//        java.lang.String str17 = dateTime16.toString();
//        org.joda.time.DateTime dateTime19 = dateTime16.withYearOfCentury((int) (short) 100);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019-06-14T11:25:37.750+00:00:00.010" + "'", str17.equals("2019-06-14T11:25:37.750+00:00:00.010"));
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.centuries();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField3 = new org.joda.time.field.DecoratedDurationField(durationField1, durationFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        org.joda.time.DateTimeField dateTimeField4 = offsetDateTimeField3.getWrappedField();
//        long long6 = offsetDateTimeField3.roundHalfFloor(0L);
//        int int8 = offsetDateTimeField3.getMinimumValue((long) 59);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = offsetDateTimeField3.getAsShortText(2L, locale10);
//        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField3.getWrappedField();
//        java.lang.String str14 = offsetDateTimeField3.getAsText((long) (byte) 0);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "44" + "'", str11.equals("44"));
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "42" + "'", str14.equals("42"));
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) ' ');
        org.joda.time.DateTime dateTime4 = dateTime0.plus(100L);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.withChronology(chronology5);
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 100L, (java.lang.Number) 0.0f, (java.lang.Number) 0L);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str6 = illegalFieldValueException4.getFieldName();
        java.lang.String str7 = illegalFieldValueException4.toString();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 100 for hi! must be in the range [0.0,0]" + "'", str7.equals("org.joda.time.IllegalFieldValueException: Value 100 for hi! must be in the range [0.0,0]"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYearOfCentury(59, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral("2019-06-15T14:02:46.976");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder2.appendFractionOfSecond(52, 842);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter13 = dateTimeFormatter12.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter13, dateTimeParser15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendYearOfCentury(59, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder19.appendLiteral("2019-06-15T14:02:46.976");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder19.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder19.appendFractionOfSecond(52, 842);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder19.appendFractionOfHour(0, 59);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter33 = dateTimeFormatter32.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser35 = dateTimeFormatter34.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter33, dateTimeParser35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder37.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter41 = dateTimeFormatter40.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser43 = dateTimeFormatter42.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter41, dateTimeParser43);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder39.appendOptional(dateTimeParser43);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder19.append(dateTimePrinter33, dateTimeParser43);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder11.append(dateTimePrinter13, dateTimeParser43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimePrinter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTimePrinter33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeParser35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(dateTimePrinter41);
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertNotNull(dateTimeParser43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfMinute(842);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral("0");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendFractionOfMinute(24, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("--06-15", "org.joda.time.IllegalFieldValueException: Value 100 for hi! must be in the range [0.0,0]", (int) (byte) 10, (int) '4');
        long long7 = fixedDateTimeZone4.convertLocalToUTC(0L, false);
        int int9 = fixedDateTimeZone4.getOffset((-11L));
        boolean boolean11 = fixedDateTimeZone4.isStandardOffset((long) 10);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean13 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-10L) + "'", long7 == (-10L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) ' ');
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.plus(readableDuration3);
        org.joda.time.DateTime dateTime6 = dateTime0.plusDays(32);
        int int7 = dateTime0.getCenturyOfEra();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gJChronology3);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) gJChronology9);
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology9);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology9.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField12, 0);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 0, (org.joda.time.Chronology) gJChronology3);
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter17.withChronology((org.joda.time.Chronology) gJChronology18);
        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology18.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter22.withChronology((org.joda.time.Chronology) gJChronology23);
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology23);
        int[] intArray27 = gJChronology18.get((org.joda.time.ReadablePartial) monthDay25, 0L);
        org.joda.time.MonthDay monthDay29 = monthDay25.minusMonths((int) '#');
        org.joda.time.MonthDay.Property property30 = monthDay25.dayOfMonth();
        org.joda.time.MonthDay monthDay32 = property30.addToCopy((int) (byte) 0);
        org.joda.time.DurationField durationField33 = property30.getRangeDurationField();
        org.joda.time.MonthDay monthDay35 = property30.setCopy(1);
        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime38 = dateTime36.plusMinutes((int) ' ');
        org.joda.time.DateTime dateTime40 = dateTime36.plus(100L);
        org.joda.time.Chronology chronology41 = null;
        org.joda.time.DateTime dateTime42 = dateTime40.withChronology(chronology41);
        org.joda.time.DateTime dateTime43 = monthDay35.toDateTime((org.joda.time.ReadableInstant) dateTime40);
        org.joda.time.DateTime dateTime45 = dateTime43.minusSeconds(1);
        org.joda.time.Instant instant46 = dateTime43.toInstant();
        org.joda.time.DateTime dateTime47 = monthDay16.toDateTime((org.joda.time.ReadableInstant) instant46);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(instant46);
        org.junit.Assert.assertNotNull(dateTime47);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.year();
//        long long10 = gregorianChronology5.add((long) (byte) 1, (long) (short) 100, (int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withChronology((org.joda.time.Chronology) gJChronology14);
//        org.joda.time.DateTimeZone dateTimeZone16 = gJChronology14.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter18.withChronology((org.joda.time.Chronology) gJChronology19);
//        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology19);
//        int[] intArray23 = gJChronology14.get((org.joda.time.ReadablePartial) monthDay21, 0L);
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology14);
//        boolean boolean25 = dateTime24.isEqualNow();
//        org.joda.time.DateTime dateTime27 = dateTime24.plusDays((int) ' ');
//        int int28 = dateTimeZone12.getOffset((org.joda.time.ReadableInstant) dateTime27);
//        long long31 = dateTimeZone12.adjustOffset((long) (byte) 100, true);
//        org.joda.time.Chronology chronology32 = gregorianChronology5.withZone(dateTimeZone12);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology33 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone12);
//        try {
//            org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((int) (byte) 0, 21, 21, 3, 0, (org.joda.time.Chronology) buddhistChronology33);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 21 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10001L + "'", long10 == 10001L);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(intArray23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 100L + "'", long31 == 100L);
//        org.junit.Assert.assertNotNull(chronology32);
//        org.junit.Assert.assertNotNull(buddhistChronology33);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.hourOfHalfday();
        org.joda.time.Chronology chronology9 = copticChronology7.withUTC();
        boolean boolean10 = gJChronology2.equals((java.lang.Object) copticChronology7);
        try {
            long long15 = copticChronology7.getDateTimeMillis(817, 1264, 132, 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1264 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        org.joda.time.DateTimeField dateTimeField4 = offsetDateTimeField3.getWrappedField();
//        int int6 = offsetDateTimeField3.getMinimumValue(1920010L);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField3.getDurationField();
//        java.lang.String str9 = offsetDateTimeField3.getAsText((long) (-292278993));
//        java.util.Locale locale10 = null;
//        int int11 = offsetDateTimeField3.getMaximumTextLength(locale10);
//        java.lang.String str12 = offsetDateTimeField3.toString();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "49" + "'", str9.equals("49"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str12.equals("DateTimeField[millisOfSecond]"));
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
        java.util.GregorianCalendar gregorianCalendar12 = dateTime11.toGregorianCalendar();
        org.joda.time.Instant instant13 = dateTime11.toInstant();
        org.joda.time.Instant instant15 = instant13.plus((long) 'a');
        org.joda.time.Chronology chronology16 = instant13.getChronology();
        org.joda.time.Chronology chronology17 = instant13.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianCalendar12);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertNotNull(instant15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(chronology17);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = julianChronology0.equals(obj1);
//        java.lang.String str3 = julianChronology0.toString();
//        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology0.getZone();
//        org.joda.time.DurationField durationField6 = julianChronology0.months();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[--06-15]" + "'", str3.equals("JulianChronology[--06-15]"));
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(durationField6);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) ' ');
        boolean boolean3 = dateTime2.isBeforeNow();
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime2.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology3.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) gJChronology8);
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology8);
        int[] intArray12 = gJChronology3.get((org.joda.time.ReadablePartial) monthDay10, 0L);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        boolean boolean14 = dateTime13.isEqualNow();
        org.joda.time.DateTime dateTime16 = dateTime13.plusDays((int) ' ');
        int int17 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime19 = dateTime16.plusMonths(0);
        java.util.Locale locale21 = null;
        java.lang.String str22 = dateTime19.toString("44", locale21);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "44" + "'", str22.equals("44"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology3.year();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField7);
//        java.lang.String str10 = skipDateTimeField8.getAsText((long) (byte) 1);
//        long long13 = skipDateTimeField8.add(0L, 817);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 25782019200000L + "'", long13 == 25782019200000L);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 100, 1);
        org.joda.time.DurationField durationField6 = gregorianChronology0.days();
        java.lang.String str7 = gregorianChronology0.toString();
        try {
            long long12 = gregorianChronology0.getDateTimeMillis(0, 100, (int) (byte) 10, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[UTC]" + "'", str7.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 817, (java.lang.Number) 100.0f, (java.lang.Number) 25782019200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        java.lang.Object obj1 = null;
//        boolean boolean2 = julianChronology0.equals(obj1);
//        java.lang.String str3 = julianChronology0.toString();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.DateTimeFormat.fullTime();
//        boolean boolean5 = julianChronology0.equals((java.lang.Object) dateTimeFormatter4);
//        java.lang.String str6 = julianChronology0.toString();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[--06-15]" + "'", str3.equals("JulianChronology[--06-15]"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "JulianChronology[--06-15]" + "'", str6.equals("JulianChronology[--06-15]"));
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYearOfCentury(59, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTwoDigitWeekyear(100, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendDayOfWeek(899);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfMinute(842);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral("0");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfHour((int) '#', 100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendHourOfDay((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.dayOfMonth();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = delegatedDateTimeField5.getAsShortText((long) (-10), locale7);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(dateTimeZone9);
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.millisOfSecond();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) gJChronology16);
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology16);
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology16.minuteOfHour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter21.withChronology((org.joda.time.Chronology) gJChronology22);
//        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology22);
//        org.joda.time.DateTimeField dateTimeField25 = gJChronology22.minuteOfHour();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField25, 0);
//        org.joda.time.DurationField durationField28 = skipUndoDateTimeField27.getDurationField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology12, (org.joda.time.DateTimeField) skipUndoDateTimeField27, (int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withChronology((org.joda.time.Chronology) gJChronology32);
//        org.joda.time.DateTimeZone dateTimeZone34 = gJChronology32.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatter36.withChronology((org.joda.time.Chronology) gJChronology37);
//        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology37);
//        int[] intArray41 = gJChronology32.get((org.joda.time.ReadablePartial) monthDay39, 0L);
//        org.joda.time.MonthDay monthDay43 = monthDay39.minusMonths((int) '#');
//        org.joda.time.MonthDay.Property property44 = monthDay39.dayOfMonth();
//        org.joda.time.MonthDay monthDay46 = property44.addToCopy((int) (byte) 0);
//        org.joda.time.DurationField durationField47 = property44.getDurationField();
//        org.joda.time.DurationField durationField48 = property44.getDurationField();
//        org.joda.time.MonthDay monthDay49 = property44.getMonthDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology53 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter54 = dateTimeFormatter52.withChronology((org.joda.time.Chronology) gJChronology53);
//        org.joda.time.MonthDay monthDay55 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology53);
//        org.joda.time.DateTimeField dateTimeField56 = gJChronology53.minuteOfHour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter58 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology59 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter60 = dateTimeFormatter58.withChronology((org.joda.time.Chronology) gJChronology59);
//        org.joda.time.MonthDay monthDay61 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology59);
//        org.joda.time.DateTimeField dateTimeField62 = gJChronology59.minuteOfHour();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField64 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology53, dateTimeField62, 0);
//        java.util.Locale locale66 = null;
//        java.lang.String str67 = skipUndoDateTimeField64.getAsText((long) (byte) 1, locale66);
//        org.joda.time.DurationField durationField68 = skipUndoDateTimeField64.getLeapDurationField();
//        java.lang.String str69 = skipUndoDateTimeField64.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology70 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay71 = new org.joda.time.MonthDay((org.joda.time.Chronology) gregorianChronology70);
//        int[] intArray75 = new int[] { (short) 1, (short) 10, (byte) 0 };
//        int int76 = skipUndoDateTimeField64.getMinimumValue((org.joda.time.ReadablePartial) monthDay71, intArray75);
//        int[] intArray78 = skipUndoDateTimeField27.addWrapField((org.joda.time.ReadablePartial) monthDay49, (int) (short) 0, intArray75, 2019);
//        int[] intArray80 = delegatedDateTimeField5.addWrapPartial((org.joda.time.ReadablePartial) monthDay10, 0, intArray78, 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(gJChronology22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(gJChronology32);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(dateTimeFormatter36);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(dateTimeFormatter38);
//        org.junit.Assert.assertNotNull(intArray41);
//        org.junit.Assert.assertNotNull(monthDay43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(monthDay46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(monthDay49);
//        org.junit.Assert.assertNotNull(dateTimeFormatter52);
//        org.junit.Assert.assertNotNull(gJChronology53);
//        org.junit.Assert.assertNotNull(dateTimeFormatter54);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(dateTimeFormatter58);
//        org.junit.Assert.assertNotNull(gJChronology59);
//        org.junit.Assert.assertNotNull(dateTimeFormatter60);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "0" + "'", str67.equals("0"));
//        org.junit.Assert.assertNull(durationField68);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str69.equals("DateTimeField[minuteOfHour]"));
//        org.junit.Assert.assertNotNull(gregorianChronology70);
//        org.junit.Assert.assertNotNull(intArray75);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
//        org.junit.Assert.assertNotNull(intArray78);
//        org.junit.Assert.assertNotNull(intArray80);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(1264);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
//        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
//        org.joda.time.MonthDay monthDay12 = monthDay8.minusMonths((int) '#');
//        org.joda.time.MonthDay.Property property13 = monthDay8.dayOfMonth();
//        org.joda.time.MonthDay monthDay15 = property13.addToCopy((int) (byte) 0);
//        org.joda.time.DurationField durationField16 = property13.getDurationField();
//        org.joda.time.DurationField durationField17 = property13.getDurationField();
//        java.lang.String str18 = property13.getAsString();
//        org.joda.time.MonthDay monthDay20 = property13.addWrapFieldToCopy(1263);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(monthDay15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
//        org.junit.Assert.assertNotNull(monthDay20);
//    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
//        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
//        boolean boolean12 = dateTime11.isEqualNow();
//        org.joda.time.DateTime.Property property13 = dateTime11.yearOfCentury();
//        org.joda.time.DateTime.Property property14 = dateTime11.minuteOfHour();
//        org.joda.time.DateTime dateTime16 = dateTime11.minusMinutes(2019);
//        java.lang.String str17 = dateTime16.toString();
//        org.joda.time.DateTime.Property property18 = dateTime16.era();
//        org.joda.time.DateTime.Property property19 = dateTime16.minuteOfHour();
//        org.joda.time.DateTime dateTime21 = dateTime16.withSecondOfMinute((int) (byte) 10);
//        org.joda.time.DateTime dateTime23 = dateTime21.minus((long) 9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019-06-14T11:25:42.502+00:00:00.010" + "'", str17.equals("2019-06-14T11:25:42.502+00:00:00.010"));
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYearOfCentury(59, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral("2019-06-15T14:02:46.976");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder2.appendFractionOfSecond(52, 842);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder2.appendFractionOfHour(0, 59);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendFractionOfDay(1, (int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime4 = dateTime2.plusMinutes((int) ' ');
        org.joda.time.DateTime dateTime6 = dateTime2.plus(100L);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.withChronology(chronology7);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime10 = dateTime6.withZoneRetainFields(dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime6.withMinuteOfHour((int) (byte) 1);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getShortName((long) '4', locale2);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone0);
//        try {
//            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) dateTimeZone0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.FixedDateTimeZone");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.010" + "'", str3.equals("+00:00:00.010"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTime5.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology2, dateTimeZone6);
        org.joda.time.Chronology chronology8 = zonedChronology7.withUTC();
        org.joda.time.DurationField durationField9 = zonedChronology7.seconds();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter10.withChronology((org.joda.time.Chronology) gJChronology11);
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology11.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = delegatedDateTimeField16.getAsShortText((int) (short) 1, locale18);
        boolean boolean20 = delegatedDateTimeField16.isLenient();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) zonedChronology7, (org.joda.time.DateTimeField) delegatedDateTimeField16);
        java.lang.String str22 = delegatedDateTimeField16.toString();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "DateTimeField[yearOfEra]" + "'", str22.equals("DateTimeField[yearOfEra]"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTime5.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology2, dateTimeZone6);
        try {
            long long13 = zonedChronology7.getDateTimeMillis(9223371985593610001L, (int) ' ', 10, (-292278993), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        int int1 = monthDay0.size();
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now();
        int int3 = monthDay2.size();
        boolean boolean4 = monthDay0.isEqual((org.joda.time.ReadablePartial) monthDay2);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay0.withPeriodAdded(readablePeriod5, (int) (byte) -1);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(monthDay7);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
        org.joda.time.MonthDay monthDay12 = monthDay8.minusMonths((int) '#');
        org.joda.time.MonthDay.Property property13 = monthDay8.dayOfMonth();
        org.joda.time.MonthDay monthDay15 = property13.addToCopy((int) (byte) 0);
        org.joda.time.DurationField durationField16 = property13.getRangeDurationField();
        org.joda.time.MonthDay monthDay18 = property13.setCopy(1);
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime21 = dateTime19.plusMinutes((int) ' ');
        org.joda.time.DateTime dateTime23 = dateTime19.plus(100L);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = dateTime23.withChronology(chronology24);
        org.joda.time.DateTime dateTime26 = monthDay18.toDateTime((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime dateTime28 = dateTime23.plus((long) (byte) 1);
        int int29 = dateTime23.getYearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 19 + "'", int29 == 19);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("BuddhistChronology[--06-15]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"BuddhistChronology[--06-15]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("0", "Pacific Standard Time");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType3);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
        boolean boolean12 = dateTime11.isEqualNow();
        org.joda.time.DateTime.Property property13 = dateTime11.yearOfCentury();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withChronology((org.joda.time.Chronology) gJChronology15);
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology15.getZone();
        org.joda.time.DateTime dateTime18 = dateTime11.toDateTime(dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime11.withYearOfCentury((int) '4');
        org.joda.time.DateTime dateTime22 = dateTime20.withMonthOfYear((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
        boolean boolean12 = dateTime11.isEqualNow();
        org.joda.time.DateTime dateTime14 = dateTime11.plusDays((int) ' ');
        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
        org.joda.time.DateTime dateTime17 = dateTime14.minusHours(0);
        org.joda.time.DateTime.Property property18 = dateTime14.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("--06-15", "org.joda.time.IllegalFieldValueException: Value 100 for hi! must be in the range [0.0,0]", (int) (byte) 10, (int) '4');
        long long6 = fixedDateTimeZone4.nextTransition((long) (short) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str9 = fixedDateTimeZone4.getShortName((long) (short) 0);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.010" + "'", str9.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(julianChronology10);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYearOfCentury(59, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral("2019-06-15T14:02:46.976");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        boolean boolean9 = dateTimeFormatterBuilder2.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        org.joda.time.DateTimeField dateTimeField4 = offsetDateTimeField3.getWrappedField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType5 = offsetDateTimeField3.getType();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = offsetDateTimeField3.getAsShortText((long) 1, locale7);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = offsetDateTimeField3.getAsText(90L, locale10);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeFieldType5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "43" + "'", str8.equals("43"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "132" + "'", str11.equals("132"));
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeField dateTimeField8 = gJChronology5.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter10.withChronology((org.joda.time.Chronology) gJChronology11);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology11);
        org.joda.time.DateTimeField dateTimeField14 = gJChronology11.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField14, 0);
        org.joda.time.DurationField durationField17 = skipUndoDateTimeField16.getDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField16, (int) (short) -1);
        org.joda.time.DateTimeField dateTimeField20 = gJChronology1.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField21 = gJChronology1.secondOfDay();
        try {
            org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) "+00:00:00.010", (org.joda.time.Chronology) gJChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00:00.010\" is malformed at \":00:00.010\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.eras();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean3 = jodaTimePermission1.equals((java.lang.Object) true);
        java.lang.String str4 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str4.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("--06-15", "org.joda.time.IllegalFieldValueException: Value 100 for hi! must be in the range [0.0,0]", (int) (byte) 10, (int) '4');
        long long6 = fixedDateTimeZone4.nextTransition((long) (short) 1);
        long long9 = fixedDateTimeZone4.adjustOffset((long) 'a', false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology8.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter12.withChronology((org.joda.time.Chronology) gJChronology13);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
        int[] intArray17 = gJChronology8.get((org.joda.time.ReadablePartial) monthDay15, 0L);
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology8);
        java.util.GregorianCalendar gregorianCalendar19 = dateTime18.toGregorianCalendar();
        org.joda.time.Instant instant20 = dateTime18.toInstant();
        org.joda.time.Instant instant22 = instant20.withMillis((-11L));
        boolean boolean23 = iSOChronology6.equals((java.lang.Object) instant20);
        try {
            org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((java.lang.Object) dateTimeField5, (org.joda.time.Chronology) iSOChronology6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gregorianCalendar19);
        org.junit.Assert.assertNotNull(instant20);
        org.junit.Assert.assertNotNull(instant22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYearOfCentury(59, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTwoDigitWeekyear(100, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendCenturyOfEra((int) (byte) 1, (int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology2);
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology2);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone6 = dateTime5.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology2, dateTimeZone6);
//        org.joda.time.Chronology chronology8 = zonedChronology7.withUTC();
//        org.joda.time.DurationField durationField9 = zonedChronology7.seconds();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter10.withChronology((org.joda.time.Chronology) gJChronology11);
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology11.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = delegatedDateTimeField16.getAsShortText((int) (short) 1, locale18);
//        boolean boolean20 = delegatedDateTimeField16.isLenient();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) zonedChronology7, (org.joda.time.DateTimeField) delegatedDateTimeField16);
//        org.joda.time.Chronology chronology22 = zonedChronology7.withUTC();
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Chronology chronology24 = gregorianChronology23.withUTC();
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.clockhourOfDay();
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.year();
//        long long31 = gregorianChronology26.add((long) (byte) 1, (long) (short) 100, (int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter34.withChronology((org.joda.time.Chronology) gJChronology35);
//        org.joda.time.DateTimeZone dateTimeZone37 = gJChronology35.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter39.withChronology((org.joda.time.Chronology) gJChronology40);
//        org.joda.time.MonthDay monthDay42 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology40);
//        int[] intArray44 = gJChronology35.get((org.joda.time.ReadablePartial) monthDay42, 0L);
//        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology35);
//        boolean boolean46 = dateTime45.isEqualNow();
//        org.joda.time.DateTime dateTime48 = dateTime45.plusDays((int) ' ');
//        int int49 = dateTimeZone33.getOffset((org.joda.time.ReadableInstant) dateTime48);
//        long long52 = dateTimeZone33.adjustOffset((long) (byte) 100, true);
//        org.joda.time.Chronology chronology53 = gregorianChronology26.withZone(dateTimeZone33);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone54 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone33);
//        org.joda.time.Chronology chronology55 = gregorianChronology23.withZone(dateTimeZone33);
//        org.joda.time.Chronology chronology56 = zonedChronology7.withZone(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(zonedChronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1" + "'", str19.equals("1"));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10001L + "'", long31 == 10001L);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTimeFormatter34);
//        org.junit.Assert.assertNotNull(gJChronology35);
//        org.junit.Assert.assertNotNull(dateTimeFormatter36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertNotNull(dateTimeFormatter39);
//        org.junit.Assert.assertNotNull(gJChronology40);
//        org.junit.Assert.assertNotNull(dateTimeFormatter41);
//        org.junit.Assert.assertNotNull(intArray44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 100L + "'", long52 == 100L);
//        org.junit.Assert.assertNotNull(chronology53);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone54);
//        org.junit.Assert.assertNotNull(chronology55);
//        org.junit.Assert.assertNotNull(chronology56);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 100L, (java.lang.Number) 0.0f, (java.lang.Number) 0L);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(dateTimeFieldType6);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 100, 1);
        try {
            long long13 = gregorianChronology0.getDateTimeMillis(1, 10, 0, 6, 842, (int) (byte) 10, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 842 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology3.year();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField7);
//        java.lang.String str10 = skipDateTimeField8.getAsText((long) (byte) 1);
//        java.lang.String str11 = skipDateTimeField8.getName();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "year" + "'", str11.equals("year"));
//    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getShortName((long) '4', locale2);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
//        org.joda.time.DateTime dateTime9 = dateTime5.plusMinutes(1263);
//        org.joda.time.DateTime.Property property10 = dateTime5.millisOfSecond();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.010" + "'", str3.equals("+00:00:00.010"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
        org.joda.time.MonthDay monthDay12 = monthDay8.minusMonths((int) '#');
        org.joda.time.MonthDay.Property property13 = monthDay8.dayOfMonth();
        org.joda.time.MonthDay monthDay15 = property13.addToCopy((int) (byte) 0);
        org.joda.time.DurationField durationField16 = property13.getRangeDurationField();
        org.joda.time.MonthDay monthDay18 = property13.setCopy(1);
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime21 = dateTime19.plusMinutes((int) ' ');
        org.joda.time.DateTime dateTime23 = dateTime19.plus(100L);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = dateTime23.withChronology(chronology24);
        org.joda.time.DateTime dateTime26 = monthDay18.toDateTime((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime.Property property27 = dateTime23.yearOfEra();
        org.joda.time.DateTime dateTime29 = property27.addToCopy((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology2);
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology2);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
//        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter10.withChronology((org.joda.time.Chronology) gJChronology11);
//        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology11);
//        int[] intArray15 = gJChronology6.get((org.joda.time.ReadablePartial) monthDay13, 0L);
//        org.joda.time.MonthDay monthDay17 = monthDay13.minusMonths((int) '#');
//        long long19 = gJChronology2.set((org.joda.time.ReadablePartial) monthDay17, 0L);
//        try {
//            java.lang.String str21 = monthDay17.toString("UTC");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: U");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertNotNull(monthDay17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2678400000L + "'", long19 == 2678400000L);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYearOfCentury(59, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendYear((int) (byte) 1, (int) 'a');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendTimeZoneName(strMap10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendSecondOfMinute((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.appendTwoDigitWeekyear((int) '#', false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("--06-15", "org.joda.time.IllegalFieldValueException: Value 100 for hi! must be in the range [0.0,0]", (int) (byte) 10, (int) '4');
        long long9 = fixedDateTimeZone6.convertLocalToUTC(0L, false);
        int int11 = fixedDateTimeZone6.getOffset((-11L));
        int int13 = fixedDateTimeZone6.getStandardOffset((long) (-10));
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) monthDay14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-10L) + "'", long9 == (-10L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
        boolean boolean12 = dateTime11.isEqualNow();
        org.joda.time.DateTime.Property property13 = dateTime11.yearOfCentury();
        org.joda.time.DurationField durationField14 = property13.getRangeDurationField();
        org.joda.time.DateTime dateTime15 = property13.roundHalfFloorCopy();
        java.lang.String str16 = property13.getAsText();
        java.util.Locale locale18 = null;
        org.joda.time.DateTime dateTime19 = property13.setCopy("4", locale18);
        org.joda.time.DateTime dateTime21 = property13.setCopy(20);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "19" + "'", str16.equals("19"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
        org.joda.time.MonthDay monthDay12 = monthDay8.minusMonths((int) '#');
        org.joda.time.MonthDay.Property property13 = monthDay8.dayOfMonth();
        org.joda.time.MonthDay monthDay15 = property13.addToCopy((int) (byte) 0);
        org.joda.time.DurationField durationField16 = property13.getDurationField();
        org.joda.time.DurationField durationField17 = property13.getDurationField();
        try {
            org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((java.lang.Object) property13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.MonthDay$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendWeekyear((int) 'a', (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendHourOfHalfday(59);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTimeZoneName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        java.lang.String str4 = offsetDateTimeField3.getName();
        int int5 = offsetDateTimeField3.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "millisOfSecond" + "'", str4.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYearOfCentury(59, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendSecondOfMinute(899);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) ' ');
//        org.joda.time.DateTime dateTime4 = dateTime0.plus(100L);
//        int int5 = dateTime0.getMillisOfSecond();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withChronology((org.joda.time.Chronology) gJChronology7);
//        org.joda.time.DateTimeZone dateTimeZone9 = gJChronology7.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter11.withChronology((org.joda.time.Chronology) gJChronology12);
//        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology12);
//        int[] intArray16 = gJChronology7.get((org.joda.time.ReadablePartial) monthDay14, 0L);
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology7);
//        org.joda.time.Chronology chronology18 = dateTime17.getChronology();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter20.withChronology((org.joda.time.Chronology) gJChronology21);
//        org.joda.time.DateTimeZone dateTimeZone23 = gJChronology21.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter25.withChronology((org.joda.time.Chronology) gJChronology26);
//        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology26);
//        int[] intArray30 = gJChronology21.get((org.joda.time.ReadablePartial) monthDay28, 0L);
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology21);
//        boolean boolean32 = dateTime31.isEqualNow();
//        org.joda.time.DateTime dateTime34 = dateTime31.plusDays((int) ' ');
//        org.joda.time.DateTime dateTime36 = dateTime31.minusYears((int) '4');
//        boolean boolean37 = dateTime31.isBeforeNow();
//        org.joda.time.ReadableDuration readableDuration38 = null;
//        org.joda.time.DateTime dateTime39 = dateTime31.plus(readableDuration38);
//        boolean boolean40 = dateTime17.isBefore((org.joda.time.ReadableInstant) dateTime39);
//        boolean boolean41 = dateTime0.isBefore((org.joda.time.ReadableInstant) dateTime17);
//        int int42 = dateTime17.getYearOfEra();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 272 + "'", int5 == 272);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(intArray16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfMinute(842);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral("0");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMinuteOfHour((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfYear(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendFractionOfSecond(52, (int) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.DateTimeFormat.longTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter13 = dateTimeFormatter12.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray16 = new org.joda.time.format.DateTimeParser[] { dateTimeParser15 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder8.append(dateTimePrinter13, dateTimeParserArray16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimePrinter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeParserArray16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.hourOfHalfday();
        try {
            org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) copticChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.CopticChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYearOfCentury(59, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTwoDigitWeekyear(100, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendSecondOfDay((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder5.appendTwoDigitWeekyear(1031, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis(41, 24, (int) (byte) 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.Instant instant4 = gJChronology1.getGregorianCutover();
        org.joda.time.DurationField durationField5 = gJChronology1.minutes();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) gJChronology8);
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField11, 0);
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipUndoDateTimeField13.getAsText((long) (byte) 1, locale15);
        org.joda.time.DurationField durationField17 = skipUndoDateTimeField13.getLeapDurationField();
        java.lang.String str18 = skipUndoDateTimeField13.toString();
        boolean boolean20 = skipUndoDateTimeField13.isLeap((long) 555);
        int int22 = skipUndoDateTimeField13.getMaximumValue(0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str18.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 59 + "'", int22 == 59);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
//        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
//        boolean boolean12 = dateTime11.isEqualNow();
//        org.joda.time.DateTime.Property property13 = dateTime11.yearOfCentury();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withChronology((org.joda.time.Chronology) gJChronology15);
//        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology15.getZone();
//        org.joda.time.DateTime dateTime18 = dateTime11.toDateTime(dateTimeZone17);
//        try {
//            org.joda.time.DateTime dateTime20 = dateTime18.withYearOfCentury(272);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 272 for yearOfCentury must be in the range [1,100]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.centuries();
        org.joda.time.DurationField durationField2 = gJChronology0.years();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.years();
        org.joda.time.DurationField durationField2 = gJChronology0.years();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) ' ');
//        org.joda.time.DateTime.Property property3 = dateTime0.minuteOfHour();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) ' ');
//        org.joda.time.DateTimeField dateTimeField8 = offsetDateTimeField7.getWrappedField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = offsetDateTimeField7.getType();
//        int int10 = dateTime0.get(dateTimeFieldType9);
//        org.joda.time.DateTime.Property property11 = dateTime0.era();
//        org.joda.time.DateTime dateTime12 = property11.getDateTime();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 888 + "'", int10 == 888);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getShortName((long) '4', locale5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter0.withZone(dateTimeZone3);
//        java.lang.StringBuffer stringBuffer10 = null;
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime13 = dateTime11.plusMinutes((int) ' ');
//        org.joda.time.DateTime dateTime15 = dateTime11.plus(100L);
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime15.withChronology(chronology16);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime19 = dateTime15.withZoneRetainFields(dateTimeZone18);
//        org.joda.time.DateTime dateTime21 = dateTime19.minusWeeks(0);
//        org.joda.time.DateTimeZone dateTimeZone22 = dateTime21.getZone();
//        try {
//            dateTimeFormatter9.printTo(stringBuffer10, (org.joda.time.ReadableInstant) dateTime21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.010" + "'", str6.equals("+00:00:00.010"));
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
        boolean boolean12 = dateTime11.isEqualNow();
        org.joda.time.DateTime dateTime14 = dateTime11.plusDays((int) ' ');
        org.joda.time.DateTime dateTime16 = dateTime11.withSecondOfMinute(1);
        org.joda.time.DateTime dateTime18 = dateTime11.plusSeconds((-292278993));
        org.joda.time.DateTime dateTime20 = dateTime18.withMillisOfSecond(1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        boolean boolean2 = dateTimeFormatter0.isParser();
        int int3 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2000 + "'", int3 == 2000);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("--06-15", "org.joda.time.IllegalFieldValueException: Value 100 for hi! must be in the range [0.0,0]", (int) (byte) 10, (int) '4');
        long long7 = fixedDateTimeZone5.nextTransition((long) (short) 1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
//        long long5 = gregorianChronology0.add((long) (byte) 1, (long) (short) 100, (int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) gJChronology9);
//        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology9.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withChronology((org.joda.time.Chronology) gJChronology14);
//        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology14);
//        int[] intArray18 = gJChronology9.get((org.joda.time.ReadablePartial) monthDay16, 0L);
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology9);
//        boolean boolean20 = dateTime19.isEqualNow();
//        org.joda.time.DateTime dateTime22 = dateTime19.plusDays((int) ' ');
//        int int23 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) dateTime22);
//        long long26 = dateTimeZone7.adjustOffset((long) (byte) 100, true);
//        org.joda.time.Chronology chronology27 = gregorianChronology0.withZone(dateTimeZone7);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone28 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        int int30 = cachedDateTimeZone28.getOffset(14331781090L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10001L + "'", long5 == 10001L);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology2);
//        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology2);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.DateTimeZone dateTimeZone6 = dateTime5.getZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology2, dateTimeZone6);
//        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfMonth();
//        java.lang.String str9 = zonedChronology7.toString();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(zonedChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ZonedChronology[GJChronology[UTC], --06-15]" + "'", str9.equals("ZonedChronology[GJChronology[UTC], --06-15]"));
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) gJChronology8);
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField11, 0);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField13);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) ' ');
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField19.getWrappedField();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder15.appendSignedDecimal(dateTimeFieldType21, 19, 0);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField14, dateTimeFieldType21, 4, 0, 838);
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType21, (java.lang.Number) 10L, "year");
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfMinute(842);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral("0");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendFractionOfHour((int) '#', 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder2.appendFractionOfSecond(2, 3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
//        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
//        boolean boolean12 = dateTime11.isEqualNow();
//        int int13 = dateTime11.getYear();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) dateTime11);
//        org.joda.time.DateTime.Property property15 = dateTime14.centuryOfEra();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertNotNull(property15);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        long long5 = gregorianChronology0.add((long) (byte) 1, (long) (short) 100, (int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) gJChronology9);
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology9.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withChronology((org.joda.time.Chronology) gJChronology14);
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology14);
        int[] intArray18 = gJChronology9.get((org.joda.time.ReadablePartial) monthDay16, 0L);
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology9);
        boolean boolean20 = dateTime19.isEqualNow();
        org.joda.time.DateTime dateTime22 = dateTime19.plusDays((int) ' ');
        int int23 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) dateTime22);
        long long26 = dateTimeZone7.adjustOffset((long) (byte) 100, true);
        org.joda.time.Chronology chronology27 = gregorianChronology0.withZone(dateTimeZone7);
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone33 = new org.joda.time.tz.FixedDateTimeZone("--06-15", "org.joda.time.IllegalFieldValueException: Value 100 for hi! must be in the range [0.0,0]", (int) (byte) 10, (int) '4');
        long long36 = fixedDateTimeZone33.convertLocalToUTC(0L, false);
        int int38 = fixedDateTimeZone33.getOffset((-11L));
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone33);
        org.joda.time.Chronology chronology40 = buddhistChronology28.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone33);
        org.joda.time.DateTimeField dateTimeField41 = buddhistChronology28.dayOfMonth();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10001L + "'", long5 == 10001L);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-10L) + "'", long36 == (-10L));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("BuddhistChronology[--06-15]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"BuddhistChronology[--06-15]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        org.joda.time.DateTimeField dateTimeField4 = offsetDateTimeField3.getWrappedField();
//        int int6 = offsetDateTimeField3.getMinimumValue(1920010L);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField3.getDurationField();
//        java.lang.String str9 = offsetDateTimeField3.getAsText((long) (-292278993));
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter10.withChronology((org.joda.time.Chronology) gJChronology11);
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology11.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
//        int int18 = delegatedDateTimeField16.getMinimumValue(0L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = delegatedDateTimeField16.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField21 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType19, (int) (byte) 10);
//        long long23 = remainderDateTimeField21.remainder((long) 59);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "49" + "'", str9.equals("49"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField4 = offsetDateTimeField3.getWrappedField();
        int int6 = offsetDateTimeField3.getMinimumValue(1920010L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withChronology((org.joda.time.Chronology) gJChronology10);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology10);
        org.joda.time.DateTimeField dateTimeField13 = gJChronology10.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) gJChronology16);
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology16);
        org.joda.time.DateTimeField dateTimeField19 = gJChronology16.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField19, 0);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) 0, (org.joda.time.Chronology) gJChronology10);
        org.joda.time.MonthDay monthDay23 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gJChronology10);
        int[] intArray30 = new int[] { (-292278993), (short) 0, 75786623, (-292269055), (-10), 75796 };
        int int31 = offsetDateTimeField3.getMaximumValue((org.joda.time.ReadablePartial) monthDay23, intArray30);
        boolean boolean32 = offsetDateTimeField3.isSupported();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1031 + "'", int31 == 1031);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology3.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) gJChronology8);
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology8);
        int[] intArray12 = gJChronology3.get((org.joda.time.ReadablePartial) monthDay10, 0L);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        boolean boolean14 = dateTime13.isEqualNow();
        org.joda.time.DateTime dateTime16 = dateTime13.plusDays((int) ' ');
        int int17 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime16);
        long long20 = dateTimeZone1.adjustOffset((long) (byte) 100, true);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) ' ');
        org.joda.time.DateTimeField dateTimeField5 = offsetDateTimeField4.getWrappedField();
        int int7 = offsetDateTimeField4.getMinimumValue(1920010L);
        boolean boolean8 = buddhistChronology0.equals((java.lang.Object) int7);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfMinute(842);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendLiteral("0");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendFractionOfMinute(24, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendSecondOfMinute(842);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder9.appendFraction(dateTimeFieldType12, (int) (byte) 0, 978);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) ' ');
//        org.joda.time.DateTime dateTime4 = dateTime0.plus(100L);
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.withChronology(chronology5);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZoneRetainFields(dateTimeZone7);
//        java.lang.Object obj9 = null;
//        boolean boolean10 = dateTime8.equals(obj9);
//        org.joda.time.DateTime.Property property11 = dateTime8.dayOfMonth();
//        int int12 = dateTime8.getMillisOfSecond();
//        org.joda.time.TimeOfDay timeOfDay13 = dateTime8.toTimeOfDay();
//        java.lang.String str15 = dateTime8.toString("21:04:37.648+00:00:00.010");
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 273 + "'", int12 == 273);
//        org.junit.Assert.assertNotNull(timeOfDay13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "21:04:37.648+00:00:00.010" + "'", str15.equals("21:04:37.648+00:00:00.010"));
//    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
//        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
//        boolean boolean12 = dateTime11.isEqualNow();
//        org.joda.time.DateTime.Property property13 = dateTime11.yearOfCentury();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withChronology((org.joda.time.Chronology) gJChronology15);
//        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology15.getZone();
//        org.joda.time.DateTime dateTime18 = dateTime11.toDateTime(dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime11.withYearOfCentury((int) '4');
//        org.joda.time.DateTime dateTime22 = dateTime11.minus((long) 3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
        boolean boolean12 = dateTime11.isEqualNow();
        org.joda.time.DateTime.Property property13 = dateTime11.yearOfCentury();
        boolean boolean14 = property13.isLeap();
        org.joda.time.DateTime dateTime15 = property13.roundHalfFloorCopy();
        java.util.Locale locale16 = null;
        java.lang.String str17 = property13.getAsShortText(locale16);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology19.hourOfHalfday();
        org.joda.time.Chronology chronology21 = copticChronology19.withUTC();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) copticChronology19);
        int int23 = property13.compareTo((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.DateTime dateTime25 = dateTime22.minus(readablePeriod24);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "19" + "'", str17.equals("19"));
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) ' ');
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfMinute();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime6 = dateTime4.plusMinutes((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime4.plus(100L);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.withChronology(chronology9);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime12 = dateTime8.withZoneRetainFields(dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime12.minusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone15 = dateTime14.getZone();
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime2, (org.joda.time.ReadableInstant) dateTime14);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
        org.joda.time.DurationField durationField11 = gJChronology1.months();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(durationField11);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
//        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
//        boolean boolean12 = dateTime11.isEqualNow();
//        org.joda.time.DateTime.Property property13 = dateTime11.yearOfCentury();
//        int int14 = property13.getMinimumValueOverall();
//        org.joda.time.Interval interval15 = property13.toInterval();
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = property13.getAsShortText(locale16);
//        long long18 = property13.remainder();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(interval15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "19" + "'", str17.equals("19"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 14331887739L + "'", long18 == 14331887739L);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        org.joda.time.DateTimeField dateTimeField4 = offsetDateTimeField3.getWrappedField();
//        int int6 = offsetDateTimeField3.getMinimumValue(1920010L);
//        org.joda.time.DurationField durationField7 = offsetDateTimeField3.getDurationField();
//        java.lang.String str9 = offsetDateTimeField3.getAsText((long) (-292278993));
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter10.withChronology((org.joda.time.Chronology) gJChronology11);
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.yearOfCentury();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology11.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType15);
//        int int18 = delegatedDateTimeField16.getMinimumValue(0L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = delegatedDateTimeField16.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField21 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType19, (int) (byte) 10);
//        int int22 = remainderDateTimeField21.getMinimumValue();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "49" + "'", str9.equals("49"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
//        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
//        boolean boolean12 = dateTime11.isEqualNow();
//        org.joda.time.DateTime.Property property13 = dateTime11.yearOfCentury();
//        org.joda.time.DateTime.Property property14 = dateTime11.minuteOfHour();
//        org.joda.time.DateTime dateTime16 = dateTime11.minusMinutes(2019);
//        java.lang.String str17 = dateTime16.toString();
//        org.joda.time.DateTime.Property property18 = dateTime16.era();
//        int int19 = property18.getLeapAmount();
//        java.util.Locale locale20 = null;
//        int int21 = property18.getMaximumTextLength(locale20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019-06-14T11:25:47.892+00:00:00.010" + "'", str17.equals("2019-06-14T11:25:47.892+00:00:00.010"));
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField4 = offsetDateTimeField3.getWrappedField();
        int int6 = offsetDateTimeField3.getMinimumValue(1920010L);
        org.joda.time.DurationField durationField7 = offsetDateTimeField3.getDurationField();
        org.joda.time.DurationField durationField8 = offsetDateTimeField3.getLeapDurationField();
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField3.getMaximumShortTextLength(locale9);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
        org.joda.time.MonthDay monthDay12 = monthDay8.minusMonths((int) '#');
        org.joda.time.MonthDay.Property property13 = monthDay8.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = new org.joda.time.tz.DateTimeZoneBuilder();
        boolean boolean15 = property13.equals((java.lang.Object) dateTimeZoneBuilder14);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder23 = dateTimeZoneBuilder14.addCutover(2, 'a', (-1), (int) 'a', (int) ' ', false, 2);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder26 = dateTimeZoneBuilder23.setFixedSavings("Property[weekyear]", 32);
        org.joda.time.DateTimeZone dateTimeZone29 = dateTimeZoneBuilder23.toDateTimeZone("2019-06-14T11:25:42.502+00:00:00.010", false);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder23);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
//        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
//        org.joda.time.MonthDay monthDay12 = monthDay8.minusMonths((int) '#');
//        org.joda.time.MonthDay.Property property13 = monthDay8.dayOfMonth();
//        int int14 = property13.getMinimumValueOverall();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) gJChronology16);
//        org.joda.time.DateTimeZone dateTimeZone18 = gJChronology16.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter20.withChronology((org.joda.time.Chronology) gJChronology21);
//        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology21);
//        int[] intArray25 = gJChronology16.get((org.joda.time.ReadablePartial) monthDay23, 0L);
//        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology16);
//        boolean boolean27 = dateTime26.isEqualNow();
//        int int28 = dateTime26.getYear();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((java.lang.Object) dateTime26);
//        int int30 = property13.compareTo((org.joda.time.ReadableInstant) dateTime29);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertNotNull(monthDay12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter20);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNotNull(intArray25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("--06-15", "org.joda.time.IllegalFieldValueException: Value 100 for hi! must be in the range [0.0,0]", (int) (byte) 10, (int) '4');
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int7 = fixedDateTimeZone4.getOffsetFromLocal((long) 100);
        boolean boolean9 = fixedDateTimeZone4.isStandardOffset((long) '4');
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.year();
        long long6 = gregorianChronology1.add((long) (byte) 1, (long) (short) 100, (int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withChronology((org.joda.time.Chronology) gJChronology10);
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withChronology((org.joda.time.Chronology) gJChronology15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology15);
        int[] intArray19 = gJChronology10.get((org.joda.time.ReadablePartial) monthDay17, 0L);
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology10);
        boolean boolean21 = dateTime20.isEqualNow();
        org.joda.time.DateTime dateTime23 = dateTime20.plusDays((int) ' ');
        int int24 = dateTimeZone8.getOffset((org.joda.time.ReadableInstant) dateTime23);
        long long27 = dateTimeZone8.adjustOffset((long) (byte) 100, true);
        org.joda.time.Chronology chronology28 = gregorianChronology1.withZone(dateTimeZone8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone29 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        long long31 = cachedDateTimeZone29.convertUTCToLocal((long) 2);
        java.lang.String str33 = cachedDateTimeZone29.getNameKey((long) 1263);
        long long35 = cachedDateTimeZone29.previousTransition((long) 2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone29);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10001L + "'", long6 == 10001L);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(cachedDateTimeZone29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2L + "'", long31 == 2L);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "UTC" + "'", str33.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2L + "'", long35 == 2L);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.clockhourOfDay();
        try {
            long long10 = gregorianChronology0.getDateTimeMillis(0, 1031, 695, 160, (int) '#', 41, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 160 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTime5.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology2, dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = zonedChronology7.dayOfMonth();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.Chronology) zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gJChronology3);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) gJChronology9);
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology9);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology9.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField12, 0);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 0, (org.joda.time.Chronology) gJChronology3);
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        boolean boolean18 = monthDay16.equals((java.lang.Object) dateTimeZone17);
        int int20 = dateTimeZone17.getOffsetFromLocal((long) 19);
        long long24 = dateTimeZone17.convertLocalToUTC(0L, false, 14331781090L);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
        org.joda.time.MonthDay monthDay12 = monthDay8.minusMonths((int) '#');
        org.joda.time.MonthDay.Property property13 = monthDay8.dayOfMonth();
        org.joda.time.MonthDay monthDay15 = property13.addToCopy((int) (byte) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter18.withChronology((org.joda.time.Chronology) gJChronology19);
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology19);
        org.joda.time.DateTimeField dateTimeField22 = gJChronology19.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter24.withChronology((org.joda.time.Chronology) gJChronology25);
        org.joda.time.MonthDay monthDay27 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology25);
        org.joda.time.DateTimeField dateTimeField28 = gJChronology25.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology19, dateTimeField28, 0);
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) 0, (org.joda.time.Chronology) gJChronology19);
        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gJChronology19);
        int int33 = property13.compareTo((org.joda.time.ReadablePartial) monthDay32);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter34.withChronology((org.joda.time.Chronology) gJChronology35);
        org.joda.time.DateTimeZone dateTimeZone37 = gJChronology35.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter39.withChronology((org.joda.time.Chronology) gJChronology40);
        org.joda.time.MonthDay monthDay42 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology40);
        int[] intArray44 = gJChronology35.get((org.joda.time.ReadablePartial) monthDay42, 0L);
        org.joda.time.ReadablePeriod readablePeriod45 = null;
        org.joda.time.MonthDay monthDay47 = monthDay42.withPeriodAdded(readablePeriod45, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = null;
        boolean boolean49 = monthDay42.isSupported(dateTimeFieldType48);
        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, (int) ' ');
        org.joda.time.DateTimeField dateTimeField54 = offsetDateTimeField53.getWrappedField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter58 = dateTimeFormatter56.withChronology((org.joda.time.Chronology) gJChronology57);
        org.joda.time.MonthDay monthDay59 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology57);
        org.joda.time.DateTimeField dateTimeField60 = gJChronology57.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter62 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology63 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter64 = dateTimeFormatter62.withChronology((org.joda.time.Chronology) gJChronology63);
        org.joda.time.MonthDay monthDay65 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology63);
        org.joda.time.DateTimeField dateTimeField66 = gJChronology63.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField68 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology57, dateTimeField66, 0);
        java.util.Locale locale70 = null;
        java.lang.String str71 = skipUndoDateTimeField68.getAsText((long) (byte) 1, locale70);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter72 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology73 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter74 = dateTimeFormatter72.withChronology((org.joda.time.Chronology) gJChronology73);
        org.joda.time.DateTimeZone dateTimeZone75 = gJChronology73.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter77 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology78 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter79 = dateTimeFormatter77.withChronology((org.joda.time.Chronology) gJChronology78);
        org.joda.time.MonthDay monthDay80 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology78);
        int[] intArray82 = gJChronology73.get((org.joda.time.ReadablePartial) monthDay80, 0L);
        org.joda.time.DateTime dateTime83 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology73);
        org.joda.time.MonthDay monthDay84 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology73);
        java.util.Locale locale86 = null;
        java.lang.String str87 = skipUndoDateTimeField68.getAsText((org.joda.time.ReadablePartial) monthDay84, (int) (byte) 1, locale86);
        int int88 = offsetDateTimeField53.getMinimumValue((org.joda.time.ReadablePartial) monthDay84);
        org.joda.time.DateTimeFieldType dateTimeFieldType90 = monthDay84.getFieldType(0);
        int int91 = monthDay42.get(dateTimeFieldType90);
        org.joda.time.MonthDay.Property property92 = monthDay32.property(dateTimeFieldType90);
        org.joda.time.IllegalFieldValueException illegalFieldValueException96 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType90, (java.lang.Number) (-10L), (java.lang.Number) 9223371985593610001L, (java.lang.Number) 33);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(gJChronology35);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(monthDay47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(gJChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeFormatter56);
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertNotNull(dateTimeFormatter58);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(dateTimeFormatter62);
        org.junit.Assert.assertNotNull(gJChronology63);
        org.junit.Assert.assertNotNull(dateTimeFormatter64);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "0" + "'", str71.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatter72);
        org.junit.Assert.assertNotNull(gJChronology73);
        org.junit.Assert.assertNotNull(dateTimeFormatter74);
        org.junit.Assert.assertNotNull(dateTimeZone75);
        org.junit.Assert.assertNotNull(dateTimeFormatter77);
        org.junit.Assert.assertNotNull(gJChronology78);
        org.junit.Assert.assertNotNull(dateTimeFormatter79);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertNotNull(dateTime83);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "1" + "'", str87.equals("1"));
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 32 + "'", int88 == 32);
        org.junit.Assert.assertNotNull(dateTimeFieldType90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1 + "'", int91 == 1);
        org.junit.Assert.assertNotNull(property92);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
//        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.Chronology chronology12 = dateTime11.getChronology();
//        org.joda.time.DateTime.Property property13 = dateTime11.millisOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withChronology((org.joda.time.Chronology) gJChronology15);
//        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology15.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter19.withChronology((org.joda.time.Chronology) gJChronology20);
//        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology20);
//        int[] intArray24 = gJChronology15.get((org.joda.time.ReadablePartial) monthDay22, 0L);
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology15);
//        boolean boolean26 = dateTime25.isEqualNow();
//        org.joda.time.DateTime dateTime28 = dateTime25.plusDays((int) ' ');
//        org.joda.time.DateTime dateTime30 = dateTime25.minusYears((int) '4');
//        boolean boolean31 = dateTime25.isBeforeNow();
//        org.joda.time.ReadableDuration readableDuration32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime25.plus(readableDuration32);
//        boolean boolean34 = dateTime11.isBefore((org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.DateTime dateTime36 = dateTime33.minusSeconds(0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(gJChronology20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertNotNull(dateTime36);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField4 = offsetDateTimeField3.getWrappedField();
        int int6 = offsetDateTimeField3.getMinimumValue(1920010L);
        java.lang.String str7 = offsetDateTimeField3.toString();
        org.joda.time.DateTimeField dateTimeField8 = offsetDateTimeField3.getWrappedField();
        long long11 = offsetDateTimeField3.add((long) (short) 1, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField3.getType();
        org.joda.time.DurationField durationField13 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField14 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField13);
        java.lang.String str15 = unsupportedDateTimeField14.getName();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = unsupportedDateTimeField14.getType();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str7.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 36L + "'", long11 == 36L);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "millisOfSecond" + "'", str15.equals("millisOfSecond"));
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
//        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
//        boolean boolean12 = dateTime11.isEqualNow();
//        org.joda.time.DateTime dateTime14 = dateTime11.plusDays((int) ' ');
//        org.joda.time.DateTime dateTime16 = dateTime11.minusYears((int) '4');
//        boolean boolean17 = dateTime11.isBeforeNow();
//        org.joda.time.DateTimeZone dateTimeZone18 = dateTime11.getZone();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology3.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) gJChronology8);
//        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology8);
//        int[] intArray12 = gJChronology3.get((org.joda.time.ReadablePartial) monthDay10, 0L);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
//        boolean boolean14 = dateTime13.isEqualNow();
//        org.joda.time.DateTime dateTime16 = dateTime13.plusDays((int) ' ');
//        int int17 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime16);
//        int int18 = dateTime16.getMinuteOfDay();
//        org.joda.time.DateTime dateTime20 = dateTime16.withMillisOfDay(100);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter21.withChronology((org.joda.time.Chronology) gJChronology22);
//        org.joda.time.DateTimeZone dateTimeZone24 = gJChronology22.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter26.withChronology((org.joda.time.Chronology) gJChronology27);
//        org.joda.time.MonthDay monthDay29 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology27);
//        int[] intArray31 = gJChronology22.get((org.joda.time.ReadablePartial) monthDay29, 0L);
//        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology22);
//        boolean boolean33 = dateTime32.isEqualNow();
//        org.joda.time.DateTime.Property property34 = dateTime32.yearOfCentury();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter35.withChronology((org.joda.time.Chronology) gJChronology36);
//        org.joda.time.DateTimeZone dateTimeZone38 = gJChronology36.getZone();
//        org.joda.time.DateTime dateTime39 = dateTime32.toDateTime(dateTimeZone38);
//        org.joda.time.DateTime dateTime41 = dateTime32.plusMillis((-10));
//        org.joda.time.Chronology chronology42 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime20, (org.joda.time.ReadableInstant) dateTime41);
//        org.joda.time.DateTime dateTime44 = dateTime41.minusDays(41);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(intArray12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1264 + "'", int18 == 1264);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(gJChronology22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(gJChronology27);
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNotNull(intArray31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertNotNull(gJChronology36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(chronology42);
//        org.junit.Assert.assertNotNull(dateTime44);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
        org.joda.time.MonthDay monthDay12 = monthDay8.minusMonths((int) '#');
        org.joda.time.MonthDay.Property property13 = monthDay8.dayOfMonth();
        org.joda.time.MonthDay monthDay15 = property13.addToCopy((int) (byte) 0);
        org.joda.time.DurationField durationField16 = property13.getDurationField();
        org.joda.time.DurationField durationField17 = property13.getDurationField();
        org.joda.time.MonthDay monthDay18 = property13.getMonthDay();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.MonthDay monthDay21 = monthDay18.withPeriodAdded(readablePeriod19, 2019);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        try {
            org.joda.time.MonthDay monthDay24 = monthDay18.withField(dateTimeFieldType22, 656);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(monthDay21);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.Object obj1 = null;
        boolean boolean2 = julianChronology0.equals(obj1);
        java.lang.String str3 = julianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology0.year();
        org.joda.time.DurationField durationField7 = julianChronology0.weeks();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("--06-15", "org.joda.time.IllegalFieldValueException: Value 100 for hi! must be in the range [0.0,0]", (int) (byte) 10, (int) '4');
        long long14 = fixedDateTimeZone11.convertLocalToUTC(0L, false);
        int int16 = fixedDateTimeZone11.getOffset((-11L));
        int int18 = fixedDateTimeZone11.getStandardOffset((long) (-10));
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.LocalDateTime localDateTime20 = null;
        boolean boolean21 = fixedDateTimeZone11.isLocalDateTimeGap(localDateTime20);
        try {
            org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(6, 24, 1, (-292278993), 132, 9, 273, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292278993 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-10L) + "'", long14 == (-10L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
        boolean boolean12 = dateTime11.isEqualNow();
        org.joda.time.DateTime.Property property13 = dateTime11.yearOfCentury();
        org.joda.time.DurationField durationField14 = property13.getLeapDurationField();
        boolean boolean15 = property13.isLeap();
        org.joda.time.ReadablePartial readablePartial16 = null;
        try {
            int int17 = property13.compareTo(readablePartial16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
        org.joda.time.MonthDay monthDay12 = monthDay8.minusMonths((int) '#');
        org.joda.time.MonthDay.Property property13 = monthDay8.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = new org.joda.time.tz.DateTimeZoneBuilder();
        boolean boolean15 = property13.equals((java.lang.Object) dateTimeZoneBuilder14);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder23 = dateTimeZoneBuilder14.addCutover(2, 'a', (-1), (int) 'a', (int) ' ', false, 2);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder26 = dateTimeZoneBuilder23.setFixedSavings("", 817);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder29 = dateTimeZoneBuilder23.setFixedSavings("2019-06-14T11:24:16.521+00:00:00.010", (int) 'a');
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder23);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder26);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder29);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withChronology((org.joda.time.Chronology) gJChronology10);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology10);
        org.joda.time.DateTimeField dateTimeField13 = gJChronology10.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField13, 0);
        org.joda.time.DurationField durationField16 = skipUndoDateTimeField15.getDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField15, (int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter19.withChronology((org.joda.time.Chronology) gJChronology20);
        org.joda.time.DateTimeZone dateTimeZone22 = gJChronology20.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter24.withChronology((org.joda.time.Chronology) gJChronology25);
        org.joda.time.MonthDay monthDay27 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology25);
        int[] intArray29 = gJChronology20.get((org.joda.time.ReadablePartial) monthDay27, 0L);
        org.joda.time.MonthDay monthDay31 = monthDay27.minusMonths((int) '#');
        org.joda.time.MonthDay.Property property32 = monthDay27.dayOfMonth();
        org.joda.time.MonthDay monthDay34 = property32.addToCopy((int) (byte) 0);
        org.joda.time.DurationField durationField35 = property32.getDurationField();
        org.joda.time.DurationField durationField36 = property32.getDurationField();
        org.joda.time.MonthDay monthDay37 = property32.getMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = dateTimeFormatter40.withChronology((org.joda.time.Chronology) gJChronology41);
        org.joda.time.MonthDay monthDay43 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology41);
        org.joda.time.DateTimeField dateTimeField44 = gJChronology41.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = dateTimeFormatter46.withChronology((org.joda.time.Chronology) gJChronology47);
        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology47);
        org.joda.time.DateTimeField dateTimeField50 = gJChronology47.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField52 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology41, dateTimeField50, 0);
        java.util.Locale locale54 = null;
        java.lang.String str55 = skipUndoDateTimeField52.getAsText((long) (byte) 1, locale54);
        org.joda.time.DurationField durationField56 = skipUndoDateTimeField52.getLeapDurationField();
        java.lang.String str57 = skipUndoDateTimeField52.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology58 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay59 = new org.joda.time.MonthDay((org.joda.time.Chronology) gregorianChronology58);
        int[] intArray63 = new int[] { (short) 1, (short) 10, (byte) 0 };
        int int64 = skipUndoDateTimeField52.getMinimumValue((org.joda.time.ReadablePartial) monthDay59, intArray63);
        int[] intArray66 = skipUndoDateTimeField15.addWrapField((org.joda.time.ReadablePartial) monthDay37, (int) (short) 0, intArray63, 2019);
        java.util.Locale locale68 = null;
        java.lang.String str69 = skipUndoDateTimeField15.getAsText((long) 656, locale68);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(monthDay37);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeFormatter46);
        org.junit.Assert.assertNotNull(gJChronology47);
        org.junit.Assert.assertNotNull(dateTimeFormatter48);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "0" + "'", str55.equals("0"));
        org.junit.Assert.assertNull(durationField56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str57.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertNotNull(gregorianChronology58);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "0" + "'", str69.equals("0"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(20);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("0", "Pacific Standard Time");
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 100L, (java.lang.Number) 0.0f, (java.lang.Number) 0L);
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException7);
        java.lang.Number number9 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYearOfCentury(59, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTwoDigitWeekyear(100, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendDayOfYear(695);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder5.appendMillisOfDay((-10));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("0", "Pacific Standard Time");
        java.lang.Throwable[] throwableArray3 = illegalFieldValueException2.getSuppressed();
        java.lang.Number number4 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
        org.joda.time.MonthDay monthDay12 = monthDay8.minusMonths((int) '#');
        org.joda.time.MonthDay.Property property13 = monthDay8.dayOfMonth();
        org.joda.time.MonthDay monthDay15 = property13.addToCopy((int) (byte) 0);
        org.joda.time.MonthDay monthDay17 = property13.addWrapFieldToCopy((int) (short) 10);
        java.util.Locale locale18 = null;
        int int19 = property13.getMaximumTextLength(locale18);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter21.withChronology((org.joda.time.Chronology) gJChronology22);
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology22);
        org.joda.time.DateTimeField dateTimeField25 = gJChronology22.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withChronology((org.joda.time.Chronology) gJChronology28);
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology28);
        org.joda.time.DateTimeField dateTimeField31 = gJChronology28.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology22, dateTimeField31, 0);
        boolean boolean34 = property13.equals((java.lang.Object) gJChronology22);
        org.joda.time.DateTimeField dateTimeField35 = gJChronology22.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone36 = gJChronology22.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYearOfCentury(59, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral("2019-06-15T14:02:46.976");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withChronology((org.joda.time.Chronology) gJChronology10);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology10);
        org.joda.time.DateTimeField dateTimeField13 = gJChronology10.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) gJChronology16);
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology16);
        org.joda.time.DateTimeField dateTimeField19 = gJChronology16.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField19, 0);
        java.util.Locale locale23 = null;
        java.lang.String str24 = skipUndoDateTimeField21.getAsText((long) (byte) 1, locale23);
        org.joda.time.DurationField durationField25 = skipUndoDateTimeField21.getLeapDurationField();
        org.joda.time.DurationField durationField26 = skipUndoDateTimeField21.getRangeDurationField();
        java.util.Locale locale27 = null;
        int int28 = skipUndoDateTimeField21.getMaximumTextLength(locale27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = skipUndoDateTimeField21.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder2.appendFixedDecimal(dateTimeFieldType29, 695);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "0" + "'", str24.equals("0"));
        org.junit.Assert.assertNull(durationField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
        org.joda.time.MonthDay monthDay12 = monthDay8.minusMonths((int) '#');
        org.joda.time.MonthDay.Property property13 = monthDay8.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = new org.joda.time.tz.DateTimeZoneBuilder();
        boolean boolean15 = property13.equals((java.lang.Object) dateTimeZoneBuilder14);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder17 = dateTimeZoneBuilder14.setStandardOffset((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder17);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
        boolean boolean12 = dateTime11.isEqualNow();
        org.joda.time.DateTime.Property property13 = dateTime11.yearOfCentury();
        org.joda.time.DateTime dateTime15 = dateTime11.withMillis(100L);
        java.util.Date date16 = dateTime15.toDate();
        int int17 = dateTime15.getYearOfEra();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1970 + "'", int17 == 1970);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gJChronology3);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology3.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField7);
        org.joda.time.DateTimeField dateTimeField9 = gJChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test211");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getShortName((long) '4', locale2);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime5.minus(readableDuration6);
//        org.joda.time.DateTime dateTime9 = dateTime5.withYearOfCentury((int) '#');
//        org.joda.time.DateTime dateTime11 = dateTime5.minusMillis(132);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.plus(readablePeriod12);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendYearOfCentury(59, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTwoDigitWeekyear(100, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendDayOfYear(695);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) ' ');
        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField15.getWrappedField();
        int int18 = offsetDateTimeField15.getMinimumValue(1920010L);
        java.lang.String str19 = offsetDateTimeField15.toString();
        org.joda.time.DateTimeField dateTimeField20 = offsetDateTimeField15.getWrappedField();
        long long23 = offsetDateTimeField15.add((long) (short) 1, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField15.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder5.appendText(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 32 + "'", int18 == 32);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str19.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 36L + "'", long23 == 36L);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("--06-15", "org.joda.time.IllegalFieldValueException: Value 100 for hi! must be in the range [0.0,0]", (int) (byte) 10, (int) '4');
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        int int13 = fixedDateTimeZone10.getOffsetFromLocal((long) 100);
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(842, 1031, (int) (byte) -1, 0, 899, (int) 'a', (org.joda.time.DateTimeZone) fixedDateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 899 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField4 = offsetDateTimeField3.getWrappedField();
        int int6 = offsetDateTimeField3.getMinimumValue(1920010L);
        java.lang.String str7 = offsetDateTimeField3.toString();
        org.joda.time.DateTimeField dateTimeField8 = offsetDateTimeField3.getWrappedField();
        long long11 = offsetDateTimeField3.add((long) (short) 1, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField3.getType();
        org.joda.time.DurationField durationField13 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField14 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField13);
        java.lang.String str15 = unsupportedDateTimeField14.getName();
        boolean boolean16 = unsupportedDateTimeField14.isLenient();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str7.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 36L + "'", long11 == 36L);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "millisOfSecond" + "'", str15.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) gJChronology4);
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology4.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withChronology((org.joda.time.Chronology) gJChronology10);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology10);
        org.joda.time.DateTimeField dateTimeField13 = gJChronology10.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField15 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology4, dateTimeField13, 0);
        org.joda.time.DurationField durationField16 = skipUndoDateTimeField15.getDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField15, (int) (short) -1);
        long long20 = skipUndoDateTimeField15.roundCeiling(24L);
        long long23 = skipUndoDateTimeField15.set((long) '4', (int) (short) 10);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 59990L + "'", long20 == 59990L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 600052L + "'", long23 == 600052L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        long long5 = gregorianChronology0.add((long) (byte) 1, (long) (short) 100, (int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) gJChronology9);
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology9.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withChronology((org.joda.time.Chronology) gJChronology14);
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology14);
        int[] intArray18 = gJChronology9.get((org.joda.time.ReadablePartial) monthDay16, 0L);
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology9);
        boolean boolean20 = dateTime19.isEqualNow();
        org.joda.time.DateTime dateTime22 = dateTime19.plusDays((int) ' ');
        int int23 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) dateTime22);
        long long26 = dateTimeZone7.adjustOffset((long) (byte) 100, true);
        org.joda.time.Chronology chronology27 = gregorianChronology0.withZone(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology0.yearOfEra();
        int int31 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10001L + "'", long5 == 10001L);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (byte) 1, dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.junit.Assert.assertNotNull(mutableDateTime3);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.Object obj5 = null;
        boolean boolean6 = julianChronology4.equals(obj5);
        org.joda.time.DateTimeField dateTimeField7 = julianChronology4.halfdayOfDay();
        java.lang.String str8 = julianChronology4.toString();
        java.lang.String str9 = julianChronology4.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "JulianChronology[--06-15]" + "'", str8.equals("JulianChronology[--06-15]"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "JulianChronology[--06-15]" + "'", str9.equals("JulianChronology[--06-15]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology3.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) gJChronology8);
//        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology8);
//        int[] intArray12 = gJChronology3.get((org.joda.time.ReadablePartial) monthDay10, 0L);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
//        boolean boolean14 = dateTime13.isEqualNow();
//        org.joda.time.DateTime dateTime16 = dateTime13.plusDays((int) ' ');
//        int int17 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime16);
//        int int18 = dateTime16.getMinuteOfDay();
//        org.joda.time.DateTime dateTime20 = dateTime16.withMillisOfDay(100);
//        int int21 = dateTime20.getMinuteOfDay();
//        org.joda.time.DateTime dateTime23 = dateTime20.withMillisOfDay(41);
//        org.joda.time.ReadableDuration readableDuration24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime20.plus(readableDuration24);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(intArray12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1264 + "'", int18 == 1264);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology5.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology5.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8, dateTimeFieldType9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField10.getAsShortText((int) (short) 1, locale12);
        boolean boolean14 = delegatedDateTimeField10.isLenient();
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) delegatedDateTimeField10);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField10, dateTimeFieldType16, 32, 2000, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTime0.getZone();
        org.joda.time.DateTime dateTime3 = dateTime0.plusMinutes((-292269055));
        org.joda.time.DateTime dateTime4 = dateTime3.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test225");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.year();
//        long long6 = gregorianChronology1.add((long) (byte) 1, (long) (short) 100, (int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withChronology((org.joda.time.Chronology) gJChronology10);
//        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withChronology((org.joda.time.Chronology) gJChronology15);
//        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology15);
//        int[] intArray19 = gJChronology10.get((org.joda.time.ReadablePartial) monthDay17, 0L);
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology10);
//        boolean boolean21 = dateTime20.isEqualNow();
//        org.joda.time.DateTime dateTime23 = dateTime20.plusDays((int) ' ');
//        int int24 = dateTimeZone8.getOffset((org.joda.time.ReadableInstant) dateTime23);
//        long long27 = dateTimeZone8.adjustOffset((long) (byte) 100, true);
//        org.joda.time.Chronology chronology28 = gregorianChronology1.withZone(dateTimeZone8);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone29 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
//        long long31 = cachedDateTimeZone29.convertUTCToLocal((long) 2);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) 2000, (org.joda.time.DateTimeZone) cachedDateTimeZone29);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10001L + "'", long6 == 10001L);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2L + "'", long31 == 2L);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology1);
        boolean boolean12 = dateTime11.isEqualNow();
        org.joda.time.DateTime.Property property13 = dateTime11.yearOfCentury();
        org.joda.time.DateTime.Property property14 = dateTime11.weekyear();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime17 = dateTime15.plusMinutes((int) ' ');
        org.joda.time.DateTime dateTime19 = dateTime15.plus(100L);
        long long20 = property14.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime15.withDurationAdded(readableDuration21, (int) (short) 100);
        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now();
        int int25 = monthDay24.size();
        org.joda.time.MonthDay monthDay26 = org.joda.time.MonthDay.now();
        int int27 = monthDay26.size();
        boolean boolean28 = monthDay24.isEqual((org.joda.time.ReadablePartial) monthDay26);
        org.joda.time.DateTime dateTime29 = dateTime15.withFields((org.joda.time.ReadablePartial) monthDay26);
        org.joda.time.DateTime.Property property30 = dateTime29.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField4 = offsetDateTimeField3.getWrappedField();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = offsetDateTimeField3.getType();
        org.joda.time.ReadablePartial readablePartial6 = null;
        int int7 = offsetDateTimeField3.getMaximumValue(readablePartial6);
        long long9 = offsetDateTimeField3.roundHalfFloor((long) 'a');
        long long11 = offsetDateTimeField3.roundHalfEven(14331781090L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1031 + "'", int7 == 1031);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 14331781090L + "'", long11 == 14331781090L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.util.Locale locale2 = null;
        java.lang.String str3 = dateTimeZone0.getShortName((long) '4', locale2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone0);
        try {
            org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.010" + "'", str3.equals("+00:00:00.010"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) gJChronology8);
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField11, 0);
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipUndoDateTimeField13.getAsText((long) (byte) 1, locale15);
        org.joda.time.DurationField durationField17 = skipUndoDateTimeField13.getLeapDurationField();
        org.joda.time.DurationField durationField18 = skipUndoDateTimeField13.getRangeDurationField();
        java.util.Locale locale19 = null;
        int int20 = skipUndoDateTimeField13.getMaximumTextLength(locale19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipUndoDateTimeField13.getType();
        int int23 = skipUndoDateTimeField13.get((long) 3);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology6);
        int[] intArray10 = gJChronology1.get((org.joda.time.ReadablePartial) monthDay8, 0L);
        org.joda.time.MonthDay monthDay12 = monthDay8.minusMonths((int) '#');
        org.joda.time.MonthDay.Property property13 = monthDay8.dayOfMonth();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = new org.joda.time.tz.DateTimeZoneBuilder();
        boolean boolean15 = property13.equals((java.lang.Object) dateTimeZoneBuilder14);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder23 = dateTimeZoneBuilder14.addCutover(2, 'a', (-1), (int) 'a', (int) ' ', false, 2);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder26 = dateTimeZoneBuilder23.setFixedSavings("", 817);
        java.io.OutputStream outputStream28 = null;
        try {
            dateTimeZoneBuilder26.writeTo("49", outputStream28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder23);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder26);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test231");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
//        long long5 = gregorianChronology0.add((long) (byte) 1, (long) (short) 100, (int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) gJChronology9);
//        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology9.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.timeParser();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withChronology((org.joda.time.Chronology) gJChronology14);
//        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology14);
//        int[] intArray18 = gJChronology9.get((org.joda.time.ReadablePartial) monthDay16, 0L);
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology9);
//        boolean boolean20 = dateTime19.isEqualNow();
//        org.joda.time.DateTime dateTime22 = dateTime19.plusDays((int) ' ');
//        int int23 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) dateTime22);
//        long long26 = dateTimeZone7.adjustOffset((long) (byte) 100, true);
//        org.joda.time.Chronology chronology27 = gregorianChronology0.withZone(dateTimeZone7);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone28 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        long long30 = cachedDateTimeZone28.nextTransition(90L);
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone28, 817);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 817");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10001L + "'", long5 == 10001L);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 100L + "'", long26 == 100L);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 90L + "'", long30 == 90L);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField4 = offsetDateTimeField3.getWrappedField();
        int int6 = offsetDateTimeField3.getMinimumValue(1920010L);
        java.lang.String str7 = offsetDateTimeField3.toString();
        org.joda.time.DateTimeField dateTimeField8 = offsetDateTimeField3.getWrappedField();
        long long11 = offsetDateTimeField3.add((long) (short) 1, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField3.getType();
        org.joda.time.DurationField durationField13 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField14 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField13);
        try {
            int int16 = unsupportedDateTimeField14.getMaximumValue((long) 817);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str7.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 36L + "'", long11 == 36L);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField14);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        org.joda.time.DateTimeField dateTimeField4 = offsetDateTimeField3.getWrappedField();
        int int6 = offsetDateTimeField3.getMinimumValue(1920010L);
        java.lang.String str7 = offsetDateTimeField3.toString();
        org.joda.time.DateTimeField dateTimeField8 = offsetDateTimeField3.getWrappedField();
        long long11 = offsetDateTimeField3.add((long) (short) 1, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField3.getType();
        org.joda.time.DurationField durationField13 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField14 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField13);
        try {
            long long16 = unsupportedDateTimeField14.remainder((-60526396800002L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str7.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 36L + "'", long11 == 36L);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField14);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.hourOfHalfday();
        org.joda.time.Chronology chronology3 = copticChronology1.withUTC();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(chronology3);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) gJChronology9);
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology9);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology9.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withChronology((org.joda.time.Chronology) gJChronology15);
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology15);
        org.joda.time.DateTimeField dateTimeField18 = gJChronology15.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField18, 0);
        org.joda.time.DurationField durationField21 = skipUndoDateTimeField20.getDurationField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology5, (org.joda.time.DateTimeField) skipUndoDateTimeField20, (int) (short) -1);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology5.clockhourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter25.withChronology((org.joda.time.Chronology) gJChronology26);
        org.joda.time.DateTimeField dateTimeField28 = gJChronology26.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField29 = gJChronology26.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29, dateTimeFieldType30);
        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField29);
        java.lang.String str34 = skipDateTimeField32.getAsText((long) 52);
        java.lang.String str36 = skipDateTimeField32.getAsShortText((long) 24);
        int int38 = skipDateTimeField32.get(41L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField(chronology3, (org.joda.time.DateTimeField) skipDateTimeField32);
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1970" + "'", str34.equals("1970"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1970" + "'", str36.equals("1970"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1970 + "'", int38 == 1970);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology8.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter12.withChronology((org.joda.time.Chronology) gJChronology13);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology13);
        int[] intArray17 = gJChronology8.get((org.joda.time.ReadablePartial) monthDay15, 0L);
        org.joda.time.MonthDay monthDay19 = monthDay15.minusMonths((int) '#');
        org.joda.time.MonthDay.Property property20 = monthDay15.dayOfMonth();
        org.joda.time.MonthDay monthDay22 = property20.addToCopy((int) (byte) 0);
        org.joda.time.DurationField durationField23 = property20.getRangeDurationField();
        org.joda.time.MonthDay monthDay25 = property20.setCopy(1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter26.withChronology((org.joda.time.Chronology) gJChronology27);
        org.joda.time.DateTimeZone dateTimeZone29 = gJChronology27.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withChronology((org.joda.time.Chronology) gJChronology32);
        org.joda.time.MonthDay monthDay34 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology32);
        int[] intArray36 = gJChronology27.get((org.joda.time.ReadablePartial) monthDay34, 0L);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology27);
        org.joda.time.MonthDay monthDay38 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology27);
        boolean boolean39 = monthDay25.isAfter((org.joda.time.ReadablePartial) monthDay38);
        int int40 = delegatedDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) monthDay25);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfMinute(842);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfWeek((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTwoDigitYear(272);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, dateTimeFieldType5);
        java.util.Locale locale8 = null;
        java.lang.String str9 = delegatedDateTimeField6.getAsShortText((int) (short) 1, locale8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter10.withChronology((org.joda.time.Chronology) gJChronology11);
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology11.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withChronology((org.joda.time.Chronology) gJChronology16);
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology16);
        int[] intArray20 = gJChronology11.get((org.joda.time.ReadablePartial) monthDay18, 0L);
        org.joda.time.MonthDay monthDay22 = monthDay18.minusMonths((int) '#');
        org.joda.time.MonthDay.Property property23 = monthDay18.dayOfMonth();
        org.joda.time.MonthDay monthDay25 = property23.addToCopy((int) (byte) 0);
        org.joda.time.MonthDay monthDay27 = property23.addWrapFieldToCopy((int) (short) 10);
        java.util.Locale locale29 = null;
        java.lang.String str30 = delegatedDateTimeField6.getAsText((org.joda.time.ReadablePartial) monthDay27, 2019, locale29);
        int int32 = delegatedDateTimeField6.get((long) 59);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1970 + "'", int32 == 1970);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withDefaultYear((int) (short) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withChronology((org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter10.withChronology((org.joda.time.Chronology) gJChronology11);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology11);
        int[] intArray15 = gJChronology6.get((org.joda.time.ReadablePartial) monthDay13, 0L);
        org.joda.time.MonthDay monthDay17 = monthDay13.minusMonths((int) '#');
        org.joda.time.MonthDay.Property property18 = monthDay13.dayOfMonth();
        org.joda.time.MonthDay monthDay20 = property18.addToCopy((int) (byte) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter23.withChronology((org.joda.time.Chronology) gJChronology24);
        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology24);
        org.joda.time.DateTimeField dateTimeField27 = gJChronology24.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter29.withChronology((org.joda.time.Chronology) gJChronology30);
        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology30);
        org.joda.time.DateTimeField dateTimeField33 = gJChronology30.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology24, dateTimeField33, 0);
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) 0, (org.joda.time.Chronology) gJChronology24);
        org.joda.time.MonthDay monthDay37 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gJChronology24);
        int int38 = property18.compareTo((org.joda.time.ReadablePartial) monthDay37);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter39.withChronology((org.joda.time.Chronology) gJChronology40);
        org.joda.time.DateTimeZone dateTimeZone42 = gJChronology40.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter44.withChronology((org.joda.time.Chronology) gJChronology45);
        org.joda.time.MonthDay monthDay47 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology45);
        int[] intArray49 = gJChronology40.get((org.joda.time.ReadablePartial) monthDay47, 0L);
        org.joda.time.ReadablePeriod readablePeriod50 = null;
        org.joda.time.MonthDay monthDay52 = monthDay47.withPeriodAdded(readablePeriod50, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = null;
        boolean boolean54 = monthDay47.isSupported(dateTimeFieldType53);
        org.joda.time.chrono.GJChronology gJChronology55 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField56 = gJChronology55.millisOfSecond();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, (int) ' ');
        org.joda.time.DateTimeField dateTimeField59 = offsetDateTimeField58.getWrappedField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter61 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology62 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter63 = dateTimeFormatter61.withChronology((org.joda.time.Chronology) gJChronology62);
        org.joda.time.MonthDay monthDay64 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology62);
        org.joda.time.DateTimeField dateTimeField65 = gJChronology62.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter67 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology68 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter69 = dateTimeFormatter67.withChronology((org.joda.time.Chronology) gJChronology68);
        org.joda.time.MonthDay monthDay70 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology68);
        org.joda.time.DateTimeField dateTimeField71 = gJChronology68.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField73 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology62, dateTimeField71, 0);
        java.util.Locale locale75 = null;
        java.lang.String str76 = skipUndoDateTimeField73.getAsText((long) (byte) 1, locale75);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter77 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology78 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter79 = dateTimeFormatter77.withChronology((org.joda.time.Chronology) gJChronology78);
        org.joda.time.DateTimeZone dateTimeZone80 = gJChronology78.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter82 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.GJChronology gJChronology83 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter84 = dateTimeFormatter82.withChronology((org.joda.time.Chronology) gJChronology83);
        org.joda.time.MonthDay monthDay85 = new org.joda.time.MonthDay((long) (byte) 10, (org.joda.time.Chronology) gJChronology83);
        int[] intArray87 = gJChronology78.get((org.joda.time.ReadablePartial) monthDay85, 0L);
        org.joda.time.DateTime dateTime88 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology78);
        org.joda.time.MonthDay monthDay89 = new org.joda.time.MonthDay((org.joda.time.Chronology) gJChronology78);
        java.util.Locale locale91 = null;
        java.lang.String str92 = skipUndoDateTimeField73.getAsText((org.joda.time.ReadablePartial) monthDay89, (int) (byte) 1, locale91);
        int int93 = offsetDateTimeField58.getMinimumValue((org.joda.time.ReadablePartial) monthDay89);
        org.joda.time.DateTimeFieldType dateTimeFieldType95 = monthDay89.getFieldType(0);
        int int96 = monthDay47.get(dateTimeFieldType95);
        org.joda.time.MonthDay.Property property97 = monthDay37.property(dateTimeFieldType95);
        java.lang.String str98 = dateTimeFormatter4.print((org.joda.time.ReadablePartial) monthDay37);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(monthDay37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertNotNull(gJChronology45);
        org.junit.Assert.assertNotNull(dateTimeFormatter46);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(monthDay52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(gJChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeFormatter61);
        org.junit.Assert.assertNotNull(gJChronology62);
        org.junit.Assert.assertNotNull(dateTimeFormatter63);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(dateTimeFormatter67);
        org.junit.Assert.assertNotNull(gJChronology68);
        org.junit.Assert.assertNotNull(dateTimeFormatter69);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "0" + "'", str76.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatter77);
        org.junit.Assert.assertNotNull(gJChronology78);
        org.junit.Assert.assertNotNull(dateTimeFormatter79);
        org.junit.Assert.assertNotNull(dateTimeZone80);
        org.junit.Assert.assertNotNull(dateTimeFormatter82);
        org.junit.Assert.assertNotNull(gJChronology83);
        org.junit.Assert.assertNotNull(dateTimeFormatter84);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertNotNull(dateTime88);
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "1" + "'", str92.equals("1"));
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 32 + "'", int93 == 32);
        org.junit.Assert.assertNotNull(dateTimeFieldType95);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 1 + "'", int96 == 1);
        org.junit.Assert.assertNotNull(property97);
        org.junit.Assert.assertTrue("'" + str98 + "' != '" + "��" + "'", str98.equals("��"));
    }
}

