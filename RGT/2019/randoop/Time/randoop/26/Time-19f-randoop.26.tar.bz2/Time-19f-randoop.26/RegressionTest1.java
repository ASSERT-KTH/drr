import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("Property[yearOfEra]", "Pacific Standard Time", 54823, 0);
        boolean boolean9 = fixedDateTimeZone8.isFixed();
        int int11 = fixedDateTimeZone8.getOffset(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone8);
        try {
            long long18 = zonedChronology12.getDateTimeMillis((long) 4, 2, 135, (int) (byte) 0, 1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 135 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 54823 + "'", int11 == 54823);
        org.junit.Assert.assertNotNull(zonedChronology12);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withLocale(locale3);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeFormatter4.getZone();
        try {
            org.joda.time.DateTime dateTime7 = dateTimeFormatter4.parseDateTime("GregorianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[America/Los_...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNull(dateTimeZone5);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendSecondOfMinute(35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendPattern("1968");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendTimeZoneName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.plusMillis(135);
        org.joda.time.Chronology chronology5 = dateTime1.getChronology();
        org.joda.time.DateTime dateTime7 = dateTime1.withHourOfDay(10);
        org.joda.time.DateTime.Property property8 = dateTime7.centuryOfEra();
        java.lang.String str9 = property8.getAsString();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "19" + "'", str9.equals("19"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder0.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.withEra((int) (byte) 0);
        try {
            org.joda.time.DateTime dateTime12 = dateTime10.withMinuteOfHour(86399999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399999 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        int int5 = dateTime3.getSecondOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 57610 + "'", int5 == 57610);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        java.lang.String str9 = offsetDateTimeField4.getName();
        int int10 = offsetDateTimeField4.getMaximumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale12 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter11.withLocale(locale12);
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withLocale(locale14);
        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter15.getParser();
        org.joda.time.LocalTime localTime18 = dateTimeFormatter15.parseLocalTime("T160000.052-0800");
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localTime18, locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfEra' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "yearOfEra" + "'", str9.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292278992 + "'", int10 == 292278992);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeParser16);
        org.junit.Assert.assertNotNull(localTime18);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(57600002);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-57600002) + "'", int1 == (-57600002));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        java.lang.String str8 = offsetDateTimeField4.getName();
        long long10 = offsetDateTimeField4.roundHalfFloor((long) (byte) -1);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField4.getMaximumTextLength(locale11);
        int int14 = offsetDateTimeField4.getLeapAmount((long) 'a');
        java.lang.String str16 = offsetDateTimeField4.getAsShortText((long) 57600002);
        java.util.Locale locale19 = null;
        try {
            long long20 = offsetDateTimeField4.set((long) (-28378000), "GregorianChronology[UTC]", locale19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[UTC]\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField3 = gregorianChronology2.minutes();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (byte) -1);
        long long9 = offsetDateTimeField6.add((long) 135, (long) 100);
        java.lang.String str10 = offsetDateTimeField6.getName();
        long long12 = offsetDateTimeField6.roundHalfFloor((long) (byte) -1);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField6.getMaximumTextLength(locale13);
        boolean boolean15 = offsetDateTimeField6.isLenient();
        boolean boolean17 = offsetDateTimeField6.isLeap((long) 70);
        org.joda.time.DurationField durationField18 = offsetDateTimeField6.getDurationField();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField19 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3155760000135L + "'", long9 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "yearOfEra" + "'", str10.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 9 + "'", int14 == 9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(durationField18);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        try {
            org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.set(0L, 10);
        int int9 = offsetDateTimeField4.getLeapAmount((long) 86399999);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61820064000000L) + "'", long7 == (-61820064000000L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime5 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime9 = dateTime7.minusDays((int) (short) -1);
        int int10 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfEra();
        int int16 = dateTime12.compareTo((org.joda.time.ReadableInstant) dateTime14);
        int int17 = dateTime14.getDayOfMonth();
        boolean boolean18 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime14);
        boolean boolean19 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime21 = dateTime5.minusWeeks(0);
        try {
            org.joda.time.DateTime dateTime23 = dateTime5.withDayOfMonth(292278992);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278992 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600002 + "'", int4 == 57600002);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600002 + "'", int10 == 57600002);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendSecondOfMinute(35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendFractionOfDay(2, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendFractionOfSecond(0, 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.io.Writer writer1 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        java.lang.String str5 = property4.getAsShortText();
        int int6 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime7 = property4.withMaximumValue();
        org.joda.time.DateTime dateTime9 = dateTime7.minus((long) 1);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMonths(0);
        org.joda.time.DateTime dateTime13 = dateTime11.minusYears(292278993);
        int int14 = dateTime11.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property19 = dateTime18.yearOfEra();
        int int20 = dateTime16.compareTo((org.joda.time.ReadableInstant) dateTime18);
        java.lang.String str21 = dateTime16.toString();
        org.joda.time.DateTime dateTime23 = dateTime16.withYearOfEra(135);
        org.joda.time.DateTime dateTime25 = dateTime16.minusYears((int) (byte) 10);
        org.joda.time.DateTime dateTime27 = dateTime25.withYear(9);
        org.joda.time.DateTime dateTime29 = dateTime25.plusDays((int) (short) 100);
        boolean boolean30 = dateTime11.isBefore((org.joda.time.ReadableInstant) dateTime29);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292278993 + "'", int6 == 292278993);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str21.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("America/Los_Angeles", "");
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        boolean boolean10 = dateTime1.isAfter((long) 8);
        org.joda.time.DateTime.Property property11 = dateTime1.millisOfDay();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendFractionOfSecond(31, 135);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFixedSignedDecimal(dateTimeFieldType3, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        int int4 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime5 = property2.withMaximumValue();
        java.util.Locale locale6 = null;
        java.lang.String str7 = property2.getAsShortText(locale6);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 292278993 + "'", int4 == 292278993);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969" + "'", str7.equals("1969"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        long long10 = offsetDateTimeField4.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime15 = dateTime13.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate16 = dateTime15.toLocalDate();
        java.lang.String str17 = dateTimeFormatter11.print((org.joda.time.ReadablePartial) localDate16);
        int[] intArray24 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray26 = offsetDateTimeField4.set((org.joda.time.ReadablePartial) localDate16, 0, intArray24, (int) (byte) 100);
        int int27 = offsetDateTimeField4.getOffset();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "T������.000" + "'", str17.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("1969-12-31T16:00:00.100-08:00", 0, 292278992, 8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for 1969-12-31T16:00:00.100-08:00 must be in the range [292278992,8]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        int int4 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime5 = property2.withMaximumValue();
        org.joda.time.DateTime dateTime7 = dateTime5.minus((long) 1);
        org.joda.time.DateTime dateTime9 = dateTime7.plusMonths(0);
        org.joda.time.DateTime dateTime11 = dateTime9.minusYears(292278993);
        int int12 = dateTime9.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property17 = dateTime16.yearOfEra();
        int int18 = dateTime14.compareTo((org.joda.time.ReadableInstant) dateTime16);
        java.lang.String str19 = dateTime14.toString();
        org.joda.time.DateTime dateTime21 = dateTime14.withYearOfEra(135);
        org.joda.time.DateTime dateTime23 = dateTime14.minusYears((int) (byte) 10);
        org.joda.time.DateTime dateTime25 = dateTime23.withYear(9);
        org.joda.time.DateTime dateTime27 = dateTime23.plusDays((int) (short) 100);
        boolean boolean28 = dateTime9.isBefore((org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.DateTime dateTime30 = dateTime9.plusMillis((int) (short) -1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 292278993 + "'", int4 == 292278993);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str19.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTime30);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime.Property property9 = dateTime1.weekyear();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfYear();
        java.util.Date date8 = dateTime1.toDate();
        int int9 = dateTime1.getHourOfDay();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-86398030L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-86398030L) + "'", long2 == (-86398030L));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.plusYears(0);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.DateTime dateTime10 = property8.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear((int) (byte) 100);
        java.lang.String str13 = dateTime12.toString();
        boolean boolean14 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime12.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime17 = dateTime12.plusYears(1870);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0100-01-05T16:00:00.002-07:52:58" + "'", str13.equals("0100-01-05T16:00:00.002-07:52:58"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        java.util.Locale locale4 = null;
        int int5 = property2.getMaximumTextLength(locale4);
        int int6 = property2.getMaximumValueOverall();
        org.joda.time.Interval interval7 = property2.toInterval();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval7);
        org.joda.time.ReadableInterval readableInterval9 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval7);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292278993 + "'", int6 == 292278993);
        org.junit.Assert.assertNotNull(interval7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(readableInterval9);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime11 = dateTime9.minusDays((int) (short) -1);
        int int12 = dateTime9.getMillisOfDay();
        org.joda.time.DateTime dateTime13 = dateTime9.withTimeAtStartOfDay();
        org.joda.time.ReadablePartial readablePartial14 = null;
        org.joda.time.DateTime dateTime15 = dateTime9.withFields(readablePartial14);
        org.joda.time.DateMidnight dateMidnight16 = dateTime9.toDateMidnight();
        int int17 = property7.getDifference((org.joda.time.ReadableInstant) dateTime9);
        try {
            org.joda.time.DateTime dateTime19 = dateTime9.withDayOfYear((-10));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57600002 + "'", int12 == 57600002);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendWeekyear(0, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendTimeZoneId();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendYearOfEra(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Property[yearOfEra]", "Pacific Standard Time", 54823, 0);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.String str8 = property7.getAsShortText();
        int int9 = property7.getMaximumValue();
        org.joda.time.DateTime dateTime10 = property7.withMaximumValue();
        int int11 = property7.get();
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) int11);
        long long14 = fixedDateTimeZone4.nextTransition((long) 70);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean16 = fixedDateTimeZone4.equals((java.lang.Object) iSOChronology15);
        java.util.TimeZone timeZone17 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 292278993 + "'", int9 == 292278993);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 70L + "'", long14 == 70L);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withLocale(locale3);
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter2.withLocale(locale5);
        java.lang.String str8 = dateTimeFormatter6.print((long) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "T160000.000-0800" + "'", str8.equals("T160000.000-0800"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder4.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withLocale(locale7);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withLocale(locale9);
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.append(dateTimeParser11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder4.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withLocale(locale15);
        org.joda.time.format.DateTimePrinter dateTimePrinter17 = dateTimeFormatter16.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser18 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter17, dateTimeParser18);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale21 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter20.withLocale(locale21);
        java.util.Locale locale23 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter22.withLocale(locale23);
        org.joda.time.DateTimeZone dateTimeZone25 = dateTimeFormatter24.getZone();
        org.joda.time.Chronology chronology26 = dateTimeFormatter24.getChronology();
        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter24.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder4.append(dateTimePrinter17, dateTimeParser27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder4.appendText(dateTimeFieldType29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimePrinter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNull(dateTimeZone25);
        org.junit.Assert.assertNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeParser27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendHourOfHalfday((int) (short) 10);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((int) (byte) -1);
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) gregorianChronology7);
        java.util.TimeZone timeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology7, dateTimeZone13);
        org.joda.time.DurationField durationField15 = zonedChronology14.eras();
        try {
            long long20 = zonedChronology14.getDateTimeMillis(69, 1959, 54823, 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1959 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        java.util.GregorianCalendar gregorianCalendar11 = dateTime10.toGregorianCalendar();
        org.joda.time.DateTime dateTime13 = dateTime10.withMinuteOfHour(0);
        int int14 = dateTime10.getYearOfEra();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianCalendar11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1959 + "'", int14 == 1959);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property2.getAsShortText(locale3);
        int int5 = property2.getMaximumValue();
        java.lang.String str6 = property2.getAsString();
        org.joda.time.DateTime dateTime7 = property2.roundCeilingCopy();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.DateTime dateTime10 = dateTime7.withFieldAdded(durationFieldType8, 54825);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969" + "'", str4.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        int int10 = offsetDateTimeField4.getDifference((long) (byte) -1, 0L);
        long long13 = offsetDateTimeField4.add(31536000000L, 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 31536000000L + "'", long13 == 31536000000L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getName((long) 9, locale12);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone8);
//        try {
//            long long22 = zonedChronology14.getDateTimeMillis(0, 86399999, 292278993, (-57600002), (-57600002), (-28378000), 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -57600002 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology14);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        int int4 = property2.getMaximumShortTextLength(locale3);
        java.util.Locale locale5 = null;
        java.lang.String str6 = property2.getAsText(locale5);
        org.joda.time.DateTime dateTime7 = property2.getDateTime();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        int int10 = offsetDateTimeField4.getDifference((long) (byte) -1, 0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField12 = gregorianChronology11.minutes();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) (byte) -1);
        long long18 = offsetDateTimeField15.add((long) 135, (long) 100);
        java.lang.String str19 = offsetDateTimeField15.getName();
        boolean boolean20 = offsetDateTimeField15.isSupported();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField22 = gregorianChronology21.minutes();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (int) (byte) -1);
        int int27 = offsetDateTimeField25.getLeapAmount((long) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField29 = gregorianChronology28.minutes();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, (int) (byte) -1);
        int int34 = offsetDateTimeField32.getLeapAmount((long) 10);
        long long36 = offsetDateTimeField32.roundHalfFloor(0L);
        long long38 = offsetDateTimeField32.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime43 = dateTime41.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate44 = dateTime43.toLocalDate();
        java.lang.String str45 = dateTimeFormatter39.print((org.joda.time.ReadablePartial) localDate44);
        int[] intArray52 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray54 = offsetDateTimeField32.set((org.joda.time.ReadablePartial) localDate44, 0, intArray52, (int) (byte) 100);
        int[] intArray59 = new int[] { (short) -1, (short) 1, 19, '#' };
        int int60 = offsetDateTimeField25.getMaximumValue((org.joda.time.ReadablePartial) localDate44, intArray59);
        boolean boolean61 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate44);
        java.util.Locale locale62 = null;
        java.lang.String str63 = offsetDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) localDate44, locale62);
        java.util.Locale locale65 = null;
        java.lang.String str66 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate44, (int) (byte) 0, locale65);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3155760000135L + "'", long18 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "yearOfEra" + "'", str19.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "T������.000" + "'", str45.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 292278992 + "'", int60 == 292278992);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "1969" + "'", str63.equals("1969"));
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "0" + "'", str66.equals("0"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        int int6 = dateTime3.getEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.plus(readablePeriod7);
        boolean boolean10 = dateTime8.isBefore(10L);
        org.joda.time.DateTime dateTime11 = dateTime8.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime13 = dateTime11.minusHours(0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        java.lang.String str8 = dateTimeFormatter2.print((org.joda.time.ReadablePartial) localDate7);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "T������.000" + "'", str8.equals("T������.000"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.plusMillis(135);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime8 = dateTime6.minusDays((int) (short) -1);
        int int9 = dateTime6.getWeekOfWeekyear();
        int int10 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime6);
        try {
            org.joda.time.DateTime dateTime12 = dateTime6.withEra((-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.withYear(9);
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime12.toMutableDateTime();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) ' ', false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitYear(100, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendMillisOfSecond((-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getName((long) 9, locale12);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone8);
//        org.joda.time.Chronology chronology15 = zonedChronology14.withUTC();
//        org.joda.time.DurationField durationField16 = zonedChronology14.weekyears();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime.Property property21 = dateTime20.yearOfEra();
//        int int22 = dateTime18.compareTo((org.joda.time.ReadableInstant) dateTime20);
//        int int23 = dateTime20.getEra();
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime20.plus(readablePeriod24);
//        boolean boolean26 = zonedChronology14.equals((java.lang.Object) dateTime25);
//        org.joda.time.DateTimeField dateTimeField27 = zonedChronology14.weekyear();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime3.plusDays(0);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime3.toMutableDateTimeISO();
        org.joda.time.Instant instant8 = dateTime3.toInstant();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        int int6 = dateTime3.getDayOfMonth();
        org.joda.time.DateTime dateTime8 = dateTime3.plusDays(135);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.plus(readablePeriod9);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("52", (-57600002), 9, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -57600002 for 52 must be in the range [9,2]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime1.plus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime8.weekOfWeekyear();
        java.lang.String str10 = property9.toString();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[weekOfWeekyear]" + "'", str10.equals("Property[weekOfWeekyear]"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("Property[yearOfEra]", "Pacific Standard Time", 54823, 0);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
        java.lang.String str15 = property14.getAsShortText();
        int int16 = property14.getMaximumValue();
        org.joda.time.DateTime dateTime17 = property14.withMaximumValue();
        int int18 = property14.get();
        boolean boolean19 = fixedDateTimeZone11.equals((java.lang.Object) int18);
        int int21 = fixedDateTimeZone11.getOffset((-1L));
        try {
            org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(1967, 57610, 0, 4, 54823, 57610, 0, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54823 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 292278993 + "'", int16 == 292278993);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1969 + "'", int18 == 1969);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 54823 + "'", int21 == 54823);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.plusMillis(135);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime8 = dateTime6.minusDays((int) (short) -1);
        int int9 = dateTime6.getWeekOfWeekyear();
        int int10 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property11 = dateTime6.weekOfWeekyear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        int int4 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime5 = property2.withMaximumValue();
        org.joda.time.DateTime dateTime7 = dateTime5.minus((long) 1);
        org.joda.time.DateTime dateTime9 = dateTime7.plusMonths(0);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.minus(readableDuration10);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 292278993 + "'", int4 == 292278993);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField14 = gregorianChronology13.minutes();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) (byte) -1);
        int int19 = offsetDateTimeField17.getLeapAmount((long) 10);
        long long21 = offsetDateTimeField17.roundHalfFloor(0L);
        long long23 = offsetDateTimeField17.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime28 = dateTime26.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate29 = dateTime28.toLocalDate();
        java.lang.String str30 = dateTimeFormatter24.print((org.joda.time.ReadablePartial) localDate29);
        int[] intArray37 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray39 = offsetDateTimeField17.set((org.joda.time.ReadablePartial) localDate29, 0, intArray37, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField41 = gregorianChronology40.minutes();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, (int) (byte) -1);
        int int46 = offsetDateTimeField44.getLeapAmount((long) 10);
        long long48 = offsetDateTimeField44.roundHalfFloor(0L);
        long long50 = offsetDateTimeField44.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime55 = dateTime53.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate56 = dateTime55.toLocalDate();
        java.lang.String str57 = dateTimeFormatter51.print((org.joda.time.ReadablePartial) localDate56);
        int[] intArray64 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray66 = offsetDateTimeField44.set((org.joda.time.ReadablePartial) localDate56, 0, intArray64, (int) (byte) 100);
        gregorianChronology9.validate((org.joda.time.ReadablePartial) localDate29, intArray66);
        int[] intArray69 = gregorianChronology3.get((org.joda.time.ReadablePartial) localDate29, (long) 1920);
        org.joda.time.DateTimeField dateTimeField70 = gregorianChronology3.yearOfCentury();
        org.joda.time.DurationField durationField71 = gregorianChronology3.months();
        org.joda.time.DateTimeField dateTimeField72 = gregorianChronology3.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "T������.000" + "'", str30.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter51);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "T������.000" + "'", str57.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(durationField71);
        org.junit.Assert.assertNotNull(dateTimeField72);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime3.plusDays(0);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime3.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        java.lang.String str11 = property10.getAsShortText();
        int int12 = property10.getMaximumValue();
        org.joda.time.DateTime dateTime13 = property10.withMaximumValue();
        org.joda.time.DateTime dateTime15 = dateTime13.minus((long) 1);
        org.joda.time.DateTime dateTime17 = dateTime15.plusMonths(0);
        org.joda.time.DateTime dateTime18 = dateTime15.toDateTime();
        boolean boolean19 = mutableDateTime7.isAfter((org.joda.time.ReadableInstant) dateTime18);
        boolean boolean20 = mutableDateTime7.isEqualNow();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 292278993 + "'", int12 == 292278993);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) ' ', 35344512001820L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35344512001852L + "'", long2 == 35344512001852L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) '4', 9, 12, (int) 'a');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 61 + "'", int4 == 61);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        int int11 = dateTime1.getCenturyOfEra();
        try {
            org.joda.time.DateTime dateTime13 = dateTime1.withSecondOfMinute((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        java.lang.String str8 = offsetDateTimeField4.getName();
        org.joda.time.DurationField durationField9 = offsetDateTimeField4.getDurationField();
        int int10 = offsetDateTimeField4.getOffset();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (int) (short) 1, 1920);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.DurationField durationField4 = iSOChronology0.seconds();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        long long8 = gregorianChronology3.add((long) 'a', (long) (-10), 0);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property11 = dateTime10.yearOfEra();
        java.lang.String str12 = property11.getAsShortText();
        int int13 = property11.getMaximumValue();
        org.joda.time.DateTime dateTime14 = property11.withMaximumValue();
        org.joda.time.DateTime dateTime16 = dateTime14.minus((long) 1);
        org.joda.time.DateTime dateTime18 = dateTime16.plusMonths(0);
        org.joda.time.DateTime dateTime20 = dateTime18.minusYears(292278993);
        boolean boolean21 = gregorianChronology3.equals((java.lang.Object) dateTime18);
        org.joda.time.DateTime.Property property22 = dateTime18.centuryOfEra();
        java.lang.String str23 = property22.toString();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969" + "'", str12.equals("1969"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 292278993 + "'", int13 == 292278993);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Property[centuryOfEra]" + "'", str23.equals("Property[centuryOfEra]"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = property2.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime5 = property2.withMaximumValue();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("Property[yearOfEra]", "Pacific Standard Time", 54823, 0);
        boolean boolean9 = fixedDateTimeZone8.isFixed();
        int int11 = fixedDateTimeZone8.getOffset(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 54823 + "'", int11 == 54823);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField8 = gregorianChronology7.minutes();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        long long12 = gregorianChronology7.add(readablePeriod9, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 100, dateTimeZone15);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone15.getName((long) 9, locale19);
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology7, dateTimeZone15);
//        org.joda.time.Chronology chronology22 = zonedChronology21.withUTC();
//        try {
//            org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(57600002, 0, 35, 10, 10, 57600002, 0, chronology22);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600002 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Pacific Standard Time" + "'", str20.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(chronology22);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 100, dateTimeZone2);
        org.joda.time.LocalDate localDate5 = dateTime4.toLocalDate();
        boolean boolean6 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate5);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        java.lang.String str9 = offsetDateTimeField4.getName();
        int int11 = offsetDateTimeField4.getMinimumValue((long) 19);
        long long13 = offsetDateTimeField4.roundHalfEven((long) 57600002);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField4.getAsShortText(0L, locale15);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "yearOfEra" + "'", str9.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter0.getPrinter();
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.minuteOfDay();
        org.joda.time.DurationField durationField12 = gregorianChronology9.months();
        org.joda.time.DurationField durationField13 = gregorianChronology9.months();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology9);
        java.lang.Appendable appendable15 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
        int int21 = dateTime17.compareTo((org.joda.time.ReadableInstant) dateTime19);
        java.lang.String str22 = dateTime17.toString();
        org.joda.time.DateTime dateTime24 = dateTime17.withYearOfEra(135);
        org.joda.time.DateTime dateTime26 = dateTime17.minusYears((int) (byte) 10);
        int int27 = dateTime17.getCenturyOfEra();
        org.joda.time.DateTime.Property property28 = dateTime17.centuryOfEra();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property31 = dateTime30.yearOfEra();
        java.lang.String str32 = property31.getAsShortText();
        int int33 = property31.getMaximumValue();
        org.joda.time.DateTime dateTime34 = property31.withMaximumValue();
        org.joda.time.DateTime dateTime36 = dateTime34.minus((long) 1);
        org.joda.time.DateTime dateTime38 = dateTime36.plusMonths(0);
        long long39 = property28.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime36);
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology40.era();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.secondOfDay();
        boolean boolean43 = org.joda.time.field.FieldUtils.equals((java.lang.Object) long39, (java.lang.Object) gregorianChronology40);
        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime47 = dateTime45.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime48 = dateTime45.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod49 = null;
        org.joda.time.DateTime dateTime50 = dateTime45.plus(readablePeriod49);
        org.joda.time.TimeOfDay timeOfDay51 = dateTime45.toTimeOfDay();
        long long53 = gregorianChronology40.set((org.joda.time.ReadablePartial) timeOfDay51, (long) (short) 10);
        try {
            dateTimeFormatter14.printTo(appendable15, (org.joda.time.ReadablePartial) timeOfDay51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str22.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 19 + "'", int27 == 19);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1969" + "'", str32.equals("1969"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 292278993 + "'", int33 == 292278993);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-2922770L) + "'", long39 == (-2922770L));
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(timeOfDay51);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 57600002L + "'", long53 == 57600002L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        long long8 = gregorianChronology3.add((long) 'a', (long) (-10), 0);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property11 = dateTime10.yearOfEra();
        java.lang.String str12 = property11.getAsShortText();
        int int13 = property11.getMaximumValue();
        org.joda.time.DateTime dateTime14 = property11.withMaximumValue();
        org.joda.time.DateTime dateTime16 = dateTime14.minus((long) 1);
        org.joda.time.DateTime dateTime18 = dateTime16.plusMonths(0);
        org.joda.time.DateTime dateTime20 = dateTime18.minusYears(292278993);
        boolean boolean21 = gregorianChronology3.equals((java.lang.Object) dateTime18);
        org.joda.time.DurationField durationField22 = gregorianChronology3.centuries();
        try {
            long long26 = gregorianChronology3.add((-62135596799931L), 9223372017129600001L, (-28378000));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The calculation caused an overflow: 9223372017129600001 * -28378000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969" + "'", str12.equals("1969"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 292278993 + "'", int13 == 292278993);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.DateTime dateTime8 = dateTime1.withField(dateTimeFieldType6, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.plusYears(0);
        org.joda.time.DateTime dateTime7 = dateTime5.withSecondOfMinute(9);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        org.joda.time.DateTime dateTime12 = dateTime9.plusMillis(135);
        boolean boolean14 = dateTime9.isBefore((long) (short) -1);
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime5, (org.joda.time.ReadableInstant) dateTime9);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime5 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime9 = dateTime7.minusDays((int) (short) -1);
        int int10 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfEra();
        int int16 = dateTime12.compareTo((org.joda.time.ReadableInstant) dateTime14);
        int int17 = dateTime14.getDayOfMonth();
        boolean boolean18 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime14);
        boolean boolean19 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime21 = dateTime7.withYear((int) '4');
        org.joda.time.DateTime dateTime23 = dateTime7.minusYears(0);
        try {
            java.lang.String str25 = dateTime23.toString("Property[yearOfEra]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600002 + "'", int4 == 57600002);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600002 + "'", int10 == 57600002);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay(365, 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        long long10 = offsetDateTimeField4.add(100L, (int) (short) 0);
        long long12 = offsetDateTimeField4.roundHalfFloor(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.plusYears(0);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.DateTime dateTime10 = property8.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear((int) (byte) 100);
        java.lang.String str13 = dateTime12.toString();
        boolean boolean14 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime12.toMutableDateTimeISO();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("Property[yearOfEra]", "Pacific Standard Time", 54823, 0);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property23 = dateTime22.yearOfEra();
        java.lang.String str24 = property23.getAsShortText();
        int int25 = property23.getMaximumValue();
        org.joda.time.DateTime dateTime26 = property23.withMaximumValue();
        int int27 = property23.get();
        boolean boolean28 = fixedDateTimeZone20.equals((java.lang.Object) int27);
        org.joda.time.DateTime dateTime29 = dateTime12.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        try {
            org.joda.time.DateTime dateTime33 = dateTime29.withDate(0, (-1), (-57600002));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0100-01-05T16:00:00.002-07:52:58" + "'", str13.equals("0100-01-05T16:00:00.002-07:52:58"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969" + "'", str24.equals("1969"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 292278993 + "'", int25 == 292278993);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        java.util.Locale locale6 = null;
        java.lang.String str7 = cachedDateTimeZone4.getShortName((long) (short) -1, locale6);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime11 = dateTime9.plusSeconds((int) (short) 10);
        org.joda.time.DateTime.Property property12 = dateTime9.millisOfDay();
        org.joda.time.DateTime dateTime13 = dateTime9.withEarlierOffsetAtOverlap();
        boolean boolean14 = cachedDateTimeZone4.equals((java.lang.Object) dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00" + "'", str7.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(9, 54825);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 54825");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.Chronology chronology4 = gregorianChronology0.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        java.lang.String str3 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.Interval interval3 = property2.toInterval();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(interval3);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        java.lang.Integer int2 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(int2);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property2.getAsShortText(locale3);
        int int5 = property2.getMaximumValue();
        java.lang.String str6 = property2.getAsString();
        org.joda.time.DateTime dateTime7 = property2.roundCeilingCopy();
        org.joda.time.Interval interval8 = property2.toInterval();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969" + "'", str4.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(interval8);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gregorianChronology1.days();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField3 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        java.lang.String str9 = cachedDateTimeZone7.getNameKey(100L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.Chronology chronology12 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("1969-12-31T16:00:00.002-08:00", 1970, 8, (int) (byte) 10, 'a', (-10), 31, 135, false, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime4 = dateTime2.minusDays((int) (short) -1);
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.DateTime dateTime7 = dateTime4.withZoneRetainFields(dateTimeZone6);
        long long10 = dateTimeZone6.convertLocalToUTC((long) (byte) 0, true);
        org.joda.time.Chronology chronology11 = iSOChronology0.withZone(dateTimeZone6);
        org.joda.time.Chronology chronology12 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800000L + "'", long10 == 28800000L);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = property2.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime6 = dateTime4.withWeekyear((int) (byte) 100);
        org.joda.time.TimeOfDay timeOfDay7 = dateTime6.toTimeOfDay();
        org.joda.time.DateTime dateTime9 = dateTime6.plusWeeks(0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendWeekyear(0, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        long long10 = offsetDateTimeField4.roundHalfFloor(0L);
        long long12 = offsetDateTimeField4.roundCeiling(2649600002L);
        long long15 = offsetDateTimeField4.add(28800000L, (long) 135);
        long long18 = offsetDateTimeField4.addWrapField((long) 1959, 365);
        long long20 = offsetDateTimeField4.remainder((long) '#');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31536000000L + "'", long12 == 31536000000L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 4260240000000L + "'", long15 == 4260240000000L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 11518243201959L + "'", long18 == 11518243201959L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 35L + "'", long20 == 35L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gregorianChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) -1);
        long long8 = offsetDateTimeField5.add((long) 135, (long) 100);
        java.lang.String str9 = offsetDateTimeField5.getName();
        long long11 = offsetDateTimeField5.roundHalfFloor((long) (byte) -1);
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField5.getMaximumTextLength(locale12);
        boolean boolean14 = offsetDateTimeField5.isLenient();
        boolean boolean16 = offsetDateTimeField5.isLeap((long) 70);
        org.joda.time.DurationField durationField17 = offsetDateTimeField5.getDurationField();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155760000135L + "'", long8 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "yearOfEra" + "'", str9.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfEra();
        int int6 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime4);
        java.lang.String str7 = dateTime2.toString();
        org.joda.time.DateTime dateTime9 = dateTime2.withYearOfEra(135);
        org.joda.time.DateTime dateTime11 = dateTime2.minusYears((int) (byte) 10);
        int int12 = dateTime2.getCenturyOfEra();
        org.joda.time.DateTime.Property property13 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfEra();
        java.lang.String str17 = property16.getAsShortText();
        int int18 = property16.getMaximumValue();
        org.joda.time.DateTime dateTime19 = property16.withMaximumValue();
        org.joda.time.DateTime dateTime21 = dateTime19.minus((long) 1);
        org.joda.time.DateTime dateTime23 = dateTime21.plusMonths(0);
        long long24 = property13.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.era();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.secondOfDay();
        boolean boolean28 = org.joda.time.field.FieldUtils.equals((java.lang.Object) long24, (java.lang.Object) gregorianChronology25);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime32 = dateTime30.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime33 = dateTime30.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.DateTime dateTime35 = dateTime30.plus(readablePeriod34);
        org.joda.time.TimeOfDay timeOfDay36 = dateTime30.toTimeOfDay();
        long long38 = gregorianChronology25.set((org.joda.time.ReadablePartial) timeOfDay36, (long) (short) 10);
        org.joda.time.DurationField durationField39 = gregorianChronology25.millis();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField40 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str7.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1969" + "'", str17.equals("1969"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292278993 + "'", int18 == 292278993);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-2922770L) + "'", long24 == (-2922770L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(timeOfDay36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 57600002L + "'", long38 == 57600002L);
        org.junit.Assert.assertNotNull(durationField39);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        java.lang.String str8 = offsetDateTimeField4.getName();
        long long10 = offsetDateTimeField4.roundHalfFloor((long) (byte) -1);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField4.getMaximumTextLength(locale11);
        boolean boolean13 = offsetDateTimeField4.isLenient();
        boolean boolean15 = offsetDateTimeField4.isLeap((long) 10);
        boolean boolean17 = offsetDateTimeField4.isLeap((long) 31);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        boolean boolean2 = dateTimeFormatter0.isParser();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusDays((int) (short) -1);
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.DateTime dateTime9 = dateTime6.withZoneRetainFields(dateTimeZone8);
        long long12 = dateTimeZone8.convertLocalToUTC((long) 100, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone13 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800100L + "'", long12 == 28800100L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone13);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) ' ', false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitYear(100, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        boolean boolean8 = dateTimeFormatterBuilder6.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfEra();
        int int6 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime.Property property7 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime.Property property8 = dateTime2.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime12 = dateTime10.minusDays((int) (short) -1);
        int int13 = dateTime10.getMillisOfDay();
        org.joda.time.DateTime dateTime14 = dateTime10.withTimeAtStartOfDay();
        org.joda.time.ReadablePartial readablePartial15 = null;
        org.joda.time.DateTime dateTime16 = dateTime10.withFields(readablePartial15);
        org.joda.time.DateMidnight dateMidnight17 = dateTime10.toDateMidnight();
        int int18 = property8.getDifference((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime21 = dateTime10.withDurationAdded(readableDuration19, (int) ' ');
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeFormatter0, (java.lang.Object) dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 57600002 + "'", int13 == 57600002);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("Property[yearOfEra]", "Pacific Standard Time", 54823, 0);
        boolean boolean9 = fixedDateTimeZone8.isFixed();
        int int11 = fixedDateTimeZone8.getOffset(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone8);
        try {
            long long20 = zonedChronology12.getDateTimeMillis(0, (int) (byte) 0, 4, (int) (short) 10, 16, 31, 70);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 54823 + "'", int11 == 54823);
        org.junit.Assert.assertNotNull(zonedChronology12);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder1 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTimeZoneBuilder1.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = cachedDateTimeZone5.getUncachedZone();
        int int8 = cachedDateTimeZone5.getStandardOffset((long) (short) 1);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 1, (org.joda.time.DateTimeZone) cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("T151320.765-0700", (java.lang.Number) (-28800000L), (java.lang.Number) 960, (java.lang.Number) (byte) 100);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime11 = dateTime9.minusDays((int) (short) -1);
        int int12 = dateTime9.getMillisOfDay();
        org.joda.time.DateTime dateTime13 = dateTime9.withTimeAtStartOfDay();
        org.joda.time.ReadablePartial readablePartial14 = null;
        org.joda.time.DateTime dateTime15 = dateTime9.withFields(readablePartial14);
        org.joda.time.DateMidnight dateMidnight16 = dateTime9.toDateMidnight();
        int int17 = property7.getDifference((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
        org.joda.time.DateTime dateTime22 = dateTime19.plusMillis(135);
        org.joda.time.Chronology chronology23 = dateTime19.getChronology();
        org.joda.time.DateTime dateTime25 = dateTime19.withHourOfDay(10);
        int int26 = property7.compareTo((org.joda.time.ReadableInstant) dateTime19);
        java.util.Locale locale27 = null;
        int int28 = property7.getMaximumShortTextLength(locale27);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57600002 + "'", int12 == 57600002);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2 + "'", int28 == 2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        java.lang.String str9 = cachedDateTimeZone7.getNameKey(100L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DurationField durationField12 = gregorianChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        java.lang.String str4 = property2.toString();
        org.joda.time.DateTime dateTime5 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime6 = property2.roundHalfCeilingCopy();
        java.lang.String str7 = property2.getAsText();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[yearOfEra]" + "'", str4.equals("Property[yearOfEra]"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969" + "'", str7.equals("1969"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        java.lang.String str4 = property2.toString();
        org.joda.time.DateTime dateTime6 = property2.addWrapFieldToCopy((int) (byte) 1);
        org.joda.time.DateTime dateTime7 = property2.roundFloorCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[yearOfEra]" + "'", str4.equals("Property[yearOfEra]"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis(56792, 19, (-10), 70, 1970, 4, 135);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 12, 97L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 109L + "'", long2 == 109L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendSecondOfMinute(35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendFractionOfDay(2, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendHourOfDay((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder11.appendWeekOfWeekyear(292278993);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) ' ', false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitYear(100, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendYear(10, 1870);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatterBuilder10.toFormatter();
        java.lang.Appendable appendable12 = null;
        try {
            dateTimeFormatter11.printTo(appendable12, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.plusMillis(135);
        org.joda.time.Chronology chronology5 = dateTime1.getChronology();
        org.joda.time.DateTime dateTime7 = dateTime1.withHourOfDay(10);
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((-57600002));
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder4.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withLocale(locale7);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withLocale(locale9);
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.append(dateTimeParser11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder4.appendMillisOfDay(9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfEra();
        int int7 = dateTime3.compareTo((org.joda.time.ReadableInstant) dateTime5);
        java.lang.String str8 = dateTime3.toString();
        org.joda.time.DateTime dateTime10 = dateTime3.withYearOfEra(135);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.LocalDate localDate13 = dateTimeFormatter11.parseLocalDate("T151324.051-0700");
        org.joda.time.DateTime dateTime14 = dateTime3.withFields((org.joda.time.ReadablePartial) localDate13);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDate13);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str8.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.plusYears(0);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.DateTime dateTime10 = property8.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear((int) (byte) 100);
        java.lang.String str13 = dateTime12.toString();
        boolean boolean14 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime12.toMutableDateTimeISO();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("Property[yearOfEra]", "Pacific Standard Time", 54823, 0);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property23 = dateTime22.yearOfEra();
        java.lang.String str24 = property23.getAsShortText();
        int int25 = property23.getMaximumValue();
        org.joda.time.DateTime dateTime26 = property23.withMaximumValue();
        int int27 = property23.get();
        boolean boolean28 = fixedDateTimeZone20.equals((java.lang.Object) int27);
        org.joda.time.DateTime dateTime29 = dateTime12.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.DateTime dateTime31 = dateTime29.withCenturyOfEra(12);
        org.joda.time.DateTime.Property property32 = dateTime31.monthOfYear();
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.DateTime dateTime35 = dateTime31.withPeriodAdded(readablePeriod33, (int) ' ');
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0100-01-05T16:00:00.002-07:52:58" + "'", str13.equals("0100-01-05T16:00:00.002-07:52:58"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969" + "'", str24.equals("1969"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 292278993 + "'", int25 == 292278993);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTime35);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField4 = gregorianChronology0.days();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.set(0L, 10);
        java.lang.String str9 = offsetDateTimeField4.getAsShortText((long) 19);
        long long12 = offsetDateTimeField4.getDifferenceAsLong(31535999999L, (-28800000L));
        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField4.getWrappedField();
        java.lang.String str14 = offsetDateTimeField4.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61820064000000L) + "'", long7 == (-61820064000000L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[yearOfEra]" + "'", str14.equals("DateTimeField[yearOfEra]"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-62166787200000L), 109L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62166787200109L) + "'", long2 == (-62166787200109L));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withLocale(locale3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter4.withDefaultYear((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        int int9 = offsetDateTimeField4.get((long) 135);
        boolean boolean10 = offsetDateTimeField4.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("AD");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"AD\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfYear(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendYear(54825, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendSecondOfDay(54825);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        int int11 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property12 = dateTime1.centuryOfEra();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfEra();
        java.lang.String str16 = property15.getAsShortText();
        int int17 = property15.getMaximumValue();
        org.joda.time.DateTime dateTime18 = property15.withMaximumValue();
        org.joda.time.DateTime dateTime20 = dateTime18.minus((long) 1);
        org.joda.time.DateTime dateTime22 = dateTime20.plusMonths(0);
        long long23 = property12.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        try {
            int int25 = dateTime20.get(dateTimeFieldType24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 292278993 + "'", int17 == 292278993);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-2922770L) + "'", long23 == (-2922770L));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) ' ', false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitYear(100, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendYear(35, 70);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        java.lang.String str9 = cachedDateTimeZone7.getNameKey(100L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        long long15 = cachedDateTimeZone7.convertLocalToUTC((-62166787200000L), true, (-28800000L));
        int int17 = cachedDateTimeZone7.getOffset(35L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62166787200000L) + "'", long15 == (-62166787200000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withLocale(locale3);
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter2.withLocale(locale5);
        java.util.Locale locale7 = dateTimeFormatter2.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNull(locale7);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField4 = gregorianChronology0.halfdays();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 10.0f, "1969-12-31T16:00:00.100-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = property2.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime6 = dateTime4.withWeekyear((int) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime6.minusHours(2);
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        boolean boolean7 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology6.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        java.lang.String str6 = cachedDateTimeZone4.getNameKey(100L);
        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone4.getUncachedZone();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.halfdayOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "T151320.765-0700");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.String str5 = illegalFieldValueException2.toString();
        java.lang.String str6 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Number number7 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNull(dateTimeFieldType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"T151320.765-0700\" for hi! is not supported" + "'", str5.equals("org.joda.time.IllegalFieldValueException: Value \"T151320.765-0700\" for hi! is not supported"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "T151320.765-0700" + "'", str6.equals("T151320.765-0700"));
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime3.plusDays(0);
        int int7 = dateTime6.getSecondOfMinute();
        org.joda.time.DateTime dateTime9 = dateTime6.minusMonths(86399999);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime5 = dateTime1.withTimeAtStartOfDay();
        int int6 = dateTime5.getYear();
        org.joda.time.DateTime.Property property7 = dateTime5.weekyear();
        int int8 = property7.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600002 + "'", int4 == 57600002);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-292275054) + "'", int8 == (-292275054));
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime8 = dateTime6.plusSeconds((int) (short) 10);
//        org.joda.time.DateTime.Property property9 = dateTime6.millisOfDay();
//        org.joda.time.DateTime dateTime11 = property9.addToCopy((int) ' ');
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField13 = gregorianChronology12.minutes();
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        long long17 = gregorianChronology12.add(readablePeriod14, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) 100, dateTimeZone20);
//        java.util.Locale locale24 = null;
//        java.lang.String str25 = dateTimeZone20.getName((long) 9, locale24);
//        org.joda.time.chrono.ZonedChronology zonedChronology26 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology12, dateTimeZone20);
//        org.joda.time.Chronology chronology27 = zonedChronology26.withUTC();
//        org.joda.time.DurationField durationField28 = zonedChronology26.weekyears();
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder30 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone33 = dateTimeZoneBuilder30.toDateTimeZone("T151321.363-0700", false);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone34 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone33);
//        boolean boolean36 = cachedDateTimeZone34.equals((java.lang.Object) 57600002);
//        org.joda.time.Chronology chronology37 = iSOChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone34);
//        org.joda.time.Chronology chronology38 = zonedChronology26.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone34);
//        org.joda.time.MutableDateTime mutableDateTime39 = dateTime11.toMutableDateTime(chronology38);
//        try {
//            org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(0, 56792, 135, (-28378000), 1967, chronology38);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28378000 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Pacific Standard Time" + "'", str25.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology26);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone34);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(chronology37);
//        org.junit.Assert.assertNotNull(chronology38);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.DurationField durationField3 = gregorianChronology0.eras();
        try {
            long long6 = durationField3.subtract((-62145878399635L), 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        int int5 = dateTime1.getYearOfEra();
        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime();
        int int7 = dateTime1.getDayOfYear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 365 + "'", int7 == 365);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.clockhourOfHalfday();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField6, 0, 4, 35);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for clockhourOfHalfday must be in the range [4,35]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime1.plus(readableDuration7);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime1.toMutableDateTime(chronology9);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime13 = dateTime1.withDurationAdded(readableDuration11, (int) ' ');
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        java.lang.String str9 = cachedDateTimeZone7.getNameKey(100L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DurationField durationField12 = gregorianChronology0.eras();
        try {
            long long15 = durationField12.subtract((-315619199998L), (long) (-57600002));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfYear(292278993);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendYear(0, (int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readablePeriod5);
        org.joda.time.TimeOfDay timeOfDay7 = dateTime1.toTimeOfDay();
        org.joda.time.DateTime.Property property8 = dateTime1.centuryOfEra();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("T151321.363-0700", "1", 292278993, (int) 'a');
        org.joda.time.DateTime dateTime14 = dateTime1.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.DateTime.Property property15 = dateTime14.monthOfYear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfDay(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendFractionOfHour((int) (byte) 10, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendDayOfMonth(35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount(10L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(69);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder2.setFixedSavings("org.joda.time.IllegalFieldValueException: Value \"T151320.765-0700\" for hi! is not supported", 10);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder2.addCutover((int) (short) 100, '4', (int) '4', (int) (byte) 1, 0, false, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 292278993);
        int int4 = offsetDateTimeField3.getMinimumValue();
        long long6 = offsetDateTimeField3.roundHalfFloor((long) 61);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 292278993 + "'", int4 == 292278993);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.plusMillis(135);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime8 = dateTime6.minusDays((int) (short) -1);
        int int9 = dateTime6.getWeekOfWeekyear();
        int int10 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime12 = dateTime1.withMillis((long) 8);
        boolean boolean13 = dateTime1.isEqualNow();
        boolean boolean15 = dateTime1.isAfter((long) 292278992);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        int int6 = dateTime3.getEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.plus(readablePeriod7);
        boolean boolean10 = dateTime8.isBefore(10L);
        org.joda.time.DateTime dateTime11 = dateTime8.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime15 = dateTime13.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime17 = dateTime13.plusMinutes(1920);
        boolean boolean18 = dateTime8.isAfter((org.joda.time.ReadableInstant) dateTime17);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getName((long) 9, locale12);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.hourOfHalfday();
//        org.joda.time.DurationField durationField16 = gregorianChronology0.weekyears();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(durationField16);
//    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
//        java.util.Locale locale1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
//        java.util.Locale locale3 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withLocale(locale3);
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        java.lang.String str6 = dateTimeFormatter4.print(readableInstant5);
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeFormatter4.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter4.withZoneUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withDefaultYear(279);
//        try {
//            org.joda.time.LocalDate localDate12 = dateTimeFormatter8.parseLocalDate("1969");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969\"");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "T151424.760-0700" + "'", str6.equals("T151424.760-0700"));
//        org.junit.Assert.assertNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMillisOfSecond(31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendClockhourOfHalfday((int) 'a');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap12 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendTimeZoneName(strMap12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withLocale(locale15);
        org.joda.time.format.DateTimePrinter dateTimePrinter17 = dateTimeFormatter16.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser18 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter17, dateTimeParser18);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale21 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter20.withLocale(locale21);
        java.util.Locale locale23 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter22.withLocale(locale23);
        org.joda.time.DateTimeZone dateTimeZone25 = dateTimeFormatter24.getZone();
        org.joda.time.Chronology chronology26 = dateTimeFormatter24.getChronology();
        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter24.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder28.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatterBuilder32.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale35 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter34.withLocale(locale35);
        java.util.Locale locale37 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatter36.withLocale(locale37);
        org.joda.time.format.DateTimeParser dateTimeParser39 = dateTimeFormatter38.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder32.append(dateTimeParser39);
        org.joda.time.format.DateTimeParser[] dateTimeParserArray41 = new org.joda.time.format.DateTimeParser[] { dateTimeParser27, dateTimeParser39 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder11.append(dateTimePrinter17, dateTimeParserArray41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder4.append(dateTimePrinter17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimePrinter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNull(dateTimeZone25);
        org.junit.Assert.assertNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeParser27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertNotNull(dateTimeParser39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeParserArray41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property2.getAsShortText(locale3);
        int int5 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime6 = property2.roundCeilingCopy();
        org.joda.time.DurationField durationField7 = property2.getDurationField();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969" + "'", str4.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Property[yearOfEra]", "Pacific Standard Time", 54823, 0);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        int int7 = fixedDateTimeZone4.getStandardOffset(0L);
        int int9 = fixedDateTimeZone4.getStandardOffset(0L);
        boolean boolean10 = fixedDateTimeZone4.isFixed();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gregorianChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfEra();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeZoneBuilder4.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        java.lang.String str10 = cachedDateTimeZone8.getNameKey(100L);
        org.joda.time.DateTimeZone dateTimeZone11 = cachedDateTimeZone8.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, (org.joda.time.DateTimeZone) cachedDateTimeZone8);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((-62145878399635L), (org.joda.time.Chronology) zonedChronology12);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(zonedChronology12);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.era();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.secondOfDay();
        int int6 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0L, (org.joda.time.Chronology) gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property2.getAsShortText(locale3);
        int int5 = property2.getMaximumValue();
        java.lang.String str6 = property2.getAsString();
        org.joda.time.DateTime dateTime7 = property2.roundCeilingCopy();
        try {
            org.joda.time.DateTime dateTime9 = property2.setCopy("��:��");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"��:��\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969" + "'", str4.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        java.lang.String str8 = offsetDateTimeField4.getName();
        boolean boolean9 = offsetDateTimeField4.isSupported();
        int int11 = offsetDateTimeField4.getLeapAmount(9223372017129600001L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 365);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatterBuilder2.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter3.withPivotYear(10);
        java.lang.Appendable appendable6 = null;
        try {
            dateTimeFormatter3.printTo(appendable6, (-86398030L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendSecondOfMinute(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMillisOfDay(279);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.minuteOfDay();
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = gregorianChronology14.minutes();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) (byte) -1);
        int int20 = offsetDateTimeField18.getLeapAmount((long) 10);
        long long22 = offsetDateTimeField18.roundHalfFloor(0L);
        long long24 = offsetDateTimeField18.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime29 = dateTime27.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate30 = dateTime29.toLocalDate();
        java.lang.String str31 = dateTimeFormatter25.print((org.joda.time.ReadablePartial) localDate30);
        int[] intArray38 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray40 = offsetDateTimeField18.set((org.joda.time.ReadablePartial) localDate30, 0, intArray38, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField42 = gregorianChronology41.minutes();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology41.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, (int) (byte) -1);
        int int47 = offsetDateTimeField45.getLeapAmount((long) 10);
        long long49 = offsetDateTimeField45.roundHalfFloor(0L);
        long long51 = offsetDateTimeField45.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime56 = dateTime54.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate57 = dateTime56.toLocalDate();
        java.lang.String str58 = dateTimeFormatter52.print((org.joda.time.ReadablePartial) localDate57);
        int[] intArray65 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray67 = offsetDateTimeField45.set((org.joda.time.ReadablePartial) localDate57, 0, intArray65, (int) (byte) 100);
        gregorianChronology10.validate((org.joda.time.ReadablePartial) localDate30, intArray67);
        int[] intArray70 = gregorianChronology4.get((org.joda.time.ReadablePartial) localDate30, (long) 1920);
        org.joda.time.DateTimeField dateTimeField71 = gregorianChronology4.minuteOfHour();
        org.joda.time.DurationField durationField72 = gregorianChronology4.minutes();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField73 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField72);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "T������.000" + "'", str31.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter52);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(localDate57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "T������.000" + "'", str58.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(durationField72);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = dateTime3.withZoneRetainFields(dateTimeZone5);
        int int7 = dateTime6.getYear();
        org.joda.time.DateTime.Property property8 = dateTime6.millisOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property2.getAsShortText(locale3);
        int int5 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime6 = property2.roundCeilingCopy();
        org.joda.time.DateTime dateTime8 = dateTime6.minusDays(1967);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969" + "'", str4.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.minuteOfDay();
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        boolean boolean17 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology16);
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology16.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField21 = gregorianChronology20.minutes();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (byte) -1);
        int int26 = offsetDateTimeField24.getLeapAmount((long) 10);
        long long28 = offsetDateTimeField24.roundHalfFloor(0L);
        long long30 = offsetDateTimeField24.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime35 = dateTime33.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate36 = dateTime35.toLocalDate();
        java.lang.String str37 = dateTimeFormatter31.print((org.joda.time.ReadablePartial) localDate36);
        int[] intArray44 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray46 = offsetDateTimeField24.set((org.joda.time.ReadablePartial) localDate36, 0, intArray44, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField48 = gregorianChronology47.minutes();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology47.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField(dateTimeField49, (int) (byte) -1);
        int int53 = offsetDateTimeField51.getLeapAmount((long) 10);
        long long55 = offsetDateTimeField51.roundHalfFloor(0L);
        long long57 = offsetDateTimeField51.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter58 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime62 = dateTime60.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate63 = dateTime62.toLocalDate();
        java.lang.String str64 = dateTimeFormatter58.print((org.joda.time.ReadablePartial) localDate63);
        int[] intArray71 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray73 = offsetDateTimeField51.set((org.joda.time.ReadablePartial) localDate63, 0, intArray71, (int) (byte) 100);
        gregorianChronology16.validate((org.joda.time.ReadablePartial) localDate36, intArray73);
        int[] intArray76 = gregorianChronology10.get((org.joda.time.ReadablePartial) localDate36, (long) 1920);
        org.joda.time.DateTimeField dateTimeField77 = gregorianChronology10.minuteOfHour();
        org.joda.time.ReadablePeriod readablePeriod78 = null;
        long long81 = gregorianChronology10.add(readablePeriod78, (long) 10, (int) (byte) 100);
        try {
            org.joda.time.DateTime dateTime82 = new org.joda.time.DateTime(135, 2, 61, 0, 35, (int) (short) 10, (int) (short) 10, (org.joda.time.Chronology) gregorianChronology10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 61 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "T������.000" + "'", str37.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter58);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(localDate63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "T������.000" + "'", str64.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertNotNull(dateTimeField77);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 10L + "'", long81 == 10L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        int int11 = dateTime7.compareTo((org.joda.time.ReadableInstant) dateTime9);
        int int12 = dateTime9.getEra();
        boolean boolean13 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime15 = dateTime3.withMinuteOfHour(0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.withYear(9);
        org.joda.time.DateTime dateTime13 = dateTime12.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime15 = dateTime13.withYear(61);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime1.minusMinutes(0);
        try {
            org.joda.time.DateTime dateTime11 = dateTime1.withDayOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property2.getAsShortText(locale3);
        int int5 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime6 = property2.roundCeilingCopy();
        org.joda.time.DateTime dateTime7 = property2.roundHalfFloorCopy();
        int int8 = dateTime7.getEra();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969" + "'", str4.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        int int6 = dateTime3.getEra();
        org.joda.time.DateTime.Property property7 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime9 = property7.addToCopy((long) (byte) 10);
        org.joda.time.DateTime dateTime11 = dateTime9.withYear(135);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatterBuilder2.toFormatter();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendCenturyOfEra((int) (short) -1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.minutes();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (byte) -1);
        int int13 = offsetDateTimeField11.getLeapAmount((long) 10);
        long long15 = offsetDateTimeField11.roundHalfFloor(0L);
        long long17 = offsetDateTimeField11.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime22 = dateTime20.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate23 = dateTime22.toLocalDate();
        java.lang.String str24 = dateTimeFormatter18.print((org.joda.time.ReadablePartial) localDate23);
        int[] intArray31 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray33 = offsetDateTimeField11.set((org.joda.time.ReadablePartial) localDate23, 0, intArray31, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField35 = gregorianChronology34.minutes();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, (int) (byte) -1);
        int int40 = offsetDateTimeField38.getLeapAmount((long) 10);
        long long42 = offsetDateTimeField38.roundHalfFloor(0L);
        long long44 = offsetDateTimeField38.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime49 = dateTime47.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate50 = dateTime49.toLocalDate();
        java.lang.String str51 = dateTimeFormatter45.print((org.joda.time.ReadablePartial) localDate50);
        int[] intArray58 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray60 = offsetDateTimeField38.set((org.joda.time.ReadablePartial) localDate50, 0, intArray58, (int) (byte) 100);
        gregorianChronology3.validate((org.joda.time.ReadablePartial) localDate23, intArray60);
        org.joda.time.DateTime dateTime62 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "T������.000" + "'", str24.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter45);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "T������.000" + "'", str51.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(dateTime62);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        org.joda.time.DurationField durationField7 = offsetDateTimeField4.getLeapDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withLocale(locale9);
        java.util.Locale locale11 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter10.withLocale(locale11);
        org.joda.time.format.DateTimeParser dateTimeParser13 = dateTimeFormatter12.getParser();
        org.joda.time.LocalTime localTime15 = dateTimeFormatter12.parseLocalTime("T160000.052-0800");
        java.util.Locale locale16 = null;
        try {
            java.lang.String str17 = offsetDateTimeField4.getAsText((org.joda.time.ReadablePartial) localTime15, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfEra' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeParser13);
        org.junit.Assert.assertNotNull(localTime15);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readablePeriod5);
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime8.minusMinutes(56792);
        org.joda.time.DateTime dateTime12 = dateTime10.plusMinutes(0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = property2.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime6 = dateTime4.withWeekyear((int) (byte) 100);
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        org.joda.time.DateTime dateTime9 = dateTime6.plusMonths((-57600002));
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(56792);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "T151320.765-0700");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        illegalFieldValueException2.prependMessage("1");
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("hi!", "T151320.765-0700");
        org.joda.time.DurationFieldType durationFieldType10 = illegalFieldValueException9.getDurationFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = illegalFieldValueException9.getDateTimeFieldType();
        java.lang.String str12 = illegalFieldValueException9.toString();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException9);
        java.lang.String str14 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNull(dateTimeFieldType3);
        org.junit.Assert.assertNull(durationFieldType4);
        org.junit.Assert.assertNull(durationFieldType10);
        org.junit.Assert.assertNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"T151320.765-0700\" for hi! is not supported" + "'", str12.equals("org.joda.time.IllegalFieldValueException: Value \"T151320.765-0700\" for hi! is not supported"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime3.withZoneRetainFields(dateTimeZone5);
//        long long9 = dateTimeZone5.convertLocalToUTC((long) 100, false);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone5.getShortName((long) 0, locale11);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.era();
//        long long18 = gregorianChronology13.add((long) (short) 100, 0L, 10);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800100L + "'", long9 == 28800100L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PST" + "'", str12.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        java.lang.String str8 = offsetDateTimeField4.getName();
        org.joda.time.DurationField durationField9 = offsetDateTimeField4.getDurationField();
        java.lang.String str11 = offsetDateTimeField4.getAsText((-61820063999990L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10" + "'", str11.equals("10"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime5 = dateTime1.withEarlierOffsetAtOverlap();
        int int6 = dateTime5.getEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(69);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder2.setFixedSavings("org.joda.time.IllegalFieldValueException: Value \"T151320.765-0700\" for hi! is not supported", 10);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder5.addRecurringSavings("T160000.052-0800", 57600001, 0, 1920, '#', 292278993, 35, (int) '4', false, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        int int4 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime5 = property2.withMaximumValue();
        org.joda.time.DateTime dateTime7 = dateTime5.minus((long) 1);
        org.joda.time.DateTime dateTime9 = dateTime7.plusMonths(0);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        java.util.Date date11 = dateTime7.toDate();
        boolean boolean12 = dateTime7.isBeforeNow();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 292278993 + "'", int4 == 292278993);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        int int4 = property2.getMaximumShortTextLength(locale3);
        java.util.Locale locale5 = null;
        java.lang.String str6 = property2.getAsText(locale5);
        int int7 = property2.get();
        org.joda.time.DateTime dateTime9 = property2.addToCopy(54825);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder4.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withDefaultYear(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withPivotYear((java.lang.Integer) 35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = dateTime3.withZoneRetainFields(dateTimeZone5);
        long long9 = dateTimeZone5.convertLocalToUTC((long) 100, false);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime12 = dateTime10.plusMonths(2);
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((-28799938L));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800100L + "'", long9 == 28800100L);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test197");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getName((long) 9, locale12);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField16 = gregorianChronology15.minutes();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        long long20 = gregorianChronology15.add(readablePeriod17, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) 100, dateTimeZone23);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = dateTimeZone23.getName((long) 9, locale27);
//        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology15, dateTimeZone23);
//        long long31 = dateTimeZone8.getMillisKeepLocal(dateTimeZone23, 97L);
//        long long35 = dateTimeZone8.convertLocalToUTC((-62166787200109L), true, 28800000L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Pacific Standard Time" + "'", str28.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 97L + "'", long31 == 97L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62166758822109L) + "'", long35 == (-62166758822109L));
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime5 = dateTime1.withTimeAtStartOfDay();
        int int6 = dateTime5.getYear();
        org.joda.time.DateTime dateTime8 = dateTime5.withWeekyear((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600002 + "'", int4 == 57600002);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (-292275054), (java.lang.Number) 16, (java.lang.Number) 100);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendSecondOfMinute(19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMillisOfSecond(19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.withEra((int) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime10.toMutableDateTimeISO();
        try {
            org.joda.time.DateTime dateTime13 = dateTime10.withDayOfYear(1870);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1870 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        org.joda.time.DateTime.Property property5 = dateTime1.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        java.lang.String str4 = property2.toString();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property2.getAsShortText(locale5);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[yearOfEra]" + "'", str4.equals("Property[yearOfEra]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1969365T������.000", "org.joda.time.IllegalFieldValueException: Value \"T151320.765-0700\" for hi! is not supported", 19, 279);
        int int6 = fixedDateTimeZone4.getStandardOffset(97L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 279 + "'", int6 == 279);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.Chronology chronology1 = null;
        try {
            org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0, chronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendSecondOfMinute(35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendFractionOfDay(2, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendHourOfDay((int) (short) 100);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "T151320.765-0700");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType3);
        org.junit.Assert.assertNull(dateTimeFieldType4);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "T151320.765-0700");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str7 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNull(dateTimeFieldType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "T151320.765-0700" + "'", str5.equals("T151320.765-0700"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "T151320.765-0700" + "'", str6.equals("T151320.765-0700"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "T151320.765-0700" + "'", str7.equals("T151320.765-0700"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField14 = gregorianChronology13.minutes();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) (byte) -1);
        int int19 = offsetDateTimeField17.getLeapAmount((long) 10);
        long long21 = offsetDateTimeField17.roundHalfFloor(0L);
        long long23 = offsetDateTimeField17.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime28 = dateTime26.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate29 = dateTime28.toLocalDate();
        java.lang.String str30 = dateTimeFormatter24.print((org.joda.time.ReadablePartial) localDate29);
        int[] intArray37 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray39 = offsetDateTimeField17.set((org.joda.time.ReadablePartial) localDate29, 0, intArray37, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField41 = gregorianChronology40.minutes();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, (int) (byte) -1);
        int int46 = offsetDateTimeField44.getLeapAmount((long) 10);
        long long48 = offsetDateTimeField44.roundHalfFloor(0L);
        long long50 = offsetDateTimeField44.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime55 = dateTime53.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate56 = dateTime55.toLocalDate();
        java.lang.String str57 = dateTimeFormatter51.print((org.joda.time.ReadablePartial) localDate56);
        int[] intArray64 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray66 = offsetDateTimeField44.set((org.joda.time.ReadablePartial) localDate56, 0, intArray64, (int) (byte) 100);
        gregorianChronology9.validate((org.joda.time.ReadablePartial) localDate29, intArray66);
        int[] intArray69 = gregorianChronology3.get((org.joda.time.ReadablePartial) localDate29, (long) 1920);
        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime73 = dateTime71.plusSeconds((int) (short) 10);
        org.joda.time.DateTime.Property property74 = dateTime73.millisOfDay();
        org.joda.time.DateTime dateTime76 = dateTime73.plusDays(0);
        org.joda.time.MutableDateTime mutableDateTime77 = dateTime73.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime79 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property80 = dateTime79.yearOfEra();
        java.lang.String str81 = property80.getAsShortText();
        int int82 = property80.getMaximumValue();
        org.joda.time.DateTime dateTime83 = property80.withMaximumValue();
        org.joda.time.DateTime dateTime85 = dateTime83.minus((long) 1);
        org.joda.time.DateTime dateTime87 = dateTime85.plusMonths(0);
        org.joda.time.DateTime dateTime88 = dateTime85.toDateTime();
        boolean boolean89 = mutableDateTime77.isAfter((org.joda.time.ReadableInstant) dateTime88);
        boolean boolean90 = gregorianChronology3.equals((java.lang.Object) boolean89);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "T������.000" + "'", str30.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter51);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "T������.000" + "'", str57.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertNotNull(property74);
        org.junit.Assert.assertNotNull(dateTime76);
        org.junit.Assert.assertNotNull(mutableDateTime77);
        org.junit.Assert.assertNotNull(property80);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "1969" + "'", str81.equals("1969"));
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 292278993 + "'", int82 == 292278993);
        org.junit.Assert.assertNotNull(dateTime83);
        org.junit.Assert.assertNotNull(dateTime85);
        org.junit.Assert.assertNotNull(dateTime87);
        org.junit.Assert.assertNotNull(dateTime88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfDay(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfWeek(57600001);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readablePeriod5);
        org.joda.time.TimeOfDay timeOfDay7 = dateTime1.toTimeOfDay();
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField10 = gregorianChronology9.minutes();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) (byte) -1);
        long long16 = offsetDateTimeField13.add((long) 135, (long) 100);
        boolean boolean17 = offsetDateTimeField13.isSupported();
        int int18 = dateTime1.get((org.joda.time.DateTimeField) offsetDateTimeField13);
        int int20 = offsetDateTimeField13.getLeapAmount((-1L));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 960 + "'", int8 == 960);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3155760000135L + "'", long16 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1969 + "'", int18 == 1969);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendSecondOfDay((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendSecondOfMinute(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        boolean boolean6 = offsetDateTimeField4.isLeap((long) 'a');
        boolean boolean8 = offsetDateTimeField4.isLeap((long) 4);
        int int9 = offsetDateTimeField4.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 292278992 + "'", int9 == 292278992);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter0.getPrinter();
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.minuteOfDay();
        org.joda.time.DurationField durationField12 = gregorianChronology9.months();
        org.joda.time.DurationField durationField13 = gregorianChronology9.months();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DurationField durationField15 = gregorianChronology9.hours();
        int int16 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = property2.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime6 = dateTime4.withWeekyear((int) (byte) 100);
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = property7.roundFloorCopy();
        org.joda.time.ReadableInstant readableInstant9 = null;
        boolean boolean10 = dateTime8.isAfter(readableInstant9);
        org.joda.time.DateTime.Property property11 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime15 = dateTime13.minusDays((int) (short) -1);
        int int16 = dateTime13.getMillisOfDay();
        org.joda.time.DateTime dateTime17 = dateTime13.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime21 = dateTime19.minusDays((int) (short) -1);
        int int22 = dateTime19.getMillisOfDay();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property27 = dateTime26.yearOfEra();
        int int28 = dateTime24.compareTo((org.joda.time.ReadableInstant) dateTime26);
        int int29 = dateTime26.getDayOfMonth();
        boolean boolean30 = dateTime19.isEqual((org.joda.time.ReadableInstant) dateTime26);
        boolean boolean31 = dateTime17.isAfter((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime dateTime33 = dateTime19.withYear((int) '4');
        org.joda.time.DateTime dateTime35 = dateTime19.minusYears(0);
        org.joda.time.DateTime dateTime37 = dateTime19.withYearOfCentury(0);
        int int38 = dateTime19.getMillisOfDay();
        int int39 = property11.compareTo((org.joda.time.ReadableInstant) dateTime19);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 57600002 + "'", int16 == 57600002);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 57600002 + "'", int22 == 57600002);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 57600002 + "'", int38 == 57600002);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        java.lang.String str9 = cachedDateTimeZone7.getNameKey(100L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        java.lang.String str12 = zonedChronology11.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ZonedChronology[GregorianChronology[UTC], T151321.363-0700]" + "'", str12.equals("ZonedChronology[GregorianChronology[UTC], T151321.363-0700]"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property2.getAsShortText(locale3);
        int int5 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime6 = property2.roundCeilingCopy();
        org.joda.time.DateTime dateTime7 = property2.roundFloorCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969" + "'", str4.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Property[yearOfEra]", "Pacific Standard Time", 54823, 0);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        int int7 = fixedDateTimeZone4.getStandardOffset(0L);
        int int9 = fixedDateTimeZone4.getStandardOffset(0L);
        long long12 = fixedDateTimeZone4.adjustOffset((-2922770L), false);
        long long14 = fixedDateTimeZone4.nextTransition((long) (short) 0);
        java.lang.String str16 = fixedDateTimeZone4.getNameKey((long) 292278993);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2922770L) + "'", long12 == (-2922770L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Pacific Standard Time" + "'", str16.equals("Pacific Standard Time"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendLiteral("UTC");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.withYear(9);
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime10.toMutableDateTime();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 16);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = property2.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime6 = dateTime4.withWeekyear((int) (byte) 100);
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        try {
            org.joda.time.DateTime dateTime9 = dateTime6.withEra((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 100, dateTimeZone2);
        int int5 = dateTime4.getYearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField4 = gregorianChronology0.hours();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatterBuilder9.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale12 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter11.withLocale(locale12);
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withLocale(locale14);
        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter15.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder9.append(dateTimeParser16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder4.append(dateTimeParser16);
        dateTimeFormatterBuilder4.clear();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder4.appendMillisOfSecond((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology3.months();
        org.joda.time.DurationField durationField7 = gregorianChronology3.months();
        org.joda.time.DurationField durationField8 = gregorianChronology3.weekyears();
        try {
            long long11 = durationField8.subtract(1009843200052L, (-61820064000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 61820064000000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getName((long) 9, locale12);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone8);
//        org.joda.time.Chronology chronology15 = zonedChronology14.withUTC();
//        org.joda.time.DurationField durationField16 = zonedChronology14.weekyears();
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder18 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone21 = dateTimeZoneBuilder18.toDateTimeZone("T151321.363-0700", false);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone21);
//        boolean boolean24 = cachedDateTimeZone22.equals((java.lang.Object) 57600002);
//        org.joda.time.Chronology chronology25 = iSOChronology17.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
//        org.joda.time.Chronology chronology26 = zonedChronology14.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.basicTTime();
//        org.joda.time.LocalDate localDate29 = dateTimeFormatter27.parseLocalDate("T151324.051-0700");
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField31 = gregorianChronology30.minutes();
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology30.yearOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) (byte) -1);
//        int int36 = offsetDateTimeField34.getLeapAmount((long) 10);
//        long long38 = offsetDateTimeField34.roundHalfFloor(0L);
//        long long40 = offsetDateTimeField34.roundHalfFloor(0L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.basicTTime();
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime45 = dateTime43.plusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate46 = dateTime45.toLocalDate();
//        java.lang.String str47 = dateTimeFormatter41.print((org.joda.time.ReadablePartial) localDate46);
//        int[] intArray54 = new int[] { 1969, 100, ' ', 10, 2 };
//        int[] intArray56 = offsetDateTimeField34.set((org.joda.time.ReadablePartial) localDate46, 0, intArray54, (int) (byte) 100);
//        zonedChronology14.validate((org.joda.time.ReadablePartial) localDate29, intArray56);
//        try {
//            long long62 = zonedChronology14.getDateTimeMillis(2922789, 19, 135, 1970);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter41);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "T������.000" + "'", str47.equals("T������.000"));
//        org.junit.Assert.assertNotNull(intArray54);
//        org.junit.Assert.assertNotNull(intArray56);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(69);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder2.setStandardOffset(1);
        java.io.DataOutput dataOutput6 = null;
        try {
            dateTimeZoneBuilder2.writeTo("", dataOutput6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "T151320.765-0700");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        java.lang.String str4 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        org.joda.time.IllegalFieldValueException illegalFieldValueException8 = new org.joda.time.IllegalFieldValueException("hi!", "T151320.765-0700");
        org.joda.time.DurationFieldType durationFieldType9 = illegalFieldValueException8.getDurationFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = illegalFieldValueException8.getDateTimeFieldType();
        java.lang.String str11 = illegalFieldValueException8.getIllegalValueAsString();
        org.joda.time.DurationFieldType durationFieldType12 = illegalFieldValueException8.getDurationFieldType();
        java.lang.String str13 = illegalFieldValueException8.getFieldName();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = illegalFieldValueException8.getDateTimeFieldType();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "T151320.765-0700" + "'", str4.equals("T151320.765-0700"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "T151320.765-0700" + "'", str5.equals("T151320.765-0700"));
        org.junit.Assert.assertNull(durationFieldType9);
        org.junit.Assert.assertNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "T151320.765-0700" + "'", str11.equals("T151320.765-0700"));
        org.junit.Assert.assertNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNull(dateTimeFieldType14);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology7);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test232");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getName((long) 9, locale12);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone8);
//        org.joda.time.Chronology chronology15 = zonedChronology14.withUTC();
//        org.joda.time.DurationField durationField16 = zonedChronology14.weekyears();
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder18 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone21 = dateTimeZoneBuilder18.toDateTimeZone("T151321.363-0700", false);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone21);
//        boolean boolean24 = cachedDateTimeZone22.equals((java.lang.Object) 57600002);
//        org.joda.time.Chronology chronology25 = iSOChronology17.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
//        org.joda.time.Chronology chronology26 = zonedChronology14.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.basicTTime();
//        org.joda.time.LocalDate localDate29 = dateTimeFormatter27.parseLocalDate("T151324.051-0700");
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField31 = gregorianChronology30.minutes();
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology30.yearOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) (byte) -1);
//        int int36 = offsetDateTimeField34.getLeapAmount((long) 10);
//        long long38 = offsetDateTimeField34.roundHalfFloor(0L);
//        long long40 = offsetDateTimeField34.roundHalfFloor(0L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.basicTTime();
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime45 = dateTime43.plusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate46 = dateTime45.toLocalDate();
//        java.lang.String str47 = dateTimeFormatter41.print((org.joda.time.ReadablePartial) localDate46);
//        int[] intArray54 = new int[] { 1969, 100, ' ', 10, 2 };
//        int[] intArray56 = offsetDateTimeField34.set((org.joda.time.ReadablePartial) localDate46, 0, intArray54, (int) (byte) 100);
//        zonedChronology14.validate((org.joda.time.ReadablePartial) localDate29, intArray56);
//        try {
//            long long62 = zonedChronology14.getDateTimeMillis(57600002, 1969, (int) (byte) 0, 1959);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter41);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "T������.000" + "'", str47.equals("T������.000"));
//        org.junit.Assert.assertNotNull(intArray54);
//        org.junit.Assert.assertNotNull(intArray56);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.withYear(9);
        org.joda.time.DateTime dateTime13 = dateTime12.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime15 = dateTime13.minusHours(1969);
        org.joda.time.MutableDateTime mutableDateTime16 = dateTime13.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property17 = dateTime13.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime18 = dateTime13.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime20 = dateTime13.plusDays((-1));
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property25 = dateTime24.yearOfEra();
        int int26 = dateTime22.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime.Property property27 = dateTime22.weekOfWeekyear();
        org.joda.time.DateTime.Property property28 = dateTime22.dayOfYear();
        int int29 = property28.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property28.getFieldType();
        try {
            org.joda.time.DateTime dateTime32 = dateTime13.withField(dateTimeFieldType30, 1967);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1967 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 365 + "'", int29 == 365);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
        long long6 = gregorianChronology0.add((long) (byte) -1, (long) (short) -1, (-10));
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.dayOfMonth();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, 0, 0, 1870);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9L + "'", long6 == 9L);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        java.lang.String str9 = offsetDateTimeField4.getName();
        long long11 = offsetDateTimeField4.roundHalfFloor((long) 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField4.getType();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property17 = dateTime16.yearOfEra();
        int int18 = dateTime14.compareTo((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime.Property property19 = dateTime14.weekOfWeekyear();
        org.joda.time.DateTime.Property property20 = dateTime14.dayOfYear();
        int int21 = property20.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property20.getFieldType();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray23 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType12, dateTimeFieldType22 };
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList24 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList24, dateTimeFieldTypeArray23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList24, true, true);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "yearOfEra" + "'", str9.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 365 + "'", int21 == 365);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        boolean boolean10 = dateTime1.isAfter((long) 8);
        java.util.Locale locale11 = null;
        java.util.Calendar calendar12 = dateTime1.toCalendar(locale11);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(calendar12);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone2 = iSOChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
        java.lang.Object obj4 = null;
        boolean boolean5 = iSOChronology0.equals(obj4);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test238");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getName((long) 9, locale12);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone15 = zonedChronology14.getZone();
//        org.joda.time.DurationField durationField16 = zonedChronology14.centuries();
//        org.joda.time.DateTimeField dateTimeField17 = zonedChronology14.yearOfCentury();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        boolean boolean9 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.minuteOfDay();
        org.joda.time.DurationField durationField11 = gregorianChronology8.months();
        org.joda.time.DurationField durationField12 = gregorianChronology8.months();
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(16, (int) (short) -1, (-1), 0, (-57600002), (org.joda.time.Chronology) gregorianChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -57600002 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfEven((long) (byte) 10);
        long long10 = offsetDateTimeField4.roundHalfCeiling((long) 53);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.minusHours(57600002);
        org.joda.time.DateTime.Property property9 = dateTime1.weekyear();
        org.joda.time.DateTime dateTime10 = dateTime1.toDateTime();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.withYear(9);
        org.joda.time.DateTime dateTime15 = dateTime10.withDurationAdded(0L, 1969);
        int int16 = dateTime15.getWeekyear();
        org.joda.time.Chronology chronology17 = dateTime15.getChronology();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1959 + "'", int16 == 1959);
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology3.months();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.year();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readablePeriod5);
        org.joda.time.DateTime dateTime8 = dateTime1.plusYears(0);
        org.joda.time.DateTime.Property property9 = dateTime1.dayOfMonth();
        int int10 = property9.getMinimumValueOverall();
        int int11 = property9.getLeapAmount();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = dateTime3.withZoneRetainFields(dateTimeZone5);
        long long9 = dateTimeZone5.convertLocalToUTC((long) (byte) 0, true);
        int int11 = dateTimeZone5.getOffsetFromLocal(1L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone16 = dateTimeZoneBuilder13.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
        boolean boolean19 = cachedDateTimeZone17.equals((java.lang.Object) 57600002);
        int int21 = cachedDateTimeZone17.getStandardOffset((long) 54823);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter12.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone17);
        long long24 = dateTimeZone5.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone17, 62L);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime28 = dateTime26.minusDays((int) (short) -1);
        int int29 = dateTime26.getMillisOfDay();
        org.joda.time.DateTime dateTime30 = dateTime26.withTimeAtStartOfDay();
        org.joda.time.ReadablePartial readablePartial31 = null;
        org.joda.time.DateTime dateTime32 = dateTime26.withFields(readablePartial31);
        org.joda.time.DateMidnight dateMidnight33 = dateTime26.toDateMidnight();
        org.joda.time.DateTime dateTime35 = dateTime26.withMillis(2649600002L);
        int int36 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime26);
        org.joda.time.DateTime dateTime37 = dateTime26.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800000L + "'", long9 == 28800000L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-28799938L) + "'", long24 == (-28799938L));
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 57600002 + "'", int29 == 57600002);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateMidnight33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-28800000) + "'", int36 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime37);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.set(0L, 10);
        java.lang.String str9 = offsetDateTimeField4.getAsShortText((long) 19);
        long long12 = offsetDateTimeField4.getDifferenceAsLong(31535999999L, (-28800000L));
        int int14 = offsetDateTimeField4.getLeapAmount((long) 292278993);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61820064000000L) + "'", long7 == (-61820064000000L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfYear(292278993);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withLocale(locale8);
        org.joda.time.format.DateTimePrinter dateTimePrinter10 = dateTimeFormatter9.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser11 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter10, dateTimeParser11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withLocale(locale14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withLocale(locale16);
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder6.append(dateTimePrinter10, dateTimeParser18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder6.appendMonthOfYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimePrinter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        java.lang.String str8 = offsetDateTimeField4.getName();
        long long10 = offsetDateTimeField4.roundHalfFloor((long) (byte) -1);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField4.getMaximumTextLength(locale11);
        boolean boolean13 = offsetDateTimeField4.isLenient();
        boolean boolean15 = offsetDateTimeField4.isLeap((long) 70);
        org.joda.time.DurationField durationField16 = offsetDateTimeField4.getDurationField();
        int int18 = offsetDateTimeField4.getLeapAmount((long) 57600);
        long long21 = offsetDateTimeField4.add((-62009366400000L), (int) (short) 10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61693833600000L) + "'", long21 == (-61693833600000L));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("19");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"19/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        int int4 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime5 = property2.withMaximumValue();
        org.joda.time.DateTime dateTime7 = dateTime5.minus((long) 1);
        org.joda.time.DateTime dateTime9 = dateTime7.plusMonths(0);
        org.joda.time.DateTime dateTime11 = dateTime9.minusYears(292278993);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime15 = dateTime13.minusDays((int) (short) -1);
        int int16 = dateTime13.getMillisOfDay();
        org.joda.time.DateTime dateTime17 = dateTime13.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime21 = dateTime19.minusDays((int) (short) -1);
        int int22 = dateTime19.getMillisOfDay();
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property27 = dateTime26.yearOfEra();
        int int28 = dateTime24.compareTo((org.joda.time.ReadableInstant) dateTime26);
        int int29 = dateTime26.getDayOfMonth();
        boolean boolean30 = dateTime19.isEqual((org.joda.time.ReadableInstant) dateTime26);
        boolean boolean31 = dateTime17.isAfter((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime dateTime33 = dateTime19.withYear((int) '4');
        org.joda.time.DateTime dateTime35 = dateTime19.minusYears(0);
        org.joda.time.DateTime dateTime37 = dateTime19.withYearOfCentury(0);
        boolean boolean38 = dateTime9.isEqual((org.joda.time.ReadableInstant) dateTime19);
        long long39 = dateTime9.getMillis();
        java.lang.String str40 = dateTime9.toString();
        boolean boolean41 = dateTime9.isAfterNow();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 292278993 + "'", int4 == 292278993);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 57600002 + "'", int16 == 57600002);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 57600002 + "'", int22 == 57600002);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 9223372017129600001L + "'", long39 == 9223372017129600001L);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "292278993-12-31T16:00:00.001-08:00" + "'", str40.equals("292278993-12-31T16:00:00.001-08:00"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "T151320.765-0700");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        org.joda.time.DurationFieldType durationFieldType6 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str7 = illegalFieldValueException2.getFieldName();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.String str9 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNull(dateTimeFieldType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "T151320.765-0700" + "'", str5.equals("T151320.765-0700"));
        org.junit.Assert.assertNull(durationFieldType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "T151320.765-0700" + "'", str9.equals("T151320.765-0700"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (-28799998L), (java.lang.Number) (-315619199998L), (java.lang.Number) 2649600002L);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.era();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.era();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfYear(292278993);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter5);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime10 = dateTime8.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime11 = dateTime8.toDateTime();
        org.joda.time.DateTime dateTime13 = dateTime11.minusMonths(0);
        org.joda.time.MutableDateTime mutableDateTime14 = dateTime11.toMutableDateTime();
        int int17 = dateTimeFormatter5.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime14, "Property[yearOfEra]", (int) (byte) -1);
        try {
            org.joda.time.DateTime dateTime19 = dateTimeFormatter5.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "T151320.765-0700");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str5 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str6 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "T151320.765-0700" + "'", str5.equals("T151320.765-0700"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "T151320.765-0700" + "'", str6.equals("T151320.765-0700"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        boolean boolean6 = offsetDateTimeField4.isLeap((long) 'a');
        int int9 = offsetDateTimeField4.getDifference((long) 57600002, (long) ' ');
        try {
            long long12 = offsetDateTimeField4.set(0L, "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime3.plusDays(0);
        org.joda.time.DateTime.Property property7 = dateTime3.secondOfMinute();
        java.lang.String str8 = property7.toString();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Property[secondOfMinute]" + "'", str8.equals("Property[secondOfMinute]"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = dateTime3.withZoneRetainFields(dateTimeZone5);
        long long9 = dateTimeZone5.convertLocalToUTC((long) (byte) 0, true);
        long long12 = dateTimeZone5.adjustOffset((long) (byte) -1, false);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (short) 1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800000L + "'", long9 == 28800000L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertNotNull(gregorianChronology14);
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test262");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getSecondOfDay();
//        org.joda.time.DateTime.Property property2 = dateTime0.minuteOfDay();
//        java.util.GregorianCalendar gregorianCalendar3 = dateTime0.toGregorianCalendar();
//        org.joda.time.DateTime dateTime4 = dateTime0.withEarlierOffsetAtOverlap();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 54870 + "'", int1 == 54870);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(gregorianCalendar3);
//        org.junit.Assert.assertNotNull(dateTime4);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        java.lang.String str8 = offsetDateTimeField4.getName();
        java.lang.String str9 = offsetDateTimeField4.getName();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, 54823);
        int int13 = offsetDateTimeField4.get((long) (short) 10);
        int int16 = offsetDateTimeField4.getDifference((long) 2922789, 31536000031L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "yearOfEra" + "'", str9.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1969 + "'", int13 == 1969);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(1969, 100, 57610, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        int int3 = property2.getLeapAmount();
        int int4 = property2.getMinimumValueOverall();
        int int5 = property2.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        int int4 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime5 = property2.withMaximumValue();
        org.joda.time.DateTime dateTime7 = dateTime5.minus((long) 1);
        try {
            org.joda.time.DateTime dateTime9 = dateTime5.withEra(57610);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57610 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 292278993 + "'", int4 == 292278993);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder4.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withLocale(locale7);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withLocale(locale9);
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.append(dateTimeParser11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder4.appendMillisOfDay(9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendTwoDigitYear(2922789);
        boolean boolean18 = dateTimeFormatterBuilder15.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("org.joda.time.IllegalFieldValueException: Value \"T151320.765-0700\" for hi! is not supported");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"org.joda.time.IllegalFieldValueException: Value \"T151320.765-0700\" for hi! is not supported/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendSecondOfMinute(35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendFractionOfDay(2, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendDayOfMonth(56792);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-28800000), 69);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 69");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology3.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        int int4 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime5 = property2.withMaximumValue();
        org.joda.time.DateTime dateTime7 = dateTime5.minus((long) 1);
        org.joda.time.DateTime dateTime9 = dateTime7.plusMonths(0);
        org.joda.time.DateTime.Property property10 = dateTime7.era();
        org.joda.time.DateTime.Property property11 = dateTime7.dayOfYear();
        java.util.Locale locale12 = null;
        java.util.Calendar calendar13 = dateTime7.toCalendar(locale12);
        org.joda.time.DateTime dateTime15 = dateTime7.minusDays(1969);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 292278993 + "'", int4 == 292278993);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(calendar13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.set(0L, 10);
        java.util.Locale locale9 = null;
        java.lang.String str10 = offsetDateTimeField4.getAsText(292278993, locale9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField4.getAsText(31507200002L, locale12);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61820064000000L) + "'", long7 == (-61820064000000L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "292278993" + "'", str10.equals("292278993"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969" + "'", str13.equals("1969"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMonthOfYear((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendMillisOfSecond(54866);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder8.appendTwoDigitYear(61);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.minutes();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (byte) -1);
        int int13 = offsetDateTimeField11.getLeapAmount((long) 10);
        long long15 = offsetDateTimeField11.roundHalfFloor(0L);
        long long17 = offsetDateTimeField11.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime22 = dateTime20.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate23 = dateTime22.toLocalDate();
        java.lang.String str24 = dateTimeFormatter18.print((org.joda.time.ReadablePartial) localDate23);
        int[] intArray31 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray33 = offsetDateTimeField11.set((org.joda.time.ReadablePartial) localDate23, 0, intArray31, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField35 = gregorianChronology34.minutes();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, (int) (byte) -1);
        int int40 = offsetDateTimeField38.getLeapAmount((long) 10);
        long long42 = offsetDateTimeField38.roundHalfFloor(0L);
        long long44 = offsetDateTimeField38.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime49 = dateTime47.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate50 = dateTime49.toLocalDate();
        java.lang.String str51 = dateTimeFormatter45.print((org.joda.time.ReadablePartial) localDate50);
        int[] intArray58 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray60 = offsetDateTimeField38.set((org.joda.time.ReadablePartial) localDate50, 0, intArray58, (int) (byte) 100);
        gregorianChronology3.validate((org.joda.time.ReadablePartial) localDate23, intArray60);
        org.joda.time.DurationField durationField62 = gregorianChronology3.centuries();
        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology3.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology3.clockhourOfHalfday();
        org.joda.time.ReadablePeriod readablePeriod65 = null;
        try {
            int[] intArray68 = gregorianChronology3.get(readablePeriod65, (long) 0, (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "T������.000" + "'", str24.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter45);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "T������.000" + "'", str51.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTimeField64);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        int int4 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime5 = property2.withMaximumValue();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) -1);
        int int12 = offsetDateTimeField10.getLeapAmount((long) 10);
        long long14 = offsetDateTimeField10.roundHalfFloor(0L);
        java.lang.String str15 = offsetDateTimeField10.getName();
        long long18 = offsetDateTimeField10.add((long) '4', (long) ' ');
        boolean boolean19 = property2.equals((java.lang.Object) ' ');
        int int20 = property2.getMaximumValueOverall();
        int int21 = property2.getMinimumValueOverall();
        java.lang.String str22 = property2.getAsShortText();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 292278993 + "'", int4 == 292278993);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "yearOfEra" + "'", str15.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1009843200052L + "'", long18 == 1009843200052L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 292278993 + "'", int20 == 292278993);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1969" + "'", str22.equals("1969"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear((-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime5 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.DateTime dateTime7 = dateTime1.withFields(readablePartial6);
        boolean boolean9 = dateTime1.isAfter(0L);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600002 + "'", int4 == 57600002);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        org.joda.time.DurationField durationField7 = offsetDateTimeField4.getLeapDurationField();
        long long10 = offsetDateTimeField4.set(62L, 35);
        int int12 = offsetDateTimeField4.getMinimumValue(8L);
        long long14 = offsetDateTimeField4.roundHalfEven((long) 56792);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61031145599938L) + "'", long10 == (-61031145599938L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "T151320.765-0700");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException2.getDurationFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException8 = new org.joda.time.IllegalFieldValueException("hi!", "T151320.765-0700");
        org.joda.time.DurationFieldType durationFieldType9 = illegalFieldValueException8.getDurationFieldType();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException8);
        org.junit.Assert.assertNull(dateTimeFieldType3);
        org.junit.Assert.assertNull(durationFieldType4);
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertNull(durationFieldType9);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder4.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withLocale(locale7);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withLocale(locale9);
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.append(dateTimeParser11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder4.appendClockhourOfDay(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendTimeZoneName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((-1));
        java.io.DataOutput dataOutput4 = null;
        try {
            dateTimeZoneBuilder0.writeTo("0100-01-05T16:00:00.002-07:52:58", dataOutput4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime5 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.DateTime dateTime7 = dateTime1.withFields(readablePartial6);
        boolean boolean9 = dateTime1.isEqual((long) (-1));
        org.joda.time.DateTime dateTime11 = dateTime1.withSecondOfMinute(0);
        org.joda.time.DateTime.Property property12 = dateTime11.year();
        org.joda.time.DateTime dateTime13 = dateTime11.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600002 + "'", int4 == 57600002);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        boolean boolean6 = offsetDateTimeField4.isLeap((long) 'a');
        java.lang.String str7 = offsetDateTimeField4.getName();
        long long9 = offsetDateTimeField4.roundHalfEven(28800000L);
        org.joda.time.DurationField durationField10 = offsetDateTimeField4.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "yearOfEra" + "'", str7.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNull(durationField10);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfEra();
        int int6 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime4);
        java.lang.String str7 = dateTime2.toString();
        org.joda.time.DateTime dateTime9 = dateTime2.withYearOfEra(135);
        java.lang.String str10 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime9);
        java.util.GregorianCalendar gregorianCalendar11 = dateTime9.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str7.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "01351231" + "'", str10.equals("01351231"));
        org.junit.Assert.assertNotNull(gregorianCalendar11);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime dateTime6 = dateTime3.withYearOfCentury((int) '4');
        java.lang.String str8 = dateTime6.toString("52");
        java.lang.String str9 = dateTime6.toString();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52" + "'", str8.equals("52"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1952-12-31T16:00:10.002-08:00" + "'", str9.equals("1952-12-31T16:00:10.002-08:00"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readablePeriod5);
        org.joda.time.TimeOfDay timeOfDay7 = dateTime1.toTimeOfDay();
        org.joda.time.DateTime.Property property8 = dateTime1.centuryOfEra();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("T151321.363-0700", "1", 292278993, (int) 'a');
        org.joda.time.DateTime dateTime14 = dateTime1.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField16 = gregorianChronology15.minutes();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) (byte) -1);
        int int21 = offsetDateTimeField19.getLeapAmount((long) 10);
        long long23 = offsetDateTimeField19.roundHalfFloor(0L);
        java.lang.String str24 = offsetDateTimeField19.getName();
        long long26 = offsetDateTimeField19.roundHalfFloor((long) 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField19.getType();
        int int28 = dateTime14.get(dateTimeFieldType27);
        try {
            org.joda.time.DateTime dateTime33 = dateTime14.withTime(86399999, 0, 292278992, 365);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399999 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "yearOfEra" + "'", str24.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1969 + "'", int28 == 1969);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = property2.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime6 = dateTime4.withWeekyear((int) (byte) 100);
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField9 = gregorianChronology8.minutes();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) (byte) -1);
        long long15 = offsetDateTimeField12.add((long) 135, (long) 100);
        boolean boolean16 = offsetDateTimeField12.isSupported();
        java.util.Locale locale19 = null;
        long long20 = offsetDateTimeField12.set((long) 69, "0", locale19);
        boolean boolean21 = property7.equals((java.lang.Object) long20);
        long long22 = property7.remainder();
        java.lang.String str23 = property7.getName();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3155760000135L + "'", long15 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-62135596799931L) + "'", long20 == (-62135596799931L));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-2208585599998L) + "'", long22 == (-2208585599998L));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "centuryOfEra" + "'", str23.equals("centuryOfEra"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property2.getAsShortText(locale3);
        int int5 = property2.getMaximumValue();
        int int6 = property2.get();
        org.joda.time.DateTime dateTime7 = property2.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime9 = dateTime7.plusMinutes(0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969" + "'", str4.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.weekOfWeekyear();
        org.joda.time.DurationField durationField12 = gregorianChronology9.millis();
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((-10), 9, (int) (byte) 0, (-1), 57600001, (int) 'a', (org.joda.time.Chronology) gregorianChronology9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.withYear(9);
        org.joda.time.DateTime dateTime14 = dateTime10.plusDays((int) (short) 100);
        org.joda.time.DateTime dateTime16 = dateTime14.withMillisOfDay(0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        int int4 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime5 = property2.withMaximumValue();
        org.joda.time.DateTime dateTime7 = dateTime5.minus((long) 1);
        org.joda.time.DateTime dateTime9 = dateTime7.plusMonths(0);
        org.joda.time.DateTime dateTime11 = dateTime9.minusYears(292278993);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime9.minus(readableDuration12);
        int int14 = dateTime9.getMonthOfYear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 292278993 + "'", int4 == 292278993);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.withYear(9);
        org.joda.time.DateTime dateTime15 = dateTime10.withDurationAdded(0L, 1969);
        long long16 = dateTime10.getMillis();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-315619199998L) + "'", long16 == (-315619199998L));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime5 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.DateTime dateTime7 = dateTime1.withFields(readablePartial6);
        boolean boolean9 = dateTime1.isEqual((long) (-1));
        java.util.GregorianCalendar gregorianCalendar10 = dateTime1.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600002 + "'", int4 == 57600002);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar10);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMonthOfYear((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendMillisOfSecond(54866);
        dateTimeFormatterBuilder8.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.DataOutput dataOutput2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("ZonedChronology[GregorianChronology[UTC], T151321.363-0700]", dataOutput2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test297");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
//        java.util.Locale locale1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
//        java.util.Locale locale3 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withLocale(locale3);
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        java.lang.String str6 = dateTimeFormatter4.print(readableInstant5);
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeFormatter4.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter4.withZoneUTC();
//        java.io.Writer writer9 = null;
//        try {
//            dateTimeFormatter8.printTo(writer9, 28800000L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "T151432.286-0700" + "'", str6.equals("T151432.286-0700"));
//        org.junit.Assert.assertNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long3 = dateTimeZone0.convertLocalToUTC(1560636829203L, false);
        java.util.TimeZone timeZone4 = dateTimeZone0.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560636829203L + "'", long3 == 1560636829203L);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.weekyears();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property2.getAsShortText(locale3);
        int int5 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime6 = property2.roundCeilingCopy();
        org.joda.time.DateTime dateTime7 = property2.roundHalfFloorCopy();
        int int8 = dateTime7.getWeekyear();
        int int9 = dateTime7.getDayOfYear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969" + "'", str4.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(69);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder2.setStandardOffset(1);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeZoneBuilder4.toDateTimeZone("centuryOfEra", true);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField4.getAsShortText(1967, locale8);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1967" + "'", str9.equals("1967"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        long long8 = dateTimeZone3.convertLocalToUTC(0L, false, (-62166758822109L));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYear(960);
        org.joda.time.DateTime dateTime9 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = dateTime3.withZoneRetainFields(dateTimeZone5);
        long long9 = dateTimeZone5.convertLocalToUTC((long) (byte) 0, true);
        int int11 = dateTimeZone5.getOffsetFromLocal(1L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone16 = dateTimeZoneBuilder13.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
        boolean boolean19 = cachedDateTimeZone17.equals((java.lang.Object) 57600002);
        int int21 = cachedDateTimeZone17.getStandardOffset((long) 54823);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter12.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone17);
        long long24 = dateTimeZone5.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone17, 62L);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime28 = dateTime26.minusDays((int) (short) -1);
        int int29 = dateTime26.getMillisOfDay();
        org.joda.time.DateTime dateTime30 = dateTime26.withTimeAtStartOfDay();
        org.joda.time.ReadablePartial readablePartial31 = null;
        org.joda.time.DateTime dateTime32 = dateTime26.withFields(readablePartial31);
        org.joda.time.DateMidnight dateMidnight33 = dateTime26.toDateMidnight();
        org.joda.time.DateTime dateTime35 = dateTime26.withMillis(2649600002L);
        int int36 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime26);
        java.util.TimeZone timeZone37 = dateTimeZone5.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forTimeZone(timeZone37);
        java.lang.String str39 = dateTimeZone38.getID();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800000L + "'", long9 == 28800000L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-28799938L) + "'", long24 == (-28799938L));
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 57600002 + "'", int29 == 57600002);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateMidnight33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-28800000) + "'", int36 == (-28800000));
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "America/Los_Angeles" + "'", str39.equals("America/Los_Angeles"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        int int4 = property2.getLeapAmount();
        int int5 = property2.getMinimumValue();
        org.joda.time.DateTime dateTime6 = property2.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime8 = dateTime6.minus(0L);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((int) (byte) -1);
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(100L, (org.joda.time.Chronology) gregorianChronology7);
        java.util.TimeZone timeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology7, dateTimeZone13);
        org.joda.time.DurationField durationField15 = gregorianChronology7.minutes();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        int int11 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property12 = dateTime1.centuryOfEra();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfEra();
        java.lang.String str16 = property15.getAsShortText();
        int int17 = property15.getMaximumValue();
        org.joda.time.DateTime dateTime18 = property15.withMaximumValue();
        org.joda.time.DateTime dateTime20 = dateTime18.minus((long) 1);
        org.joda.time.DateTime dateTime22 = dateTime20.plusMonths(0);
        long long23 = property12.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime20);
        java.util.Locale locale24 = null;
        java.lang.String str25 = property12.getAsShortText(locale24);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 292278993 + "'", int17 == 292278993);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-2922770L) + "'", long23 == (-2922770L));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "19" + "'", str25.equals("19"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime7 = dateTime3.plusYears(31);
        java.lang.Class<?> wildcardClass8 = dateTime3.getClass();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.plusYears(0);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.DateTime dateTime10 = property8.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear((int) (byte) 100);
        java.lang.String str13 = dateTime12.toString();
        boolean boolean14 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime12.toMutableDateTimeISO();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("Property[yearOfEra]", "Pacific Standard Time", 54823, 0);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property23 = dateTime22.yearOfEra();
        java.lang.String str24 = property23.getAsShortText();
        int int25 = property23.getMaximumValue();
        org.joda.time.DateTime dateTime26 = property23.withMaximumValue();
        int int27 = property23.get();
        boolean boolean28 = fixedDateTimeZone20.equals((java.lang.Object) int27);
        org.joda.time.DateTime dateTime29 = dateTime12.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.DateTime.Property property30 = dateTime12.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0100-01-05T16:00:00.002-07:52:58" + "'", str13.equals("0100-01-05T16:00:00.002-07:52:58"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969" + "'", str24.equals("1969"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 292278993 + "'", int25 == 292278993);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = dateTime3.withZoneRetainFields(dateTimeZone5);
        long long9 = dateTimeZone5.convertLocalToUTC((long) (byte) 0, true);
        int int11 = dateTimeZone5.getOffsetFromLocal(1L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone16 = dateTimeZoneBuilder13.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
        boolean boolean19 = cachedDateTimeZone17.equals((java.lang.Object) 57600002);
        int int21 = cachedDateTimeZone17.getStandardOffset((long) 54823);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter12.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone17);
        long long24 = dateTimeZone5.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone17, 62L);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime28 = dateTime26.minusDays((int) (short) -1);
        int int29 = dateTime26.getMillisOfDay();
        org.joda.time.DateTime dateTime30 = dateTime26.withTimeAtStartOfDay();
        org.joda.time.ReadablePartial readablePartial31 = null;
        org.joda.time.DateTime dateTime32 = dateTime26.withFields(readablePartial31);
        org.joda.time.DateMidnight dateMidnight33 = dateTime26.toDateMidnight();
        org.joda.time.DateTime dateTime35 = dateTime26.withMillis(2649600002L);
        int int36 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime26);
        java.util.TimeZone timeZone37 = dateTimeZone5.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forTimeZone(timeZone37);
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forTimeZone(timeZone37);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800000L + "'", long9 == 28800000L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-28799938L) + "'", long24 == (-28799938L));
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 57600002 + "'", int29 == 57600002);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateMidnight33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-28800000) + "'", int36 == (-28800000));
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.withYear(9);
        org.joda.time.DateTime dateTime13 = dateTime12.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime15 = dateTime13.minusHours(1969);
        org.joda.time.MutableDateTime mutableDateTime16 = dateTime13.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property17 = dateTime13.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime18 = dateTime13.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime20 = dateTime13.plusDays((-1));
        org.joda.time.DateTime dateTime22 = dateTime20.plusMillis(0);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        java.lang.String str9 = offsetDateTimeField4.getName();
        org.joda.time.DurationField durationField10 = offsetDateTimeField4.getLeapDurationField();
        long long13 = offsetDateTimeField4.add((long) 10, (long) 35);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField4.getAsShortText((int) (byte) 1, locale15);
        int int18 = offsetDateTimeField4.getMinimumValue((long) (short) 10);
        long long21 = offsetDateTimeField4.getDifferenceAsLong(70L, (long) (short) 0);
        boolean boolean22 = offsetDateTimeField4.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "yearOfEra" + "'", str9.equals("yearOfEra"));
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1104537600010L + "'", long13 == 1104537600010L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1" + "'", str16.equals("1"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readablePeriod5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.minutes();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (byte) -1);
        int int13 = offsetDateTimeField11.getLeapAmount((long) 10);
        long long15 = offsetDateTimeField11.roundHalfFloor(0L);
        java.lang.String str16 = offsetDateTimeField11.getName();
        long long18 = offsetDateTimeField11.roundHalfFloor((long) 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField11.getType();
        org.joda.time.DateTime dateTime21 = dateTime6.withField(dateTimeFieldType19, 1870);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "yearOfEra" + "'", str16.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTime21);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test315");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getSecondOfDay();
//        org.joda.time.DateTime.Property property2 = dateTime0.minuteOfDay();
//        java.lang.String str3 = property2.getAsString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 54873 + "'", int1 == 54873);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "914" + "'", str3.equals("914"));
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        int int9 = offsetDateTimeField4.getLeapAmount(35344512001852L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime4 = dateTime2.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate5 = dateTime4.toLocalDate();
        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate5);
        boolean boolean7 = dateTimeFormatter0.isPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withPivotYear((-292275054));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "T������.000" + "'", str6.equals("T������.000"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) (-57600002));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder4.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withLocale(locale7);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withLocale(locale9);
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.append(dateTimeParser11);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder4.appendFractionOfMinute((-1), (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder4.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withLocale(locale7);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withLocale(locale9);
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.append(dateTimeParser11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder4.appendClockhourOfDay(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder14.appendTimeZoneOffset("GregorianChronology[UTC]", true, 2, 292278992);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder20.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatterBuilder24.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale27 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter26.withLocale(locale27);
        java.util.Locale locale29 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter28.withLocale(locale29);
        org.joda.time.format.DateTimeParser dateTimeParser31 = dateTimeFormatter30.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder24.append(dateTimeParser31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder24.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale35 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter34.withLocale(locale35);
        org.joda.time.format.DateTimePrinter dateTimePrinter37 = dateTimeFormatter36.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser38 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter37, dateTimeParser38);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale41 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = dateTimeFormatter40.withLocale(locale41);
        java.util.Locale locale43 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = dateTimeFormatter42.withLocale(locale43);
        org.joda.time.DateTimeZone dateTimeZone45 = dateTimeFormatter44.getZone();
        org.joda.time.Chronology chronology46 = dateTimeFormatter44.getChronology();
        org.joda.time.format.DateTimeParser dateTimeParser47 = dateTimeFormatter44.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder24.append(dateTimePrinter37, dateTimeParser47);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder14.append(dateTimeParser47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeParser31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTimePrinter37);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertNull(dateTimeZone45);
        org.junit.Assert.assertNull(chronology46);
        org.junit.Assert.assertNotNull(dateTimeParser47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        int int4 = property2.getLeapAmount();
        java.lang.String str5 = property2.getAsShortText();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime9 = dateTime7.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime11 = dateTime9.plusYears(0);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
        org.joda.time.DateTime dateTime16 = property14.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime18 = dateTime16.withWeekyear((int) (byte) 100);
        java.lang.String str19 = dateTime18.toString();
        boolean boolean20 = dateTime11.isEqual((org.joda.time.ReadableInstant) dateTime18);
        int int21 = property2.compareTo((org.joda.time.ReadableInstant) dateTime18);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0100-01-05T16:00:00.002-07:52:58" + "'", str19.equals("0100-01-05T16:00:00.002-07:52:58"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendWeekyear(0, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendDayOfYear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendClockhourOfHalfday((int) 'a');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap20 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendTimeZoneName(strMap20);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale23 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter22.withLocale(locale23);
        org.joda.time.format.DateTimePrinter dateTimePrinter25 = dateTimeFormatter24.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser26 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter25, dateTimeParser26);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale29 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter28.withLocale(locale29);
        java.util.Locale locale31 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter30.withLocale(locale31);
        org.joda.time.DateTimeZone dateTimeZone33 = dateTimeFormatter32.getZone();
        org.joda.time.Chronology chronology34 = dateTimeFormatter32.getChronology();
        org.joda.time.format.DateTimeParser dateTimeParser35 = dateTimeFormatter32.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder36.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder36.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatterBuilder40.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale43 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = dateTimeFormatter42.withLocale(locale43);
        java.util.Locale locale45 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter44.withLocale(locale45);
        org.joda.time.format.DateTimeParser dateTimeParser47 = dateTimeFormatter46.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder40.append(dateTimeParser47);
        org.joda.time.format.DateTimeParser[] dateTimeParserArray49 = new org.joda.time.format.DateTimeParser[] { dateTimeParser35, dateTimeParser47 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder19.append(dateTimePrinter25, dateTimeParserArray49);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder51.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder51.appendClockhourOfHalfday((int) 'a');
        org.joda.time.format.DateTimeParser dateTimeParser56 = dateTimeFormatterBuilder55.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder50.append(dateTimeParser56);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder12.append(dateTimeParser56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTimePrinter25);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNull(dateTimeZone33);
        org.junit.Assert.assertNull(chronology34);
        org.junit.Assert.assertNotNull(dateTimeParser35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertNotNull(dateTimeFormatter46);
        org.junit.Assert.assertNotNull(dateTimeParser47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeParserArray49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
        org.junit.Assert.assertNotNull(dateTimeParser56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        java.lang.String str9 = offsetDateTimeField4.getName();
        int int11 = offsetDateTimeField4.getLeapAmount((-28799998L));
        boolean boolean13 = offsetDateTimeField4.isLeap((long) 57600001);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "yearOfEra" + "'", str9.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = dateTime3.withZoneRetainFields(dateTimeZone5);
        long long9 = dateTimeZone5.convertLocalToUTC((long) 100, false);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800100L + "'", long9 == 28800100L);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "DateTimeField[yearOfEra]", "GregorianChronology[UTC]");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "0", "centuryOfEra");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusSeconds((int) (byte) -1);
        org.joda.time.DateTime dateTime8 = dateTime1.withWeekyear(10);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime1.getZone();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600002 + "'", int4 == 57600002);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 56792, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test329");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getName((long) 9, locale12);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone8);
//        org.joda.time.Chronology chronology15 = zonedChronology14.withUTC();
//        org.joda.time.DurationField durationField16 = zonedChronology14.weekyears();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime.Property property21 = dateTime20.yearOfEra();
//        int int22 = dateTime18.compareTo((org.joda.time.ReadableInstant) dateTime20);
//        int int23 = dateTime20.getEra();
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime20.plus(readablePeriod24);
//        boolean boolean26 = zonedChronology14.equals((java.lang.Object) dateTime25);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime30 = dateTime28.minusDays((int) (short) -1);
//        java.util.TimeZone timeZone31 = null;
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forTimeZone(timeZone31);
//        org.joda.time.DateTime dateTime33 = dateTime30.withZoneRetainFields(dateTimeZone32);
//        long long36 = dateTimeZone32.convertLocalToUTC((long) (byte) 0, true);
//        int int38 = dateTimeZone32.getOffsetFromLocal(1L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder40 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone43 = dateTimeZoneBuilder40.toDateTimeZone("T151321.363-0700", false);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone44 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone43);
//        boolean boolean46 = cachedDateTimeZone44.equals((java.lang.Object) 57600002);
//        int int48 = cachedDateTimeZone44.getStandardOffset((long) 54823);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = dateTimeFormatter39.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone44);
//        long long51 = dateTimeZone32.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone44, 62L);
//        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime55 = dateTime53.minusDays((int) (short) -1);
//        int int56 = dateTime53.getMillisOfDay();
//        org.joda.time.DateTime dateTime57 = dateTime53.withTimeAtStartOfDay();
//        org.joda.time.ReadablePartial readablePartial58 = null;
//        org.joda.time.DateTime dateTime59 = dateTime53.withFields(readablePartial58);
//        org.joda.time.DateMidnight dateMidnight60 = dateTime53.toDateMidnight();
//        org.joda.time.DateTime dateTime62 = dateTime53.withMillis(2649600002L);
//        int int63 = dateTimeZone32.getOffset((org.joda.time.ReadableInstant) dateTime53);
//        java.util.TimeZone timeZone64 = dateTimeZone32.toTimeZone();
//        org.joda.time.DateTimeZone dateTimeZone65 = org.joda.time.DateTimeZone.forTimeZone(timeZone64);
//        org.joda.time.Chronology chronology66 = zonedChronology14.withZone(dateTimeZone65);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 28800000L + "'", long36 == 28800000L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-28800000) + "'", int38 == (-28800000));
//        org.junit.Assert.assertNotNull(dateTimeFormatter39);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone44);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter49);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-28799938L) + "'", long51 == (-28799938L));
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 57600002 + "'", int56 == 57600002);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(dateMidnight60);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-28800000) + "'", int63 == (-28800000));
//        org.junit.Assert.assertNotNull(timeZone64);
//        org.junit.Assert.assertNotNull(dateTimeZone65);
//        org.junit.Assert.assertNotNull(chronology66);
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        java.lang.String str9 = cachedDateTimeZone7.getNameKey(100L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.Chronology chronology12 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        boolean boolean6 = offsetDateTimeField4.isLeap((long) 'a');
        java.lang.String str7 = offsetDateTimeField4.getName();
        long long9 = offsetDateTimeField4.roundHalfEven(28800000L);
        long long12 = offsetDateTimeField4.addWrapField(4260240000000L, (int) (short) 1);
        boolean boolean14 = offsetDateTimeField4.isLeap(4291776000000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "yearOfEra" + "'", str7.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 4291776000000L + "'", long12 == 4291776000000L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        int int11 = dateTime7.compareTo((org.joda.time.ReadableInstant) dateTime9);
        int int12 = dateTime9.getEra();
        boolean boolean13 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime9);
        java.lang.Class<?> wildcardClass14 = dateTime3.getClass();
        boolean boolean16 = dateTime3.isBefore((long) 54866);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readablePeriod5);
        org.joda.time.TimeOfDay timeOfDay7 = dateTime1.toTimeOfDay();
        org.joda.time.DateTime.Property property8 = dateTime1.centuryOfEra();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("T151321.363-0700", "1", 292278993, (int) 'a');
        org.joda.time.DateTime dateTime14 = dateTime1.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        long long16 = fixedDateTimeZone13.previousTransition(0L);
        int int18 = fixedDateTimeZone13.getOffset(57600002L);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292278993 + "'", int18 == 292278993);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = dateTime3.withZoneRetainFields(dateTimeZone5);
        long long10 = dateTimeZone5.convertLocalToUTC((long) 1969, false, (long) 1);
        java.lang.String str11 = dateTimeZone5.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28801969L + "'", long10 == 28801969L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "America/Los_Angeles" + "'", str11.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime5 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime9 = dateTime7.minusDays((int) (short) -1);
        int int10 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfEra();
        int int16 = dateTime12.compareTo((org.joda.time.ReadableInstant) dateTime14);
        int int17 = dateTime14.getDayOfMonth();
        boolean boolean18 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime14);
        boolean boolean19 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime21 = dateTime7.withYear((int) '4');
        org.joda.time.DateTime dateTime23 = dateTime7.minusYears(0);
        org.joda.time.DateTime dateTime25 = dateTime7.withYearOfCentury(0);
        java.util.GregorianCalendar gregorianCalendar26 = dateTime25.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600002 + "'", int4 == 57600002);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600002 + "'", int10 == 57600002);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(gregorianCalendar26);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getCenturyOfEra();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readablePeriod5);
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.Interval interval8 = property7.toInterval();
        int int9 = property7.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(interval8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 4, dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Property[yearOfEra]", "Pacific Standard Time", 54823, 0);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.String str8 = property7.getAsShortText();
        int int9 = property7.getMaximumValue();
        org.joda.time.DateTime dateTime10 = property7.withMaximumValue();
        int int11 = property7.get();
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) int11);
        long long14 = fixedDateTimeZone4.nextTransition((long) 70);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean16 = fixedDateTimeZone4.equals((java.lang.Object) iSOChronology15);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField18 = gregorianChronology17.minutes();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) (byte) -1);
        int int23 = offsetDateTimeField21.getLeapAmount((long) 10);
        long long25 = offsetDateTimeField21.roundHalfFloor(0L);
        java.lang.String str26 = offsetDateTimeField21.getName();
        org.joda.time.DurationField durationField27 = offsetDateTimeField21.getLeapDurationField();
        long long30 = offsetDateTimeField21.add((long) 10, (long) 35);
        org.joda.time.DateTimeField dateTimeField31 = offsetDateTimeField21.getWrappedField();
        boolean boolean32 = iSOChronology15.equals((java.lang.Object) dateTimeField31);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 292278993 + "'", int9 == 292278993);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 70L + "'", long14 == 70L);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "yearOfEra" + "'", str26.equals("yearOfEra"));
        org.junit.Assert.assertNull(durationField27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1104537600010L + "'", long30 == 1104537600010L);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test339");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
//        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
//        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
//        long long10 = offsetDateTimeField4.roundHalfFloor(0L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.basicTTime();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime15 = dateTime13.plusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate16 = dateTime15.toLocalDate();
//        java.lang.String str17 = dateTimeFormatter11.print((org.joda.time.ReadablePartial) localDate16);
//        int[] intArray24 = new int[] { 1969, 100, ' ', 10, 2 };
//        int[] intArray26 = offsetDateTimeField4.set((org.joda.time.ReadablePartial) localDate16, 0, intArray24, (int) (byte) 100);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = offsetDateTimeField4.getAsText((-1313999948L), locale28);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime.Property property32 = dateTime31.yearOfEra();
//        java.lang.String str33 = property32.getAsShortText();
//        int int34 = property32.getMaximumValue();
//        org.joda.time.DateTime dateTime35 = property32.withMaximumValue();
//        org.joda.time.DateTime dateTime37 = dateTime35.minus((long) 1);
//        org.joda.time.DateTime dateTime39 = dateTime37.plusMonths(0);
//        org.joda.time.DateTime.Property property40 = dateTime37.era();
//        org.joda.time.DateTime.Property property41 = dateTime37.dayOfYear();
//        int int42 = dateTime37.getDayOfMonth();
//        org.joda.time.DateTime dateTime43 = dateTime37.toDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField45 = gregorianChronology44.minutes();
//        org.joda.time.ReadablePeriod readablePeriod46 = null;
//        long long49 = gregorianChronology44.add(readablePeriod46, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone51 = null;
//        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forTimeZone(timeZone51);
//        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone52);
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((long) 100, dateTimeZone52);
//        java.util.Locale locale56 = null;
//        java.lang.String str57 = dateTimeZone52.getName((long) 9, locale56);
//        org.joda.time.chrono.ZonedChronology zonedChronology58 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology44, dateTimeZone52);
//        org.joda.time.DateTimeZone dateTimeZone59 = zonedChronology58.getZone();
//        org.joda.time.MutableDateTime mutableDateTime60 = dateTime43.toMutableDateTime(dateTimeZone59);
//        org.joda.time.LocalDate localDate61 = dateTime43.toLocalDate();
//        int[] intArray67 = new int[] { 54873, (-1), (-1), 2 };
//        java.util.Locale locale69 = null;
//        try {
//            int[] intArray70 = offsetDateTimeField4.set((org.joda.time.ReadablePartial) localDate61, 0, intArray67, "America/Los_Angeles", locale69);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"America/Los_Angeles\" for yearOfEra is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "T������.000" + "'", str17.equals("T������.000"));
//        org.junit.Assert.assertNotNull(intArray24);
//        org.junit.Assert.assertNotNull(intArray26);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1968" + "'", str29.equals("1968"));
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1969" + "'", str33.equals("1969"));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 292278993 + "'", int34 == 292278993);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 31 + "'", int42 == 31);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(gregorianChronology44);
//        org.junit.Assert.assertNotNull(durationField45);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//        org.junit.Assert.assertNotNull(gregorianChronology53);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Pacific Standard Time" + "'", str57.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology58);
//        org.junit.Assert.assertNotNull(dateTimeZone59);
//        org.junit.Assert.assertNotNull(mutableDateTime60);
//        org.junit.Assert.assertNotNull(localDate61);
//        org.junit.Assert.assertNotNull(intArray67);
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        int int6 = dateTime3.getEra();
        org.joda.time.DateTime dateTime8 = dateTime3.plusMonths(8);
        boolean boolean9 = dateTime3.isEqualNow();
        int int10 = dateTime3.getDayOfWeek();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readablePeriod5);
        org.joda.time.TimeOfDay timeOfDay7 = dateTime1.toTimeOfDay();
        org.joda.time.DateTime.Property property8 = dateTime1.centuryOfEra();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("T151321.363-0700", "1", 292278993, (int) 'a');
        org.joda.time.DateTime dateTime14 = dateTime1.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        int int15 = dateTime1.getYearOfCentury();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 69 + "'", int15 == 69);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("T160000.052-0800");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"T160000.052-0800/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getCenturyOfEra();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readablePeriod5);
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        int int9 = dateTime1.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfYear();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime1.plus(readablePeriod8);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property2.getAsShortText(locale3);
        int int5 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime6 = property2.roundCeilingCopy();
        org.joda.time.DateTime dateTime7 = property2.roundHalfFloorCopy();
        int int8 = dateTime7.getWeekyear();
        java.util.Locale locale10 = null;
        try {
            java.lang.String str11 = dateTime7.toString("UTC", locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: U");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969" + "'", str4.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1970 + "'", int8 == 1970);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser4 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter3, dateTimeParser4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withLocale(locale7);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withLocale(locale9);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeFormatter10.getZone();
        org.joda.time.Chronology chronology12 = dateTimeFormatter10.getChronology();
        org.joda.time.format.DateTimeParser dateTimeParser13 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter3, dateTimeParser13);
        try {
            org.joda.time.LocalTime localTime16 = dateTimeFormatter14.parseLocalTime("1968");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1968\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNull(dateTimeZone11);
        org.junit.Assert.assertNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeParser13);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        long long10 = offsetDateTimeField4.roundHalfFloor(0L);
        long long12 = offsetDateTimeField4.roundCeiling(2649600002L);
        long long14 = offsetDateTimeField4.roundHalfFloor((-61820064000000L));
        long long17 = offsetDateTimeField4.getDifferenceAsLong((long) 12, (long) (byte) -1);
        try {
            long long20 = offsetDateTimeField4.set(9223372017129600001L, "yearOfEra");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"yearOfEra\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31536000000L + "'", long12 == 31536000000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61820064000000L) + "'", long14 == (-61820064000000L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = property2.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime6 = dateTime4.withWeekyear((int) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime6.minusHours(2);
        org.joda.time.DateTime dateTime10 = dateTime8.minusMillis(35);
        org.joda.time.TimeOfDay timeOfDay11 = dateTime8.toTimeOfDay();
        org.joda.time.DateTime dateTime13 = dateTime8.withYear(1870);
        org.joda.time.DateTime dateTime15 = dateTime13.plus((long) 69);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(timeOfDay11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test349");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
//        java.util.Locale locale1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
//        java.util.Locale locale3 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withLocale(locale3);
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        java.lang.String str6 = dateTimeFormatter4.print(readableInstant5);
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTimeFormatter4.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter4.withZoneUTC();
//        boolean boolean9 = dateTimeFormatter8.isOffsetParsed();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "T151436.948-0700" + "'", str6.equals("T151436.948-0700"));
//        org.junit.Assert.assertNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        java.lang.String str8 = offsetDateTimeField4.getName();
        long long10 = offsetDateTimeField4.roundHalfFloor((long) (byte) -1);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField4.getMaximumTextLength(locale11);
        boolean boolean13 = offsetDateTimeField4.isLenient();
        int int16 = offsetDateTimeField4.getDifference((long) (short) 10, 8L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        int int5 = dateTime4.getYearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime4.minus(1L);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology8);
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime4, (java.lang.Object) chronology9);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTime4.getZone();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 69 + "'", int5 == 69);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("DateTimeField[yearOfEra]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'DateTimeField[yearOfEra]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readablePeriod5);
        org.joda.time.DateTime dateTime8 = dateTime1.plusYears(0);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime1.toMutableDateTime();
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 100, dateTimeZone12);
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime1.toMutableDateTime(dateTimeZone12);
        boolean boolean17 = dateTime1.isAfter((long) 8);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) '#', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property2.getAsShortText(locale3);
        int int5 = property2.getMaximumValue();
        java.lang.String str6 = property2.getAsString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property2.getAsShortText(locale7);
        org.joda.time.DateTime dateTime9 = property2.roundFloorCopy();
        org.joda.time.Interval interval10 = property2.toInterval();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969" + "'", str4.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(interval10);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneName(strMap5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withLocale(locale8);
        org.joda.time.format.DateTimePrinter dateTimePrinter10 = dateTimeFormatter9.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser11 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter10, dateTimeParser11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withLocale(locale14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withLocale(locale16);
        org.joda.time.DateTimeZone dateTimeZone18 = dateTimeFormatter17.getZone();
        org.joda.time.Chronology chronology19 = dateTimeFormatter17.getChronology();
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder21.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatterBuilder25.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale28 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withLocale(locale28);
        java.util.Locale locale30 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter29.withLocale(locale30);
        org.joda.time.format.DateTimeParser dateTimeParser32 = dateTimeFormatter31.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder25.append(dateTimeParser32);
        org.joda.time.format.DateTimeParser[] dateTimeParserArray34 = new org.joda.time.format.DateTimeParser[] { dateTimeParser20, dateTimeParser32 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder4.append(dateTimePrinter10, dateTimeParserArray34);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder36.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder36.appendClockhourOfHalfday((int) 'a');
        org.joda.time.format.DateTimeParser dateTimeParser41 = dateTimeFormatterBuilder40.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder35.append(dateTimeParser41);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.format.DateTimeParser dateTimeParser44 = dateTimeFormatter43.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder35.appendOptional(dateTimeParser44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder45.appendMinuteOfHour(365);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimePrinter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNull(dateTimeZone18);
        org.junit.Assert.assertNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeParser32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeParserArray34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
        org.junit.Assert.assertNotNull(dateTimeParser41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertNotNull(dateTimeParser44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        int int3 = property2.getLeapAmount();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property2.getAsShortText(locale4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((java.lang.Integer) 365);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.LocalDate localDate11 = dateTimeFormatter9.parseLocalDate("T151324.051-0700");
        java.lang.String str12 = dateTimeFormatter8.print((org.joda.time.ReadablePartial) localDate11);
        int int13 = property2.compareTo((org.joda.time.ReadablePartial) localDate11);
        java.lang.String str14 = property2.toString();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "��:��" + "'", str12.equals("��:��"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Property[yearOfEra]" + "'", str14.equals("Property[yearOfEra]"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        int int11 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property12 = dateTime1.centuryOfEra();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfEra();
        java.lang.String str16 = property15.getAsShortText();
        int int17 = property15.getMaximumValue();
        org.joda.time.DateTime dateTime18 = property15.withMaximumValue();
        org.joda.time.DateTime dateTime20 = dateTime18.minus((long) 1);
        org.joda.time.DateTime dateTime22 = dateTime20.plusMonths(0);
        long long23 = property12.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime20);
        long long24 = property12.remainder();
        org.joda.time.DateTime dateTime25 = property12.roundHalfCeilingCopy();
        java.lang.String str26 = property12.toString();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 292278993 + "'", int17 == 292278993);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-2922770L) + "'", long23 == (-2922770L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-28799998L) + "'", long24 == (-28799998L));
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Property[centuryOfEra]" + "'", str26.equals("Property[centuryOfEra]"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property2.getAsShortText(locale3);
        int int5 = property2.getMaximumValue();
        java.lang.String str6 = property2.getAsString();
        org.joda.time.DateTime dateTime7 = property2.roundCeilingCopy();
        int int8 = property2.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969" + "'", str4.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 292278993 + "'", int8 == 292278993);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "T151320.765-0700");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendSecondOfDay((int) (short) 10);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap9 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTimeZoneName(strMap9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((-1));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setFixedSavings("+00:00", 0);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test364");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        int int1 = dateTime0.getSecondOfDay();
//        org.joda.time.DateTime dateTime2 = dateTime0.withTimeAtStartOfDay();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 54877 + "'", int1 == 54877);
//        org.junit.Assert.assertNotNull(dateTime2);
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder4.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withLocale(locale7);
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatter8.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser10 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter9, dateTimeParser10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder12.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder17.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatterBuilder21.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale24 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter23.withLocale(locale24);
        java.util.Locale locale26 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter25.withLocale(locale26);
        org.joda.time.format.DateTimeParser dateTimeParser28 = dateTimeFormatter27.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder21.append(dateTimeParser28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder16.append(dateTimeParser28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder4.append(dateTimePrinter9, dateTimeParser28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(dateTimeParser28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 35, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime9 = dateTime8.withLaterOffsetAtOverlap();
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology13);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology13.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField18 = gregorianChronology17.minutes();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) (byte) -1);
        int int23 = offsetDateTimeField21.getLeapAmount((long) 10);
        long long25 = offsetDateTimeField21.roundHalfFloor(0L);
        long long27 = offsetDateTimeField21.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime32 = dateTime30.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate33 = dateTime32.toLocalDate();
        java.lang.String str34 = dateTimeFormatter28.print((org.joda.time.ReadablePartial) localDate33);
        int[] intArray41 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray43 = offsetDateTimeField21.set((org.joda.time.ReadablePartial) localDate33, 0, intArray41, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField45 = gregorianChronology44.minutes();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology44.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField(dateTimeField46, (int) (byte) -1);
        int int50 = offsetDateTimeField48.getLeapAmount((long) 10);
        long long52 = offsetDateTimeField48.roundHalfFloor(0L);
        long long54 = offsetDateTimeField48.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime59 = dateTime57.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate60 = dateTime59.toLocalDate();
        java.lang.String str61 = dateTimeFormatter55.print((org.joda.time.ReadablePartial) localDate60);
        int[] intArray68 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray70 = offsetDateTimeField48.set((org.joda.time.ReadablePartial) localDate60, 0, intArray68, (int) (byte) 100);
        gregorianChronology13.validate((org.joda.time.ReadablePartial) localDate33, intArray70);
        org.joda.time.ReadablePeriod readablePeriod72 = null;
        long long75 = gregorianChronology13.add(readablePeriod72, 0L, (int) (byte) 0);
        org.joda.time.DateTime dateTime76 = dateTime8.withChronology((org.joda.time.Chronology) gregorianChronology13);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "T������.000" + "'", str34.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(gregorianChronology44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter55);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localDate60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "T������.000" + "'", str61.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 0L + "'", long75 == 0L);
        org.junit.Assert.assertNotNull(dateTime76);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property2.getAsShortText(locale3);
        int int5 = property2.getMaximumValue();
        java.lang.String str6 = property2.getAsString();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property2.getAsShortText(locale7);
        org.joda.time.DateTime dateTime10 = property2.addToCopy(1L);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969" + "'", str4.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        int int4 = property2.getLeapAmount();
        org.joda.time.DurationField durationField5 = property2.getDurationField();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        int int11 = dateTime7.compareTo((org.joda.time.ReadableInstant) dateTime9);
        int int12 = dateTime9.getEra();
        org.joda.time.DateTime.Property property13 = dateTime9.monthOfYear();
        org.joda.time.DateTime dateTime15 = property13.addToCopy((long) (byte) 10);
        int int16 = property2.getDifference((org.joda.time.ReadableInstant) dateTime15);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfDay(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatterBuilder6.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        java.lang.String str4 = property2.toString();
        int int5 = property2.getMaximumValue();
        boolean boolean6 = property2.isLeap();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[yearOfEra]" + "'", str4.equals("Property[yearOfEra]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.plusYears(0);
        org.joda.time.DateTime dateTime7 = dateTime3.withWeekyear(2922789);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        java.lang.String str8 = offsetDateTimeField4.getName();
        long long10 = offsetDateTimeField4.roundHalfFloor((long) (byte) -1);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField4.getMaximumTextLength(locale11);
        int int14 = offsetDateTimeField4.getLeapAmount((long) 'a');
        int int17 = offsetDateTimeField4.getDifference((long) 0, 0L);
        java.util.Locale locale18 = null;
        int int19 = offsetDateTimeField4.getMaximumTextLength(locale18);
        java.util.Locale locale20 = null;
        int int21 = offsetDateTimeField4.getMaximumTextLength(locale20);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        org.joda.time.DurationField durationField7 = offsetDateTimeField4.getLeapDurationField();
        long long10 = offsetDateTimeField4.set((-1L), 100);
        int int13 = offsetDateTimeField4.getDifference(28800100L, (long) 1);
        java.lang.String str14 = offsetDateTimeField4.getName();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-58948387200001L) + "'", long10 == (-58948387200001L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "yearOfEra" + "'", str14.equals("yearOfEra"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime1.plusMinutes(1920);
        org.joda.time.DateTime dateTime7 = dateTime1.withDayOfYear(31);
        try {
            org.joda.time.DateTime dateTime9 = dateTime1.withMinuteOfHour(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        java.lang.String str6 = cachedDateTimeZone4.getNameKey(100L);
        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone4.getUncachedZone();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        java.lang.Object obj9 = null;
        boolean boolean10 = iSOChronology8.equals(obj9);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("Property[yearOfEra]", "Pacific Standard Time", 54823, 0);
        boolean boolean9 = fixedDateTimeZone8.isFixed();
        int int11 = fixedDateTimeZone8.getOffset(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone8);
        try {
            long long17 = zonedChronology12.getDateTimeMillis(69, 292278993, 8, 31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 54823 + "'", int11 == 54823);
        org.junit.Assert.assertNotNull(zonedChronology12);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        java.util.Locale locale4 = null;
        int int5 = property2.getMaximumShortTextLength(locale4);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfYear(292278993);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfEra();
        int int10 = dateTime6.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime.Property property12 = dateTime6.dayOfYear();
        int int13 = property12.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property12.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType14);
        boolean boolean20 = dateTimeFormatterBuilder4.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 365 + "'", int13 == 365);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology3.months();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology3.hourOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime5 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime9 = dateTime7.minusDays((int) (short) -1);
        int int10 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfEra();
        int int16 = dateTime12.compareTo((org.joda.time.ReadableInstant) dateTime14);
        int int17 = dateTime14.getDayOfMonth();
        boolean boolean18 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime14);
        boolean boolean19 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime21 = dateTime7.withYear((int) '4');
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField23 = gregorianChronology22.minutes();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) (byte) -1);
        long long29 = offsetDateTimeField26.add((long) 135, (long) 100);
        long long32 = offsetDateTimeField26.add(100L, (int) (short) 0);
        int int33 = dateTime7.get((org.joda.time.DateTimeField) offsetDateTimeField26);
        org.joda.time.ReadablePartial readablePartial34 = null;
        org.joda.time.DateTime dateTime35 = dateTime7.withFields(readablePartial34);
        org.joda.time.LocalDate localDate36 = dateTime35.toLocalDate();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600002 + "'", int4 == 57600002);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600002 + "'", int10 == 57600002);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 3155760000135L + "'", long29 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 100L + "'", long32 == 100L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1969 + "'", int33 == 1969);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(localDate36);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Property[yearOfEra]", "Pacific Standard Time", 54823, 0);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        int int7 = fixedDateTimeZone4.getStandardOffset(0L);
        int int9 = fixedDateTimeZone4.getStandardOffset(0L);
        java.lang.String str11 = fixedDateTimeZone4.getShortName((long) (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:54.823" + "'", str11.equals("+00:00:54.823"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.withYear(9);
        org.joda.time.DateTimeZone dateTimeZone13 = dateTime12.getZone();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.LocalDate localDate3 = dateTimeFormatter1.parseLocalDate("T151324.051-0700");
        org.joda.time.Chronology chronology4 = dateTimeFormatter1.getChronology();
        try {
            org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.parse("0100-01-05T16:00:00.002-07:52:58", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"0100-01-05T16:00:00.002-07:52:58\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNull(chronology4);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.minutes();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (byte) -1);
        int int13 = offsetDateTimeField11.getLeapAmount((long) 10);
        long long15 = offsetDateTimeField11.roundHalfFloor(0L);
        long long17 = offsetDateTimeField11.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime22 = dateTime20.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate23 = dateTime22.toLocalDate();
        java.lang.String str24 = dateTimeFormatter18.print((org.joda.time.ReadablePartial) localDate23);
        int[] intArray31 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray33 = offsetDateTimeField11.set((org.joda.time.ReadablePartial) localDate23, 0, intArray31, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField35 = gregorianChronology34.minutes();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, (int) (byte) -1);
        int int40 = offsetDateTimeField38.getLeapAmount((long) 10);
        long long42 = offsetDateTimeField38.roundHalfFloor(0L);
        long long44 = offsetDateTimeField38.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime49 = dateTime47.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate50 = dateTime49.toLocalDate();
        java.lang.String str51 = dateTimeFormatter45.print((org.joda.time.ReadablePartial) localDate50);
        int[] intArray58 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray60 = offsetDateTimeField38.set((org.joda.time.ReadablePartial) localDate50, 0, intArray58, (int) (byte) 100);
        gregorianChronology3.validate((org.joda.time.ReadablePartial) localDate23, intArray60);
        org.joda.time.DurationField durationField62 = gregorianChronology3.centuries();
        org.joda.time.Chronology chronology63 = gregorianChronology3.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "T������.000" + "'", str24.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter45);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "T������.000" + "'", str51.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(chronology63);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test387");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
//        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
//        org.joda.time.DateTime.Property property7 = dateTime1.dayOfYear();
//        int int8 = property7.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField15 = gregorianChronology14.minutes();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        long long19 = gregorianChronology14.add(readablePeriod16, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 100, dateTimeZone22);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone22.getName((long) 9, locale26);
//        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology14, dateTimeZone22);
//        org.joda.time.Chronology chronology29 = zonedChronology28.withUTC();
//        org.joda.time.DurationField durationField30 = zonedChronology28.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField30);
//        try {
//            boolean boolean33 = unsupportedDateTimeField31.isLeap((long) 2);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 365 + "'", int8 == 365);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Pacific Standard Time" + "'", str27.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        int int4 = property2.getMaximumShortTextLength(locale3);
        org.joda.time.DateTime dateTime5 = property2.withMaximumValue();
        boolean boolean6 = dateTime5.isBeforeNow();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (-28799938L), 292278993);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 292278993);
        int int4 = offsetDateTimeField3.getMinimumValue();
        int int6 = offsetDateTimeField3.getLeapAmount(35344512001820L);
        long long9 = offsetDateTimeField3.add(2649600002L, 960);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 292278993 + "'", int4 == 292278993);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 6105600002L + "'", long9 == 6105600002L);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) -1, 1970);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1970L) + "'", long2 == (-1970L));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "T151320.765-0700");
        java.lang.Number number3 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (byte) 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Property[yearOfEra]", "Pacific Standard Time", 54823, 0);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        int int7 = fixedDateTimeZone4.getOffset(0L);
        org.joda.time.ReadableInstant readableInstant8 = null;
        int int9 = fixedDateTimeZone4.getOffset(readableInstant8);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 54823 + "'", int7 == 54823);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 54823 + "'", int9 == 54823);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField14 = gregorianChronology13.minutes();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) (byte) -1);
        int int19 = offsetDateTimeField17.getLeapAmount((long) 10);
        long long21 = offsetDateTimeField17.roundHalfFloor(0L);
        long long23 = offsetDateTimeField17.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime28 = dateTime26.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate29 = dateTime28.toLocalDate();
        java.lang.String str30 = dateTimeFormatter24.print((org.joda.time.ReadablePartial) localDate29);
        int[] intArray37 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray39 = offsetDateTimeField17.set((org.joda.time.ReadablePartial) localDate29, 0, intArray37, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField41 = gregorianChronology40.minutes();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, (int) (byte) -1);
        int int46 = offsetDateTimeField44.getLeapAmount((long) 10);
        long long48 = offsetDateTimeField44.roundHalfFloor(0L);
        long long50 = offsetDateTimeField44.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime55 = dateTime53.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate56 = dateTime55.toLocalDate();
        java.lang.String str57 = dateTimeFormatter51.print((org.joda.time.ReadablePartial) localDate56);
        int[] intArray64 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray66 = offsetDateTimeField44.set((org.joda.time.ReadablePartial) localDate56, 0, intArray64, (int) (byte) 100);
        gregorianChronology9.validate((org.joda.time.ReadablePartial) localDate29, intArray66);
        int[] intArray69 = gregorianChronology3.get((org.joda.time.ReadablePartial) localDate29, (long) 1920);
        org.joda.time.DateTimeField dateTimeField70 = gregorianChronology3.weekyearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "T������.000" + "'", str30.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter51);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "T������.000" + "'", str57.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(dateTimeField70);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 279);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime1.plus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime8.weekOfWeekyear();
        int int10 = property9.get();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test398");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
//        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
//        org.joda.time.DateTime.Property property7 = dateTime1.dayOfYear();
//        int int8 = property7.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField15 = gregorianChronology14.minutes();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        long long19 = gregorianChronology14.add(readablePeriod16, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 100, dateTimeZone22);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone22.getName((long) 9, locale26);
//        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology14, dateTimeZone22);
//        org.joda.time.Chronology chronology29 = zonedChronology28.withUTC();
//        org.joda.time.DurationField durationField30 = zonedChronology28.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField30);
//        org.joda.time.ReadablePartial readablePartial32 = null;
//        int[] intArray34 = null;
//        try {
//            int[] intArray36 = unsupportedDateTimeField31.addWrapPartial(readablePartial32, 8, intArray34, (int) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 365 + "'", int8 == 365);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Pacific Standard Time" + "'", str27.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        int int4 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime5 = property2.withMaximumValue();
        org.joda.time.DateTime dateTime7 = dateTime5.minus((long) 1);
        org.joda.time.DateTime dateTime9 = dateTime7.plusMonths(0);
        org.joda.time.DateTime dateTime10 = dateTime7.toDateTime();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime14 = dateTime12.minusDays((int) (short) -1);
        java.util.TimeZone timeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
        org.joda.time.DateTime dateTime17 = dateTime14.withZoneRetainFields(dateTimeZone16);
        long long20 = dateTimeZone16.convertLocalToUTC((long) 100, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone21 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
        org.joda.time.DateTime dateTime23 = dateTime7.withZone(dateTimeZone16);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 292278993 + "'", int4 == 292278993);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 28800100L + "'", long20 == 28800100L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        int int4 = property2.getLeapAmount();
        java.lang.String str5 = property2.getAsShortText();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.DateTime dateTime10 = property8.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear((int) (byte) 100);
        org.joda.time.DateTime dateTime14 = dateTime12.minusHours(2);
        org.joda.time.DateTime dateTime16 = dateTime14.minusMillis(35);
        org.joda.time.TimeOfDay timeOfDay17 = dateTime14.toTimeOfDay();
        boolean boolean18 = org.joda.time.field.FieldUtils.equals((java.lang.Object) str5, (java.lang.Object) timeOfDay17);
        boolean boolean19 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) timeOfDay17);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(timeOfDay17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        org.joda.time.DurationField durationField7 = offsetDateTimeField4.getLeapDurationField();
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField4.getMaximumShortTextLength(locale8);
        long long12 = offsetDateTimeField4.add((long) (-1), (long) 'a');
        long long14 = offsetDateTimeField4.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property19 = dateTime18.yearOfEra();
        int int20 = dateTime16.compareTo((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime.Property property21 = dateTime16.weekOfWeekyear();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfYear();
        int int23 = property22.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property22.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField30 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType24, 57600002);
        long long32 = remainderDateTimeField30.roundCeiling((long) 31);
        long long34 = remainderDateTimeField30.remainder((-62166758822109L));
        long long36 = remainderDateTimeField30.roundHalfCeiling((long) 19);
        org.joda.time.DurationField durationField37 = remainderDateTimeField30.getRangeDurationField();
        long long39 = remainderDateTimeField30.roundCeiling(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3061065599999L + "'", long12 == 3061065599999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 31536000000L + "'", long32 == 31536000000L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 460377891L + "'", long34 == 460377891L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.era();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.dayOfYear();
        int int4 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime9 = dateTime8.withLaterOffsetAtOverlap();
        boolean boolean11 = dateTime9.isAfter(0L);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildPrinter();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendHourOfDay((-28378000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfEra();
        java.lang.String str4 = property3.getAsShortText();
        int int5 = property3.getMaximumValue();
        org.joda.time.DateTime dateTime6 = property3.withMaximumValue();
        org.joda.time.DateTime dateTime8 = dateTime6.minus((long) 1);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMonths(0);
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withChronology(chronology11);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969" + "'", str4.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        int int6 = dateTime3.getEra();
        org.joda.time.DateTime dateTime8 = dateTime3.plusMonths(8);
        boolean boolean9 = dateTime3.isEqualNow();
        org.joda.time.DateTime dateTime11 = dateTime3.plusMonths(365);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getSecondOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600 + "'", int4 == 57600);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendWeekyear(0, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendDayOfYear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendHourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter17.withZone(dateTimeZone19);
        org.joda.time.format.DateTimePrinter dateTimePrinter22 = dateTimeFormatter17.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder23.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder28.appendClockhourOfHalfday((int) 'a');
        org.joda.time.format.DateTimeParser dateTimeParser33 = dateTimeFormatterBuilder32.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder23.append(dateTimeParser33);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder14.append(dateTimePrinter22, dateTimeParser33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimePrinter22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeParser33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime9 = dateTime8.withLaterOffsetAtOverlap();
        int int10 = dateTime8.getDayOfMonth();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendSecondOfMinute(35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendTwoDigitYear((int) ' ', false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder3.appendDayOfWeek(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfYear(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("T151333.319-0700", "0", 2, (int) ' ');
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((-61820063999990L), (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean8 = dateTime6.isBefore((long) 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendSecondOfMinute(35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendFractionOfDay(2, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendWeekOfWeekyear((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.String str8 = property7.getAsShortText();
        int int9 = property7.getMaximumValue();
        org.joda.time.DateTime dateTime10 = property7.withMaximumValue();
        org.joda.time.DateTime dateTime12 = dateTime10.minus((long) 1);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMonths(0);
        org.joda.time.DateTime dateTime16 = dateTime14.minusYears(292278993);
        boolean boolean17 = dateTime1.isEqual((org.joda.time.ReadableInstant) dateTime16);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 292278993 + "'", int9 == 292278993);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfEra();
        int int6 = dateTime2.compareTo((org.joda.time.ReadableInstant) dateTime4);
        java.lang.String str7 = dateTime2.toString();
        org.joda.time.DateTime dateTime9 = dateTime2.withYearOfEra(135);
        java.lang.String str10 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime9);
        java.util.Locale locale11 = dateTimeFormatter0.getLocale();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField13 = gregorianChronology12.minutes();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) -1);
        int int18 = offsetDateTimeField16.getLeapAmount((long) 10);
        long long20 = offsetDateTimeField16.roundHalfFloor(0L);
        long long22 = offsetDateTimeField16.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime27 = dateTime25.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate28 = dateTime27.toLocalDate();
        java.lang.String str29 = dateTimeFormatter23.print((org.joda.time.ReadablePartial) localDate28);
        int[] intArray36 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray38 = offsetDateTimeField16.set((org.joda.time.ReadablePartial) localDate28, 0, intArray36, (int) (byte) 100);
        java.lang.String str39 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate28);
        boolean boolean40 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate28);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str7.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "01351231" + "'", str10.equals("01351231"));
        org.junit.Assert.assertNull(locale11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "T������.000" + "'", str29.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "19691231" + "'", str39.equals("19691231"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(69);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setFixedSavings("1969-12-31T16:00:00.002-08:00", (int) ' ');
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime10 = dateTime8.plusSeconds((int) (short) 10);
        org.joda.time.DateTime.Property property11 = dateTime10.millisOfDay();
        org.joda.time.DateTime dateTime13 = dateTime10.plusDays(0);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime17 = dateTime15.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime19 = dateTime17.plusYears(0);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property22 = dateTime21.yearOfEra();
        org.joda.time.DateTime dateTime24 = property22.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime26 = dateTime24.withWeekyear((int) (byte) 100);
        java.lang.String str27 = dateTime26.toString();
        boolean boolean28 = dateTime19.isEqual((org.joda.time.ReadableInstant) dateTime26);
        org.joda.time.MutableDateTime mutableDateTime29 = dateTime26.toMutableDateTimeISO();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone34 = new org.joda.time.tz.FixedDateTimeZone("Property[yearOfEra]", "Pacific Standard Time", 54823, 0);
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property37 = dateTime36.yearOfEra();
        java.lang.String str38 = property37.getAsShortText();
        int int39 = property37.getMaximumValue();
        org.joda.time.DateTime dateTime40 = property37.withMaximumValue();
        int int41 = property37.get();
        boolean boolean42 = fixedDateTimeZone34.equals((java.lang.Object) int41);
        org.joda.time.DateTime dateTime43 = dateTime26.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone34);
        org.joda.time.DateTime dateTime44 = dateTime10.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone34);
        try {
            org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(960, (-10), 57600, 0, 54870, 2, 292278993, (org.joda.time.DateTimeZone) fixedDateTimeZone34);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54870 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0100-01-05T16:00:00.002-07:52:58" + "'", str27.equals("0100-01-05T16:00:00.002-07:52:58"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(mutableDateTime29);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1969" + "'", str38.equals("1969"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 292278993 + "'", int39 == 292278993);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime44);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        int int4 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime5 = property2.withMaximumValue();
        org.joda.time.DateTime dateTime7 = dateTime5.minus((long) 1);
        org.joda.time.DateTime dateTime9 = dateTime7.plusMonths(0);
        org.joda.time.DateTime.Property property10 = dateTime7.era();
        java.lang.String str11 = property10.getAsShortText();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 292278993 + "'", int4 == 292278993);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "AD" + "'", str11.equals("AD"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZone(dateTimeZone3);
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatter1.getPrinter();
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.minuteOfDay();
        org.joda.time.DurationField durationField13 = gregorianChronology10.months();
        org.joda.time.DurationField durationField14 = gregorianChronology10.months();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DurationField durationField16 = gregorianChronology10.hours();
        org.joda.time.DurationField durationField17 = gregorianChronology10.halfdays();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField18 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimePrinter6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology3.months();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology3.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone2 = iSOChronology0.getZone();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        int int5 = dateTime4.getYearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime4.minus(1L);
        org.joda.time.DateTime.Property property8 = dateTime4.secondOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 69 + "'", int5 == 69);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = cachedDateTimeZone4.getUncachedZone();
        boolean boolean6 = cachedDateTimeZone4.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 53, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology4);
        long long9 = gregorianChronology4.add((long) 'a', (long) (-10), 0);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfEra();
        java.lang.String str13 = property12.getAsShortText();
        int int14 = property12.getMaximumValue();
        org.joda.time.DateTime dateTime15 = property12.withMaximumValue();
        org.joda.time.DateTime dateTime17 = dateTime15.minus((long) 1);
        org.joda.time.DateTime dateTime19 = dateTime17.plusMonths(0);
        org.joda.time.DateTime dateTime21 = dateTime19.minusYears(292278993);
        boolean boolean22 = gregorianChronology4.equals((java.lang.Object) dateTime19);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) 100, (org.joda.time.Chronology) gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969" + "'", str13.equals("1969"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 292278993 + "'", int14 == 292278993);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        int int6 = dateTime3.getEra();
        org.joda.time.DateTime.Property property7 = dateTime3.monthOfYear();
        org.joda.time.DateTime.Property property8 = dateTime3.secondOfMinute();
        int int9 = dateTime3.getMillisOfDay();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 57600002 + "'", int9 == 57600002);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "T151333.319-0700");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        int int4 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime5 = property2.withMaximumValue();
        org.joda.time.DateTime dateTime7 = dateTime5.minus((long) 1);
        org.joda.time.DateTime dateTime9 = dateTime7.plusMonths(0);
        org.joda.time.DateTime.Property property10 = dateTime7.era();
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime7.minus(readableDuration11);
        int int13 = dateTime12.getMillisOfDay();
        org.joda.time.DateTime dateTime15 = dateTime12.withMinuteOfHour((int) (byte) 1);
        try {
            org.joda.time.DateTime dateTime17 = dateTime15.withEra(279);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 279 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 292278993 + "'", int4 == 292278993);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 57600001 + "'", int13 == 57600001);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        long long8 = gregorianChronology3.add((long) 'a', (long) (-10), 0);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property11 = dateTime10.yearOfEra();
        java.lang.String str12 = property11.getAsShortText();
        int int13 = property11.getMaximumValue();
        org.joda.time.DateTime dateTime14 = property11.withMaximumValue();
        org.joda.time.DateTime dateTime16 = dateTime14.minus((long) 1);
        org.joda.time.DateTime dateTime18 = dateTime16.plusMonths(0);
        org.joda.time.DateTime dateTime20 = dateTime18.minusYears(292278993);
        boolean boolean21 = gregorianChronology3.equals((java.lang.Object) dateTime18);
        org.joda.time.DateTime.Property property22 = dateTime18.centuryOfEra();
        int int23 = property22.getMaximumValue();
        try {
            org.joda.time.DateTime dateTime24 = property22.roundCeilingCopy();
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292279000 for year must be in the range [-292275054,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969" + "'", str12.equals("1969"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 292278993 + "'", int13 == 292278993);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2922789 + "'", int23 == 2922789);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfEra();
        int int7 = dateTime3.compareTo((org.joda.time.ReadableInstant) dateTime5);
        java.lang.String str8 = dateTime3.toString();
        org.joda.time.DateTime dateTime10 = dateTime3.withYearOfEra(135);
        org.joda.time.DateTime dateTime12 = dateTime3.minusYears((int) (byte) 10);
        int int13 = dateTime3.getCenturyOfEra();
        org.joda.time.DateTime.Property property14 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime16 = dateTime3.withSecondOfMinute(0);
        try {
            java.lang.String str17 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime3);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str8.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 19 + "'", int13 == 19);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        java.lang.String str9 = offsetDateTimeField4.getName();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property14 = dateTime13.yearOfEra();
        int int15 = dateTime11.compareTo((org.joda.time.ReadableInstant) dateTime13);
        java.lang.String str16 = dateTime11.toString();
        org.joda.time.DateTime dateTime18 = dateTime11.withYearOfEra(135);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.LocalDate localDate21 = dateTimeFormatter19.parseLocalDate("T151324.051-0700");
        org.joda.time.DateTime dateTime22 = dateTime11.withFields((org.joda.time.ReadablePartial) localDate21);
        int[] intArray27 = new int[] { 'a', (-28800000), 365 };
        try {
            int[] intArray29 = offsetDateTimeField4.addWrapField((org.joda.time.ReadablePartial) localDate21, (int) (byte) 1, intArray27, (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 234678992");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "yearOfEra" + "'", str9.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str16.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.set(0L, 10);
        java.lang.String str9 = offsetDateTimeField4.getAsShortText((long) 19);
        boolean boolean10 = offsetDateTimeField4.isSupported();
        long long12 = offsetDateTimeField4.roundHalfFloor(31L);
        long long14 = offsetDateTimeField4.roundFloor(0L);
        boolean boolean15 = offsetDateTimeField4.isSupported();
        long long17 = offsetDateTimeField4.roundHalfFloor(460377891L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61820064000000L) + "'", long7 == (-61820064000000L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.days();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField4 = gregorianChronology3.minutes();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (byte) -1);
        long long10 = offsetDateTimeField7.add((long) 135, (long) 100);
        java.util.TimeZone timeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        boolean boolean15 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology14);
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.minuteOfDay();
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
        boolean boolean21 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology20);
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology20.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField25 = gregorianChronology24.minutes();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (byte) -1);
        int int30 = offsetDateTimeField28.getLeapAmount((long) 10);
        long long32 = offsetDateTimeField28.roundHalfFloor(0L);
        long long34 = offsetDateTimeField28.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime39 = dateTime37.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate40 = dateTime39.toLocalDate();
        java.lang.String str41 = dateTimeFormatter35.print((org.joda.time.ReadablePartial) localDate40);
        int[] intArray48 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray50 = offsetDateTimeField28.set((org.joda.time.ReadablePartial) localDate40, 0, intArray48, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField52 = gregorianChronology51.minutes();
        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology51.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField(dateTimeField53, (int) (byte) -1);
        int int57 = offsetDateTimeField55.getLeapAmount((long) 10);
        long long59 = offsetDateTimeField55.roundHalfFloor(0L);
        long long61 = offsetDateTimeField55.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter62 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime66 = dateTime64.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate67 = dateTime66.toLocalDate();
        java.lang.String str68 = dateTimeFormatter62.print((org.joda.time.ReadablePartial) localDate67);
        int[] intArray75 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray77 = offsetDateTimeField55.set((org.joda.time.ReadablePartial) localDate67, 0, intArray75, (int) (byte) 100);
        gregorianChronology20.validate((org.joda.time.ReadablePartial) localDate40, intArray77);
        int[] intArray80 = gregorianChronology14.get((org.joda.time.ReadablePartial) localDate40, (long) 1920);
        java.util.Locale locale82 = null;
        java.lang.String str83 = offsetDateTimeField7.getAsText((org.joda.time.ReadablePartial) localDate40, (int) '4', locale82);
        long long85 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDate40, (long) 1970);
        org.joda.time.DateTimeField dateTimeField86 = gregorianChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3155760000135L + "'", long10 == 3155760000135L);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "T������.000" + "'", str41.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 0L + "'", long59 == 0L);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter62);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertNotNull(localDate67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "T������.000" + "'", str68.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "52" + "'", str83.equals("52"));
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + (-86398030L) + "'", long85 == (-86398030L));
        org.junit.Assert.assertNotNull(dateTimeField86);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate4 = dateTime3.toLocalDate();
        org.joda.time.DateTime.Property property5 = dateTime3.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test438");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
//        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
//        java.lang.String str8 = offsetDateTimeField4.getName();
//        java.lang.String str9 = offsetDateTimeField4.getName();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = offsetDateTimeField4.getAsText(279, locale11);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField14 = gregorianChronology13.minutes();
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        long long18 = gregorianChronology13.add(readablePeriod15, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) 100, dateTimeZone21);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = dateTimeZone21.getName((long) 9, locale25);
//        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology13, dateTimeZone21);
//        org.joda.time.Chronology chronology28 = zonedChronology27.withUTC();
//        org.joda.time.DurationField durationField29 = zonedChronology27.weekyears();
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder31 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone34 = dateTimeZoneBuilder31.toDateTimeZone("T151321.363-0700", false);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone35 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone34);
//        boolean boolean37 = cachedDateTimeZone35.equals((java.lang.Object) 57600002);
//        org.joda.time.Chronology chronology38 = iSOChronology30.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone35);
//        org.joda.time.Chronology chronology39 = zonedChronology27.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone35);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.basicTTime();
//        org.joda.time.LocalDate localDate42 = dateTimeFormatter40.parseLocalDate("T151324.051-0700");
//        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField44 = gregorianChronology43.minutes();
//        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology43.yearOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField(dateTimeField45, (int) (byte) -1);
//        int int49 = offsetDateTimeField47.getLeapAmount((long) 10);
//        long long51 = offsetDateTimeField47.roundHalfFloor(0L);
//        long long53 = offsetDateTimeField47.roundHalfFloor(0L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter54 = org.joda.time.format.ISODateTimeFormat.basicTTime();
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime58 = dateTime56.plusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate59 = dateTime58.toLocalDate();
//        java.lang.String str60 = dateTimeFormatter54.print((org.joda.time.ReadablePartial) localDate59);
//        int[] intArray67 = new int[] { 1969, 100, ' ', 10, 2 };
//        int[] intArray69 = offsetDateTimeField47.set((org.joda.time.ReadablePartial) localDate59, 0, intArray67, (int) (byte) 100);
//        zonedChronology27.validate((org.joda.time.ReadablePartial) localDate42, intArray69);
//        int int71 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localDate42);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "yearOfEra" + "'", str9.equals("yearOfEra"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "279" + "'", str12.equals("279"));
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Pacific Standard Time" + "'", str26.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology27);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(chronology38);
//        org.junit.Assert.assertNotNull(chronology39);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertNotNull(localDate42);
//        org.junit.Assert.assertNotNull(gregorianChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter54);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(localDate59);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "T������.000" + "'", str60.equals("T������.000"));
//        org.junit.Assert.assertNotNull(intArray67);
//        org.junit.Assert.assertNotNull(intArray69);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
//    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        org.joda.time.DurationField durationField7 = offsetDateTimeField4.getLeapDurationField();
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField4.getMaximumShortTextLength(locale8);
        long long12 = offsetDateTimeField4.add((long) (-1), (long) 'a');
        long long14 = offsetDateTimeField4.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property19 = dateTime18.yearOfEra();
        int int20 = dateTime16.compareTo((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime.Property property21 = dateTime16.weekOfWeekyear();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfYear();
        int int23 = property22.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property22.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField30 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType24, 57600002);
        long long32 = remainderDateTimeField30.roundCeiling((long) 31);
        long long34 = remainderDateTimeField30.remainder((-62166758822109L));
        long long36 = remainderDateTimeField30.roundHalfCeiling((long) 19);
        org.joda.time.DurationField durationField37 = remainderDateTimeField30.getRangeDurationField();
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property40 = dateTime39.yearOfEra();
        java.lang.String str41 = property40.getAsShortText();
        int int42 = property40.getMaximumValue();
        org.joda.time.DateTime dateTime43 = property40.withMaximumValue();
        org.joda.time.DateTime dateTime45 = dateTime43.minus((long) 1);
        org.joda.time.DateTime dateTime47 = dateTime45.plusMonths(0);
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property52 = dateTime51.yearOfEra();
        int int53 = dateTime49.compareTo((org.joda.time.ReadableInstant) dateTime51);
        org.joda.time.DateTime.Property property54 = dateTime49.weekOfWeekyear();
        org.joda.time.DateTime.Property property55 = dateTime49.dayOfYear();
        int int56 = property55.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = property55.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException61 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType57, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
        int int62 = dateTime47.get(dateTimeFieldType57);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField63 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField30, dateTimeFieldType57);
        long long66 = remainderDateTimeField30.set(31535999999L, (int) (short) 10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3061065599999L + "'", long12 == 3061065599999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 31536000000L + "'", long32 == 31536000000L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 460377891L + "'", long34 == 460377891L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1969" + "'", str41.equals("1969"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 292278993 + "'", int42 == 292278993);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 365 + "'", int56 == 365);
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 365 + "'", int62 == 365);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-61788528000001L) + "'", long66 == (-61788528000001L));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder4.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withDefaultYear(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter5.withPivotYear((java.lang.Integer) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.plusYears(0);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.DateTime dateTime10 = property8.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear((int) (byte) 100);
        java.lang.String str13 = dateTime12.toString();
        boolean boolean14 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime.Property property15 = dateTime12.monthOfYear();
        java.util.Locale locale16 = null;
        int int17 = property15.getMaximumTextLength(locale16);
        java.util.TimeZone timeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology21);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.minuteOfDay();
        java.util.TimeZone timeZone25 = null;
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forTimeZone(timeZone25);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone26);
        boolean boolean28 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology27);
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology27.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField32 = gregorianChronology31.minutes();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology31.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, (int) (byte) -1);
        int int37 = offsetDateTimeField35.getLeapAmount((long) 10);
        long long39 = offsetDateTimeField35.roundHalfFloor(0L);
        long long41 = offsetDateTimeField35.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime46 = dateTime44.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate47 = dateTime46.toLocalDate();
        java.lang.String str48 = dateTimeFormatter42.print((org.joda.time.ReadablePartial) localDate47);
        int[] intArray55 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray57 = offsetDateTimeField35.set((org.joda.time.ReadablePartial) localDate47, 0, intArray55, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology58 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField59 = gregorianChronology58.minutes();
        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology58.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField(dateTimeField60, (int) (byte) -1);
        int int64 = offsetDateTimeField62.getLeapAmount((long) 10);
        long long66 = offsetDateTimeField62.roundHalfFloor(0L);
        long long68 = offsetDateTimeField62.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter69 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime73 = dateTime71.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate74 = dateTime73.toLocalDate();
        java.lang.String str75 = dateTimeFormatter69.print((org.joda.time.ReadablePartial) localDate74);
        int[] intArray82 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray84 = offsetDateTimeField62.set((org.joda.time.ReadablePartial) localDate74, 0, intArray82, (int) (byte) 100);
        gregorianChronology27.validate((org.joda.time.ReadablePartial) localDate47, intArray84);
        int[] intArray87 = gregorianChronology21.get((org.joda.time.ReadablePartial) localDate47, (long) 1920);
        int int88 = property15.compareTo((org.joda.time.ReadablePartial) localDate47);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0100-01-05T16:00:00.002-07:52:58" + "'", str13.equals("0100-01-05T16:00:00.002-07:52:58"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(localDate47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "T������.000" + "'", str48.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(gregorianChronology58);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 0L + "'", long66 == 0L);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter69);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertNotNull(localDate74);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "T������.000" + "'", str75.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + (-1) + "'", int88 == (-1));
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test445");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getName((long) 9, locale12);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone15 = zonedChronology14.getZone();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.Chronology chronology17 = zonedChronology14.withZone(dateTimeZone16);
//        java.lang.String str18 = zonedChronology14.toString();
//        org.joda.time.DateTimeField dateTimeField19 = zonedChronology14.hourOfHalfday();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]" + "'", str18.equals("ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(dateTimeField19);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        java.lang.String str9 = offsetDateTimeField4.getName();
        int int10 = offsetDateTimeField4.getMaximumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfEra();
        int int17 = dateTime13.compareTo((org.joda.time.ReadableInstant) dateTime15);
        java.lang.String str18 = dateTime13.toString();
        org.joda.time.DateTime dateTime20 = dateTime13.withYearOfEra(135);
        java.lang.String str21 = dateTimeFormatter11.print((org.joda.time.ReadableInstant) dateTime20);
        java.util.Locale locale22 = dateTimeFormatter11.getLocale();
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField24 = gregorianChronology23.minutes();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, (int) (byte) -1);
        int int29 = offsetDateTimeField27.getLeapAmount((long) 10);
        long long31 = offsetDateTimeField27.roundHalfFloor(0L);
        long long33 = offsetDateTimeField27.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime38 = dateTime36.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate39 = dateTime38.toLocalDate();
        java.lang.String str40 = dateTimeFormatter34.print((org.joda.time.ReadablePartial) localDate39);
        int[] intArray47 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray49 = offsetDateTimeField27.set((org.joda.time.ReadablePartial) localDate39, 0, intArray47, (int) (byte) 100);
        java.lang.String str50 = dateTimeFormatter11.print((org.joda.time.ReadablePartial) localDate39);
        java.util.Locale locale52 = null;
        java.lang.String str53 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) localDate39, 2, locale52);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "yearOfEra" + "'", str9.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292278992 + "'", int10 == 292278992);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str18.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "01351231" + "'", str21.equals("01351231"));
        org.junit.Assert.assertNull(locale22);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "T������.000" + "'", str40.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "19691231" + "'", str50.equals("19691231"));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "2" + "'", str53.equals("2"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        int int6 = dateTime3.getEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.plus(readablePeriod7);
        boolean boolean10 = dateTime8.isBefore(10L);
        org.joda.time.DateTime dateTime11 = dateTime8.withEarlierOffsetAtOverlap();
        int int12 = dateTime11.getHourOfDay();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 16 + "'", int12 == 16);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readablePeriod5);
        org.joda.time.DateTime dateTime8 = dateTime1.plusYears(0);
        org.joda.time.DateTime dateTime9 = dateTime1.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property10 = dateTime1.era();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "T151320.765-0700");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException2.toString();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNull(dateTimeFieldType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "T151320.765-0700" + "'", str5.equals("T151320.765-0700"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"T151320.765-0700\" for hi! is not supported" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value \"T151320.765-0700\" for hi! is not supported"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.set(0L, 10);
        java.lang.String str9 = offsetDateTimeField4.getAsShortText((long) 19);
        boolean boolean10 = offsetDateTimeField4.isSupported();
        long long12 = offsetDateTimeField4.roundHalfFloor(31L);
        long long14 = offsetDateTimeField4.roundFloor(0L);
        boolean boolean15 = offsetDateTimeField4.isSupported();
        org.joda.time.DurationField durationField16 = offsetDateTimeField4.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61820064000000L) + "'", long7 == (-61820064000000L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(durationField16);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readablePeriod5);
        org.joda.time.TimeOfDay timeOfDay7 = dateTime1.toTimeOfDay();
        org.joda.time.DateTime.Property property8 = dateTime1.centuryOfEra();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("T151321.363-0700", "1", 292278993, (int) 'a');
        org.joda.time.DateTime dateTime14 = dateTime1.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField16 = gregorianChronology15.minutes();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) (byte) -1);
        int int21 = offsetDateTimeField19.getLeapAmount((long) 10);
        long long23 = offsetDateTimeField19.roundHalfFloor(0L);
        java.lang.String str24 = offsetDateTimeField19.getName();
        long long26 = offsetDateTimeField19.roundHalfFloor((long) 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField19.getType();
        int int28 = dateTime14.get(dateTimeFieldType27);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField30 = gregorianChronology29.minutes();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology29.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (int) (byte) -1);
        int int35 = offsetDateTimeField33.getLeapAmount((long) 10);
        org.joda.time.DurationField durationField36 = offsetDateTimeField33.getLeapDurationField();
        java.util.Locale locale37 = null;
        int int38 = offsetDateTimeField33.getMaximumShortTextLength(locale37);
        long long41 = offsetDateTimeField33.add((long) (-1), (long) 'a');
        long long43 = offsetDateTimeField33.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property48 = dateTime47.yearOfEra();
        int int49 = dateTime45.compareTo((org.joda.time.ReadableInstant) dateTime47);
        org.joda.time.DateTime.Property property50 = dateTime45.weekOfWeekyear();
        org.joda.time.DateTime.Property property51 = dateTime45.dayOfYear();
        int int52 = property51.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property51.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException57 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField59 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField33, dateTimeFieldType53, 57600002);
        long long61 = remainderDateTimeField59.roundCeiling((long) 31);
        org.joda.time.DurationField durationField62 = remainderDateTimeField59.getRangeDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology64 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology63);
        org.joda.time.DateTimeField dateTimeField65 = gregorianChronology63.dayOfYear();
        java.lang.String str66 = gregorianChronology63.toString();
        org.joda.time.DurationField durationField67 = gregorianChronology63.days();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField68 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType27, durationField62, durationField67);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "yearOfEra" + "'", str24.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1969 + "'", int28 == 1969);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNull(durationField36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 9 + "'", int38 == 9);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 3061065599999L + "'", long41 == 3061065599999L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 365 + "'", int52 == 365);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 31536000000L + "'", long61 == 31536000000L);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(gregorianChronology63);
        org.junit.Assert.assertNotNull(chronology64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "GregorianChronology[UTC]" + "'", str66.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField67);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "T151320.765-0700");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        org.joda.time.DurationFieldType durationFieldType6 = illegalFieldValueException2.getDurationFieldType();
        java.lang.Number number7 = illegalFieldValueException2.getUpperBound();
        java.lang.String str8 = illegalFieldValueException2.getFieldName();
        java.lang.Number number9 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNull(dateTimeFieldType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "T151320.765-0700" + "'", str5.equals("T151320.765-0700"));
        org.junit.Assert.assertNull(durationFieldType6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "T151320.765-0700");
        java.lang.String str3 = illegalFieldValueException2.getFieldName();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        java.lang.Number number5 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNull(durationFieldType4);
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendLiteral("ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.set(0L, 10);
        java.lang.String str9 = offsetDateTimeField4.getAsShortText((long) 19);
        boolean boolean10 = offsetDateTimeField4.isSupported();
        long long12 = offsetDateTimeField4.roundHalfFloor(31L);
        try {
            long long15 = offsetDateTimeField4.set((long) '4', "T151332.735-0700");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"T151332.735-0700\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61820064000000L) + "'", long7 == (-61820064000000L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getCenturyOfEra();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readablePeriod5);
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        java.util.Locale locale9 = null;
        try {
            java.lang.String str10 = dateTime1.toString("T151333.319-0700", locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        boolean boolean6 = offsetDateTimeField4.isLeap((long) 'a');
        java.lang.String str7 = offsetDateTimeField4.getName();
        int int9 = offsetDateTimeField4.get((long) 56792);
        java.util.Locale locale12 = null;
        long long13 = offsetDateTimeField4.set((-61820063999990L), "279", locale12);
        int int14 = offsetDateTimeField4.getOffset();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "yearOfEra" + "'", str7.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-53331263999990L) + "'", long13 == (-53331263999990L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-1), (java.lang.Number) 9223372017129600001L, (java.lang.Number) 35L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 292278993);
        java.util.Locale locale4 = null;
        int int5 = offsetDateTimeField3.getMaximumTextLength(locale4);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.clockhourOfHalfday();
        try {
            long long10 = gregorianChronology3.getDateTimeMillis((int) (short) 0, (int) (byte) 10, 86399999, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399999 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        int int11 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property12 = dateTime1.centuryOfEra();
        org.joda.time.DateTime dateTime14 = dateTime1.withSecondOfMinute(0);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime14.plus(readableDuration15);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test462");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
//        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
//        org.joda.time.DateTime.Property property7 = dateTime1.dayOfYear();
//        int int8 = property7.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField15 = gregorianChronology14.minutes();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        long long19 = gregorianChronology14.add(readablePeriod16, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 100, dateTimeZone22);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone22.getName((long) 9, locale26);
//        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology14, dateTimeZone22);
//        org.joda.time.Chronology chronology29 = zonedChronology28.withUTC();
//        org.joda.time.DurationField durationField30 = zonedChronology28.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField30);
//        try {
//            int int33 = unsupportedDateTimeField31.getMaximumValue(3L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 365 + "'", int8 == 365);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Pacific Standard Time" + "'", str27.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test463");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
//        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
//        org.joda.time.DateTime.Property property7 = dateTime1.dayOfYear();
//        int int8 = property7.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField15 = gregorianChronology14.minutes();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        long long19 = gregorianChronology14.add(readablePeriod16, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 100, dateTimeZone22);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone22.getName((long) 9, locale26);
//        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology14, dateTimeZone22);
//        org.joda.time.Chronology chronology29 = zonedChronology28.withUTC();
//        org.joda.time.DurationField durationField30 = zonedChronology28.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField30);
//        try {
//            long long34 = unsupportedDateTimeField31.add(3155760000135L, 1560636829203L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 1560636829203");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 365 + "'", int8 == 365);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Pacific Standard Time" + "'", str27.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "279");
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Property[yearOfEra]", "Pacific Standard Time", 54823, 0);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        int int7 = fixedDateTimeZone4.getStandardOffset(0L);
        boolean boolean8 = fixedDateTimeZone4.isFixed();
        int int10 = fixedDateTimeZone4.getStandardOffset((long) 1959);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test466");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
//        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
//        org.joda.time.DateTime.Property property7 = dateTime1.dayOfYear();
//        int int8 = property7.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField15 = gregorianChronology14.minutes();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        long long19 = gregorianChronology14.add(readablePeriod16, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 100, dateTimeZone22);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone22.getName((long) 9, locale26);
//        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology14, dateTimeZone22);
//        org.joda.time.Chronology chronology29 = zonedChronology28.withUTC();
//        org.joda.time.DurationField durationField30 = zonedChronology28.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField30);
//        try {
//            java.lang.String str33 = unsupportedDateTimeField31.getAsShortText((long) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 365 + "'", int8 == 365);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Pacific Standard Time" + "'", str27.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder8.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatterBuilder6.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        org.joda.time.DurationField durationField7 = offsetDateTimeField4.getLeapDurationField();
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField4.getMaximumShortTextLength(locale8);
        long long12 = offsetDateTimeField4.add((long) (-1), (long) 'a');
        long long14 = offsetDateTimeField4.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property19 = dateTime18.yearOfEra();
        int int20 = dateTime16.compareTo((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime.Property property21 = dateTime16.weekOfWeekyear();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfYear();
        int int23 = property22.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property22.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField30 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType24, 57600002);
        long long32 = remainderDateTimeField30.roundCeiling((long) 31);
        long long34 = remainderDateTimeField30.remainder((-62166758822109L));
        java.util.Locale locale36 = null;
        java.lang.String str37 = remainderDateTimeField30.getAsText((-28799938L), locale36);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3061065599999L + "'", long12 == 3061065599999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 31536000000L + "'", long32 == 31536000000L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 460377891L + "'", long34 == 460377891L);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1968" + "'", str37.equals("1968"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(4291776000000L);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        long long10 = offsetDateTimeField4.roundHalfFloor(0L);
        long long12 = offsetDateTimeField4.roundCeiling(2649600002L);
        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField4.getWrappedField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31536000000L + "'", long12 == 31536000000L);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        long long10 = offsetDateTimeField4.roundHalfFloor(0L);
        long long12 = offsetDateTimeField4.roundCeiling(2649600002L);
        boolean boolean13 = offsetDateTimeField4.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31536000000L + "'", long12 == 31536000000L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        int int5 = dateTime4.getYearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime4.minus(1L);
        org.joda.time.DateTime.Property property8 = dateTime7.minuteOfHour();
        org.joda.time.DurationField durationField9 = property8.getDurationField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 69 + "'", int5 == 69);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property2.getAsShortText(locale3);
        org.joda.time.DateTime dateTime6 = property2.addToCopy((long) 1959);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969" + "'", str4.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendWeekyear(0, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendDayOfYear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendHourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendClockhourOfDay(135);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime1.weekOfWeekyear();
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology11.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField16 = gregorianChronology15.minutes();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) (byte) -1);
        int int21 = offsetDateTimeField19.getLeapAmount((long) 10);
        long long23 = offsetDateTimeField19.roundHalfFloor(0L);
        long long25 = offsetDateTimeField19.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime30 = dateTime28.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate31 = dateTime30.toLocalDate();
        java.lang.String str32 = dateTimeFormatter26.print((org.joda.time.ReadablePartial) localDate31);
        int[] intArray39 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray41 = offsetDateTimeField19.set((org.joda.time.ReadablePartial) localDate31, 0, intArray39, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField43 = gregorianChronology42.minutes();
        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology42.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField44, (int) (byte) -1);
        int int48 = offsetDateTimeField46.getLeapAmount((long) 10);
        long long50 = offsetDateTimeField46.roundHalfFloor(0L);
        long long52 = offsetDateTimeField46.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime57 = dateTime55.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate58 = dateTime57.toLocalDate();
        java.lang.String str59 = dateTimeFormatter53.print((org.joda.time.ReadablePartial) localDate58);
        int[] intArray66 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray68 = offsetDateTimeField46.set((org.joda.time.ReadablePartial) localDate58, 0, intArray66, (int) (byte) 100);
        gregorianChronology11.validate((org.joda.time.ReadablePartial) localDate31, intArray68);
        int int70 = property7.compareTo((org.joda.time.ReadablePartial) localDate31);
        org.joda.time.chrono.GregorianChronology gregorianChronology71 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField72 = gregorianChronology71.minutes();
        org.joda.time.DateTimeField dateTimeField73 = gregorianChronology71.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField75 = new org.joda.time.field.OffsetDateTimeField(dateTimeField73, (int) (byte) -1);
        long long78 = offsetDateTimeField75.add((long) 135, (long) 100);
        java.util.Locale locale79 = null;
        int int80 = offsetDateTimeField75.getMaximumShortTextLength(locale79);
        boolean boolean81 = property7.equals((java.lang.Object) int80);
        int int82 = property7.get();
        org.joda.time.DateTime dateTime83 = property7.roundFloorCopy();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "T������.000" + "'", str32.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter53);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(localDate58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "T������.000" + "'", str59.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology71);
        org.junit.Assert.assertNotNull(durationField72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 3155760000135L + "'", long78 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 9 + "'", int80 == 9);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
        org.junit.Assert.assertNotNull(dateTime83);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        boolean boolean6 = offsetDateTimeField4.isLeap((long) 'a');
        java.lang.String str7 = offsetDateTimeField4.getName();
        long long9 = offsetDateTimeField4.roundHalfEven(28800000L);
        long long12 = offsetDateTimeField4.addWrapField(4260240000000L, (int) (short) 1);
        org.joda.time.DurationField durationField13 = offsetDateTimeField4.getLeapDurationField();
        long long15 = offsetDateTimeField4.roundHalfCeiling((-1970L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "yearOfEra" + "'", str7.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 4291776000000L + "'", long12 == 4291776000000L);
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        int int6 = dateTime3.getEra();
        org.joda.time.DateTime.Property property7 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime9 = property7.addToCopy((long) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime9.withDurationAdded((-61788528000001L), 365);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.minutes();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (byte) -1);
        int int13 = offsetDateTimeField11.getLeapAmount((long) 10);
        long long15 = offsetDateTimeField11.roundHalfFloor(0L);
        long long17 = offsetDateTimeField11.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime22 = dateTime20.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate23 = dateTime22.toLocalDate();
        java.lang.String str24 = dateTimeFormatter18.print((org.joda.time.ReadablePartial) localDate23);
        int[] intArray31 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray33 = offsetDateTimeField11.set((org.joda.time.ReadablePartial) localDate23, 0, intArray31, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField35 = gregorianChronology34.minutes();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, (int) (byte) -1);
        int int40 = offsetDateTimeField38.getLeapAmount((long) 10);
        long long42 = offsetDateTimeField38.roundHalfFloor(0L);
        long long44 = offsetDateTimeField38.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime49 = dateTime47.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate50 = dateTime49.toLocalDate();
        java.lang.String str51 = dateTimeFormatter45.print((org.joda.time.ReadablePartial) localDate50);
        int[] intArray58 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray60 = offsetDateTimeField38.set((org.joda.time.ReadablePartial) localDate50, 0, intArray58, (int) (byte) 100);
        gregorianChronology3.validate((org.joda.time.ReadablePartial) localDate23, intArray60);
        org.joda.time.DurationField durationField62 = gregorianChronology3.centuries();
        try {
            long long68 = gregorianChronology3.getDateTimeMillis((-28800000L), 1967, 54877, 8, 1870);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1967 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "T������.000" + "'", str24.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter45);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "T������.000" + "'", str51.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(durationField62);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) ' ', false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitYear(100, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendYear(10, 1870);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendDayOfWeek(57600001);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMonthOfYear((int) 'a');
        dateTimeFormatterBuilder8.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfYear(292278993);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfEra();
        int int10 = dateTime6.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTime.Property property12 = dateTime6.dayOfYear();
        int int13 = property12.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property12.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType14);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear(12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 365 + "'", int13 == 365);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test484");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
//        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
//        org.joda.time.DateTime.Property property7 = dateTime1.dayOfYear();
//        int int8 = property7.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField15 = gregorianChronology14.minutes();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        long long19 = gregorianChronology14.add(readablePeriod16, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 100, dateTimeZone22);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone22.getName((long) 9, locale26);
//        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology14, dateTimeZone22);
//        org.joda.time.Chronology chronology29 = zonedChronology28.withUTC();
//        org.joda.time.DurationField durationField30 = zonedChronology28.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField30);
//        java.lang.String str32 = unsupportedDateTimeField31.toString();
//        java.util.Locale locale34 = null;
//        try {
//            java.lang.String str35 = unsupportedDateTimeField31.getAsText((int) (short) -1, locale34);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 365 + "'", int8 == 365);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Pacific Standard Time" + "'", str27.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "UnsupportedDateTimeField" + "'", str32.equals("UnsupportedDateTimeField"));
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        int int5 = dateTime1.getYearOfEra();
        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime();
        org.joda.time.ReadablePartial readablePartial7 = null;
        org.joda.time.DateTime dateTime8 = dateTime1.withFields(readablePartial7);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        org.joda.time.Chronology chronology5 = dateTime3.getChronology();
        org.joda.time.DateTime dateTime7 = dateTime3.withCenturyOfEra(0);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfYear();
        boolean boolean8 = dateTime1.isEqualNow();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField10 = gregorianChronology9.minutes();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) (byte) -1);
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        org.joda.time.DurationField durationField16 = offsetDateTimeField13.getLeapDurationField();
        java.util.Locale locale17 = null;
        int int18 = offsetDateTimeField13.getMaximumShortTextLength(locale17);
        long long21 = offsetDateTimeField13.add((long) (-1), (long) 'a');
        long long23 = offsetDateTimeField13.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property28 = dateTime27.yearOfEra();
        int int29 = dateTime25.compareTo((org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.DateTime.Property property30 = dateTime25.weekOfWeekyear();
        org.joda.time.DateTime.Property property31 = dateTime25.dayOfYear();
        int int32 = property31.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property31.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField39 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType33, 57600002);
        boolean boolean40 = dateTime1.isSupported(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(durationField16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 3061065599999L + "'", long21 == 3061065599999L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 365 + "'", int32 == 365);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        java.util.GregorianCalendar gregorianCalendar11 = dateTime10.toGregorianCalendar();
        org.joda.time.DateTime dateTime13 = dateTime10.plusMonths((int) (byte) 10);
        org.joda.time.DateTime.Property property14 = dateTime10.weekyear();
        int int15 = dateTime10.getMillisOfDay();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianCalendar11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 57600002 + "'", int15 == 57600002);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime5 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime9 = dateTime7.minusDays((int) (short) -1);
        int int10 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfEra();
        int int16 = dateTime12.compareTo((org.joda.time.ReadableInstant) dateTime14);
        int int17 = dateTime14.getDayOfMonth();
        boolean boolean18 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime14);
        boolean boolean19 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property20 = dateTime5.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.DateTime dateTime22 = dateTime5.minus(readablePeriod21);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600002 + "'", int4 == 57600002);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600002 + "'", int10 == 57600002);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone2 = iSOChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
        org.joda.time.Chronology chronology4 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        int int6 = dateTime3.getEra();
        org.joda.time.DateTime.Property property7 = dateTime3.monthOfYear();
        org.joda.time.DateTime dateTime9 = property7.addToCopy((long) (byte) 10);
        int int10 = dateTime9.getYearOfCentury();
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime9.toMutableDateTimeISO();
        try {
            org.joda.time.DateTime dateTime13 = dateTime9.withDayOfWeek(54873);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54873 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 70 + "'", int10 == 70);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = cachedDateTimeZone4.getUncachedZone();
        int int7 = cachedDateTimeZone4.getStandardOffset((long) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) gregorianChronology11);
        boolean boolean13 = cachedDateTimeZone4.equals((java.lang.Object) gregorianChronology11);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property18 = dateTime17.yearOfEra();
        int int19 = dateTime15.compareTo((org.joda.time.ReadableInstant) dateTime17);
        int int20 = dateTime17.getEra();
        org.joda.time.DateTime.Property property21 = dateTime17.monthOfYear();
        java.lang.Object obj22 = null;
        boolean boolean23 = property21.equals(obj22);
        boolean boolean24 = cachedDateTimeZone4.equals(obj22);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = dateTime3.withZoneRetainFields(dateTimeZone5);
        int int7 = dateTime6.getYear();
        org.joda.time.TimeOfDay timeOfDay8 = dateTime6.toTimeOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
        org.junit.Assert.assertNotNull(timeOfDay8);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 365);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear(57600002);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "T160000.052-0800");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getCenturyOfEra();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readablePeriod5);
        org.joda.time.DateTime.Property property7 = dateTime1.dayOfMonth();
        org.joda.time.DateTime dateTime9 = dateTime1.withMillisOfSecond(0);
        int int10 = dateTime1.getYearOfCentury();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 69 + "'", int10 == 69);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.plusMillis(135);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime8 = dateTime6.minusDays((int) (short) -1);
        int int9 = dateTime6.getWeekOfWeekyear();
        int int10 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfEra();
        int int16 = dateTime12.compareTo((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime.Property property17 = dateTime12.weekOfWeekyear();
        org.joda.time.DateTime.Property property18 = dateTime12.weekOfWeekyear();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime22 = dateTime20.minusDays((int) (short) -1);
        int int23 = dateTime20.getMillisOfDay();
        org.joda.time.DateTime dateTime24 = dateTime20.withTimeAtStartOfDay();
        org.joda.time.ReadablePartial readablePartial25 = null;
        org.joda.time.DateTime dateTime26 = dateTime20.withFields(readablePartial25);
        org.joda.time.DateMidnight dateMidnight27 = dateTime20.toDateMidnight();
        int int28 = property18.getDifference((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.ReadableDuration readableDuration29 = null;
        org.joda.time.DateTime dateTime31 = dateTime20.withDurationAdded(readableDuration29, (int) ' ');
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime6, (org.joda.time.ReadableInstant) dateTime31);
        java.lang.String str33 = dateTime31.toString();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 57600002 + "'", int23 == 57600002);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateMidnight27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str33.equals("1969-12-31T16:00:00.002-08:00"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        long long10 = offsetDateTimeField4.roundHalfFloor(0L);
        long long12 = offsetDateTimeField4.roundCeiling(2649600002L);
        long long15 = offsetDateTimeField4.addWrapField((long) (-28800000), 53);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31536000000L + "'", long12 == 31536000000L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1672502400000L + "'", long15 == 1672502400000L);
    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test499");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
//        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
//        org.joda.time.DateTime.Property property7 = dateTime1.dayOfYear();
//        int int8 = property7.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField15 = gregorianChronology14.minutes();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        long long19 = gregorianChronology14.add(readablePeriod16, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 100, dateTimeZone22);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone22.getName((long) 9, locale26);
//        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology14, dateTimeZone22);
//        org.joda.time.Chronology chronology29 = zonedChronology28.withUTC();
//        org.joda.time.DurationField durationField30 = zonedChronology28.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField30);
//        try {
//            long long33 = unsupportedDateTimeField31.roundHalfFloor(31536000000L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 365 + "'", int8 == 365);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Pacific Standard Time" + "'", str27.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "1967");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }
}

