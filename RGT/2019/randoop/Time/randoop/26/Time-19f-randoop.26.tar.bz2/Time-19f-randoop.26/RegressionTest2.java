import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        int int6 = dateTime3.getEra();
        int int7 = dateTime3.getMillisOfSecond();
        org.joda.time.DateTime dateTime9 = dateTime3.minusMillis((int) (byte) 0);
        int int10 = dateTime9.getMinuteOfDay();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 960 + "'", int10 == 960);
    }

//    @Test
//    public void test02() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test02");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime3.withZoneRetainFields(dateTimeZone5);
//        long long9 = dateTimeZone5.convertLocalToUTC((long) 100, false);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone5.getShortName((long) 0, locale11);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField15 = gregorianChronology14.minutes();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.yearOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) (byte) -1);
//        int int20 = offsetDateTimeField18.getLeapAmount((long) 10);
//        long long22 = offsetDateTimeField18.roundHalfFloor(0L);
//        long long24 = offsetDateTimeField18.roundHalfFloor(0L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.basicTTime();
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime29 = dateTime27.plusSeconds((int) (short) 10);
//        org.joda.time.LocalDate localDate30 = dateTime29.toLocalDate();
//        java.lang.String str31 = dateTimeFormatter25.print((org.joda.time.ReadablePartial) localDate30);
//        int[] intArray38 = new int[] { 1969, 100, ' ', 10, 2 };
//        int[] intArray40 = offsetDateTimeField18.set((org.joda.time.ReadablePartial) localDate30, 0, intArray38, (int) (byte) 100);
//        long long42 = gregorianChronology13.set((org.joda.time.ReadablePartial) localDate30, 1120L);
//        int int43 = gregorianChronology13.getMinimumDaysInFirstWeek();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800100L + "'", long9 == 28800100L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PST" + "'", str12.equals("PST"));
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "T������.000" + "'", str31.equals("T������.000"));
//        org.junit.Assert.assertNotNull(intArray38);
//        org.junit.Assert.assertNotNull(intArray40);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1120L + "'", long42 == 1120L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
//    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser4 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter3, dateTimeParser4);
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatter5.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimePrinter6);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        java.lang.String str8 = offsetDateTimeField4.getName();
        org.joda.time.DurationField durationField9 = offsetDateTimeField4.getDurationField();
        long long11 = offsetDateTimeField4.remainder((long) (byte) -1);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField4.getWrappedField();
        org.joda.time.DateTimeField dateTimeField13 = offsetDateTimeField4.getWrappedField();
        int int15 = offsetDateTimeField4.getLeapAmount((-2922770L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 31535999999L + "'", long11 == 31535999999L);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = property2.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime6 = dateTime4.withWeekyear((int) (byte) 100);
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = property7.roundFloorCopy();
        org.joda.time.ReadableInstant readableInstant9 = null;
        boolean boolean10 = dateTime8.isAfter(readableInstant9);
        org.joda.time.DateTime.Property property11 = dateTime8.minuteOfHour();
        java.lang.String str12 = dateTime8.toString();
        org.joda.time.DateTime.Property property13 = dateTime8.weekyear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0100-01-01T00:00:00.000-07:52:58" + "'", str12.equals("0100-01-01T00:00:00.000-07:52:58"));
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime11 = dateTime9.minusDays((int) (short) -1);
        int int12 = dateTime9.getMillisOfDay();
        org.joda.time.DateTime dateTime13 = dateTime9.withTimeAtStartOfDay();
        org.joda.time.ReadablePartial readablePartial14 = null;
        org.joda.time.DateTime dateTime15 = dateTime9.withFields(readablePartial14);
        org.joda.time.DateMidnight dateMidnight16 = dateTime9.toDateMidnight();
        int int17 = property7.getDifference((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
        org.joda.time.DateTime dateTime22 = dateTime19.plusMillis(135);
        org.joda.time.Chronology chronology23 = dateTime19.getChronology();
        org.joda.time.DateTime dateTime25 = dateTime19.withHourOfDay(10);
        int int26 = property7.compareTo((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property29 = dateTime28.yearOfEra();
        java.lang.String str30 = property29.getAsShortText();
        int int31 = property29.getMaximumValue();
        org.joda.time.DateTime dateTime32 = property29.withMaximumValue();
        org.joda.time.DateTime dateTime34 = dateTime32.minus((long) 1);
        org.joda.time.DateTime dateTime36 = dateTime34.plusMonths(0);
        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime34);
        int int38 = property7.compareTo((org.joda.time.ReadableInstant) dateTime34);
        int int39 = property7.getMinimumValue();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57600002 + "'", int12 == 57600002);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 292278993 + "'", int31 == 292278993);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
        long long6 = gregorianChronology0.add((long) (byte) -1, (long) (short) -1, (-10));
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.dayOfMonth();
        org.joda.time.DurationField durationField8 = gregorianChronology0.eras();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9L + "'", long6 == 9L);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        boolean boolean6 = cachedDateTimeZone4.equals((java.lang.Object) 57600002);
        int int8 = cachedDateTimeZone4.getStandardOffset((long) (short) 10);
        long long10 = cachedDateTimeZone4.nextTransition((long) (-28800000));
        org.joda.time.LocalDateTime localDateTime11 = null;
        boolean boolean12 = cachedDateTimeZone4.isLocalDateTimeGap(localDateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-28800000L) + "'", long10 == (-28800000L));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Property[yearOfEra]", "Pacific Standard Time", 54823, 0);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        int int7 = fixedDateTimeZone4.getStandardOffset(0L);
        int int9 = fixedDateTimeZone4.getStandardOffset(0L);
        long long12 = fixedDateTimeZone4.adjustOffset((-2922770L), false);
        long long14 = fixedDateTimeZone4.nextTransition((long) (short) 0);
        int int16 = fixedDateTimeZone4.getOffset((long) (-292275054));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2922770L) + "'", long12 == (-2922770L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 54823 + "'", int16 == 54823);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readablePeriod5);
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime8.minusMinutes(56792);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField13 = gregorianChronology12.minutes();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) -1);
        int int18 = offsetDateTimeField16.getLeapAmount((long) 10);
        long long20 = offsetDateTimeField16.roundHalfFloor(0L);
        long long22 = offsetDateTimeField16.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime27 = dateTime25.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate28 = dateTime27.toLocalDate();
        java.lang.String str29 = dateTimeFormatter23.print((org.joda.time.ReadablePartial) localDate28);
        int[] intArray36 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray38 = offsetDateTimeField16.set((org.joda.time.ReadablePartial) localDate28, 0, intArray36, (int) (byte) 100);
        org.joda.time.DateTime dateTime39 = dateTime8.withFields((org.joda.time.ReadablePartial) localDate28);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "T������.000" + "'", str29.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(dateTime39);
    }

//    @Test
//    public void test12() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test12");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
//        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
//        org.joda.time.DateTime.Property property7 = dateTime1.dayOfYear();
//        int int8 = property7.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField15 = gregorianChronology14.minutes();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        long long19 = gregorianChronology14.add(readablePeriod16, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 100, dateTimeZone22);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone22.getName((long) 9, locale26);
//        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology14, dateTimeZone22);
//        org.joda.time.Chronology chronology29 = zonedChronology28.withUTC();
//        org.joda.time.DurationField durationField30 = zonedChronology28.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField30);
//        java.lang.String str32 = unsupportedDateTimeField31.toString();
//        try {
//            int int34 = unsupportedDateTimeField31.getMaximumValue(315532800032L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 365 + "'", int8 == 365);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Pacific Standard Time" + "'", str27.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "UnsupportedDateTimeField" + "'", str32.equals("UnsupportedDateTimeField"));
//    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        int int4 = property2.getMaximumShortTextLength(locale3);
        java.util.Locale locale5 = null;
        int int6 = property2.getMaximumTextLength(locale5);
        org.joda.time.DurationField durationField7 = property2.getDurationField();
        org.joda.time.DateTime dateTime8 = property2.roundHalfFloorCopy();
        int int9 = property2.getLeapAmount();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        java.lang.String str5 = gregorianChronology3.toString();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.year();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology3.dayOfYear();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology3.dayOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str5.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Property[yearOfEra]", "Pacific Standard Time", 54823, 0);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.String str8 = property7.getAsShortText();
        int int9 = property7.getMaximumValue();
        org.joda.time.DateTime dateTime10 = property7.withMaximumValue();
        int int11 = property7.get();
        boolean boolean12 = fixedDateTimeZone4.equals((java.lang.Object) int11);
        int int14 = fixedDateTimeZone4.getOffset((-1L));
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 292278993 + "'", int9 == 292278993);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 54823 + "'", int14 == 54823);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        int int11 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property12 = dateTime1.centuryOfEra();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfEra();
        java.lang.String str16 = property15.getAsShortText();
        int int17 = property15.getMaximumValue();
        org.joda.time.DateTime dateTime18 = property15.withMaximumValue();
        org.joda.time.DateTime dateTime20 = dateTime18.minus((long) 1);
        org.joda.time.DateTime dateTime22 = dateTime20.plusMonths(0);
        long long23 = property12.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.era();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.secondOfDay();
        boolean boolean27 = org.joda.time.field.FieldUtils.equals((java.lang.Object) long23, (java.lang.Object) gregorianChronology24);
        try {
            long long35 = gregorianChronology24.getDateTimeMillis(0, (-28378000), 69, 54866, 10, 1970, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54866 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 292278993 + "'", int17 == 292278993);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-2922770L) + "'", long23 == (-2922770L));
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder4.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withLocale(locale7);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withLocale(locale9);
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.append(dateTimeParser11);
        boolean boolean13 = dateTimeFormatterBuilder12.canBuildFormatter();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder12.appendFractionOfHour((-10), (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        long long10 = offsetDateTimeField4.roundHalfFloor(0L);
        long long12 = offsetDateTimeField4.roundCeiling(2649600002L);
        long long14 = offsetDateTimeField4.roundHalfFloor((-61820064000000L));
        long long17 = offsetDateTimeField4.addWrapField(109L, 19);
        java.lang.String str19 = offsetDateTimeField4.getAsShortText((-62145878399635L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31536000000L + "'", long12 == 31536000000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61820064000000L) + "'", long14 == (-61820064000000L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 599616000109L + "'", long17 == 599616000109L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getCenturyOfEra();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readablePeriod5);
        int int7 = dateTime6.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfYear(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendClockhourOfHalfday(31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendDayOfYear(292278993);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder8.append(dateTimeFormatter13);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendSecondOfDay(1967);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property21 = dateTime20.yearOfEra();
        int int22 = dateTime18.compareTo((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime.Property property23 = dateTime18.weekOfWeekyear();
        org.joda.time.DateTime.Property property24 = dateTime18.dayOfYear();
        int int25 = property24.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType26, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder16.appendDecimal(dateTimeFieldType26, 2922789, 57600002);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder4.appendFraction(dateTimeFieldType26, (int) (short) -1, 279);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 365 + "'", int25 == 365);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendWeekyear(0, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendDayOfYear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendHourOfDay((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder16.appendFractionOfDay(2922789, (-28800000));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime4 = dateTime2.minusDays((int) (short) -1);
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.DateTime dateTime7 = dateTime4.withZoneRetainFields(dateTimeZone6);
        long long10 = dateTimeZone6.convertLocalToUTC((long) (byte) 0, true);
        org.joda.time.Chronology chronology11 = iSOChronology0.withZone(dateTimeZone6);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("T160000.000-0800", "", 53, 100);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance(chronology11, (org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800000L + "'", long10 == 28800000L);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(zonedChronology17);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendWeekyear(0, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendDayOfYear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder12.appendTwoDigitYear(35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTwoDigitYear(19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property2.getAsShortText(locale3);
        int int5 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime6 = property2.roundCeilingCopy();
        org.joda.time.DateTime dateTime7 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime9 = dateTime7.plusYears(135);
        org.joda.time.DateTime dateTime11 = dateTime7.plusMinutes((int) '4');
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969" + "'", str4.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(10L);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        org.joda.time.DurationField durationField7 = offsetDateTimeField4.getLeapDurationField();
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField4.getMaximumShortTextLength(locale8);
        long long12 = offsetDateTimeField4.add((long) (-1), (long) 'a');
        long long14 = offsetDateTimeField4.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property19 = dateTime18.yearOfEra();
        int int20 = dateTime16.compareTo((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime.Property property21 = dateTime16.weekOfWeekyear();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfYear();
        int int23 = property22.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property22.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField30 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType24, 57600002);
        long long32 = remainderDateTimeField30.roundCeiling((long) 31);
        long long34 = remainderDateTimeField30.remainder((-62166758822109L));
        long long36 = remainderDateTimeField30.roundHalfCeiling((long) 19);
        org.joda.time.DurationField durationField37 = remainderDateTimeField30.getRangeDurationField();
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property40 = dateTime39.yearOfEra();
        java.lang.String str41 = property40.getAsShortText();
        int int42 = property40.getMaximumValue();
        org.joda.time.DateTime dateTime43 = property40.withMaximumValue();
        org.joda.time.DateTime dateTime45 = dateTime43.minus((long) 1);
        org.joda.time.DateTime dateTime47 = dateTime45.plusMonths(0);
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property52 = dateTime51.yearOfEra();
        int int53 = dateTime49.compareTo((org.joda.time.ReadableInstant) dateTime51);
        org.joda.time.DateTime.Property property54 = dateTime49.weekOfWeekyear();
        org.joda.time.DateTime.Property property55 = dateTime49.dayOfYear();
        int int56 = property55.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = property55.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException61 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType57, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
        int int62 = dateTime47.get(dateTimeFieldType57);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField63 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField30, dateTimeFieldType57);
        int int65 = dividedDateTimeField63.get((long) 69);
        long long68 = dividedDateTimeField63.getDifferenceAsLong((-61693833600000L), 0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3061065599999L + "'", long12 == 3061065599999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 31536000000L + "'", long32 == 31536000000L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 460377891L + "'", long34 == 460377891L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1969" + "'", str41.equals("1969"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 292278993 + "'", int42 == 292278993);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 365 + "'", int56 == 365);
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 365 + "'", int62 == 365);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
    }

//    @Test
//    public void test27() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test27");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
//        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
//        org.joda.time.DateTime.Property property7 = dateTime1.dayOfYear();
//        int int8 = property7.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField15 = gregorianChronology14.minutes();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        long long19 = gregorianChronology14.add(readablePeriod16, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 100, dateTimeZone22);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone22.getName((long) 9, locale26);
//        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology14, dateTimeZone22);
//        org.joda.time.Chronology chronology29 = zonedChronology28.withUTC();
//        org.joda.time.DurationField durationField30 = zonedChronology28.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField30);
//        int int34 = unsupportedDateTimeField31.getDifference((long) 56792, (long) 1);
//        java.util.Locale locale35 = null;
//        try {
//            int int36 = unsupportedDateTimeField31.getMaximumShortTextLength(locale35);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 365 + "'", int8 == 365);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Pacific Standard Time" + "'", str27.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField2 = gregorianChronology0.eras();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = gregorianChronology0.add(readablePeriod3, (long) 1920, 54877);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1920L + "'", long6 == 1920L);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = property2.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime8 = dateTime6.minusDays((int) (short) -1);
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.DateTime dateTime11 = dateTime8.withZoneRetainFields(dateTimeZone10);
        long long14 = dateTimeZone10.convertLocalToUTC((long) 100, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((java.lang.Object) property2, dateTimeZone16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.DateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 28800100L + "'", long14 == 28800100L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
    }

//    @Test
//    public void test30() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test30");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getName((long) 9, locale12);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone8);
//        org.joda.time.Chronology chronology15 = zonedChronology14.withUTC();
//        org.joda.time.DurationField durationField16 = zonedChronology14.weekyears();
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder18 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone21 = dateTimeZoneBuilder18.toDateTimeZone("T151321.363-0700", false);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone21);
//        boolean boolean24 = cachedDateTimeZone22.equals((java.lang.Object) 57600002);
//        org.joda.time.Chronology chronology25 = iSOChronology17.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
//        org.joda.time.Chronology chronology26 = zonedChronology14.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime.Property property29 = dateTime28.yearOfEra();
//        org.joda.time.DateTime dateTime31 = dateTime28.plusMillis(135);
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime35 = dateTime33.minusDays((int) (short) -1);
//        int int36 = dateTime33.getWeekOfWeekyear();
//        int int37 = dateTime28.compareTo((org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.DateTime.Property property38 = dateTime33.millisOfSecond();
//        boolean boolean39 = cachedDateTimeZone22.equals((java.lang.Object) dateTime33);
//        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime43 = dateTime41.plusSeconds((int) (short) 10);
//        org.joda.time.DateTime dateTime44 = dateTime41.toDateTime();
//        org.joda.time.ReadablePeriod readablePeriod45 = null;
//        org.joda.time.DateTime dateTime46 = dateTime41.plus(readablePeriod45);
//        org.joda.time.TimeOfDay timeOfDay47 = dateTime41.toTimeOfDay();
//        org.joda.time.DateTime.Property property48 = dateTime41.centuryOfEra();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone53 = new org.joda.time.tz.FixedDateTimeZone("T151321.363-0700", "1", 292278993, (int) 'a');
//        org.joda.time.DateTime dateTime54 = dateTime41.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone53);
//        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField56 = gregorianChronology55.minutes();
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology55.yearOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField57, (int) (byte) -1);
//        int int61 = offsetDateTimeField59.getLeapAmount((long) 10);
//        long long63 = offsetDateTimeField59.roundHalfFloor(0L);
//        java.lang.String str64 = offsetDateTimeField59.getName();
//        long long66 = offsetDateTimeField59.roundHalfFloor((long) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType67 = offsetDateTimeField59.getType();
//        int int68 = dateTime54.get(dateTimeFieldType67);
//        boolean boolean69 = dateTime33.isSupported(dateTimeFieldType67);
//        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime.Property property74 = dateTime73.yearOfEra();
//        int int75 = dateTime71.compareTo((org.joda.time.ReadableInstant) dateTime73);
//        java.lang.String str76 = dateTime71.toString();
//        org.joda.time.DateTime dateTime78 = dateTime71.withYearOfEra(135);
//        org.joda.time.DateTime dateTime80 = dateTime71.minusYears((int) (byte) 10);
//        java.util.GregorianCalendar gregorianCalendar81 = dateTime80.toGregorianCalendar();
//        boolean boolean83 = dateTime80.isBefore(28800000L);
//        boolean boolean84 = dateTime33.isAfter((org.joda.time.ReadableInstant) dateTime80);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(timeOfDay47);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(gregorianChronology55);
//        org.junit.Assert.assertNotNull(durationField56);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 0L + "'", long63 == 0L);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "yearOfEra" + "'", str64.equals("yearOfEra"));
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 0L + "'", long66 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType67);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1969 + "'", int68 == 1969);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
//        org.junit.Assert.assertNotNull(property74);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str76.equals("1969-12-31T16:00:00.002-08:00"));
//        org.junit.Assert.assertNotNull(dateTime78);
//        org.junit.Assert.assertNotNull(dateTime80);
//        org.junit.Assert.assertNotNull(gregorianCalendar81);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
//    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfHour((int) 'a', 1920);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear(0, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property2.getAsShortText(locale3);
        int int5 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime6 = property2.roundCeilingCopy();
        org.joda.time.DateTime dateTime7 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime9 = dateTime7.plusYears(135);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readableDuration10);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969" + "'", str4.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime5 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime9 = dateTime7.minusDays((int) (short) -1);
        int int10 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfEra();
        int int16 = dateTime12.compareTo((org.joda.time.ReadableInstant) dateTime14);
        int int17 = dateTime14.getDayOfMonth();
        boolean boolean18 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime14);
        boolean boolean19 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime21 = dateTime7.withYear((int) '4');
        org.joda.time.DateTime dateTime23 = dateTime7.minusYears(0);
        try {
            org.joda.time.DateTime dateTime27 = dateTime7.withDate(0, 1969, 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600002 + "'", int4 == 57600002);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600002 + "'", int10 == 57600002);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property2.getAsShortText(locale3);
        int int5 = property2.getMaximumValue();
        java.lang.String str6 = property2.getAsString();
        int int7 = property2.get();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969" + "'", str4.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        int int6 = dateTime3.getDayOfMonth();
        org.joda.time.DateTime dateTime8 = dateTime3.plusDays(135);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTimeISO();
        boolean boolean10 = mutableDateTime9.isBeforeNow();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "T151320.765-0700");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        illegalFieldValueException2.prependMessage("1");
        java.lang.String str7 = illegalFieldValueException2.toString();
        org.junit.Assert.assertNull(dateTimeFieldType3);
        org.junit.Assert.assertNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: 1: Value \"T151320.765-0700\" for hi! is not supported" + "'", str7.equals("org.joda.time.IllegalFieldValueException: 1: Value \"T151320.765-0700\" for hi! is not supported"));
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        int int4 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime5 = property2.withMaximumValue();
        org.joda.time.DateTimeField dateTimeField6 = property2.getField();
        org.joda.time.DateTime dateTime7 = property2.roundFloorCopy();
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime7, (org.joda.time.ReadableInstant) dateTime10);
        try {
            org.joda.time.DateTime dateTime13 = dateTime7.withMonthOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 292278993 + "'", int4 == 292278993);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        org.joda.time.DurationField durationField7 = offsetDateTimeField4.getLeapDurationField();
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField4.getMaximumShortTextLength(locale8);
        long long12 = offsetDateTimeField4.add((long) (-1), (long) 'a');
        long long14 = offsetDateTimeField4.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property19 = dateTime18.yearOfEra();
        int int20 = dateTime16.compareTo((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime.Property property21 = dateTime16.weekOfWeekyear();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfYear();
        int int23 = property22.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property22.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField30 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType24, 57600002);
        long long32 = remainderDateTimeField30.roundHalfFloor((long) 57600001);
        long long34 = remainderDateTimeField30.roundCeiling(28800100L);
        long long36 = remainderDateTimeField30.roundHalfCeiling(28800000L);
        int int37 = remainderDateTimeField30.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3061065599999L + "'", long12 == 3061065599999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 31536000000L + "'", long34 == 31536000000L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Property[yearOfEra]", "Pacific Standard Time", 54823, 0);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        int int7 = fixedDateTimeZone4.getStandardOffset(0L);
        int int9 = fixedDateTimeZone4.getStandardOffset(0L);
        int int11 = fixedDateTimeZone4.getOffsetFromLocal(100L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 54823 + "'", int11 == 54823);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        org.joda.time.DurationField durationField7 = offsetDateTimeField4.getLeapDurationField();
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField4.getMaximumShortTextLength(locale8);
        long long12 = offsetDateTimeField4.add((long) (-1), (long) 'a');
        long long14 = offsetDateTimeField4.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property19 = dateTime18.yearOfEra();
        int int20 = dateTime16.compareTo((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime.Property property21 = dateTime16.weekOfWeekyear();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfYear();
        int int23 = property22.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property22.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField30 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType24, 57600002);
        long long32 = remainderDateTimeField30.roundHalfFloor((long) 57600001);
        long long34 = remainderDateTimeField30.roundCeiling(28800100L);
        long long36 = remainderDateTimeField30.roundFloor((-2208585599998L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3061065599999L + "'", long12 == 3061065599999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 31536000000L + "'", long34 == 31536000000L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-2208988800000L) + "'", long36 == (-2208988800000L));
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        java.lang.String str8 = offsetDateTimeField4.getName();
        org.joda.time.DurationField durationField9 = offsetDateTimeField4.getDurationField();
        long long11 = offsetDateTimeField4.remainder((long) (byte) -1);
        int int12 = offsetDateTimeField4.getOffset();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 31535999999L + "'", long11 == 31535999999L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        java.lang.String str6 = cachedDateTimeZone4.getNameKey(100L);
        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone4.getUncachedZone();
        int int9 = cachedDateTimeZone4.getStandardOffset(460377891L);
        java.lang.String str11 = cachedDateTimeZone4.getNameKey((long) 135);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        java.lang.String str9 = cachedDateTimeZone7.getNameKey(100L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.Chronology chronology12 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        try {
            int[] intArray16 = gregorianChronology0.get(readablePeriod14, (long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "T151320.765-0700");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.String str4 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertNull(dateTimeFieldType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "T151320.765-0700" + "'", str4.equals("T151320.765-0700"));
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 100, dateTimeZone2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusSeconds((int) ' ');
        java.lang.String str7 = dateTime4.toString();
        boolean boolean9 = dateTime4.isEqual(28801969L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str7.equals("1969-12-31T16:00:00.100-08:00"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test46() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test46");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getName((long) 9, locale12);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone8);
//        org.joda.time.Chronology chronology15 = zonedChronology14.withUTC();
//        org.joda.time.DurationField durationField16 = zonedChronology14.weekyears();
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder18 = new org.joda.time.tz.DateTimeZoneBuilder();
//        org.joda.time.DateTimeZone dateTimeZone21 = dateTimeZoneBuilder18.toDateTimeZone("T151321.363-0700", false);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone21);
//        boolean boolean24 = cachedDateTimeZone22.equals((java.lang.Object) 57600002);
//        org.joda.time.Chronology chronology25 = iSOChronology17.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
//        org.joda.time.Chronology chronology26 = zonedChronology14.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime.Property property29 = dateTime28.yearOfEra();
//        org.joda.time.DateTime dateTime31 = dateTime28.plusMillis(135);
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime35 = dateTime33.minusDays((int) (short) -1);
//        int int36 = dateTime33.getWeekOfWeekyear();
//        int int37 = dateTime28.compareTo((org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.DateTime.Property property38 = dateTime33.millisOfSecond();
//        boolean boolean39 = cachedDateTimeZone22.equals((java.lang.Object) dateTime33);
//        long long43 = cachedDateTimeZone22.convertLocalToUTC((long) 57600002, true, 0L);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = cachedDateTimeZone22.getName((long) 19, locale45);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 57600002L + "'", long43 == 57600002L);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "+00:00" + "'", str46.equals("+00:00"));
//    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.set(0L, 10);
        java.lang.String str9 = offsetDateTimeField4.getAsShortText((long) 19);
        boolean boolean10 = offsetDateTimeField4.isSupported();
        long long12 = offsetDateTimeField4.roundHalfFloor(31L);
        long long14 = offsetDateTimeField4.roundFloor(0L);
        boolean boolean15 = offsetDateTimeField4.isSupported();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property18 = dateTime17.yearOfEra();
        java.lang.String str19 = property18.getAsShortText();
        int int20 = property18.getMaximumValue();
        org.joda.time.DateTime dateTime21 = property18.withMaximumValue();
        org.joda.time.DateTime dateTime23 = dateTime21.minus((long) 1);
        org.joda.time.DateTime dateTime25 = dateTime23.plusMonths(0);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property30 = dateTime29.yearOfEra();
        int int31 = dateTime27.compareTo((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.DateTime.Property property32 = dateTime27.weekOfWeekyear();
        org.joda.time.DateTime.Property property33 = dateTime27.dayOfYear();
        int int34 = property33.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property33.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType35, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
        int int40 = dateTime25.get(dateTimeFieldType35);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType35, 9);
        long long44 = dividedDateTimeField42.roundFloor((long) 69);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61820064000000L) + "'", long7 == (-61820064000000L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1969" + "'", str19.equals("1969"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 292278993 + "'", int20 == 292278993);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 365 + "'", int34 == 365);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 365 + "'", int40 == 365);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-220924800000L) + "'", long44 == (-220924800000L));
    }

//    @Test
//    public void test48() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test48");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getName((long) 9, locale12);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone15 = zonedChronology14.getZone();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime20 = dateTime18.plusSeconds((int) (short) 10);
//        org.joda.time.DateTime dateTime21 = dateTime18.toDateTime();
//        org.joda.time.ReadablePeriod readablePeriod22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime18.plus(readablePeriod22);
//        org.joda.time.DateTime dateTime25 = dateTime18.plusYears(0);
//        org.joda.time.MutableDateTime mutableDateTime26 = dateTime18.toMutableDateTime();
//        org.joda.time.DateTime.Property property27 = dateTime18.yearOfCentury();
//        int int28 = dateTimeZone15.getOffset((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime.Property property29 = dateTime18.secondOfMinute();
//        int int30 = property29.getMaximumValueOverall();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(mutableDateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-28800000) + "'", int28 == (-28800000));
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 59 + "'", int30 == 59);
//    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (int) (short) 1, 57600001);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test50");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

//    @Test
//    public void test51() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test51");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
//        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
//        java.lang.String str6 = dateTime1.toString();
//        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
//        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
//        org.joda.time.DateTime dateTime12 = dateTime10.withYear(9);
//        org.joda.time.DateTime dateTime15 = dateTime10.withDurationAdded(0L, 1969);
//        int int16 = dateTime15.getCenturyOfEra();
//        long long17 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime19 = dateTime15.plusMillis(0);
//        java.util.TimeZone timeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 100, dateTimeZone22);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone22.getName((long) 9, locale26);
//        java.util.Locale locale29 = null;
//        java.lang.String str30 = dateTimeZone22.getShortName((long) 1969, locale29);
//        org.joda.time.DateTime dateTime31 = dateTime15.withZoneRetainFields(dateTimeZone22);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 19 + "'", int16 == 19);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-315619199998L) + "'", long17 == (-315619199998L));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Pacific Standard Time" + "'", str27.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PST" + "'", str30.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime31);
//    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test52");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Property[yearOfEra]", "Pacific Standard Time", 54823, 0);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        int int7 = fixedDateTimeZone4.getStandardOffset(0L);
        int int9 = fixedDateTimeZone4.getStandardOffset(0L);
        boolean boolean10 = fixedDateTimeZone4.isFixed();
        int int12 = fixedDateTimeZone4.getOffset((-28800000L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 54823 + "'", int12 == 54823);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test53");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        java.lang.String str8 = offsetDateTimeField4.getName();
        org.joda.time.DurationField durationField9 = offsetDateTimeField4.getDurationField();
        long long11 = offsetDateTimeField4.roundHalfFloor((long) 2);
        org.joda.time.DurationField durationField12 = offsetDateTimeField4.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNull(durationField12);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test54");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        int int5 = dateTime1.getYearOfEra();
        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.DateTime dateTime9 = dateTime6.withFieldAdded(durationFieldType7, 1920);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test55() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test55");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
//        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
//        int int6 = dateTime3.getEra();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime3.plus(readablePeriod7);
//        boolean boolean10 = dateTime8.isBefore(10L);
//        org.joda.time.DateTime dateTime11 = dateTime8.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime15 = dateTime13.minusDays((int) (short) -1);
//        java.util.TimeZone timeZone16 = null;
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
//        org.joda.time.DateTime dateTime18 = dateTime15.withZoneRetainFields(dateTimeZone17);
//        long long21 = dateTimeZone17.convertLocalToUTC((long) 100, false);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = dateTimeZone17.getShortName((long) 0, locale23);
//        org.joda.time.DateTime dateTime25 = dateTime8.toDateTime(dateTimeZone17);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800100L + "'", long21 == 28800100L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "PST" + "'", str24.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime25);
//    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test56");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = property2.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime6 = dateTime4.withWeekyear((int) (byte) 100);
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = property7.roundFloorCopy();
        org.joda.time.ReadableInstant readableInstant9 = null;
        boolean boolean10 = dateTime8.isAfter(readableInstant9);
        org.joda.time.DateTime.Property property11 = dateTime8.minuteOfHour();
        org.joda.time.DateTime.Property property12 = dateTime8.minuteOfDay();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test57");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField14 = gregorianChronology13.minutes();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) (byte) -1);
        int int19 = offsetDateTimeField17.getLeapAmount((long) 10);
        long long21 = offsetDateTimeField17.roundHalfFloor(0L);
        long long23 = offsetDateTimeField17.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime28 = dateTime26.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate29 = dateTime28.toLocalDate();
        java.lang.String str30 = dateTimeFormatter24.print((org.joda.time.ReadablePartial) localDate29);
        int[] intArray37 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray39 = offsetDateTimeField17.set((org.joda.time.ReadablePartial) localDate29, 0, intArray37, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField41 = gregorianChronology40.minutes();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, (int) (byte) -1);
        int int46 = offsetDateTimeField44.getLeapAmount((long) 10);
        long long48 = offsetDateTimeField44.roundHalfFloor(0L);
        long long50 = offsetDateTimeField44.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime55 = dateTime53.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate56 = dateTime55.toLocalDate();
        java.lang.String str57 = dateTimeFormatter51.print((org.joda.time.ReadablePartial) localDate56);
        int[] intArray64 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray66 = offsetDateTimeField44.set((org.joda.time.ReadablePartial) localDate56, 0, intArray64, (int) (byte) 100);
        gregorianChronology9.validate((org.joda.time.ReadablePartial) localDate29, intArray66);
        int[] intArray69 = gregorianChronology3.get((org.joda.time.ReadablePartial) localDate29, (long) 1920);
        org.joda.time.DateTimeField dateTimeField70 = gregorianChronology3.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField71 = gregorianChronology3.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "T������.000" + "'", str30.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter51);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "T������.000" + "'", str57.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(dateTimeField71);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test58");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readablePeriod5);
        org.joda.time.DateTime dateTime8 = dateTime1.plusYears(0);
        org.joda.time.DateTime dateTime9 = dateTime1.withLaterOffsetAtOverlap();
        int int10 = dateTime9.getYear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test59");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Property[yearOfEra]", "Pacific Standard Time", 54823, 0);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        int int7 = fixedDateTimeZone4.getStandardOffset(0L);
        int int9 = fixedDateTimeZone4.getStandardOffset(0L);
        long long12 = fixedDateTimeZone4.adjustOffset((-2922770L), false);
        java.util.TimeZone timeZone13 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2922770L) + "'", long12 == (-2922770L));
        org.junit.Assert.assertNotNull(timeZone13);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test60");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField14 = gregorianChronology13.minutes();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) (byte) -1);
        int int19 = offsetDateTimeField17.getLeapAmount((long) 10);
        long long21 = offsetDateTimeField17.roundHalfFloor(0L);
        long long23 = offsetDateTimeField17.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime28 = dateTime26.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate29 = dateTime28.toLocalDate();
        java.lang.String str30 = dateTimeFormatter24.print((org.joda.time.ReadablePartial) localDate29);
        int[] intArray37 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray39 = offsetDateTimeField17.set((org.joda.time.ReadablePartial) localDate29, 0, intArray37, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField41 = gregorianChronology40.minutes();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, (int) (byte) -1);
        int int46 = offsetDateTimeField44.getLeapAmount((long) 10);
        long long48 = offsetDateTimeField44.roundHalfFloor(0L);
        long long50 = offsetDateTimeField44.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime55 = dateTime53.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate56 = dateTime55.toLocalDate();
        java.lang.String str57 = dateTimeFormatter51.print((org.joda.time.ReadablePartial) localDate56);
        int[] intArray64 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray66 = offsetDateTimeField44.set((org.joda.time.ReadablePartial) localDate56, 0, intArray64, (int) (byte) 100);
        gregorianChronology9.validate((org.joda.time.ReadablePartial) localDate29, intArray66);
        int[] intArray69 = gregorianChronology3.get((org.joda.time.ReadablePartial) localDate29, (long) 1920);
        org.joda.time.DateTimeField dateTimeField70 = gregorianChronology3.minuteOfHour();
        org.joda.time.ReadablePeriod readablePeriod71 = null;
        long long74 = gregorianChronology3.add(readablePeriod71, (long) 10, (int) (byte) 100);
        org.joda.time.DurationField durationField75 = gregorianChronology3.millis();
        org.joda.time.DurationFieldType durationFieldType76 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField77 = new org.joda.time.field.DecoratedDurationField(durationField75, durationFieldType76);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "T������.000" + "'", str30.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter51);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "T������.000" + "'", str57.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 10L + "'", long74 == 10L);
        org.junit.Assert.assertNotNull(durationField75);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test61");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder1 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTimeZoneBuilder1.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        boolean boolean7 = cachedDateTimeZone5.equals((java.lang.Object) 57600002);
        int int9 = cachedDateTimeZone5.getStandardOffset((long) 54823);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField12 = gregorianChronology11.minutes();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) (byte) -1);
        long long18 = offsetDateTimeField15.add((long) 135, (long) 100);
        java.util.TimeZone timeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.minuteOfDay();
        java.util.TimeZone timeZone26 = null;
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forTimeZone(timeZone26);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27);
        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology28);
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology28.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField33 = gregorianChronology32.minutes();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology32.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, (int) (byte) -1);
        int int38 = offsetDateTimeField36.getLeapAmount((long) 10);
        long long40 = offsetDateTimeField36.roundHalfFloor(0L);
        long long42 = offsetDateTimeField36.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime47 = dateTime45.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate48 = dateTime47.toLocalDate();
        java.lang.String str49 = dateTimeFormatter43.print((org.joda.time.ReadablePartial) localDate48);
        int[] intArray56 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray58 = offsetDateTimeField36.set((org.joda.time.ReadablePartial) localDate48, 0, intArray56, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology59 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField60 = gregorianChronology59.minutes();
        org.joda.time.DateTimeField dateTimeField61 = gregorianChronology59.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField(dateTimeField61, (int) (byte) -1);
        int int65 = offsetDateTimeField63.getLeapAmount((long) 10);
        long long67 = offsetDateTimeField63.roundHalfFloor(0L);
        long long69 = offsetDateTimeField63.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter70 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime72 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime74 = dateTime72.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate75 = dateTime74.toLocalDate();
        java.lang.String str76 = dateTimeFormatter70.print((org.joda.time.ReadablePartial) localDate75);
        int[] intArray83 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray85 = offsetDateTimeField63.set((org.joda.time.ReadablePartial) localDate75, 0, intArray83, (int) (byte) 100);
        gregorianChronology28.validate((org.joda.time.ReadablePartial) localDate48, intArray85);
        int[] intArray88 = gregorianChronology22.get((org.joda.time.ReadablePartial) localDate48, (long) 1920);
        java.util.Locale locale90 = null;
        java.lang.String str91 = offsetDateTimeField15.getAsText((org.joda.time.ReadablePartial) localDate48, (int) '4', locale90);
        java.lang.String str92 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate48);
        java.util.Locale locale93 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3155760000135L + "'", long18 == 3155760000135L);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "T������.000" + "'", str49.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(gregorianChronology59);
        org.junit.Assert.assertNotNull(durationField60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 0L + "'", long67 == 0L);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 0L + "'", long69 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter70);
        org.junit.Assert.assertNotNull(dateTime74);
        org.junit.Assert.assertNotNull(localDate75);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "T������.000" + "'", str76.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "52" + "'", str91.equals("52"));
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "1969365T������.000" + "'", str92.equals("1969365T������.000"));
        org.junit.Assert.assertNull(locale93);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test62");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        int int4 = property2.getMaximumShortTextLength(locale3);
        java.util.Locale locale5 = null;
        int int6 = property2.getMaximumTextLength(locale5);
        org.joda.time.DurationField durationField7 = property2.getDurationField();
        org.joda.time.DateTime dateTime8 = property2.roundHalfFloorCopy();
        int int9 = dateTime8.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test63");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = property2.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime6 = dateTime4.withWeekyear((int) (byte) 100);
        org.joda.time.DateTime dateTime8 = dateTime6.minusHours(2);
        org.joda.time.DateTime dateTime10 = dateTime8.minusMillis(35);
        org.joda.time.TimeOfDay timeOfDay11 = dateTime8.toTimeOfDay();
        java.util.GregorianCalendar gregorianCalendar12 = dateTime8.toGregorianCalendar();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(timeOfDay11);
        org.junit.Assert.assertNotNull(gregorianCalendar12);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test64");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long9 = offsetDateTimeField4.set(0L, 4);
        java.lang.String str11 = offsetDateTimeField4.getAsShortText((long) (byte) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField13 = gregorianChronology12.minutes();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) -1);
        int int18 = offsetDateTimeField16.getLeapAmount((long) 10);
        org.joda.time.DurationField durationField19 = offsetDateTimeField16.getLeapDurationField();
        java.util.Locale locale20 = null;
        int int21 = offsetDateTimeField16.getMaximumShortTextLength(locale20);
        long long24 = offsetDateTimeField16.add((long) (-1), (long) 'a');
        long long26 = offsetDateTimeField16.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property31 = dateTime30.yearOfEra();
        int int32 = dateTime28.compareTo((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime.Property property33 = dateTime28.weekOfWeekyear();
        org.joda.time.DateTime.Property property34 = dateTime28.dayOfYear();
        int int35 = property34.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property34.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType36, 57600002);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType36);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62009366400000L) + "'", long9 == (-62009366400000L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1968" + "'", str11.equals("1968"));
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(durationField19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3061065599999L + "'", long24 == 3061065599999L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 365 + "'", int35 == 365);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
    }

//    @Test
//    public void test65() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test65");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("Property[yearOfEra]");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder4.toFormatter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicTTime();
//        java.util.Locale locale7 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withLocale(locale7);
//        java.util.Locale locale9 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withLocale(locale9);
//        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.append(dateTimeParser11);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder4.appendMillisOfDay(9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendEraText();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
//        int int21 = dateTime17.compareTo((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.DateTime.Property property22 = dateTime17.weekOfWeekyear();
//        org.joda.time.DateTime.Property property23 = dateTime17.dayOfYear();
//        int int24 = property23.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property23.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField31 = gregorianChronology30.minutes();
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        long long35 = gregorianChronology30.add(readablePeriod32, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone37 = null;
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forTimeZone(timeZone37);
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone38);
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((long) 100, dateTimeZone38);
//        java.util.Locale locale42 = null;
//        java.lang.String str43 = dateTimeZone38.getName((long) 9, locale42);
//        org.joda.time.chrono.ZonedChronology zonedChronology44 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology30, dateTimeZone38);
//        org.joda.time.Chronology chronology45 = zonedChronology44.withUTC();
//        org.joda.time.DurationField durationField46 = zonedChronology44.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField47 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType25, durationField46);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder15.appendSignedDecimal(dateTimeFieldType25, 54825, (int) (byte) 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeParser11);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 365 + "'", int24 == 365);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Pacific Standard Time" + "'", str43.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology44);
//        org.junit.Assert.assertNotNull(chronology45);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
//    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test66");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = dateTime3.withZoneRetainFields(dateTimeZone5);
        long long9 = dateTimeZone5.convertLocalToUTC((long) 100, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        long long13 = dateTimeZone5.convertUTCToLocal((-62145878399635L));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800100L + "'", long9 == 28800100L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-62145906777635L) + "'", long13 == (-62145906777635L));
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test67");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "T151320.765-0700");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        org.joda.time.DurationFieldType durationFieldType6 = illegalFieldValueException2.getDurationFieldType();
        java.lang.Number number7 = illegalFieldValueException2.getUpperBound();
        java.lang.String str8 = illegalFieldValueException2.getFieldName();
        illegalFieldValueException2.prependMessage("ZonedChronology[GregorianChronology[UTC], T151321.363-0700]");
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNull(dateTimeFieldType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "T151320.765-0700" + "'", str5.equals("T151320.765-0700"));
        org.junit.Assert.assertNull(durationFieldType6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test68");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        java.lang.String str9 = cachedDateTimeZone7.getNameKey(100L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        long long15 = gregorianChronology0.add(readablePeriod12, 100L, (int) (short) -1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test69");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendSecondOfMinute(35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendPattern("1968");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendHourOfHalfday(1967);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendHourOfHalfday(54866);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test70");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        org.joda.time.DurationField durationField7 = offsetDateTimeField4.getLeapDurationField();
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField4.getMaximumShortTextLength(locale8);
        long long12 = offsetDateTimeField4.add((long) (-1), (long) 'a');
        int int14 = offsetDateTimeField4.getMinimumValue(31L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3061065599999L + "'", long12 == 3061065599999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

//    @Test
//    public void test71() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test71");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
//        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
//        org.joda.time.DateTime.Property property7 = dateTime1.dayOfYear();
//        int int8 = property7.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField15 = gregorianChronology14.minutes();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        long long19 = gregorianChronology14.add(readablePeriod16, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 100, dateTimeZone22);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone22.getName((long) 9, locale26);
//        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology14, dateTimeZone22);
//        org.joda.time.Chronology chronology29 = zonedChronology28.withUTC();
//        org.joda.time.DurationField durationField30 = zonedChronology28.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField30);
//        int int34 = unsupportedDateTimeField31.getDifference((long) 56792, (long) 1);
//        boolean boolean35 = unsupportedDateTimeField31.isSupported();
//        try {
//            int int37 = unsupportedDateTimeField31.get((long) 59);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 365 + "'", int8 == 365);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Pacific Standard Time" + "'", str27.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test72");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = property2.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime6 = dateTime4.withWeekyear((int) (byte) 100);
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        org.joda.time.DateTime dateTime8 = property7.roundFloorCopy();
        org.joda.time.ReadableInstant readableInstant9 = null;
        boolean boolean10 = dateTime8.isAfter(readableInstant9);
        org.joda.time.DateTime.Property property11 = dateTime8.minuteOfHour();
        java.lang.String str12 = dateTime8.toString();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime8.plus(readablePeriod13);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0100-01-01T00:00:00.000-07:52:58" + "'", str12.equals("0100-01-01T00:00:00.000-07:52:58"));
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test73");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.plusMillis(135);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime8 = dateTime6.minusDays((int) (short) -1);
        int int9 = dateTime6.getWeekOfWeekyear();
        int int10 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime12 = dateTime1.withMillis((long) 8);
        boolean boolean13 = dateTime1.isEqualNow();
        java.util.GregorianCalendar gregorianCalendar14 = dateTime1.toGregorianCalendar();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar14);
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test74");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.years();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test75");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime8 = dateTime6.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime6.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime6.plus(readablePeriod10);
        org.joda.time.TimeOfDay timeOfDay12 = dateTime6.toTimeOfDay();
        org.joda.time.DateTime.Property property13 = dateTime6.centuryOfEra();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("T151321.363-0700", "1", 292278993, (int) 'a');
        org.joda.time.DateTime dateTime19 = dateTime6.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        int int20 = cachedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime19);
        try {
            org.joda.time.DateTime dateTime22 = dateTime19.withMillisOfDay((-28378000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28378000 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(timeOfDay12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test76");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendDayOfYear(2922789);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYear(57610, 57600002);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test77");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("PST");
    }

//    @Test
//    public void test78() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test78");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getName((long) 9, locale12);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.hourOfHalfday();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        long long19 = gregorianChronology0.add(readablePeriod16, 31535999999L, 8);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 31535999999L + "'", long19 == 31535999999L);
//    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test79");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatterBuilder9.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale12 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter11.withLocale(locale12);
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withLocale(locale14);
        org.joda.time.format.DateTimeParser dateTimeParser16 = dateTimeFormatter15.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder9.append(dateTimeParser16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder4.append(dateTimeParser16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendTwoDigitWeekyear(12, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeParser16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
    }

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test80");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        long long10 = offsetDateTimeField4.roundHalfFloor(0L);
        java.lang.String str12 = offsetDateTimeField4.getAsText((long) (short) 10);
        int int14 = offsetDateTimeField4.get((-62104060743208L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969" + "'", str12.equals("1969"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test81() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test81");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("hi!", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test82() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test82");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
//        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
//        org.joda.time.DateTime.Property property7 = dateTime1.dayOfYear();
//        int int8 = property7.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField15 = gregorianChronology14.minutes();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        long long19 = gregorianChronology14.add(readablePeriod16, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 100, dateTimeZone22);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone22.getName((long) 9, locale26);
//        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology14, dateTimeZone22);
//        org.joda.time.Chronology chronology29 = zonedChronology28.withUTC();
//        org.joda.time.DurationField durationField30 = zonedChronology28.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField30);
//        java.lang.String str32 = unsupportedDateTimeField31.toString();
//        java.util.TimeZone timeZone34 = null;
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forTimeZone(timeZone34);
//        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone35);
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) 100, dateTimeZone35);
//        org.joda.time.LocalDate localDate38 = dateTime37.toLocalDate();
//        java.util.Locale locale40 = null;
//        try {
//            java.lang.String str41 = unsupportedDateTimeField31.getAsShortText((org.joda.time.ReadablePartial) localDate38, (-1), locale40);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 365 + "'", int8 == 365);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Pacific Standard Time" + "'", str27.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "UnsupportedDateTimeField" + "'", str32.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertNotNull(gregorianChronology36);
//        org.junit.Assert.assertNotNull(localDate38);
//    }

//    @Test
//    public void test83() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test83");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
//        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime8 = dateTime6.minusDays((int) (short) -1);
//        java.util.TimeZone timeZone9 = null;
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
//        org.joda.time.DateTime dateTime11 = dateTime8.withZoneRetainFields(dateTimeZone10);
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = dateTimeZone10.getName((long) 135, locale13);
//        org.joda.time.DateTime dateTime15 = dateTime3.withZone(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Pacific Standard Time" + "'", str14.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test84() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test84");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = property2.addWrapFieldToCopy((-1));
        int int5 = property2.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
    }

    @Test
    public void test85() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test85");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.era();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.era();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test86() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test86");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendWeekOfWeekyear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendHourOfHalfday(16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

//    @Test
//    public void test87() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test87");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
//        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
//        org.joda.time.DateTime.Property property7 = dateTime1.dayOfYear();
//        int int8 = property7.get();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType9, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField15 = gregorianChronology14.minutes();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        long long19 = gregorianChronology14.add(readablePeriod16, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 100, dateTimeZone22);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = dateTimeZone22.getName((long) 9, locale26);
//        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology14, dateTimeZone22);
//        org.joda.time.Chronology chronology29 = zonedChronology28.withUTC();
//        org.joda.time.DurationField durationField30 = zonedChronology28.weekyears();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType9, durationField30);
//        int int34 = unsupportedDateTimeField31.getDifference((long) 56792, (long) 1);
//        boolean boolean35 = unsupportedDateTimeField31.isSupported();
//        java.util.Locale locale36 = null;
//        try {
//            int int37 = unsupportedDateTimeField31.getMaximumTextLength(locale36);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 365 + "'", int8 == 365);
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Pacific Standard Time" + "'", str27.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

    @Test
    public void test88() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test88");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        org.joda.time.DurationField durationField7 = offsetDateTimeField4.getLeapDurationField();
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField4.getMaximumShortTextLength(locale8);
        long long12 = offsetDateTimeField4.add((long) (-1), (long) 'a');
        long long14 = offsetDateTimeField4.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property19 = dateTime18.yearOfEra();
        int int20 = dateTime16.compareTo((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime.Property property21 = dateTime16.weekOfWeekyear();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfYear();
        int int23 = property22.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property22.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField30 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType24, 57600002);
        long long32 = remainderDateTimeField30.roundCeiling((long) 31);
        org.joda.time.DurationField durationField33 = remainderDateTimeField30.getRangeDurationField();
        long long35 = remainderDateTimeField30.roundFloor((long) 57600001);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3061065599999L + "'", long12 == 3061065599999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 31536000000L + "'", long32 == 31536000000L);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
    }

    @Test
    public void test89() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test89");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, 292278993);
        java.lang.Class<?> wildcardClass7 = dateTime6.getClass();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test90() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test90");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        org.joda.time.DurationField durationField7 = offsetDateTimeField4.getLeapDurationField();
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField4.getMaximumShortTextLength(locale8);
        long long12 = offsetDateTimeField4.add((long) (-1), (long) 'a');
        long long14 = offsetDateTimeField4.roundHalfFloor((long) (short) 1);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property19 = dateTime18.yearOfEra();
        int int20 = dateTime16.compareTo((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime.Property property21 = dateTime16.weekOfWeekyear();
        org.joda.time.DateTime.Property property22 = dateTime16.dayOfYear();
        int int23 = property22.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property22.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField30 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType24, 57600002);
        long long32 = remainderDateTimeField30.roundCeiling((long) 31);
        long long34 = remainderDateTimeField30.remainder((-62166758822109L));
        long long36 = remainderDateTimeField30.roundHalfCeiling((long) 19);
        org.joda.time.DurationField durationField37 = remainderDateTimeField30.getRangeDurationField();
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property40 = dateTime39.yearOfEra();
        java.lang.String str41 = property40.getAsShortText();
        int int42 = property40.getMaximumValue();
        org.joda.time.DateTime dateTime43 = property40.withMaximumValue();
        org.joda.time.DateTime dateTime45 = dateTime43.minus((long) 1);
        org.joda.time.DateTime dateTime47 = dateTime45.plusMonths(0);
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property52 = dateTime51.yearOfEra();
        int int53 = dateTime49.compareTo((org.joda.time.ReadableInstant) dateTime51);
        org.joda.time.DateTime.Property property54 = dateTime49.weekOfWeekyear();
        org.joda.time.DateTime.Property property55 = dateTime49.dayOfYear();
        int int56 = property55.get();
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = property55.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException61 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType57, (java.lang.Number) 54825, (java.lang.Number) (short) 0, (java.lang.Number) (-86398030L));
        int int62 = dateTime47.get(dateTimeFieldType57);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField63 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField30, dateTimeFieldType57);
        int int65 = dividedDateTimeField63.get((long) 69);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField66 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField63);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3061065599999L + "'", long12 == 3061065599999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 31536000000L + "'", long32 == 31536000000L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 460377891L + "'", long34 == 460377891L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1969" + "'", str41.equals("1969"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 292278993 + "'", int42 == 292278993);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 365 + "'", int56 == 365);
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 365 + "'", int62 == 365);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
    }

    @Test
    public void test91() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test91");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.withYear(9);
        org.joda.time.DateTime dateTime14 = dateTime10.plusDays((int) (short) 100);
        int int15 = dateTime10.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property16 = dateTime10.minuteOfHour();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 53 + "'", int15 == 53);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test92() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test92");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendWeekyear(0, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendDayOfYear((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendHourOfDay((int) (byte) 1);
        boolean boolean17 = dateTimeFormatterBuilder14.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test93() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test93");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        boolean boolean8 = offsetDateTimeField4.isSupported();
        java.util.Locale locale11 = null;
        long long12 = offsetDateTimeField4.set((long) 69, "0", locale11);
        long long15 = offsetDateTimeField4.getDifferenceAsLong((-62166758822109L), 1672502400000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62135596799931L) + "'", long12 == (-62135596799931L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-2022L) + "'", long15 == (-2022L));
    }

    @Test
    public void test94() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test94");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        int int6 = dateTime3.getEra();
        int int7 = dateTime3.getMillisOfSecond();
        org.joda.time.DateTime dateTime9 = dateTime3.minusMillis((int) (byte) 0);
        org.joda.time.DateTime.Property property10 = dateTime9.era();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
        int int14 = dateTime13.getWeekyear();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "AD" + "'", str12.equals("AD"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1968) + "'", int14 == (-1968));
    }

    @Test
    public void test95() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test95");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.minusHours(57600002);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property13 = dateTime12.yearOfEra();
        int int14 = dateTime10.compareTo((org.joda.time.ReadableInstant) dateTime12);
        java.lang.String str15 = dateTime10.toString();
        org.joda.time.DateTime dateTime17 = dateTime10.withYearOfEra(135);
        org.joda.time.DateTime dateTime19 = dateTime10.minusYears((int) (byte) 10);
        int int20 = dateTime10.getCenturyOfEra();
        org.joda.time.DateTime.Property property21 = dateTime10.centuryOfEra();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
        java.lang.String str25 = property24.getAsShortText();
        int int26 = property24.getMaximumValue();
        org.joda.time.DateTime dateTime27 = property24.withMaximumValue();
        org.joda.time.DateTime dateTime29 = dateTime27.minus((long) 1);
        org.joda.time.DateTime dateTime31 = dateTime29.plusMonths(0);
        long long32 = property21.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.era();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology33.secondOfDay();
        boolean boolean36 = org.joda.time.field.FieldUtils.equals((java.lang.Object) long32, (java.lang.Object) gregorianChronology33);
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime40 = dateTime38.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime41 = dateTime38.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod42 = null;
        org.joda.time.DateTime dateTime43 = dateTime38.plus(readablePeriod42);
        org.joda.time.TimeOfDay timeOfDay44 = dateTime38.toTimeOfDay();
        long long46 = gregorianChronology33.set((org.joda.time.ReadablePartial) timeOfDay44, (long) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime47 = dateTime8.toMutableDateTime((org.joda.time.Chronology) gregorianChronology33);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str15.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 19 + "'", int20 == 19);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1969" + "'", str25.equals("1969"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 292278993 + "'", int26 == 292278993);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2922770L) + "'", long32 == (-2922770L));
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(timeOfDay44);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 57600002L + "'", long46 == 57600002L);
        org.junit.Assert.assertNotNull(mutableDateTime47);
    }
}

