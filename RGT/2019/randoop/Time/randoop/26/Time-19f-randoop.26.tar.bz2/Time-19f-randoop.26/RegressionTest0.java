import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DurationField durationField2 = null;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField3 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(1, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 1, (int) (byte) 1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        try {
            long long2 = dateTimeFormatter0.parseMillis("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) 35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.Chronology chronology7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 0, 0, 1, 0, 35, (int) (short) -1, 1, chronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("hi!", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 10L, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.days();
        org.joda.time.DurationField durationField2 = gregorianChronology0.eras();
        try {
            long long7 = gregorianChronology0.getDateTimeMillis(1, (int) (short) -1, 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) (-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withLocale(locale2);
        try {
            org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("hi!", dateTimeFormatter3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) '#', 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 135 + "'", int2 == 135);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            int[] intArray3 = gregorianChronology0.get(readablePartial1, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, (-1), (int) (short) 100, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField2, (int) ' ', 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for yearOfEra must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 0L, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int[] intArray7 = null;
        try {
            int[] intArray9 = offsetDateTimeField4.set(readablePartial5, (int) '4', intArray7, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (int) ' ', 31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 35, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime10 = dateTime8.minusDays((int) (short) -1);
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.DateTime dateTime13 = dateTime10.withZoneRetainFields(dateTimeZone12);
        try {
            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((int) 'a', (int) (byte) 1, 2, (int) (byte) 1, (int) ' ', (int) (short) 100, (int) (short) 100, dateTimeZone12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount((long) 35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime5 = dateTime3.minusDays((int) (short) -1);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        org.joda.time.ReadablePartial readablePartial7 = null;
        int[] intArray14 = new int[] { 31, (short) 10, '#', (short) 1, 'a' };
        try {
            int[] intArray16 = offsetDateTimeField4.addWrapField(readablePartial7, (int) '4', intArray14, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateParser();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("hi!", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        java.util.Locale locale5 = null;
        try {
            java.lang.String str6 = dateTime3.toString("T151324.051-0700", locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime5 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.DateTime dateTime7 = dateTime1.withFields(readablePartial6);
        java.util.Locale locale9 = null;
        try {
            java.lang.String str10 = dateTime7.toString("T151321.363-0700", locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600002 + "'", int4 == 57600002);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        int int11 = dateTime7.compareTo((org.joda.time.ReadableInstant) dateTime9);
        int int12 = dateTime9.getEra();
        boolean boolean13 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        try {
            int int15 = dateTime9.get(dateTimeFieldType14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, number1, (java.lang.Number) 9, (java.lang.Number) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, (int) (short) 10, 135, 1, 2, (int) (short) -1, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime5 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.DateTime dateTime7 = dateTime1.withFields(readablePartial6);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.DateTime dateTime10 = dateTime1.withFieldAdded(durationFieldType8, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600002 + "'", int4 == 57600002);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.clockhourOfHalfday();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        try {
            int[] intArray9 = gregorianChronology3.get(readablePeriod6, (long) (byte) 1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.dayOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        boolean boolean2 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        try {
            org.joda.time.DateTime dateTime12 = dateTime10.withEra((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime5 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.DateTime dateTime7 = dateTime1.withFields(readablePartial6);
        boolean boolean9 = dateTime1.isEqual((long) (-1));
        try {
            org.joda.time.DateTime dateTime13 = dateTime1.withDate(1969, (int) (byte) 100, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600002 + "'", int4 == 57600002);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.weekOfWeekyear();
        long long10 = gregorianChronology3.add((long) (-1), 0L, 9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        try {
            int[] intArray13 = gregorianChronology3.get(readablePeriod11, (long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime6 = dateTime4.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        int[] intArray9 = new int[] { 19 };
        try {
            gregorianChronology0.validate((org.joda.time.ReadablePartial) localDate7, intArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "T151320.765-0700");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.Number number5 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNull(dateTimeFieldType4);
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.lang.Appendable appendable3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime8 = dateTime6.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate9 = dateTime8.toLocalDate();
        java.lang.String str10 = dateTimeFormatter4.print((org.joda.time.ReadablePartial) localDate9);
        try {
            dateTimeFormatter0.printTo(appendable3, (org.joda.time.ReadablePartial) localDate9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "T������.000" + "'", str10.equals("T������.000"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "yearOfEra");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        try {
            long long7 = gregorianChronology0.getDateTimeMillis(2, (int) (byte) -1, (int) (byte) 100, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86400000]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        int int6 = dateTime3.getEra();
        org.joda.time.DateTime.Property property7 = dateTime3.monthOfYear();
        long long8 = property7.remainder();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2649600002L + "'", long8 == 2649600002L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (int) (byte) 0, 135);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withZone(dateTimeZone3);
        boolean boolean6 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 1.0d, (java.lang.Object) dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(2, 960);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1920 + "'", int2 == 1920);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.withYear(9);
        org.joda.time.DateTime dateTime15 = dateTime10.withDurationAdded(0L, 1969);
        try {
            org.joda.time.DateTime dateTime17 = dateTime15.withCenturyOfEra((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for centuryOfEra must be in the range [0,2922789]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        try {
            long long2 = org.joda.time.field.FieldUtils.safeMultiply(3155760000135L, (long) 57600002);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The calculation caused an overflow: 3155760000135 * 57600002");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray5 = gregorianChronology0.get(readablePeriod3, (long) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-10) + "'", int1 == (-10));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = gregorianChronology14.minutes();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) (byte) -1);
        int int20 = offsetDateTimeField18.getLeapAmount((long) 10);
        long long22 = offsetDateTimeField18.roundHalfFloor(0L);
        long long24 = offsetDateTimeField18.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime29 = dateTime27.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate30 = dateTime29.toLocalDate();
        java.lang.String str31 = dateTimeFormatter25.print((org.joda.time.ReadablePartial) localDate30);
        int[] intArray38 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray40 = offsetDateTimeField18.set((org.joda.time.ReadablePartial) localDate30, 0, intArray38, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField42 = gregorianChronology41.minutes();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology41.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, (int) (byte) -1);
        int int47 = offsetDateTimeField45.getLeapAmount((long) 10);
        long long49 = offsetDateTimeField45.roundHalfFloor(0L);
        long long51 = offsetDateTimeField45.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime56 = dateTime54.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate57 = dateTime56.toLocalDate();
        java.lang.String str58 = dateTimeFormatter52.print((org.joda.time.ReadablePartial) localDate57);
        int[] intArray65 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray67 = offsetDateTimeField45.set((org.joda.time.ReadablePartial) localDate57, 0, intArray65, (int) (byte) 100);
        gregorianChronology10.validate((org.joda.time.ReadablePartial) localDate30, intArray67);
        try {
            org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(31, (int) (byte) 0, 960, (int) (byte) 1, 2, 292278993, (int) 'a', (org.joda.time.Chronology) gregorianChronology10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "T������.000" + "'", str31.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter52);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(localDate57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "T������.000" + "'", str58.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray67);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.weekOfWeekyear();
        try {
            long long12 = gregorianChronology3.getDateTimeMillis(0L, (int) (byte) 0, 31, (int) (short) -1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test073");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.set(0L, 10);
        java.util.Locale locale10 = null;
        try {
            long long11 = offsetDateTimeField4.set(10L, "Pacific Standard Time", locale10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Pacific Standard Time\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61820064000000L) + "'", long7 == (-61820064000000L));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        java.lang.String str9 = offsetDateTimeField4.getName();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime13 = dateTime11.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime14 = dateTime11.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime11.plus(readablePeriod15);
        org.joda.time.TimeOfDay timeOfDay17 = dateTime11.toTimeOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField20 = gregorianChronology19.minutes();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (int) (byte) -1);
        int int25 = offsetDateTimeField23.getLeapAmount((long) 10);
        long long27 = offsetDateTimeField23.roundHalfFloor(0L);
        long long29 = offsetDateTimeField23.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime34 = dateTime32.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate35 = dateTime34.toLocalDate();
        java.lang.String str36 = dateTimeFormatter30.print((org.joda.time.ReadablePartial) localDate35);
        int[] intArray43 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray45 = offsetDateTimeField23.set((org.joda.time.ReadablePartial) localDate35, 0, intArray43, (int) (byte) 100);
        try {
            int[] intArray47 = offsetDateTimeField4.add((org.joda.time.ReadablePartial) timeOfDay17, 1969, intArray45, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1969");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "yearOfEra" + "'", str9.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(timeOfDay17);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "T������.000" + "'", str36.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray45);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField2 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime5 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.DateTime dateTime7 = dateTime1.withFields(readablePartial6);
        try {
            org.joda.time.DateTime dateTime9 = dateTime1.withMonthOfYear((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600002 + "'", int4 == 57600002);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (byte) 10);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        try {
            dateTimeFormatter2.printTo(stringBuffer3, readableInstant4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = dateTime3.withZoneRetainFields(dateTimeZone5);
        long long9 = dateTimeZone5.convertLocalToUTC((long) (byte) 0, true);
        long long12 = dateTimeZone5.adjustOffset((long) (byte) -1, false);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800000L + "'", long9 == 28800000L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        try {
            long long13 = gregorianChronology3.getDateTimeMillis(8, (int) '4', (int) '4', 100, (int) (byte) -1, (-28800000), (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.minutes();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (byte) -1);
        int int13 = offsetDateTimeField11.getLeapAmount((long) 10);
        long long15 = offsetDateTimeField11.roundHalfFloor(0L);
        long long17 = offsetDateTimeField11.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime22 = dateTime20.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate23 = dateTime22.toLocalDate();
        java.lang.String str24 = dateTimeFormatter18.print((org.joda.time.ReadablePartial) localDate23);
        int[] intArray31 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray33 = offsetDateTimeField11.set((org.joda.time.ReadablePartial) localDate23, 0, intArray31, (int) (byte) 100);
        int[] intArray38 = new int[] { (short) -1, (short) 1, 19, '#' };
        int int39 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate23, intArray38);
        java.util.Locale locale40 = null;
        int int41 = offsetDateTimeField4.getMaximumTextLength(locale40);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "T������.000" + "'", str24.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 292278992 + "'", int39 == 292278992);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral('4');
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType5, (int) (short) -1, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray6 = gregorianChronology0.get(readablePeriod3, (long) 1, (long) 292278993);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        java.lang.String str9 = offsetDateTimeField4.getName();
        org.joda.time.DurationField durationField10 = offsetDateTimeField4.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial11 = null;
        java.util.Locale locale12 = null;
        try {
            java.lang.String str13 = offsetDateTimeField4.getAsText(readablePartial11, locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "yearOfEra" + "'", str9.equals("yearOfEra"));
        org.junit.Assert.assertNull(durationField10);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(0L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        int int4 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime5 = property2.withMaximumValue();
        org.joda.time.DateTime dateTime6 = property2.roundCeilingCopy();
        org.joda.time.DateTime dateTime7 = property2.getDateTime();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 292278993 + "'", int4 == 292278993);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(1009843200052L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime5 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime9 = dateTime7.minusDays((int) (short) -1);
        int int10 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfEra();
        int int16 = dateTime12.compareTo((org.joda.time.ReadableInstant) dateTime14);
        int int17 = dateTime14.getDayOfMonth();
        boolean boolean18 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime14);
        boolean boolean19 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime7);
        try {
            org.joda.time.DateTime dateTime21 = dateTime5.withYearOfCentury((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600002 + "'", int4 == 57600002);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600002 + "'", int10 == 57600002);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getMillisOfDay();
        try {
            org.joda.time.DateTime dateTime8 = dateTime1.withDate((int) (short) 1, 2, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600002 + "'", int4 == 57600002);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.ReadWritableInstant readWritableInstant1 = null;
        try {
            int int4 = dateTimeFormatter0.parseInto(readWritableInstant1, "01351231", 35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        try {
            long long10 = gregorianChronology0.getDateTimeMillis(31, 31, 31, 1, 0, 31, 292278992);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278992 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
//        java.util.Locale locale1 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
//        java.util.Locale locale3 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withLocale(locale3);
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        java.lang.String str6 = dateTimeFormatter4.print(readableInstant5);
//        java.lang.String str8 = dateTimeFormatter4.print((long) '4');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter4.withPivotYear((java.lang.Integer) 19);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "T151333.319-0700" + "'", str6.equals("T151333.319-0700"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "T160000.052-0800" + "'", str8.equals("T160000.052-0800"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test097");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) '#', locale3);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField6 = gregorianChronology5.minutes();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.yearOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) (byte) -1);
//        long long12 = offsetDateTimeField9.set(0L, 10);
//        boolean boolean13 = org.joda.time.field.FieldUtils.equals((java.lang.Object) '#', (java.lang.Object) long12);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61820064000000L) + "'", long12 == (-61820064000000L));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.minusMonths(0);
        org.joda.time.DateTime dateTime8 = dateTime6.plusSeconds((int) '#');
        int int9 = dateTime8.getEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(292278992);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test100");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getName((long) 9, locale12);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone8);
//        try {
//            long long19 = zonedChronology14.getDateTimeMillis(10, (-28800000), 100, 292278992);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278992 for millisOfDay must be in the range [0,86400000]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology14);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        java.lang.String str8 = offsetDateTimeField4.getName();
        try {
            long long11 = offsetDateTimeField4.add((long) 8, 31536000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 31536000000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getName((long) 9, locale12);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone8);
//        try {
//            long long20 = zonedChronology14.getDateTimeMillis((-1L), 292278992, (int) (byte) -1, (-1), 35);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278992 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology14);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYear((-10));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        try {
            long long13 = gregorianChronology3.getDateTimeMillis(57600002, 1, (-28800000), 57600002, (int) (byte) 10, (int) (short) 10, 57600002);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600002 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = dateTime3.withZoneRetainFields(dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        java.lang.String str7 = property6.getName();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "weekOfWeekyear" + "'", str7.equals("weekOfWeekyear"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readablePeriod5);
        org.joda.time.TimeOfDay timeOfDay7 = dateTime1.toTimeOfDay();
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField10 = gregorianChronology9.minutes();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) (byte) -1);
        long long16 = offsetDateTimeField13.add((long) 135, (long) 100);
        boolean boolean17 = offsetDateTimeField13.isSupported();
        int int18 = dateTime1.get((org.joda.time.DateTimeField) offsetDateTimeField13);
        try {
            long long21 = offsetDateTimeField13.add(28801969L, 1009843200052L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 1009843200052");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 960 + "'", int8 == 960);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3155760000135L + "'", long16 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1969 + "'", int18 == 1969);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) 'a', (int) (short) 1, 1969, 1969, (int) (byte) -1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        int int1 = org.joda.time.format.FormatUtils.calculateDigitCount(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.DurationField durationField3 = gregorianChronology0.eras();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.minuteOfDay();
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology13);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology13.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField18 = gregorianChronology17.minutes();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) (byte) -1);
        int int23 = offsetDateTimeField21.getLeapAmount((long) 10);
        long long25 = offsetDateTimeField21.roundHalfFloor(0L);
        long long27 = offsetDateTimeField21.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime32 = dateTime30.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate33 = dateTime32.toLocalDate();
        java.lang.String str34 = dateTimeFormatter28.print((org.joda.time.ReadablePartial) localDate33);
        int[] intArray41 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray43 = offsetDateTimeField21.set((org.joda.time.ReadablePartial) localDate33, 0, intArray41, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField45 = gregorianChronology44.minutes();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology44.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField(dateTimeField46, (int) (byte) -1);
        int int50 = offsetDateTimeField48.getLeapAmount((long) 10);
        long long52 = offsetDateTimeField48.roundHalfFloor(0L);
        long long54 = offsetDateTimeField48.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime59 = dateTime57.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate60 = dateTime59.toLocalDate();
        java.lang.String str61 = dateTimeFormatter55.print((org.joda.time.ReadablePartial) localDate60);
        int[] intArray68 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray70 = offsetDateTimeField48.set((org.joda.time.ReadablePartial) localDate60, 0, intArray68, (int) (byte) 100);
        gregorianChronology13.validate((org.joda.time.ReadablePartial) localDate33, intArray70);
        int[] intArray73 = gregorianChronology7.get((org.joda.time.ReadablePartial) localDate33, (long) 1920);
        int[] intArray74 = null;
        try {
            gregorianChronology0.validate((org.joda.time.ReadablePartial) localDate33, intArray74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "T������.000" + "'", str34.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(gregorianChronology44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter55);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localDate60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "T������.000" + "'", str61.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray73);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) '#', 1009843200052L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35344512001820L + "'", long2 == 35344512001820L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.minuteOfDay();
        org.joda.time.DurationField durationField7 = gregorianChronology4.months();
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.minuteOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology11.months();
        org.joda.time.DurationField durationField15 = gregorianChronology11.months();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField16 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField7, durationField15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        try {
            org.joda.time.LocalDateTime localDateTime4 = dateTimeFormatter0.parseLocalDateTime("GregorianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[America/Los_...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        java.lang.String str9 = offsetDateTimeField4.getName();
        long long11 = offsetDateTimeField4.roundHalfFloor((long) 0);
        try {
            long long14 = offsetDateTimeField4.add((long) 35, (long) 292278992);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292280962 for year must be in the range [-292275054,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "yearOfEra" + "'", str9.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withLocale(locale3);
        java.lang.Class<?> wildcardClass5 = dateTimeFormatter2.getClass();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendDecimal(dateTimeFieldType4, (int) (byte) -1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(1009843200052L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((-28800000), (int) '#', 57600002, 292278993, 960, (int) (byte) 1, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        int int10 = offsetDateTimeField4.getDifference((long) (byte) -1, 0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType11, 69);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property2.getAsShortText(locale3);
        int int5 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime6 = property2.roundFloorCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969" + "'", str4.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendSecondOfMinute(35);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendHourOfHalfday((-10));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withLocale(locale3);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeFormatter4.getZone();
        org.joda.time.Chronology chronology6 = dateTimeFormatter4.getChronology();
        java.lang.StringBuffer stringBuffer7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        try {
            dateTimeFormatter4.printTo(stringBuffer7, readableInstant8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNull(dateTimeZone5);
        org.junit.Assert.assertNull(chronology6);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getName((long) 9, locale12);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone15 = zonedChronology14.getZone();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.Chronology chronology17 = zonedChronology14.withZone(dateTimeZone16);
//        try {
//            long long22 = zonedChronology14.getDateTimeMillis((-10), 31, (int) (short) 10, 960);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(chronology17);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (byte) -1, (int) (byte) 100, (-10), 1, (int) (byte) 10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[UTC]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.field.FieldUtils.verifyValueBounds("52", (int) (short) 0, 0, 19);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        int int11 = dateTime7.compareTo((org.joda.time.ReadableInstant) dateTime9);
        int int12 = dateTime9.getEra();
        boolean boolean13 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime9);
        try {
            org.joda.time.DateTime dateTime15 = dateTime9.withYearOfCentury((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property2.getAsShortText(locale3);
        int int5 = property2.getMaximumValue();
        java.lang.String str6 = property2.getAsText();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969" + "'", str4.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology3.months();
        long long9 = durationField6.subtract(31L, (long) 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 31L + "'", long9 == 31L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (byte) -1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        boolean boolean7 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gregorianChronology6);
        java.io.Writer writer10 = null;
        try {
            dateTimeFormatter9.printTo(writer10, (long) 292278992);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getName((long) 9, locale12);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone15 = zonedChronology14.getZone();
//        try {
//            long long23 = zonedChronology14.getDateTimeMillis(0, (int) (short) 0, (int) (byte) -1, 960, 0, 1920, 35);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendDayOfYear((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.minuteOfDay();
        java.util.TimeZone timeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        boolean boolean18 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology17);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology17.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField22 = gregorianChronology21.minutes();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (int) (byte) -1);
        int int27 = offsetDateTimeField25.getLeapAmount((long) 10);
        long long29 = offsetDateTimeField25.roundHalfFloor(0L);
        long long31 = offsetDateTimeField25.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime36 = dateTime34.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate37 = dateTime36.toLocalDate();
        java.lang.String str38 = dateTimeFormatter32.print((org.joda.time.ReadablePartial) localDate37);
        int[] intArray45 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray47 = offsetDateTimeField25.set((org.joda.time.ReadablePartial) localDate37, 0, intArray45, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField49 = gregorianChronology48.minutes();
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology48.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, (int) (byte) -1);
        int int54 = offsetDateTimeField52.getLeapAmount((long) 10);
        long long56 = offsetDateTimeField52.roundHalfFloor(0L);
        long long58 = offsetDateTimeField52.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter59 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime63 = dateTime61.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate64 = dateTime63.toLocalDate();
        java.lang.String str65 = dateTimeFormatter59.print((org.joda.time.ReadablePartial) localDate64);
        int[] intArray72 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray74 = offsetDateTimeField52.set((org.joda.time.ReadablePartial) localDate64, 0, intArray72, (int) (byte) 100);
        gregorianChronology17.validate((org.joda.time.ReadablePartial) localDate37, intArray74);
        int[] intArray77 = gregorianChronology11.get((org.joda.time.ReadablePartial) localDate37, (long) 1920);
        java.util.Locale locale79 = null;
        java.lang.String str80 = offsetDateTimeField4.getAsText((org.joda.time.ReadablePartial) localDate37, (int) '4', locale79);
        boolean boolean81 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate37);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "T������.000" + "'", str38.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter59);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "T������.000" + "'", str65.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "52" + "'", str80.equals("52"));
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendFixedSignedDecimal(dateTimeFieldType7, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 1920, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        int int11 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property12 = dateTime1.centuryOfEra();
        org.joda.time.DateTime dateTime13 = property12.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 1009843200052L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.yearOfEra();
        try {
            long long12 = gregorianChronology3.getDateTimeMillis((int) (byte) 0, 1, 57600002, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600002 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime7 = dateTime3.plusYears(31);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.DateTime dateTime10 = dateTime3.withField(dateTimeFieldType8, 292278993);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            int int12 = dateTime10.get(dateTimeFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = dateTime3.withZoneRetainFields(dateTimeZone5);
        java.util.GregorianCalendar gregorianCalendar7 = dateTime3.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getName((long) 9, locale12);
//        try {
//            org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(0, (int) (byte) 0, (-1), (int) 'a', (int) (short) 1, 0, dateTimeZone8);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "T151320.765-0700");
//        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 100, dateTimeZone7);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone7.getName((long) 9, locale11);
//        try {
//            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) illegalFieldValueException2, dateTimeZone7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.IllegalFieldValueException");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(durationFieldType3);
//        org.junit.Assert.assertNull(dateTimeFieldType4);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pacific Standard Time" + "'", str12.equals("Pacific Standard Time"));
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = property2.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime6 = dateTime4.withWeekyear((int) (byte) 100);
        java.lang.String str7 = dateTime6.toString();
        long long8 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime6);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0100-01-05T16:00:00.002-07:52:58" + "'", str7.equals("0100-01-05T16:00:00.002-07:52:58"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-59011027621998L) + "'", long8 == (-59011027621998L));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.days();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField3 = new org.joda.time.field.DecoratedDurationField(durationField1, durationFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.plusMillis(135);
        try {
            org.joda.time.DateTime dateTime6 = dateTime4.withYearOfEra(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "T151321.363-0700");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.minuteOfDay();
        org.joda.time.DurationField durationField7 = gregorianChronology4.months();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        java.lang.String str11 = property10.getAsShortText();
        int int12 = property10.getLeapAmount();
        org.joda.time.DurationField durationField13 = property10.getDurationField();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField14 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField7, durationField13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (-62135596799931L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.set(0L, 10);
        long long9 = offsetDateTimeField4.roundHalfFloor((long) (short) 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61820064000000L) + "'", long7 == (-61820064000000L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        long long10 = offsetDateTimeField4.roundHalfFloor(0L);
        int int11 = offsetDateTimeField4.getMinimumValue();
        org.joda.time.DurationField durationField12 = offsetDateTimeField4.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(durationField12);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDayOfWeek((int) '4');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfSecond((int) (byte) -1, (-10));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("1969", (-1), 0, 292278993);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for 1969 must be in the range [0,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 28801969L, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        int int4 = property2.getMaximumShortTextLength(locale3);
        boolean boolean5 = property2.isLeap();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (byte) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendText(dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) 10, "T160000.052-0800");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        java.io.Writer writer1 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfEra();
        int int7 = dateTime3.compareTo((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime.Property property8 = dateTime3.weekOfWeekyear();
        org.joda.time.DateTime.Property property9 = dateTime3.dayOfYear();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime5 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600002 + "'", int4 == 57600002);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 100, dateTimeZone2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusDays(57600002);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField14 = gregorianChronology13.minutes();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) (byte) -1);
        int int19 = offsetDateTimeField17.getLeapAmount((long) 10);
        long long21 = offsetDateTimeField17.roundHalfFloor(0L);
        long long23 = offsetDateTimeField17.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime28 = dateTime26.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate29 = dateTime28.toLocalDate();
        java.lang.String str30 = dateTimeFormatter24.print((org.joda.time.ReadablePartial) localDate29);
        int[] intArray37 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray39 = offsetDateTimeField17.set((org.joda.time.ReadablePartial) localDate29, 0, intArray37, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField41 = gregorianChronology40.minutes();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, (int) (byte) -1);
        int int46 = offsetDateTimeField44.getLeapAmount((long) 10);
        long long48 = offsetDateTimeField44.roundHalfFloor(0L);
        long long50 = offsetDateTimeField44.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime55 = dateTime53.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate56 = dateTime55.toLocalDate();
        java.lang.String str57 = dateTimeFormatter51.print((org.joda.time.ReadablePartial) localDate56);
        int[] intArray64 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray66 = offsetDateTimeField44.set((org.joda.time.ReadablePartial) localDate56, 0, intArray64, (int) (byte) 100);
        gregorianChronology9.validate((org.joda.time.ReadablePartial) localDate29, intArray66);
        int[] intArray69 = gregorianChronology3.get((org.joda.time.ReadablePartial) localDate29, (long) 1920);
        org.joda.time.DateTimeField dateTimeField70 = gregorianChronology3.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField71 = gregorianChronology3.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "T������.000" + "'", str30.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter51);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "T������.000" + "'", str57.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(dateTimeField71);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.withYear(9);
        org.joda.time.DateTime dateTime15 = dateTime10.withDurationAdded(0L, 1969);
        java.util.TimeZone timeZone16 = null;
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        try {
            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) 1969, dateTimeZone17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        java.util.GregorianCalendar gregorianCalendar11 = dateTime10.toGregorianCalendar();
        try {
            org.joda.time.DateTime dateTime13 = dateTime10.withMonthOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianCalendar11);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendSecondOfMinute(35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendHourOfDay(31);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder8.appendFraction(dateTimeFieldType11, (int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 97L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        long long10 = offsetDateTimeField4.roundHalfFloor(0L);
        long long12 = offsetDateTimeField4.roundCeiling(2649600002L);
        int int14 = offsetDateTimeField4.getLeapAmount((long) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType15, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31536000000L + "'", long12 == 31536000000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.halfdayOfDay();
        java.lang.String str3 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("Property[yearOfEra]");
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getName((long) 9, locale12);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone15 = zonedChronology14.getZone();
//        try {
//            long long21 = zonedChronology14.getDateTimeMillis((long) 100, 0, 31, 1920, (int) '#');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1920 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 8, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.minutes();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (byte) -1);
        int int13 = offsetDateTimeField11.getLeapAmount((long) 10);
        long long15 = offsetDateTimeField11.roundHalfFloor(0L);
        long long17 = offsetDateTimeField11.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime22 = dateTime20.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate23 = dateTime22.toLocalDate();
        java.lang.String str24 = dateTimeFormatter18.print((org.joda.time.ReadablePartial) localDate23);
        int[] intArray31 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray33 = offsetDateTimeField11.set((org.joda.time.ReadablePartial) localDate23, 0, intArray31, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField35 = gregorianChronology34.minutes();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, (int) (byte) -1);
        int int40 = offsetDateTimeField38.getLeapAmount((long) 10);
        long long42 = offsetDateTimeField38.roundHalfFloor(0L);
        long long44 = offsetDateTimeField38.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime49 = dateTime47.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate50 = dateTime49.toLocalDate();
        java.lang.String str51 = dateTimeFormatter45.print((org.joda.time.ReadablePartial) localDate50);
        int[] intArray58 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray60 = offsetDateTimeField38.set((org.joda.time.ReadablePartial) localDate50, 0, intArray58, (int) (byte) 100);
        gregorianChronology3.validate((org.joda.time.ReadablePartial) localDate23, intArray60);
        org.joda.time.DateTimeField dateTimeField62 = gregorianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology3.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "T������.000" + "'", str24.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter45);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "T������.000" + "'", str51.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(dateTimeField63);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        boolean boolean6 = offsetDateTimeField4.isLeap((long) 'a');
        boolean boolean8 = offsetDateTimeField4.isLeap(0L);
        int int9 = offsetDateTimeField4.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 292278992 + "'", int9 == 292278992);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType3, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime4 = dateTime2.minusDays((int) (short) -1);
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.DateTime dateTime7 = dateTime4.withZoneRetainFields(dateTimeZone6);
        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime7);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-W01" + "'", str8.equals("1970-W01"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.withYear(9);
        org.joda.time.DateTime dateTime13 = dateTime12.withTimeAtStartOfDay();
        org.joda.time.Instant instant14 = dateTime13.toInstant();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(instant14);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
        long long4 = durationField1.subtract(0L, 1970);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62166787200000L) + "'", long4 == (-62166787200000L));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 54823);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.plusMillis(135);
        org.joda.time.DateTime.Property property5 = dateTime1.centuryOfEra();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getName((long) 9, locale12);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone15 = zonedChronology14.getZone();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.Chronology chronology17 = zonedChronology14.withZone(dateTimeZone16);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        try {
//            int[] intArray20 = zonedChronology14.get(readablePeriod18, 3155760000135L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(chronology17);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (byte) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendSecondOfDay((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendDecimal(dateTimeFieldType7, 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("T151321.363-0700");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'T151321.363-0700' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder4.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withLocale(locale7);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withLocale(locale9);
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.append(dateTimeParser11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendFractionOfDay(8, 292278993);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("Pacific Standard Time", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Pacific Standard Time/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 2, 31);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 62L + "'", long2 == 62L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("T151321.363-0700", false);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.addRecurringSavings("", (int) (byte) 100, (int) (byte) 0, (int) (short) 1, '#', 86399999, (int) ' ', 1969, false, 960);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        java.lang.String str8 = offsetDateTimeField4.getName();
        java.lang.String str9 = offsetDateTimeField4.getName();
        org.joda.time.DurationField durationField10 = offsetDateTimeField4.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "yearOfEra" + "'", str9.equals("yearOfEra"));
        org.junit.Assert.assertNull(durationField10);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(54823, 1969, (int) (short) 0, 57600002);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 56792 + "'", int4 == 56792);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        java.util.Locale locale2 = dateTimeFormatter0.getLocale();
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter0.printTo(appendable3, 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-61820064000000L), (long) (-10));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61820063999990L) + "'", long2 == (-61820063999990L));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(31, 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 279 + "'", int2 == 279);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.weekOfWeekyear();
        long long10 = gregorianChronology3.add((long) (-1), 0L, 9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology3.hourOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) '#', locale3);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 100, dateTimeZone2);
        int int5 = dateTime4.getSecondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (byte) -1, false);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter4.withLocale(locale5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.append(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        java.lang.String str5 = gregorianChronology3.toString();
        org.joda.time.DurationField durationField6 = gregorianChronology3.weekyears();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str5.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendSecondOfMinute(35);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendPattern("Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        int int11 = dateTime1.getCenturyOfEra();
        boolean boolean12 = dateTime1.isAfterNow();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) ' ', false);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendSignedDecimal(dateTimeFieldType4, 279, 56792);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test217");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        java.util.Locale locale3 = null;
//        java.lang.String str4 = dateTimeZone1.getName((long) '#', locale3);
//        java.lang.String str5 = dateTimeZone1.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "America/Los_Angeles" + "'", str5.equals("America/Los_Angeles"));
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime5 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.DateTime dateTime7 = dateTime1.withFields(readablePartial6);
        boolean boolean9 = dateTime1.isEqual((long) (-1));
        org.joda.time.DateTime dateTime11 = dateTime1.withSecondOfMinute(0);
        org.joda.time.DurationFieldType durationFieldType12 = null;
        try {
            org.joda.time.DateTime dateTime14 = dateTime11.withFieldAdded(durationFieldType12, 57600002);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600002 + "'", int4 == 57600002);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        java.lang.String str6 = cachedDateTimeZone4.getNameKey(100L);
        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone4.getUncachedZone();
        long long10 = cachedDateTimeZone4.adjustOffset((long) '4', true);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 52L + "'", long10 == 52L);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(69);
        java.io.DataOutput dataOutput4 = null;
        try {
            dateTimeZoneBuilder0.writeTo("T151332.735-0700", dataOutput4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField8 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField6, dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 19, 292278993);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        java.util.Locale locale5 = null;
        int int6 = property4.getMaximumTextLength(locale5);
        int int7 = property4.getMaximumValue();
        try {
            org.joda.time.DateTime dateTime9 = property4.setCopy("T151324.051-0700");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"T151324.051-0700\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 86399999 + "'", int7 == 86399999);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneName(strMap5);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfDay((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendWeekyear(0, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale12 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter11.withLocale(locale12);
        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatter13.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser15 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter14, dateTimeParser15);
        org.joda.time.format.DateTimeParser[] dateTimeParserArray17 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder9.append(dateTimePrinter14, dateTimeParserArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parsers supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimePrinter14);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        int int4 = property2.getMaximumValue();
        java.lang.String str5 = property2.toString();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 292278993 + "'", int4 == 292278993);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Property[yearOfEra]" + "'", str5.equals("Property[yearOfEra]"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getWeekOfWeekyear();
        boolean boolean6 = dateTime1.isAfter((long) (short) 0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        int int5 = dateTime1.getYearOfEra();
        try {
            org.joda.time.DateTime dateTime7 = dateTime1.withSecondOfMinute(56792);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 56792 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (byte) -1, false);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType4, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        long long6 = gregorianChronology0.getDateTimeMillis(0, 9, 4, 365);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62145878399635L) + "'", long6 == (-62145878399635L));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        long long10 = offsetDateTimeField4.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime15 = dateTime13.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate16 = dateTime15.toLocalDate();
        java.lang.String str17 = dateTimeFormatter11.print((org.joda.time.ReadablePartial) localDate16);
        int[] intArray24 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray26 = offsetDateTimeField4.set((org.joda.time.ReadablePartial) localDate16, 0, intArray24, (int) (byte) 100);
        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField4, (int) (short) 1, (int) (byte) 1, 1920);
        long long33 = offsetDateTimeField4.addWrapField((long) ' ', 10);
        try {
            long long36 = offsetDateTimeField4.set(0L, "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "T������.000" + "'", str17.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 315532800032L + "'", long33 == 315532800032L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        int int11 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property12 = dateTime1.centuryOfEra();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfEra();
        java.lang.String str16 = property15.getAsShortText();
        int int17 = property15.getMaximumValue();
        org.joda.time.DateTime dateTime18 = property15.withMaximumValue();
        org.joda.time.DateTime dateTime20 = dateTime18.minus((long) 1);
        org.joda.time.DateTime dateTime22 = dateTime20.plusMonths(0);
        long long23 = property12.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.era();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.secondOfDay();
        boolean boolean27 = org.joda.time.field.FieldUtils.equals((java.lang.Object) long23, (java.lang.Object) gregorianChronology24);
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology24.minuteOfHour();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 292278993 + "'", int17 == 292278993);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-2922770L) + "'", long23 == (-2922770L));
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTimeField28);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        org.joda.time.DurationField durationField7 = offsetDateTimeField4.getLeapDurationField();
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField4.getMaximumShortTextLength(locale8);
        java.lang.String str10 = offsetDateTimeField4.getName();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "yearOfEra" + "'", str10.equals("yearOfEra"));
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560636829203L + "'", long0 == 1560636829203L);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        int int4 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime5 = property2.withMaximumValue();
        org.joda.time.DateTime dateTime7 = dateTime5.minus((long) 1);
        org.joda.time.DateTime dateTime9 = dateTime7.plusMonths(0);
        org.joda.time.DateTime dateTime11 = dateTime9.minusYears(292278993);
        int int12 = dateTime9.getWeekOfWeekyear();
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime9);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 292278993 + "'", int4 == 292278993);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        java.lang.String str9 = offsetDateTimeField4.getName();
        int int11 = offsetDateTimeField4.getMinimumValue((long) 19);
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField4.getMaximumTextLength(locale12);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "yearOfEra" + "'", str9.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 3061065599999L, "T151332.735-0700");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(0L, (long) (-28800000));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        int int5 = property4.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.era();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.withYear(9);
        org.joda.time.DateTime dateTime13 = dateTime12.toDateTimeISO();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        java.util.Locale locale4 = null;
        int int5 = property2.getMaximumTextLength(locale4);
        int int6 = property2.get();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.era();
        org.joda.time.DurationField durationField5 = gregorianChronology1.years();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField6 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        java.lang.String str8 = offsetDateTimeField4.getName();
        long long10 = offsetDateTimeField4.roundHalfFloor((long) (byte) -1);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField4.getMaximumTextLength(locale11);
        long long15 = offsetDateTimeField4.add((long) 31, (long) (byte) 1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31536000031L + "'", long15 == 31536000031L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.plusYears(0);
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.minuteOfDay();
        java.util.TimeZone timeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField20 = gregorianChronology19.minutes();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (int) (byte) -1);
        int int25 = offsetDateTimeField23.getLeapAmount((long) 10);
        long long27 = offsetDateTimeField23.roundHalfFloor(0L);
        long long29 = offsetDateTimeField23.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime34 = dateTime32.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate35 = dateTime34.toLocalDate();
        java.lang.String str36 = dateTimeFormatter30.print((org.joda.time.ReadablePartial) localDate35);
        int[] intArray43 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray45 = offsetDateTimeField23.set((org.joda.time.ReadablePartial) localDate35, 0, intArray43, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField47 = gregorianChronology46.minutes();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology46.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, (int) (byte) -1);
        int int52 = offsetDateTimeField50.getLeapAmount((long) 10);
        long long54 = offsetDateTimeField50.roundHalfFloor(0L);
        long long56 = offsetDateTimeField50.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter57 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime61 = dateTime59.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate62 = dateTime61.toLocalDate();
        java.lang.String str63 = dateTimeFormatter57.print((org.joda.time.ReadablePartial) localDate62);
        int[] intArray70 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray72 = offsetDateTimeField50.set((org.joda.time.ReadablePartial) localDate62, 0, intArray70, (int) (byte) 100);
        gregorianChronology15.validate((org.joda.time.ReadablePartial) localDate35, intArray72);
        int[] intArray75 = gregorianChronology9.get((org.joda.time.ReadablePartial) localDate35, (long) 1920);
        org.joda.time.DateTimeField dateTimeField76 = gregorianChronology9.yearOfCentury();
        org.joda.time.DurationField durationField77 = gregorianChronology9.months();
        org.joda.time.MutableDateTime mutableDateTime78 = dateTime3.toMutableDateTime((org.joda.time.Chronology) gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "T������.000" + "'", str36.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(gregorianChronology46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter57);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(localDate62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "T������.000" + "'", str63.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertNotNull(dateTimeField76);
        org.junit.Assert.assertNotNull(durationField77);
        org.junit.Assert.assertNotNull(mutableDateTime78);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) ' ', false);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        boolean boolean8 = offsetDateTimeField4.isSupported();
        long long11 = offsetDateTimeField4.getDifferenceAsLong((long) 57600002, 100L);
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField4.getAsShortText((long) 960, locale13);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1969" + "'", str14.equals("1969"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "52");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField14 = gregorianChronology13.minutes();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) (byte) -1);
        int int19 = offsetDateTimeField17.getLeapAmount((long) 10);
        long long21 = offsetDateTimeField17.roundHalfFloor(0L);
        long long23 = offsetDateTimeField17.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime28 = dateTime26.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate29 = dateTime28.toLocalDate();
        java.lang.String str30 = dateTimeFormatter24.print((org.joda.time.ReadablePartial) localDate29);
        int[] intArray37 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray39 = offsetDateTimeField17.set((org.joda.time.ReadablePartial) localDate29, 0, intArray37, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField41 = gregorianChronology40.minutes();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, (int) (byte) -1);
        int int46 = offsetDateTimeField44.getLeapAmount((long) 10);
        long long48 = offsetDateTimeField44.roundHalfFloor(0L);
        long long50 = offsetDateTimeField44.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime55 = dateTime53.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate56 = dateTime55.toLocalDate();
        java.lang.String str57 = dateTimeFormatter51.print((org.joda.time.ReadablePartial) localDate56);
        int[] intArray64 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray66 = offsetDateTimeField44.set((org.joda.time.ReadablePartial) localDate56, 0, intArray64, (int) (byte) 100);
        gregorianChronology9.validate((org.joda.time.ReadablePartial) localDate29, intArray66);
        int[] intArray69 = gregorianChronology3.get((org.joda.time.ReadablePartial) localDate29, (long) 1920);
        org.joda.time.DateTimeField dateTimeField70 = gregorianChronology3.yearOfCentury();
        try {
            long long78 = gregorianChronology3.getDateTimeMillis((int) (short) 100, 86399999, 960, (int) (byte) -1, 9, (int) ' ', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "T������.000" + "'", str30.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter51);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "T������.000" + "'", str57.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(dateTimeField70);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        long long6 = durationField3.subtract(52L, 365);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1313999948L) + "'", long6 == (-1313999948L));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(292278992, 19, (int) '#', 0, 19, 0, 292278993);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime5 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime9 = dateTime7.minusDays((int) (short) -1);
        int int10 = dateTime7.getMillisOfDay();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfEra();
        int int16 = dateTime12.compareTo((org.joda.time.ReadableInstant) dateTime14);
        int int17 = dateTime14.getDayOfMonth();
        boolean boolean18 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime14);
        boolean boolean19 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime21 = dateTime7.withYear((int) '4');
        try {
            org.joda.time.DateTime dateTime23 = dateTime21.withCenturyOfEra((-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for centuryOfEra must be in the range [0,2922789]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600002 + "'", int4 == 57600002);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 57600002 + "'", int10 == 57600002);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 10, 8, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours(135);
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology3 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, dateTimeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gregorianChronology1.minutes();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (byte) -1);
        int int7 = offsetDateTimeField5.getLeapAmount((long) 10);
        long long9 = offsetDateTimeField5.roundHalfFloor(0L);
        long long11 = offsetDateTimeField5.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime16 = dateTime14.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate17 = dateTime16.toLocalDate();
        java.lang.String str18 = dateTimeFormatter12.print((org.joda.time.ReadablePartial) localDate17);
        int[] intArray25 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray27 = offsetDateTimeField5.set((org.joda.time.ReadablePartial) localDate17, 0, intArray25, (int) (byte) 100);
        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField5, (int) (short) 1, (int) (byte) 1, 1920);
        long long34 = offsetDateTimeField5.addWrapField((long) ' ', 10);
        org.joda.time.DurationField durationField35 = offsetDateTimeField5.getDurationField();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "T������.000" + "'", str18.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 315532800032L + "'", long34 == 315532800032L);
        org.junit.Assert.assertNotNull(durationField35);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        int int5 = dateTime1.getYearOfEra();
        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime();
        int int7 = dateTime6.getSecondOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 57600 + "'", int7 == 57600);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(69);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder2.addRecurringSavings("T151320.765-0700", 54825, 19, 69, 'a', 9, (int) ' ', (int) (short) 100, false, 69);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder4.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withLocale(locale7);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withLocale(locale9);
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.append(dateTimeParser11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder4.appendDayOfWeekShortText();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.appendFraction(dateTimeFieldType14, (int) (short) 100, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        int int5 = dateTime1.getYearOfEra();
        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfYear();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.era();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology7.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime12 = dateTime1.toMutableDateTime((org.joda.time.Chronology) gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        java.util.Locale locale4 = null;
        int int5 = property2.getMaximumTextLength(locale4);
        int int6 = property2.getMaximumValueOverall();
        org.joda.time.Interval interval7 = property2.toInterval();
        long long8 = property2.remainder();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292278993 + "'", int6 == 292278993);
        org.junit.Assert.assertNotNull(interval7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 31507200002L + "'", long8 == 31507200002L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField3 = gregorianChronology1.weeks();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.hourOfHalfday();
        org.joda.time.DurationField durationField6 = gregorianChronology4.eras();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField7 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField3, durationField6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        java.lang.String str3 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, 292278993);
        boolean boolean5 = offsetDateTimeField3.isLeap((long) (short) 1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(54825, 1969, 69, 57600, 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 10, (java.lang.Number) 100L, (java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) ' ', false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitYear(100, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) '4');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(100, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) -1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        java.lang.String str9 = offsetDateTimeField4.getName();
        org.joda.time.DurationField durationField10 = offsetDateTimeField4.getLeapDurationField();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime14 = dateTime12.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime12.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime12.plus(readablePeriod16);
        org.joda.time.TimeOfDay timeOfDay18 = dateTime12.toTimeOfDay();
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) timeOfDay18, locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfEra' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "yearOfEra" + "'", str9.equals("yearOfEra"));
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(timeOfDay18);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(12, 0, 1970, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "weekOfWeekyear");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfMonth(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendShortText(dateTimeFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        java.lang.String str9 = offsetDateTimeField4.getName();
        org.joda.time.DurationField durationField10 = offsetDateTimeField4.getLeapDurationField();
        long long13 = offsetDateTimeField4.add((long) 10, (long) 35);
        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField4.getWrappedField();
        java.util.Locale locale17 = null;
        try {
            long long18 = offsetDateTimeField4.set((long) (byte) 100, "weekOfWeekyear", locale17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"weekOfWeekyear\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "yearOfEra" + "'", str9.equals("yearOfEra"));
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1104537600010L + "'", long13 == 1104537600010L);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readablePeriod5);
        org.joda.time.DateTime dateTime8 = dateTime1.plusYears(0);
        org.joda.time.DateTime dateTime9 = dateTime1.withLaterOffsetAtOverlap();
        try {
            org.joda.time.DateTime dateTime11 = dateTime1.withSecondOfMinute(1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        java.lang.String str8 = offsetDateTimeField4.getName();
        long long10 = offsetDateTimeField4.roundHalfFloor((long) (byte) -1);
        boolean boolean11 = offsetDateTimeField4.isSupported();
        java.util.TimeZone timeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology15);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField20 = gregorianChronology19.minutes();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology19.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (int) (byte) -1);
        int int25 = offsetDateTimeField23.getLeapAmount((long) 10);
        long long27 = offsetDateTimeField23.roundHalfFloor(0L);
        long long29 = offsetDateTimeField23.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime34 = dateTime32.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate35 = dateTime34.toLocalDate();
        java.lang.String str36 = dateTimeFormatter30.print((org.joda.time.ReadablePartial) localDate35);
        int[] intArray43 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray45 = offsetDateTimeField23.set((org.joda.time.ReadablePartial) localDate35, 0, intArray43, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField47 = gregorianChronology46.minutes();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology46.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, (int) (byte) -1);
        int int52 = offsetDateTimeField50.getLeapAmount((long) 10);
        long long54 = offsetDateTimeField50.roundHalfFloor(0L);
        long long56 = offsetDateTimeField50.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter57 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime61 = dateTime59.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate62 = dateTime61.toLocalDate();
        java.lang.String str63 = dateTimeFormatter57.print((org.joda.time.ReadablePartial) localDate62);
        int[] intArray70 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray72 = offsetDateTimeField50.set((org.joda.time.ReadablePartial) localDate62, 0, intArray70, (int) (byte) 100);
        gregorianChronology15.validate((org.joda.time.ReadablePartial) localDate35, intArray72);
        org.joda.time.DateTimeField dateTimeField74 = gregorianChronology15.monthOfYear();
        org.joda.time.DateTime dateTime76 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime78 = dateTime76.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate79 = dateTime78.toLocalDate();
        int[] intArray81 = gregorianChronology15.get((org.joda.time.ReadablePartial) localDate79, 1L);
        int int82 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate79);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "T������.000" + "'", str36.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(gregorianChronology46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter57);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(localDate62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "T������.000" + "'", str63.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(dateTimeField74);
        org.junit.Assert.assertNotNull(dateTime78);
        org.junit.Assert.assertNotNull(localDate79);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 292278992 + "'", int82 == 292278992);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime11 = dateTime9.minusDays((int) (short) -1);
        int int12 = dateTime9.getMillisOfDay();
        org.joda.time.DateTime dateTime13 = dateTime9.withTimeAtStartOfDay();
        org.joda.time.ReadablePartial readablePartial14 = null;
        org.joda.time.DateTime dateTime15 = dateTime9.withFields(readablePartial14);
        org.joda.time.DateMidnight dateMidnight16 = dateTime9.toDateMidnight();
        int int17 = property7.getDifference((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime9.withDurationAdded(readableDuration18, (int) ' ');
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23);
        boolean boolean25 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology24);
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.minuteOfDay();
        java.util.TimeZone timeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forTimeZone(timeZone28);
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        boolean boolean31 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology30);
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology30.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology30.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField35 = gregorianChronology34.minutes();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, (int) (byte) -1);
        int int40 = offsetDateTimeField38.getLeapAmount((long) 10);
        long long42 = offsetDateTimeField38.roundHalfFloor(0L);
        long long44 = offsetDateTimeField38.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime49 = dateTime47.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate50 = dateTime49.toLocalDate();
        java.lang.String str51 = dateTimeFormatter45.print((org.joda.time.ReadablePartial) localDate50);
        int[] intArray58 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray60 = offsetDateTimeField38.set((org.joda.time.ReadablePartial) localDate50, 0, intArray58, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology61 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField62 = gregorianChronology61.minutes();
        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology61.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField(dateTimeField63, (int) (byte) -1);
        int int67 = offsetDateTimeField65.getLeapAmount((long) 10);
        long long69 = offsetDateTimeField65.roundHalfFloor(0L);
        long long71 = offsetDateTimeField65.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter72 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime74 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime76 = dateTime74.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate77 = dateTime76.toLocalDate();
        java.lang.String str78 = dateTimeFormatter72.print((org.joda.time.ReadablePartial) localDate77);
        int[] intArray85 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray87 = offsetDateTimeField65.set((org.joda.time.ReadablePartial) localDate77, 0, intArray85, (int) (byte) 100);
        gregorianChronology30.validate((org.joda.time.ReadablePartial) localDate50, intArray87);
        int[] intArray90 = gregorianChronology24.get((org.joda.time.ReadablePartial) localDate50, (long) 1920);
        org.joda.time.DateTimeField dateTimeField91 = gregorianChronology24.minuteOfHour();
        org.joda.time.ReadablePeriod readablePeriod92 = null;
        long long95 = gregorianChronology24.add(readablePeriod92, (long) 10, (int) (byte) 100);
        try {
            org.joda.time.DateTime dateTime96 = new org.joda.time.DateTime((java.lang.Object) ' ', (org.joda.time.Chronology) gregorianChronology24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Character");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57600002 + "'", int12 == 57600002);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter45);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "T������.000" + "'", str51.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(gregorianChronology61);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 0L + "'", long69 == 0L);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 0L + "'", long71 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter72);
        org.junit.Assert.assertNotNull(dateTime76);
        org.junit.Assert.assertNotNull(localDate77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "T������.000" + "'", str78.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertNotNull(dateTimeField91);
        org.junit.Assert.assertTrue("'" + long95 + "' != '" + 10L + "'", long95 == 10L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder4.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withLocale(locale7);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withLocale(locale9);
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.append(dateTimeParser11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder4.appendClockhourOfDay(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder14.appendTimeZoneOffset("GregorianChronology[UTC]", true, 2, 292278992);
        dateTimeFormatterBuilder14.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendWeekyear(0, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendSecondOfDay(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder6.appendShortText(dateTimeFieldType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        boolean boolean5 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.minuteOfDay();
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField15 = gregorianChronology14.minutes();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) (byte) -1);
        int int20 = offsetDateTimeField18.getLeapAmount((long) 10);
        long long22 = offsetDateTimeField18.roundHalfFloor(0L);
        long long24 = offsetDateTimeField18.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime29 = dateTime27.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate30 = dateTime29.toLocalDate();
        java.lang.String str31 = dateTimeFormatter25.print((org.joda.time.ReadablePartial) localDate30);
        int[] intArray38 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray40 = offsetDateTimeField18.set((org.joda.time.ReadablePartial) localDate30, 0, intArray38, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField42 = gregorianChronology41.minutes();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology41.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, (int) (byte) -1);
        int int47 = offsetDateTimeField45.getLeapAmount((long) 10);
        long long49 = offsetDateTimeField45.roundHalfFloor(0L);
        long long51 = offsetDateTimeField45.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime56 = dateTime54.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate57 = dateTime56.toLocalDate();
        java.lang.String str58 = dateTimeFormatter52.print((org.joda.time.ReadablePartial) localDate57);
        int[] intArray65 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray67 = offsetDateTimeField45.set((org.joda.time.ReadablePartial) localDate57, 0, intArray65, (int) (byte) 100);
        gregorianChronology10.validate((org.joda.time.ReadablePartial) localDate30, intArray67);
        int[] intArray70 = gregorianChronology4.get((org.joda.time.ReadablePartial) localDate30, (long) 1920);
        org.joda.time.DateTimeField dateTimeField71 = gregorianChronology4.yearOfCentury();
        org.joda.time.DurationField durationField72 = gregorianChronology4.months();
        org.joda.time.DurationField durationField73 = gregorianChronology4.days();
        org.joda.time.DateTime dateTime75 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property76 = dateTime75.yearOfEra();
        java.lang.String str77 = property76.getAsShortText();
        int int78 = property76.getLeapAmount();
        org.joda.time.DurationField durationField79 = property76.getDurationField();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField80 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField73, durationField79);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "T������.000" + "'", str31.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter52);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(localDate57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "T������.000" + "'", str58.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(durationField72);
        org.junit.Assert.assertNotNull(durationField73);
        org.junit.Assert.assertNotNull(property76);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "1969" + "'", str77.equals("1969"));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertNotNull(durationField79);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("1969", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969\" is malformed at \"69\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime5 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.DateTime dateTime7 = dateTime1.withFields(readablePartial6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusSeconds(1969);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600002 + "'", int4 == 57600002);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.hourOfHalfday();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        boolean boolean9 = cachedDateTimeZone7.equals((java.lang.Object) 57600002);
        int int11 = cachedDateTimeZone7.getStandardOffset((long) (short) 10);
        org.joda.time.Chronology chronology12 = iSOChronology1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 10, chronology12);
        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(57600002, 100, 0, (int) (byte) 10, (int) (short) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property2.getAsShortText(locale3);
        int int5 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime6 = property2.roundCeilingCopy();
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969" + "'", str4.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime3.withZoneRetainFields(dateTimeZone5);
//        long long9 = dateTimeZone5.convertLocalToUTC((long) 100, false);
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = dateTimeZone5.getShortName((-28800000L), locale11);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800100L + "'", long9 == 28800100L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PST" + "'", str12.equals("PST"));
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        int int6 = dateTime3.getEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.plus(readablePeriod7);
        int int9 = dateTime8.getYear();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendMillisOfDay(100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        java.lang.String str4 = property2.toString();
        try {
            org.joda.time.DateTime dateTime6 = property2.setCopy("T151332.735-0700");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"T151332.735-0700\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[yearOfEra]" + "'", str4.equals("Property[yearOfEra]"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime5 = dateTime3.minusDays((int) (short) -1);
        int int6 = dateTime3.getMillisOfDay();
        org.joda.time.DateTime dateTime8 = dateTime3.plusSeconds((int) (byte) -1);
        org.joda.time.DateTime dateTime10 = dateTime3.withWeekyear(10);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 57600002 + "'", int6 == 57600002);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 54825, (java.lang.Number) (byte) 0, (java.lang.Number) (-62135596799931L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        boolean boolean8 = offsetDateTimeField4.isSupported();
        long long11 = offsetDateTimeField4.getDifferenceAsLong((long) 57600002, 100L);
        long long13 = offsetDateTimeField4.roundHalfCeiling(10L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfDay(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMillisOfSecond((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = property2.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime6 = dateTime4.withYearOfCentury(8);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        int int4 = property2.getLeapAmount();
        int int5 = property2.getMinimumValue();
        boolean boolean6 = property2.isLeap();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusSeconds((int) (byte) -1);
        org.joda.time.DateTime dateTime8 = dateTime1.withWeekyear(10);
        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths(1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600002 + "'", int4 == 57600002);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        int int5 = dateTime1.getYearOfEra();
        org.joda.time.DateTime dateTime6 = dateTime1.toDateTime();
        boolean boolean7 = dateTime6.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("T151321.363-0700", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"T151321.363-0700/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime1.minusMinutes(35);
        try {
            org.joda.time.DateTime dateTime14 = dateTime12.withEra(12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 12 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        java.lang.String str8 = offsetDateTimeField4.getName();
        long long10 = offsetDateTimeField4.roundHalfFloor((long) (byte) -1);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField4.getMaximumTextLength(locale11);
        int int14 = offsetDateTimeField4.getLeapAmount((long) 'a');
        java.lang.String str16 = offsetDateTimeField4.getAsShortText((long) 57600002);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField4, 100, (-10), (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for yearOfEra must be in the range [-10,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 100, 279);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 279");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        java.lang.String str8 = offsetDateTimeField4.getName();
        long long10 = offsetDateTimeField4.roundHalfFloor((long) (byte) -1);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField4.getMaximumTextLength(locale11);
        long long14 = offsetDateTimeField4.roundCeiling((-1L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.era();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
        int int5 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.minutes();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (byte) -1);
        int int13 = offsetDateTimeField11.getLeapAmount((long) 10);
        long long15 = offsetDateTimeField11.roundHalfFloor(0L);
        long long17 = offsetDateTimeField11.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime22 = dateTime20.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate23 = dateTime22.toLocalDate();
        java.lang.String str24 = dateTimeFormatter18.print((org.joda.time.ReadablePartial) localDate23);
        int[] intArray31 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray33 = offsetDateTimeField11.set((org.joda.time.ReadablePartial) localDate23, 0, intArray31, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField35 = gregorianChronology34.minutes();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, (int) (byte) -1);
        int int40 = offsetDateTimeField38.getLeapAmount((long) 10);
        long long42 = offsetDateTimeField38.roundHalfFloor(0L);
        long long44 = offsetDateTimeField38.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime49 = dateTime47.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate50 = dateTime49.toLocalDate();
        java.lang.String str51 = dateTimeFormatter45.print((org.joda.time.ReadablePartial) localDate50);
        int[] intArray58 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray60 = offsetDateTimeField38.set((org.joda.time.ReadablePartial) localDate50, 0, intArray58, (int) (byte) 100);
        gregorianChronology3.validate((org.joda.time.ReadablePartial) localDate23, intArray60);
        org.joda.time.DateTimeField dateTimeField62 = gregorianChronology3.monthOfYear();
        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime66 = dateTime64.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate67 = dateTime66.toLocalDate();
        int[] intArray69 = gregorianChronology3.get((org.joda.time.ReadablePartial) localDate67, 1L);
        org.joda.time.ReadablePeriod readablePeriod70 = null;
        try {
            int[] intArray73 = gregorianChronology3.get(readablePeriod70, 52L, (long) 54823);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "T������.000" + "'", str24.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter45);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "T������.000" + "'", str51.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertNotNull(localDate67);
        org.junit.Assert.assertNotNull(intArray69);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTwoDigitYear((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder1 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTimeZoneBuilder1.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        boolean boolean7 = cachedDateTimeZone5.equals((java.lang.Object) 57600002);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) chronology8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField6 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readablePeriod5);
        org.joda.time.TimeOfDay timeOfDay7 = dateTime1.toTimeOfDay();
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField10 = gregorianChronology9.minutes();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) (byte) -1);
        long long16 = offsetDateTimeField13.add((long) 135, (long) 100);
        boolean boolean17 = offsetDateTimeField13.isSupported();
        int int18 = dateTime1.get((org.joda.time.DateTimeField) offsetDateTimeField13);
        long long21 = offsetDateTimeField13.addWrapField((long) 100, 0);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property24 = dateTime23.yearOfEra();
        org.joda.time.DateTime dateTime26 = property24.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime28 = dateTime26.withWeekyear((int) (byte) 100);
        org.joda.time.TimeOfDay timeOfDay29 = dateTime28.toTimeOfDay();
        java.util.Locale locale30 = null;
        try {
            java.lang.String str31 = offsetDateTimeField13.getAsText((org.joda.time.ReadablePartial) timeOfDay29, locale30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfEra' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 960 + "'", int8 == 960);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3155760000135L + "'", long16 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1969 + "'", int18 == 1969);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(timeOfDay29);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfDay(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfHour(0, 35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        int int4 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime5 = property2.withMaximumValue();
        org.joda.time.DateTime dateTime7 = dateTime5.minus((long) 1);
        org.joda.time.DateTime dateTime9 = dateTime7.plusMonths(0);
        org.joda.time.DateTime dateTime11 = dateTime9.minusYears(292278993);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime9.minus(readableDuration12);
        org.joda.time.Instant instant14 = dateTime13.toInstant();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 292278993 + "'", int4 == 292278993);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(instant14);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        long long6 = gregorianChronology2.add(0L, 28800100L, 1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28800100L + "'", long6 == 28800100L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "org.joda.time.IllegalFieldValueException: Value \"T151320.765-0700\" for hi! is not supported");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"0\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfDay(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendLiteral("T151332.735-0700");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        try {
            org.joda.time.DateTime dateTime4 = property2.setCopy("0");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        try {
            org.joda.time.DateTime dateTime5 = dateTime3.withDayOfWeek(1920);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1920 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "T151320.765-0700");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.Number number4 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNull(dateTimeFieldType3);
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 54825);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.set(0L, 10);
        java.util.Locale locale9 = null;
        java.lang.String str10 = offsetDateTimeField4.getAsText(292278993, locale9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField12 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61820064000000L) + "'", long7 == (-61820064000000L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "292278993" + "'", str10.equals("292278993"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendSecondOfDay((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendFractionOfMinute((int) (byte) 100, (int) 'a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property2.getAsShortText(locale3);
        int int5 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime6 = property2.roundCeilingCopy();
        int int7 = property2.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969" + "'", str4.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278993 + "'", int7 == 292278993);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property2.getAsShortText(locale3);
        int int5 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime6 = property2.roundCeilingCopy();
        org.joda.time.DateTime dateTime7 = property2.roundHalfFloorCopy();
        java.lang.String str8 = property2.getAsShortText();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969" + "'", str4.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.plusMillis(135);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime8 = dateTime6.minusDays((int) (short) -1);
        int int9 = dateTime6.getWeekOfWeekyear();
        int int10 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime6);
        try {
            org.joda.time.DateTime dateTime15 = dateTime1.withTime((int) (byte) 10, 1970, 69, (-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "T151320.765-0700");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        illegalFieldValueException2.prependMessage("292278993");
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNull(dateTimeFieldType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "T151320.765-0700" + "'", str5.equals("T151320.765-0700"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = dateTime1.plusMillis(135);
        org.joda.time.Chronology chronology5 = dateTime1.getChronology();
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = dateTime1.withZoneRetainFields(dateTimeZone7);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        int int5 = dateTime1.getYearOfEra();
        boolean boolean6 = dateTime1.isAfterNow();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        int int6 = dateTime3.getEra();
        int int7 = dateTime3.getMillisOfSecond();
        org.joda.time.DateTime dateTime9 = dateTime3.minusMillis((int) (byte) 0);
        org.joda.time.DateTime.Property property10 = dateTime9.centuryOfEra();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        int int6 = dateTime3.getEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.plus(readablePeriod7);
        try {
            org.joda.time.DateTime dateTime10 = dateTime3.withDayOfMonth(86399999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399999 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        java.lang.String str9 = offsetDateTimeField4.getName();
        org.joda.time.DurationField durationField10 = offsetDateTimeField4.getLeapDurationField();
        long long13 = offsetDateTimeField4.add((long) 10, (long) 35);
        long long15 = offsetDateTimeField4.remainder((long) ' ');
        java.lang.String str17 = offsetDateTimeField4.getAsShortText((long) 4);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "yearOfEra" + "'", str9.equals("yearOfEra"));
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1104537600010L + "'", long13 == 1104537600010L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 32L + "'", long15 == 32L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1969" + "'", str17.equals("1969"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("Property[yearOfEra]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[yearOfEra]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (byte) 10, (int) (byte) -1, (int) ' ', 69, (int) (short) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime4 = dateTime2.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate5 = dateTime4.toLocalDate();
        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate5);
        try {
            org.joda.time.LocalTime localTime8 = dateTimeFormatter0.parseLocalTime("UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "T������.000" + "'", str6.equals("T������.000"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        org.joda.time.DurationField durationField7 = offsetDateTimeField4.getLeapDurationField();
        long long10 = offsetDateTimeField4.set(62L, 35);
        int int13 = offsetDateTimeField4.getDifference((long) 35, (-62104060743208L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61031145599938L) + "'", long10 == (-61031145599938L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1967 + "'", int13 == 1967);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.era();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
        org.joda.time.ReadablePartial readablePartial5 = null;
        try {
            int[] intArray7 = gregorianChronology0.get(readablePartial5, (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.joda.time.DurationField durationField3 = gregorianChronology0.hours();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("Property[yearOfEra]", "Pacific Standard Time", 54823, 0);
        boolean boolean9 = fixedDateTimeZone8.isFixed();
        int int11 = fixedDateTimeZone8.getOffset(0L);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        try {
            int[] intArray16 = zonedChronology12.get(readablePeriod13, (long) 960, 70L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 54823 + "'", int11 == 54823);
        org.junit.Assert.assertNotNull(zonedChronology12);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendWeekyear(0, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendSecondOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendMonthOfYearText();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder6.appendShortText(dateTimeFieldType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(19, 54823, (int) (short) 100, (int) (short) -1, 1967, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) -1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder4.toFormatter();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendTimeZoneOffset("1969", true, (-10), 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime5 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.DateTime dateTime7 = dateTime1.withFields(readablePartial6);
        org.joda.time.DateMidnight dateMidnight8 = dateTime1.toDateMidnight();
        org.joda.time.DateTime dateTime10 = dateTime1.withMillis(2649600002L);
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime10);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600002 + "'", int4 == 57600002);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 100, dateTimeZone2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusSeconds((int) ' ');
        try {
            org.joda.time.DateTime dateTime8 = dateTime6.withWeekOfWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        int int11 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property12 = dateTime1.centuryOfEra();
        org.joda.time.DateTime dateTime14 = dateTime1.withCenturyOfEra((int) (byte) 0);
        java.util.Locale locale16 = null;
        java.lang.String str17 = dateTime14.toString("0", locale16);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        long long10 = offsetDateTimeField4.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime15 = dateTime13.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate16 = dateTime15.toLocalDate();
        java.lang.String str17 = dateTimeFormatter11.print((org.joda.time.ReadablePartial) localDate16);
        int[] intArray24 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray26 = offsetDateTimeField4.set((org.joda.time.ReadablePartial) localDate16, 0, intArray24, (int) (byte) 100);
        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField4, (int) (short) 1, (int) (byte) 1, 1920);
        java.util.Locale locale32 = null;
        java.lang.String str33 = offsetDateTimeField4.getAsText((int) (short) 10, locale32);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "T������.000" + "'", str17.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "10" + "'", str33.equals("10"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readablePeriod5);
        org.joda.time.TimeOfDay timeOfDay7 = dateTime1.toTimeOfDay();
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField10 = gregorianChronology9.minutes();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) (byte) -1);
        long long16 = offsetDateTimeField13.add((long) 135, (long) 100);
        boolean boolean17 = offsetDateTimeField13.isSupported();
        int int18 = dateTime1.get((org.joda.time.DateTimeField) offsetDateTimeField13);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, 1970);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 960 + "'", int8 == 960);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3155760000135L + "'", long16 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1969 + "'", int18 == 1969);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        java.lang.String str9 = offsetDateTimeField4.getName();
        org.joda.time.DurationField durationField10 = offsetDateTimeField4.getLeapDurationField();
        long long13 = offsetDateTimeField4.add((long) 10, (long) 35);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField4.getAsShortText((int) (byte) 1, locale15);
        int int17 = offsetDateTimeField4.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "yearOfEra" + "'", str9.equals("yearOfEra"));
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1104537600010L + "'", long13 == 1104537600010L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1" + "'", str16.equals("1"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 292278992 + "'", int17 == 292278992);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiply(292278993, 57600002);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The calculation caused an overflow: 292278993 * 57600002");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 100, dateTimeZone2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusSeconds((int) ' ');
        try {
            org.joda.time.DateTime dateTime8 = dateTime4.withHourOfDay(292278993);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("0");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.clockhourOfHalfday();
        try {
            long long10 = gregorianChronology3.getDateTimeMillis(292278992, 19, (int) (short) -1, 960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        java.lang.String str3 = gregorianChronology0.toString();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis((int) '#', 10, (int) (short) 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86400000]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.minutes();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (byte) -1);
        int int13 = offsetDateTimeField11.getLeapAmount((long) 10);
        long long15 = offsetDateTimeField11.roundHalfFloor(0L);
        long long17 = offsetDateTimeField11.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime22 = dateTime20.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate23 = dateTime22.toLocalDate();
        java.lang.String str24 = dateTimeFormatter18.print((org.joda.time.ReadablePartial) localDate23);
        int[] intArray31 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray33 = offsetDateTimeField11.set((org.joda.time.ReadablePartial) localDate23, 0, intArray31, (int) (byte) 100);
        int[] intArray38 = new int[] { (short) -1, (short) 1, 19, '#' };
        int int39 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate23, intArray38);
        long long41 = offsetDateTimeField4.remainder((long) (short) 10);
        org.joda.time.DurationField durationField42 = offsetDateTimeField4.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "T������.000" + "'", str24.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 292278992 + "'", int39 == 292278992);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertNotNull(durationField42);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.plusYears(0);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.DateTime dateTime10 = property8.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear((int) (byte) 100);
        java.lang.String str13 = dateTime12.toString();
        boolean boolean14 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime12);
        try {
            org.joda.time.DateTime dateTime18 = dateTime12.withDate((int) (short) 10, 9, 1920);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1920 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0100-01-05T16:00:00.002-07:52:58" + "'", str13.equals("0100-01-05T16:00:00.002-07:52:58"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField4 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        java.lang.String str5 = gregorianChronology3.toString();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.year();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.dayOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str5.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime5 = dateTime1.withTimeAtStartOfDay();
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.DateTime dateTime7 = dateTime1.withFields(readablePartial6);
        org.joda.time.DateMidnight dateMidnight8 = dateTime1.toDateMidnight();
        int int9 = dateMidnight8.getDayOfMonth();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600002 + "'", int4 == 57600002);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 31 + "'", int9 == 31);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder4.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withDefaultYear((int) ' ');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField14 = gregorianChronology13.minutes();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) (byte) -1);
        int int19 = offsetDateTimeField17.getLeapAmount((long) 10);
        long long21 = offsetDateTimeField17.roundHalfFloor(0L);
        long long23 = offsetDateTimeField17.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime28 = dateTime26.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate29 = dateTime28.toLocalDate();
        java.lang.String str30 = dateTimeFormatter24.print((org.joda.time.ReadablePartial) localDate29);
        int[] intArray37 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray39 = offsetDateTimeField17.set((org.joda.time.ReadablePartial) localDate29, 0, intArray37, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField41 = gregorianChronology40.minutes();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, (int) (byte) -1);
        int int46 = offsetDateTimeField44.getLeapAmount((long) 10);
        long long48 = offsetDateTimeField44.roundHalfFloor(0L);
        long long50 = offsetDateTimeField44.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime55 = dateTime53.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate56 = dateTime55.toLocalDate();
        java.lang.String str57 = dateTimeFormatter51.print((org.joda.time.ReadablePartial) localDate56);
        int[] intArray64 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray66 = offsetDateTimeField44.set((org.joda.time.ReadablePartial) localDate56, 0, intArray64, (int) (byte) 100);
        gregorianChronology9.validate((org.joda.time.ReadablePartial) localDate29, intArray66);
        int[] intArray69 = gregorianChronology3.get((org.joda.time.ReadablePartial) localDate29, (long) 1920);
        org.joda.time.DateTimeField dateTimeField70 = gregorianChronology3.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField71 = gregorianChronology3.halfdayOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "T������.000" + "'", str30.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter51);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "T������.000" + "'", str57.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(dateTimeField71);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        java.lang.String str9 = offsetDateTimeField4.getName();
        org.joda.time.DurationField durationField10 = offsetDateTimeField4.getLeapDurationField();
        long long13 = offsetDateTimeField4.add((long) 10, (long) 35);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField4.getAsShortText((int) (byte) 1, locale15);
        int int18 = offsetDateTimeField4.getMinimumValue((long) (short) 10);
        long long20 = offsetDateTimeField4.remainder(62L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "yearOfEra" + "'", str9.equals("yearOfEra"));
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1104537600010L + "'", long13 == 1104537600010L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1" + "'", str16.equals("1"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 62L + "'", long20 == 62L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        boolean boolean8 = offsetDateTimeField4.isSupported();
        boolean boolean9 = offsetDateTimeField4.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readablePeriod5);
        org.joda.time.TimeOfDay timeOfDay7 = dateTime1.toTimeOfDay();
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField10 = gregorianChronology9.minutes();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) (byte) -1);
        long long16 = offsetDateTimeField13.add((long) 135, (long) 100);
        boolean boolean17 = offsetDateTimeField13.isSupported();
        int int18 = dateTime1.get((org.joda.time.DateTimeField) offsetDateTimeField13);
        long long21 = offsetDateTimeField13.addWrapField((long) 100, 0);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField13.getAsShortText((-28800000L), locale23);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 960 + "'", int8 == 960);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3155760000135L + "'", long16 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1969 + "'", int18 == 1969);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1968" + "'", str24.equals("1968"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        long long10 = offsetDateTimeField4.roundHalfFloor(0L);
        long long12 = offsetDateTimeField4.roundCeiling(2649600002L);
        int int14 = offsetDateTimeField4.getLeapAmount((long) '4');
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField4.getAsShortText(31, locale16);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 31536000000L + "'", long12 == 31536000000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "31" + "'", str17.equals("31"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime6 = property4.addToCopy((int) ' ');
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("��:��");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"��:��\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withZone(dateTimeZone2);
        java.lang.Appendable appendable5 = null;
        org.joda.time.ReadablePartial readablePartial6 = null;
        try {
            dateTimeFormatter0.printTo(appendable5, readablePartial6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendWeekyear(0, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendSecondOfDay(0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder11.appendTimeZoneOffset("PST", true, 365, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        boolean boolean6 = cachedDateTimeZone4.equals((java.lang.Object) 57600002);
        int int8 = cachedDateTimeZone4.getStandardOffset((long) (short) 10);
        int int10 = cachedDateTimeZone4.getStandardOffset((long) 19);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        java.lang.String str8 = offsetDateTimeField4.getName();
        long long10 = offsetDateTimeField4.roundHalfFloor((long) (byte) -1);
        boolean boolean11 = offsetDateTimeField4.isSupported();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField13 = gregorianChronology12.minutes();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) -1);
        long long19 = offsetDateTimeField16.add((long) 135, (long) 100);
        java.lang.String str20 = offsetDateTimeField16.getName();
        boolean boolean21 = offsetDateTimeField16.isSupported();
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField23 = gregorianChronology22.minutes();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) (byte) -1);
        int int28 = offsetDateTimeField26.getLeapAmount((long) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField30 = gregorianChronology29.minutes();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology29.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (int) (byte) -1);
        int int35 = offsetDateTimeField33.getLeapAmount((long) 10);
        long long37 = offsetDateTimeField33.roundHalfFloor(0L);
        long long39 = offsetDateTimeField33.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime44 = dateTime42.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate45 = dateTime44.toLocalDate();
        java.lang.String str46 = dateTimeFormatter40.print((org.joda.time.ReadablePartial) localDate45);
        int[] intArray53 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray55 = offsetDateTimeField33.set((org.joda.time.ReadablePartial) localDate45, 0, intArray53, (int) (byte) 100);
        int[] intArray60 = new int[] { (short) -1, (short) 1, 19, '#' };
        int int61 = offsetDateTimeField26.getMaximumValue((org.joda.time.ReadablePartial) localDate45, intArray60);
        boolean boolean62 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate45);
        java.util.Locale locale63 = null;
        java.lang.String str64 = offsetDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDate45, locale63);
        int[] intArray66 = null;
        java.util.Locale locale68 = null;
        try {
            int[] intArray69 = offsetDateTimeField4.set((org.joda.time.ReadablePartial) localDate45, (int) (short) 0, intArray66, "T151321.363-0700", locale68);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"T151321.363-0700\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 3155760000135L + "'", long19 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "yearOfEra" + "'", str20.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(localDate45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "T������.000" + "'", str46.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 292278992 + "'", int61 == 292278992);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "1969" + "'", str64.equals("1969"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime1.weekOfWeekyear();
        try {
            org.joda.time.DateTime dateTime9 = property7.setCopy("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 86399999);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        boolean boolean8 = offsetDateTimeField4.isSupported();
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField4.getMaximumShortTextLength(locale9);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readablePeriod5);
        org.joda.time.TimeOfDay timeOfDay7 = dateTime1.toTimeOfDay();
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField10 = gregorianChronology9.minutes();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) (byte) -1);
        long long16 = offsetDateTimeField13.add((long) 135, (long) 100);
        boolean boolean17 = offsetDateTimeField13.isSupported();
        int int18 = dateTime1.get((org.joda.time.DateTimeField) offsetDateTimeField13);
        long long21 = offsetDateTimeField13.addWrapField((long) 100, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.LocalDate localDate24 = dateTimeFormatter22.parseLocalDate("T151324.051-0700");
        int[] intArray26 = new int[] {};
        try {
            int[] intArray28 = offsetDateTimeField13.addWrapPartial((org.joda.time.ReadablePartial) localDate24, (int) (byte) 0, intArray26, 57600);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 960 + "'", int8 == 960);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3155760000135L + "'", long16 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1969 + "'", int18 == 1969);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(intArray26);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        int int6 = dateTime3.getEra();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.plus(readablePeriod7);
        boolean boolean10 = dateTime8.isBefore(10L);
        org.joda.time.DateTime dateTime11 = dateTime8.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime12 = dateTime11.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.yearOfEra();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        try {
            int[] intArray11 = gregorianChronology3.get(readablePeriod8, 1009843200052L, (-61820064000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = dateTime3.withZoneRetainFields(dateTimeZone5);
        long long9 = dateTimeZone5.convertLocalToUTC((long) 100, false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        int int12 = cachedDateTimeZone10.getOffset((long) 12);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800100L + "'", long9 == 28800100L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-28800000) + "'", int12 == (-28800000));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        java.lang.String str6 = cachedDateTimeZone4.getNameKey(100L);
        int int8 = cachedDateTimeZone4.getStandardOffset((-62166787200000L));
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        int int6 = dateTime3.getDayOfMonth();
        org.joda.time.DateTime dateTime8 = dateTime3.plusDays(135);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime12 = dateTime10.minusDays((int) (short) -1);
        int int13 = dateTime10.getMillisOfDay();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property18 = dateTime17.yearOfEra();
        int int19 = dateTime15.compareTo((org.joda.time.ReadableInstant) dateTime17);
        int int20 = dateTime17.getDayOfMonth();
        boolean boolean21 = dateTime10.isEqual((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime8, (org.joda.time.ReadableInstant) dateTime10);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 31 + "'", int6 == 31);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 57600002 + "'", int13 == 57600002);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 31 + "'", int20 == 31);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(chronology22);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("T151333.319-0700", "0", 2, (int) ' ');
        long long6 = fixedDateTimeZone4.previousTransition((long) 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property6 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime11 = dateTime9.minusDays((int) (short) -1);
        int int12 = dateTime9.getMillisOfDay();
        org.joda.time.DateTime dateTime13 = dateTime9.withTimeAtStartOfDay();
        org.joda.time.ReadablePartial readablePartial14 = null;
        org.joda.time.DateTime dateTime15 = dateTime9.withFields(readablePartial14);
        org.joda.time.DateMidnight dateMidnight16 = dateTime9.toDateMidnight();
        int int17 = property7.getDifference((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property22 = dateTime21.yearOfEra();
        int int23 = dateTime19.compareTo((org.joda.time.ReadableInstant) dateTime21);
        java.lang.String str24 = dateTime19.toString();
        org.joda.time.DateTime dateTime26 = dateTime19.withYear(960);
        int int27 = property7.compareTo((org.joda.time.ReadableInstant) dateTime26);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57600002 + "'", int12 == 57600002);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str24.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.days();
        org.joda.time.DurationField durationField2 = gregorianChronology0.eras();
        try {
            long long5 = durationField2.subtract((long) (byte) 10, (-1313999948L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.halfdayOfDay();
        try {
            long long10 = gregorianChronology0.getDateTimeMillis(135, 1969, (int) ' ', (int) (short) 100, (int) (short) 100, 54825, 135);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getName((long) 9, locale12);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone15 = zonedChronology14.getZone();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime dateTime20 = dateTime18.plusSeconds((int) (short) 10);
//        org.joda.time.DateTime dateTime22 = dateTime20.plusYears(0);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) 2);
//        org.joda.time.DateTime.Property property25 = dateTime24.yearOfEra();
//        org.joda.time.DateTime dateTime27 = property25.addWrapFieldToCopy((-1));
//        org.joda.time.DateTime dateTime29 = dateTime27.withWeekyear((int) (byte) 100);
//        java.lang.String str30 = dateTime29.toString();
//        boolean boolean31 = dateTime22.isEqual((org.joda.time.ReadableInstant) dateTime29);
//        org.joda.time.MutableDateTime mutableDateTime32 = dateTime29.toMutableDateTimeISO();
//        int int33 = dateTimeZone15.getOffset((org.joda.time.ReadableInstant) dateTime29);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "0100-01-05T16:00:00.002-07:52:58" + "'", str30.equals("0100-01-05T16:00:00.002-07:52:58"));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-28378000) + "'", int33 == (-28378000));
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField14 = gregorianChronology13.minutes();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) (byte) -1);
        int int19 = offsetDateTimeField17.getLeapAmount((long) 10);
        long long21 = offsetDateTimeField17.roundHalfFloor(0L);
        long long23 = offsetDateTimeField17.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime28 = dateTime26.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate29 = dateTime28.toLocalDate();
        java.lang.String str30 = dateTimeFormatter24.print((org.joda.time.ReadablePartial) localDate29);
        int[] intArray37 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray39 = offsetDateTimeField17.set((org.joda.time.ReadablePartial) localDate29, 0, intArray37, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField41 = gregorianChronology40.minutes();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, (int) (byte) -1);
        int int46 = offsetDateTimeField44.getLeapAmount((long) 10);
        long long48 = offsetDateTimeField44.roundHalfFloor(0L);
        long long50 = offsetDateTimeField44.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime55 = dateTime53.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate56 = dateTime55.toLocalDate();
        java.lang.String str57 = dateTimeFormatter51.print((org.joda.time.ReadablePartial) localDate56);
        int[] intArray64 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray66 = offsetDateTimeField44.set((org.joda.time.ReadablePartial) localDate56, 0, intArray64, (int) (byte) 100);
        gregorianChronology9.validate((org.joda.time.ReadablePartial) localDate29, intArray66);
        int[] intArray69 = gregorianChronology3.get((org.joda.time.ReadablePartial) localDate29, (long) 1920);
        org.joda.time.DateTimeField dateTimeField70 = gregorianChronology3.minuteOfHour();
        org.joda.time.ReadablePeriod readablePeriod71 = null;
        long long74 = gregorianChronology3.add(readablePeriod71, (long) 10, (int) (byte) 100);
        try {
            long long82 = gregorianChronology3.getDateTimeMillis(69, (int) (short) 100, 135, 292278993, (int) (byte) 1, 279, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "T������.000" + "'", str30.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter51);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "T������.000" + "'", str57.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 10L + "'", long74 == 10L);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfYear(292278993);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter5);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder0.appendTimeZoneOffset("0100-01-05T16:00:00.002-07:52:58", "Property[yearOfEra]", true, 100, 69);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfYear(292278993);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimeFormatter5);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendMinuteOfDay((-10));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime1.plus(readableDuration7);
        org.joda.time.DateTime dateTime9 = dateTime8.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneName(strMap5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withLocale(locale8);
        org.joda.time.format.DateTimePrinter dateTimePrinter10 = dateTimeFormatter9.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser11 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter10, dateTimeParser11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withLocale(locale14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter15.withLocale(locale16);
        org.joda.time.DateTimeZone dateTimeZone18 = dateTimeFormatter17.getZone();
        org.joda.time.Chronology chronology19 = dateTimeFormatter17.getChronology();
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder21.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatterBuilder25.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale28 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter27.withLocale(locale28);
        java.util.Locale locale30 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter29.withLocale(locale30);
        org.joda.time.format.DateTimeParser dateTimeParser32 = dateTimeFormatter31.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder25.append(dateTimeParser32);
        org.joda.time.format.DateTimeParser[] dateTimeParserArray34 = new org.joda.time.format.DateTimeParser[] { dateTimeParser20, dateTimeParser32 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder4.append(dateTimePrinter10, dateTimeParserArray34);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder4.appendTimeZoneOffset("", "", true, 0, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimePrinter10);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNull(dateTimeZone18);
        org.junit.Assert.assertNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeParser32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeParserArray34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.withYear(9);
        org.joda.time.DateTime dateTime13 = dateTime12.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime15 = dateTime13.minusHours(1969);
        org.joda.time.MutableDateTime mutableDateTime16 = dateTime13.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property17 = dateTime13.dayOfYear();
        org.joda.time.DateTime.Property property18 = dateTime13.weekyear();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(property18);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendSecondOfDay((int) (short) 10);
        dateTimeFormatterBuilder8.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("weekOfWeekyear");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"weekOfWeekyear\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        java.lang.String str5 = gregorianChronology3.toString();
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField14 = gregorianChronology13.minutes();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) (byte) -1);
        int int19 = offsetDateTimeField17.getLeapAmount((long) 10);
        long long21 = offsetDateTimeField17.roundHalfFloor(0L);
        long long23 = offsetDateTimeField17.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime28 = dateTime26.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate29 = dateTime28.toLocalDate();
        java.lang.String str30 = dateTimeFormatter24.print((org.joda.time.ReadablePartial) localDate29);
        int[] intArray37 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray39 = offsetDateTimeField17.set((org.joda.time.ReadablePartial) localDate29, 0, intArray37, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField41 = gregorianChronology40.minutes();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, (int) (byte) -1);
        int int46 = offsetDateTimeField44.getLeapAmount((long) 10);
        long long48 = offsetDateTimeField44.roundHalfFloor(0L);
        long long50 = offsetDateTimeField44.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime55 = dateTime53.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate56 = dateTime55.toLocalDate();
        java.lang.String str57 = dateTimeFormatter51.print((org.joda.time.ReadablePartial) localDate56);
        int[] intArray64 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray66 = offsetDateTimeField44.set((org.joda.time.ReadablePartial) localDate56, 0, intArray64, (int) (byte) 100);
        gregorianChronology9.validate((org.joda.time.ReadablePartial) localDate29, intArray66);
        int[] intArray69 = gregorianChronology3.get((org.joda.time.ReadablePartial) localDate29, (long) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str5.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "T������.000" + "'", str30.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter51);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "T������.000" + "'", str57.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray69);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.plusYears(0);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.DateTime dateTime10 = property8.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear((int) (byte) 100);
        java.lang.String str13 = dateTime12.toString();
        boolean boolean14 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime.Property property15 = dateTime12.monthOfYear();
        try {
            org.joda.time.DateTime dateTime17 = property15.setCopy(292278993);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0100-01-05T16:00:00.002-07:52:58" + "'", str13.equals("0100-01-05T16:00:00.002-07:52:58"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime3.plusDays(0);
        int int7 = dateTime6.getDayOfMonth();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime4 = dateTime2.minusDays((int) (short) -1);
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.DateTime dateTime7 = dateTime4.withZoneRetainFields(dateTimeZone6);
        long long11 = dateTimeZone6.convertLocalToUTC((long) 1969, false, (long) 1);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 56792, dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28801969L + "'", long11 == 28801969L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        java.lang.String str9 = cachedDateTimeZone7.getNameKey(100L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DurationField durationField12 = gregorianChronology0.centuries();
        org.joda.time.DurationFieldType durationFieldType13 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField15 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType13, 279);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        boolean boolean4 = dateTimeZone1.isStandardOffset((-2922770L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        int int4 = dateTime1.getMillisOfDay();
        org.joda.time.DateTime dateTime6 = dateTime1.plusSeconds((int) (byte) -1);
        org.joda.time.DateTime dateTime8 = dateTime1.withWeekyear(10);
        try {
            org.joda.time.DateTime dateTime12 = dateTime1.withDate((int) 'a', (-28800000), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600002 + "'", int4 == 57600002);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        java.lang.String str8 = offsetDateTimeField4.getName();
        long long10 = offsetDateTimeField4.roundHalfFloor((long) (byte) -1);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField4.getMaximumTextLength(locale11);
        boolean boolean13 = offsetDateTimeField4.isLenient();
        java.util.Locale locale14 = null;
        int int15 = offsetDateTimeField4.getMaximumTextLength(locale14);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        java.lang.Object obj4 = null;
        boolean boolean5 = dateTime1.equals(obj4);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(56792);
        boolean boolean3 = dateTimeZone1.isStandardOffset(1L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "T151320.765-0700");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        org.joda.time.DurationFieldType durationFieldType4 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNull(dateTimeFieldType3);
        org.junit.Assert.assertNull(durationFieldType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(chronology2);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (byte) -1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfDay(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTwoDigitYear(10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("GregorianChronology[UTC]", (int) (short) 0, 35, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for GregorianChronology[UTC] must be in the range [35,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(31, 9);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 0L, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        try {
            int[] intArray6 = iSOChronology0.get(readablePeriod4, 8L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) -1, 100, 1970);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1870 + "'", int3 == 1870);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(69);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder0.addCutover(10, 'a', (int) '4', 57600002, (int) (short) 100, true, 56792);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        java.lang.String str3 = gregorianChronology0.toString();
        org.joda.time.DurationField durationField4 = gregorianChronology0.eras();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        boolean boolean6 = cachedDateTimeZone4.equals((java.lang.Object) 57600002);
        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone4.getUncachedZone();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readablePeriod5);
        org.joda.time.DateTime dateTime8 = dateTime1.plusYears(0);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime1.toMutableDateTime();
        int int10 = mutableDateTime9.getMonthOfYear();
        java.util.GregorianCalendar gregorianCalendar11 = mutableDateTime9.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertNotNull(gregorianCalendar11);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        java.lang.String str3 = gregorianChronology0.toString();
        org.joda.time.DurationField durationField4 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[UTC]" + "'", str3.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        org.joda.time.DateTime dateTime4 = property2.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime6 = dateTime4.withWeekyear((int) (byte) 100);
        java.lang.String str7 = dateTime6.toString();
        org.joda.time.ReadablePartial readablePartial8 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.withFields(readablePartial8);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0100-01-05T16:00:00.002-07:52:58" + "'", str7.equals("0100-01-05T16:00:00.002-07:52:58"));
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        java.lang.String str8 = offsetDateTimeField4.getName();
        long long10 = offsetDateTimeField4.roundHalfFloor((long) (byte) -1);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField4.getMaximumTextLength(locale11);
        int int14 = offsetDateTimeField4.getLeapAmount((long) 'a');
        java.lang.String str16 = offsetDateTimeField4.getAsShortText((long) 57600002);
        long long18 = offsetDateTimeField4.roundHalfEven((long) 279);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder0.toParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(100, '#', 4, 0, 2, false, 8);
        java.io.DataOutput dataOutput10 = null;
        try {
            dateTimeZoneBuilder0.writeTo("10", dataOutput10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        java.util.Locale locale4 = null;
        int int5 = property2.getMaximumTextLength(locale4);
        int int6 = property2.getMaximumValueOverall();
        org.joda.time.Interval interval7 = property2.toInterval();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval7);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292278993 + "'", int6 == 292278993);
        org.junit.Assert.assertNotNull(interval7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        org.joda.time.DurationField durationField7 = offsetDateTimeField4.getLeapDurationField();
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField4.getMaximumShortTextLength(locale8);
        java.util.Locale locale12 = null;
        long long13 = offsetDateTimeField4.set((long) 56792, "1", locale12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField4.getAsText(0, locale15);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-62104060743208L) + "'", long13 == (-62104060743208L));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.plusYears(0);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.DateTime dateTime10 = property8.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear((int) (byte) 100);
        java.lang.String str13 = dateTime12.toString();
        boolean boolean14 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime12.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property16 = dateTime12.hourOfDay();
        org.joda.time.DurationField durationField17 = property16.getDurationField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0100-01-05T16:00:00.002-07:52:58" + "'", str13.equals("0100-01-05T16:00:00.002-07:52:58"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("292278993", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"292278993/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDayOfWeek((int) '4');
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatterBuilder0.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendYearOfEra(365, (int) 'a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfDay(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMonthOfYear(57600);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.plusYears(0);
        int int6 = dateTime5.getWeekyear();
        int int7 = dateTime5.getEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1970 + "'", int6 == 1970);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        int int4 = property2.getLeapAmount();
        org.joda.time.DurationField durationField5 = property2.getDurationField();
        org.joda.time.DurationField durationField6 = property2.getRangeDurationField();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNull(durationField6);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneShortName();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendDecimal(dateTimeFieldType5, 1920, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (short) 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime.Property property4 = dateTime1.millisOfDay();
        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
        boolean boolean7 = dateTime5.isBefore((long) 292278993);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 86399999, "1969-12-31T16:00:00.002-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendPattern("Pacific Standard Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.withYear(9);
        org.joda.time.DateTime dateTime13 = dateTime12.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime15 = dateTime13.minusHours(1969);
        org.joda.time.MutableDateTime mutableDateTime16 = dateTime13.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property17 = dateTime13.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime18 = dateTime13.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime20 = dateTime13.plusDays((-1));
        int int21 = dateTime13.getWeekyear();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        java.lang.String str8 = offsetDateTimeField4.getName();
        long long10 = offsetDateTimeField4.roundHalfFloor((long) (byte) -1);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField4.getMaximumTextLength(locale11);
        int int14 = offsetDateTimeField4.getLeapAmount((long) 'a');
        java.lang.String str16 = offsetDateTimeField4.getAsShortText((long) 57600002);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField4.getAsText(readablePartial17, (int) (short) 0, locale19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType21, (-28378000), (-10), (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.plusYears(0);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.DateTime dateTime10 = property8.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear((int) (byte) 100);
        java.lang.String str13 = dateTime12.toString();
        boolean boolean14 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime12.toMutableDateTimeISO();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("Property[yearOfEra]", "Pacific Standard Time", 54823, 0);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property23 = dateTime22.yearOfEra();
        java.lang.String str24 = property23.getAsShortText();
        int int25 = property23.getMaximumValue();
        org.joda.time.DateTime dateTime26 = property23.withMaximumValue();
        int int27 = property23.get();
        boolean boolean28 = fixedDateTimeZone20.equals((java.lang.Object) int27);
        org.joda.time.DateTime dateTime29 = dateTime12.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.DateTime dateTime31 = dateTime29.withCenturyOfEra(12);
        try {
            org.joda.time.DateTime dateTime36 = dateTime29.withTime(10, (int) '4', (int) (byte) 100, 69);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0100-01-05T16:00:00.002-07:52:58" + "'", str13.equals("0100-01-05T16:00:00.002-07:52:58"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969" + "'", str24.equals("1969"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 292278993 + "'", int25 == 292278993);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.plusYears(0);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.DateTime dateTime10 = property8.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear((int) (byte) 100);
        java.lang.String str13 = dateTime12.toString();
        boolean boolean14 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.MutableDateTime mutableDateTime15 = dateTime12.toMutableDateTimeISO();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("Property[yearOfEra]", "Pacific Standard Time", 54823, 0);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property23 = dateTime22.yearOfEra();
        java.lang.String str24 = property23.getAsShortText();
        int int25 = property23.getMaximumValue();
        org.joda.time.DateTime dateTime26 = property23.withMaximumValue();
        int int27 = property23.get();
        boolean boolean28 = fixedDateTimeZone20.equals((java.lang.Object) int27);
        org.joda.time.DateTime dateTime29 = dateTime12.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.DateTime dateTime31 = dateTime29.withCenturyOfEra(12);
        org.joda.time.DateTime.Property property32 = dateTime31.monthOfYear();
        org.joda.time.DateTime dateTime33 = property32.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0100-01-05T16:00:00.002-07:52:58" + "'", str13.equals("0100-01-05T16:00:00.002-07:52:58"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969" + "'", str24.equals("1969"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 292278993 + "'", int25 == 292278993);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTime33);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendSecondOfMinute(35);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder3.appendFractionOfDay(2, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendHourOfDay((int) (short) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder11.appendDecimal(dateTimeFieldType14, 31, 1870);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology3.months();
        org.joda.time.DurationField durationField7 = gregorianChronology3.months();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        try {
            int[] intArray10 = gregorianChronology3.get(readablePeriod8, (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (byte) 10, 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendWeekyear(0, (int) (short) 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter10 = dateTimeFormatterBuilder9.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendCenturyOfEra((int) (short) 10, 292278992);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimePrinter10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.plus(readablePeriod5);
        org.joda.time.TimeOfDay timeOfDay7 = dateTime1.toTimeOfDay();
        int int8 = dateTime1.getMinuteOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField10 = gregorianChronology9.minutes();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) (byte) -1);
        long long16 = offsetDateTimeField13.add((long) 135, (long) 100);
        boolean boolean17 = offsetDateTimeField13.isSupported();
        int int18 = dateTime1.get((org.joda.time.DateTimeField) offsetDateTimeField13);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = null;
        try {
            int int20 = dateTime1.get(dateTimeFieldType19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(timeOfDay7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 960 + "'", int8 == 960);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3155760000135L + "'", long16 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1969 + "'", int18 == 1969);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.util.Locale locale3 = null;
        java.lang.String str4 = property2.getAsShortText(locale3);
        int int5 = property2.getMaximumValue();
        java.lang.String str6 = property2.getAsString();
        org.joda.time.DateTime dateTime7 = property2.roundCeilingCopy();
        java.util.Locale locale8 = null;
        java.util.Calendar calendar9 = dateTime7.toCalendar(locale8);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfEra();
        java.util.Locale locale13 = null;
        int int14 = property12.getMaximumShortTextLength(locale13);
        java.util.Locale locale15 = null;
        int int16 = property12.getMaximumTextLength(locale15);
        org.joda.time.DurationField durationField17 = property12.getDurationField();
        org.joda.time.DateTime dateTime18 = property12.roundHalfFloorCopy();
        boolean boolean19 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime18);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969" + "'", str4.equals("1969"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 292278993 + "'", int5 == 292278993);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(calendar9);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 9 + "'", int14 == 9);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 9 + "'", int16 == 9);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property2 = dateTime1.yearOfEra();
        java.lang.String str3 = property2.getAsShortText();
        int int4 = property2.getMaximumValue();
        org.joda.time.DateTime dateTime5 = property2.withMaximumValue();
        org.joda.time.DateTime dateTime7 = dateTime5.minus((long) 1);
        try {
            org.joda.time.DateTime dateTime9 = dateTime5.withHourOfDay((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969" + "'", str3.equals("1969"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 292278993 + "'", int4 == 292278993);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        long long8 = offsetDateTimeField4.roundHalfFloor(0L);
        long long10 = offsetDateTimeField4.roundHalfFloor(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField12 = gregorianChronology11.minutes();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology11.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) (byte) -1);
        long long18 = offsetDateTimeField15.add((long) 135, (long) 100);
        java.util.TimeZone timeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        boolean boolean23 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.minuteOfDay();
        java.util.TimeZone timeZone26 = null;
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forTimeZone(timeZone26);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27);
        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology28);
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology28.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField33 = gregorianChronology32.minutes();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology32.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, (int) (byte) -1);
        int int38 = offsetDateTimeField36.getLeapAmount((long) 10);
        long long40 = offsetDateTimeField36.roundHalfFloor(0L);
        long long42 = offsetDateTimeField36.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime47 = dateTime45.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate48 = dateTime47.toLocalDate();
        java.lang.String str49 = dateTimeFormatter43.print((org.joda.time.ReadablePartial) localDate48);
        int[] intArray56 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray58 = offsetDateTimeField36.set((org.joda.time.ReadablePartial) localDate48, 0, intArray56, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology59 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField60 = gregorianChronology59.minutes();
        org.joda.time.DateTimeField dateTimeField61 = gregorianChronology59.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField(dateTimeField61, (int) (byte) -1);
        int int65 = offsetDateTimeField63.getLeapAmount((long) 10);
        long long67 = offsetDateTimeField63.roundHalfFloor(0L);
        long long69 = offsetDateTimeField63.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter70 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime72 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime74 = dateTime72.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate75 = dateTime74.toLocalDate();
        java.lang.String str76 = dateTimeFormatter70.print((org.joda.time.ReadablePartial) localDate75);
        int[] intArray83 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray85 = offsetDateTimeField63.set((org.joda.time.ReadablePartial) localDate75, 0, intArray83, (int) (byte) 100);
        gregorianChronology28.validate((org.joda.time.ReadablePartial) localDate48, intArray85);
        int[] intArray88 = gregorianChronology22.get((org.joda.time.ReadablePartial) localDate48, (long) 1920);
        java.util.Locale locale90 = null;
        java.lang.String str91 = offsetDateTimeField15.getAsText((org.joda.time.ReadablePartial) localDate48, (int) '4', locale90);
        int[] intArray93 = null;
        java.util.Locale locale95 = null;
        try {
            int[] intArray96 = offsetDateTimeField4.set((org.joda.time.ReadablePartial) localDate48, 135, intArray93, "01351231", locale95);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3155760000135L + "'", long18 == 3155760000135L);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "T������.000" + "'", str49.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(gregorianChronology59);
        org.junit.Assert.assertNotNull(durationField60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 0L + "'", long67 == 0L);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 0L + "'", long69 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter70);
        org.junit.Assert.assertNotNull(dateTime74);
        org.junit.Assert.assertNotNull(localDate75);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "T������.000" + "'", str76.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "52" + "'", str91.equals("52"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.weekOfWeekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField8 = gregorianChronology7.minutes();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (byte) -1);
        int int13 = offsetDateTimeField11.getLeapAmount((long) 10);
        long long15 = offsetDateTimeField11.roundHalfFloor(0L);
        long long17 = offsetDateTimeField11.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime22 = dateTime20.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate23 = dateTime22.toLocalDate();
        java.lang.String str24 = dateTimeFormatter18.print((org.joda.time.ReadablePartial) localDate23);
        int[] intArray31 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray33 = offsetDateTimeField11.set((org.joda.time.ReadablePartial) localDate23, 0, intArray31, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField35 = gregorianChronology34.minutes();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, (int) (byte) -1);
        int int40 = offsetDateTimeField38.getLeapAmount((long) 10);
        long long42 = offsetDateTimeField38.roundHalfFloor(0L);
        long long44 = offsetDateTimeField38.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime49 = dateTime47.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate50 = dateTime49.toLocalDate();
        java.lang.String str51 = dateTimeFormatter45.print((org.joda.time.ReadablePartial) localDate50);
        int[] intArray58 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray60 = offsetDateTimeField38.set((org.joda.time.ReadablePartial) localDate50, 0, intArray58, (int) (byte) 100);
        gregorianChronology3.validate((org.joda.time.ReadablePartial) localDate23, intArray60);
        org.joda.time.DateTimeField dateTimeField62 = gregorianChronology3.monthOfYear();
        org.joda.time.DurationField durationField63 = gregorianChronology3.halfdays();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "T������.000" + "'", str24.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter45);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "T������.000" + "'", str51.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(durationField63);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("T151321.363-0700", false);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(960, 69, 2, (int) (byte) -1, 0, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 100, dateTimeZone8);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getName((long) 9, locale12);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField16 = gregorianChronology15.minutes();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        long long20 = gregorianChronology15.add(readablePeriod17, (long) 0, (int) (short) 100);
//        java.util.TimeZone timeZone22 = null;
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) 100, dateTimeZone23);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = dateTimeZone23.getName((long) 9, locale27);
//        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology15, dateTimeZone23);
//        long long31 = dateTimeZone8.getMillisKeepLocal(dateTimeZone23, 97L);
//        java.lang.String str33 = dateTimeZone8.getShortName((long) 57600002);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Pacific Standard Time" + "'", str13.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Pacific Standard Time" + "'", str28.equals("Pacific Standard Time"));
//        org.junit.Assert.assertNotNull(zonedChronology29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 97L + "'", long31 == 97L);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "PST" + "'", str33.equals("PST"));
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        java.lang.Integer int2 = dateTimeFormatter1.getPivotYear();
        try {
            org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("��:��", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"��:��\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(int2);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        int int11 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property12 = dateTime1.centuryOfEra();
        org.joda.time.DateTime dateTime14 = dateTime1.withCenturyOfEra((int) (byte) 0);
        long long15 = dateTime14.getMillis();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-59958144421998L) + "'", long15 == (-59958144421998L));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withLocale(locale3);
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter2.withLocale(locale5);
        org.joda.time.Chronology chronology7 = dateTimeFormatter2.getChronolgy();
        java.lang.Integer int8 = dateTimeFormatter2.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNull(chronology7);
        org.junit.Assert.assertNull(int8);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime10 = dateTime8.plusSeconds((int) (short) 10);
        org.joda.time.DateTime.Property property11 = dateTime10.millisOfDay();
        org.joda.time.DateTime dateTime13 = dateTime10.plusDays(0);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime17 = dateTime15.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime19 = dateTime17.plusYears(0);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property22 = dateTime21.yearOfEra();
        org.joda.time.DateTime dateTime24 = property22.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime26 = dateTime24.withWeekyear((int) (byte) 100);
        java.lang.String str27 = dateTime26.toString();
        boolean boolean28 = dateTime19.isEqual((org.joda.time.ReadableInstant) dateTime26);
        org.joda.time.MutableDateTime mutableDateTime29 = dateTime26.toMutableDateTimeISO();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone34 = new org.joda.time.tz.FixedDateTimeZone("Property[yearOfEra]", "Pacific Standard Time", 54823, 0);
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property37 = dateTime36.yearOfEra();
        java.lang.String str38 = property37.getAsShortText();
        int int39 = property37.getMaximumValue();
        org.joda.time.DateTime dateTime40 = property37.withMaximumValue();
        int int41 = property37.get();
        boolean boolean42 = fixedDateTimeZone34.equals((java.lang.Object) int41);
        org.joda.time.DateTime dateTime43 = dateTime26.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone34);
        org.joda.time.DateTime dateTime44 = dateTime10.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone34);
        try {
            org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(1870, (int) (byte) 0, 0, 0, 1967, (int) (byte) 0, 54825, (org.joda.time.DateTimeZone) fixedDateTimeZone34);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1967 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0100-01-05T16:00:00.002-07:52:58" + "'", str27.equals("0100-01-05T16:00:00.002-07:52:58"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(mutableDateTime29);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1969" + "'", str38.equals("1969"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 292278993 + "'", int39 == 292278993);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1969 + "'", int41 == 1969);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime44);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        java.lang.String str9 = cachedDateTimeZone7.getNameKey(100L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.Chronology chronology12 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        java.lang.String str8 = offsetDateTimeField4.getName();
        long long10 = offsetDateTimeField4.roundHalfFloor((long) (byte) -1);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField4.getMaximumTextLength(locale11);
        int int14 = offsetDateTimeField4.getLeapAmount((long) 'a');
        java.lang.String str16 = offsetDateTimeField4.getAsShortText((long) 57600002);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField4.getAsText(readablePartial17, (int) (short) 0, locale19);
        long long23 = offsetDateTimeField4.getDifferenceAsLong(35344512001820L, 28800100L);
        java.util.Locale locale24 = null;
        int int25 = offsetDateTimeField4.getMaximumShortTextLength(locale24);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1120L + "'", long23 == 1120L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.minusDays((int) (short) -1);
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = dateTime3.withZoneRetainFields(dateTimeZone5);
        long long9 = dateTimeZone5.convertLocalToUTC((long) 100, false);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfEra();
        int int16 = dateTime12.compareTo((org.joda.time.ReadableInstant) dateTime14);
        java.lang.String str17 = dateTime12.toString();
        org.joda.time.DateTime dateTime19 = dateTime12.withYearOfEra(135);
        org.joda.time.DateTime dateTime21 = dateTime12.minusYears((int) (byte) 10);
        java.util.GregorianCalendar gregorianCalendar22 = dateTime21.toGregorianCalendar();
        org.joda.time.DateTime dateTime24 = dateTime21.withMinuteOfHour(0);
        int int25 = dateTime10.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800100L + "'", long9 == 28800100L);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str17.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(gregorianCalendar22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) '4');
        org.joda.time.ReadablePartial readablePartial4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = gregorianChronology6.minutes();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) (byte) -1);
        int int12 = offsetDateTimeField10.getLeapAmount((long) 10);
        long long14 = offsetDateTimeField10.roundHalfFloor(0L);
        long long16 = offsetDateTimeField10.roundHalfFloor(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime21 = dateTime19.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate22 = dateTime21.toLocalDate();
        java.lang.String str23 = dateTimeFormatter17.print((org.joda.time.ReadablePartial) localDate22);
        int[] intArray30 = new int[] { 1969, 100, ' ', 10, 2 };
        int[] intArray32 = offsetDateTimeField10.set((org.joda.time.ReadablePartial) localDate22, 0, intArray30, (int) (byte) 100);
        try {
            int[] intArray34 = offsetDateTimeField3.addWrapField(readablePartial4, (int) (short) 10, intArray30, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "T������.000" + "'", str23.equals("T������.000"));
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray32);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.addRecurringSavings("��:��", 86399999, 0, (-1), 'a', 8, 1870, 8, false, (int) '4');
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        int int6 = offsetDateTimeField4.getLeapAmount((long) 10);
        org.joda.time.DurationField durationField7 = offsetDateTimeField4.getLeapDurationField();
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField4.getMaximumTextLength(locale8);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) 100, dateTimeZone2);
        org.joda.time.DateTime dateTime6 = dateTime4.minusSeconds((int) ' ');
        java.lang.String str7 = dateTime4.toString();
        try {
            org.joda.time.DateTime dateTime9 = dateTime4.withYearOfCentury(54825);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54825 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str7.equals("1969-12-31T16:00:00.100-08:00"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfYear(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendClockhourOfHalfday(8);
        boolean boolean8 = dateTimeFormatterBuilder7.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = dateTime1.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime3.plusYears(0);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        org.joda.time.DateTime dateTime10 = property8.addWrapFieldToCopy((-1));
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear((int) (byte) 100);
        java.lang.String str13 = dateTime12.toString();
        boolean boolean14 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime12);
        try {
            org.joda.time.DateTime dateTime16 = dateTime12.withDayOfYear(54825);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54825 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0100-01-05T16:00:00.002-07:52:58" + "'", str13.equals("0100-01-05T16:00:00.002-07:52:58"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) (byte) -1);
        long long7 = offsetDateTimeField4.add((long) 135, (long) 100);
        java.lang.String str8 = offsetDateTimeField4.getName();
        boolean boolean9 = offsetDateTimeField4.isSupported();
        java.lang.String str10 = offsetDateTimeField4.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000135L + "'", long7 == 3155760000135L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTimeField[yearOfEra]" + "'", str10.equals("DateTimeField[yearOfEra]"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) (byte) 100, 1967);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 365, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime4 = dateTime2.plusSeconds((int) (short) 10);
        org.joda.time.LocalDate localDate5 = dateTime4.toLocalDate();
        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate5);
        boolean boolean7 = dateTimeFormatter0.isPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withOffsetParsed();
        java.lang.Appendable appendable9 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime13 = dateTime11.plusSeconds((int) (short) 10);
        org.joda.time.DateTime dateTime14 = dateTime11.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime11.plus(readablePeriod15);
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
        boolean boolean21 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology20);
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology20.weekOfWeekyear();
        long long27 = gregorianChronology20.add((long) (-1), 0L, 9);
        boolean boolean28 = dateTime16.equals((java.lang.Object) 9);
        try {
            dateTimeFormatter8.printTo(appendable9, (org.joda.time.ReadableInstant) dateTime16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "T������.000" + "'", str6.equals("T������.000"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1L) + "'", long27 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(4260240000000L, 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 149108400000000L + "'", long2 == 149108400000000L);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        boolean boolean6 = cachedDateTimeZone4.equals((java.lang.Object) 57600002);
        int int8 = cachedDateTimeZone4.getStandardOffset((long) (short) 10);
        java.lang.String str9 = cachedDateTimeZone4.getID();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "T151321.363-0700" + "'", str9.equals("T151321.363-0700"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        java.util.GregorianCalendar gregorianCalendar11 = dateTime10.toGregorianCalendar();
        org.joda.time.DateTime dateTime13 = dateTime10.plusMonths((int) (byte) 10);
        org.joda.time.Chronology chronology14 = dateTime13.getChronology();
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianCalendar11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) 2);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        int int5 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime3);
        java.lang.String str6 = dateTime1.toString();
        org.joda.time.DateTime dateTime8 = dateTime1.withYearOfEra(135);
        org.joda.time.DateTime dateTime10 = dateTime1.minusYears((int) (byte) 10);
        int int11 = dateTime1.getCenturyOfEra();
        org.joda.time.DateTime.Property property12 = dateTime1.centuryOfEra();
        org.joda.time.DateTime dateTime14 = dateTime1.withSecondOfMinute(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        try {
            org.joda.time.DateTime.Property property16 = dateTime1.property(dateTimeFieldType15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969-12-31T16:00:00.002-08:00" + "'", str6.equals("1969-12-31T16:00:00.002-08:00"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.yearOfEra();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder3.toDateTimeZone("T151321.363-0700", false);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        java.lang.String str9 = cachedDateTimeZone7.getNameKey(100L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        long long14 = cachedDateTimeZone7.adjustOffset((long) 0, false);
        int int16 = cachedDateTimeZone7.getStandardOffset((-61820064000000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral("Property[yearOfEra]");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder4.toFormatter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withLocale(locale7);
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter8.withLocale(locale9);
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.append(dateTimeParser11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder4.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter14.withLocale(locale15);
        org.joda.time.format.DateTimePrinter dateTimePrinter17 = dateTimeFormatter16.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser18 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter17, dateTimeParser18);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale21 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter20.withLocale(locale21);
        java.util.Locale locale23 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter22.withLocale(locale23);
        org.joda.time.DateTimeZone dateTimeZone25 = dateTimeFormatter24.getZone();
        org.joda.time.Chronology chronology26 = dateTimeFormatter24.getChronology();
        org.joda.time.format.DateTimeParser dateTimeParser27 = dateTimeFormatter24.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder4.append(dateTimePrinter17, dateTimeParser27);
        boolean boolean29 = dateTimeFormatterBuilder28.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimePrinter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNull(dateTimeZone25);
        org.junit.Assert.assertNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeParser27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 4);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (short) 100, (java.lang.Object) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        long long9 = gregorianChronology3.add(readablePeriod6, (long) 31, 1969);
        try {
            long long14 = gregorianChronology3.getDateTimeMillis((int) (byte) 0, (int) 'a', (int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 31L + "'", long9 == 31L);
    }
}

