import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.Chronology chronology7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((-1), (int) (byte) 1, (int) '4', (int) (byte) 1, (-1), 0, 0, chronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) 100.0d, dateTimeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Double");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList1 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, dateTimeFieldTypeArray0);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList1, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        try {
            org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 0.0d, dateTimeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Double");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("hi!", (int) (byte) 10, (int) (byte) 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for hi! must be in the range [0,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gJChronology0.add(readablePeriod1, (-99948L), 10);
        org.joda.time.DurationField durationField5 = gJChronology0.millis();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        try {
            int[] intArray9 = gJChronology0.get(readablePeriod6, (long) '#', (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-99948L) + "'", long4 == (-99948L));
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        boolean boolean9 = dateTime4.isAfter((-99948L));
        org.joda.time.DateTime.Property property10 = dateTime4.secondOfDay();
        try {
            org.joda.time.DateTime dateTime12 = property10.setCopy("1969-12-31T16:00:00.032-08:00");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1969-12-31T16:00:00.032-08:00\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        boolean boolean9 = dateTime4.isAfter((-99948L));
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            int int11 = dateTime4.get(dateTimeFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        int int7 = dateTime4.getMinuteOfDay();
        try {
            org.joda.time.DateTime dateTime12 = dateTime4.withTime((int) (byte) 10, (int) '4', (int) 'a', (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 960 + "'", int7 == 960);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gJChronology0.add(readablePeriod1, (-99948L), 10);
        try {
            long long9 = gJChronology0.getDateTimeMillis(0, (int) (byte) 1, 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-99948L) + "'", long4 == (-99948L));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(0, 0, (int) (byte) 1, (int) (short) 1, 10, (int) (short) 1, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.date();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 0, (org.joda.time.Chronology) gJChronology1, locale2, (java.lang.Integer) 0, 16);
        try {
            long long10 = gJChronology1.getDateTimeMillis(0, (int) (byte) -1, 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        int int6 = dateTime4.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime8 = dateTime4.minusDays(10);
        org.joda.time.DateTime dateTime10 = dateTime8.minusDays(0);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        try {
            org.joda.time.DateTime dateTime13 = dateTime8.withFieldAdded(durationFieldType11, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((-99948L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.4988431945d + "'", double1 == 2440587.4988431945d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', chronology4);
        int int6 = dateTime5.getHourOfDay();
        org.joda.time.DateTime dateTime8 = dateTime5.withYear((int) (short) -1);
        java.lang.String str9 = dateTime5.toString();
        int int10 = dateTime5.getEra();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime5.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime5);
        try {
            java.lang.String str16 = dateTime5.toString("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str9.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(gJChronology14);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime4.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
        try {
            org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, 0L, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str8.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        boolean boolean9 = dateTime4.isAfter((-99948L));
        org.joda.time.DateTime.Property property10 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime12 = dateTime4.withMonthOfYear(1);
        try {
            org.joda.time.DateTime dateTime17 = dateTime12.withTime((int) 'a', 0, 960, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.lang.Throwable throwable0 = null;
        try {
            boolean boolean1 = org.joda.time.IllegalInstantException.isIllegalInstant(throwable0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.seconds();
        long long5 = durationField2.subtract((long) '4', (long) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        long long10 = gJChronology6.add(readablePeriod7, (-99948L), 10);
        org.joda.time.DurationField durationField11 = gJChronology6.millis();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField12 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField2, durationField11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-99948L) + "'", long5 == (-99948L));
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-99948L) + "'", long10 == (-99948L));
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.seconds();
        long long4 = durationField1.subtract((long) '4', (long) (short) 100);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField7 = new org.joda.time.field.ScaledDurationField(durationField1, durationFieldType5, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-99948L) + "'", long4 == (-99948L));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setWeekOfWeekyear((int) ' ');
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.secondOfMinute();
        try {
            mutableDateTime2.setRounding(dateTimeField6, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal rounding mode: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField8 = gJChronology7.seconds();
        try {
            org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(0, 0, (int) (short) 1, 0, 0, (int) (byte) 10, 0, (org.joda.time.Chronology) gJChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("1969-12-31T16:00:00.032-08:00");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"1969-12-31T16:00:00.032-08:00/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.millisOfSecond();
        java.util.Locale locale11 = null;
        try {
            org.joda.time.DateTime dateTime12 = property9.setCopy("", locale11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setWeekOfWeekyear((int) ' ');
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            int int6 = mutableDateTime2.get(dateTimeFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        boolean boolean9 = dateTime4.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) ' ', chronology13);
        int int15 = dateTime14.getHourOfDay();
        org.joda.time.DateTime dateTime17 = dateTime14.withYear((int) (short) -1);
        java.lang.String str18 = dateTime14.toString();
        int int19 = dateTime14.getEra();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime14.toDateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime14.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone24 = dateTime23.getZone();
        org.joda.time.DateTime dateTime25 = dateTime4.toDateTime(dateTimeZone24);
        int int26 = dateTime4.getMinuteOfDay();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str18.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 960 + "'", int26 == 960);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-10) + "'", int1 == (-10));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DurationField durationField2 = gJChronology0.weekyears();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField4 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.monthOfYear();
        java.util.Locale locale7 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime8 = property5.set("", locale7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "57600");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime4.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str8.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = org.joda.time.MutableDateTime.ROUND_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
        boolean boolean7 = dateMidnight5.isAfter((long) ' ');
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime4.dayOfMonth();
        org.joda.time.DateTime dateTime14 = dateTime4.plusYears((int) (byte) 0);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str8.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.era();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.monthOfYear();
        try {
            mutableDateTime2.setDate(100, (-1), (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) ' ', (-99948L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3198336L) + "'", long2 == (-3198336L));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        long long15 = skipDateTimeField11.remainder((long) (-10));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        try {
            org.joda.time.DateTime dateTime7 = dateTime4.withEra((-10));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 0, (org.joda.time.Chronology) gJChronology1, locale2, (java.lang.Integer) 0, 16);
        long long7 = dateTimeParserBucket5.computeMillis(true);
        long long9 = dateTimeParserBucket5.computeMillis(false);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800000L + "'", long9 == 28800000L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        boolean boolean20 = dateTime18.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        int[] intArray23 = julianChronology13.get((org.joda.time.ReadablePartial) localDateTime21, (-62112150421990L));
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) (byte) 0, locale25);
        int int28 = skipDateTimeField11.get(10L);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone29);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant32, readableInstant33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) ' ', chronology34);
        boolean boolean37 = dateTime35.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime38 = dateTime35.toLocalDateTime();
        int[] intArray40 = julianChronology30.get((org.joda.time.ReadablePartial) localDateTime38, (-62112150421990L));
        boolean boolean41 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime38);
        int[] intArray43 = null;
        java.util.Locale locale45 = null;
        try {
            int[] intArray46 = skipDateTimeField11.set((org.joda.time.ReadablePartial) localDateTime38, 57600, intArray43, "", locale45);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(localDateTime38);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 0, (org.joda.time.Chronology) gJChronology1, locale2, (java.lang.Integer) 0, 16);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            dateTimeParserBucket5.saveField(dateTimeFieldType6, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.DateTime.Property property7 = dateTime4.property(dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) ' ', chronology15);
        boolean boolean18 = dateTime16.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime19 = dateTime16.toLocalDateTime();
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDateTime19, locale20);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType22, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(localDateTime19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "32" + "'", str21.equals("32"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(97, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        int int7 = dateTime4.getMinuteOfDay();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime4);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 960 + "'", int7 == 960);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        java.lang.String str15 = skipDateTimeField11.getAsShortText((long) 57600);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        long long24 = gJChronology16.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField26);
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone28);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant31, readableInstant32);
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) ' ', chronology33);
        boolean boolean36 = dateTime34.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime37 = dateTime34.toLocalDateTime();
        int[] intArray39 = julianChronology29.get((org.joda.time.ReadablePartial) localDateTime37, (-62112150421990L));
        java.util.Locale locale41 = null;
        java.lang.String str42 = skipDateTimeField27.getAsShortText((org.joda.time.ReadablePartial) localDateTime37, (int) (byte) 0, locale41);
        int[] intArray48 = new int[] { 10, (short) -1, (byte) 100, (-1) };
        try {
            int[] intArray50 = skipDateTimeField11.addWrapField((org.joda.time.ReadablePartial) localDateTime37, (int) '#', intArray48, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "600" + "'", str15.equals("600"));
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-62112150421990L) + "'", long24 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(localDateTime37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "0" + "'", str42.equals("0"));
        org.junit.Assert.assertNotNull(intArray48);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.era();
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = property5.add(16);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 100, 100, 31, 57600);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 200 + "'", int4 == 200);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        boolean boolean20 = dateTime18.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        int[] intArray23 = julianChronology13.get((org.joda.time.ReadablePartial) localDateTime21, (-62112150421990L));
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) (byte) 0, locale25);
        int int28 = skipDateTimeField11.get(10L);
        long long31 = skipDateTimeField11.add(33L, (long) (byte) 10);
        org.joda.time.ReadablePartial readablePartial32 = null;
        java.util.Locale locale33 = null;
        try {
            java.lang.String str34 = skipDateTimeField11.getAsText(readablePartial32, locale33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 43L + "'", long31 == 43L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        int int8 = dateTime7.getWeekyear();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        java.lang.String str14 = skipDateTimeField11.toString();
        long long17 = skipDateTimeField11.add((long) (byte) 1, 32L);
        try {
            long long20 = skipDateTimeField11.set((-1L), "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str14.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 33L + "'", long17 == 33L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        mutableDateTime2.setYear(0);
        try {
            mutableDateTime2.setDayOfMonth(1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendWeekOfWeekyear((int) (byte) 100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendHourOfHalfday((-10));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 0, (int) (short) 1, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) '#', (int) '4');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendCenturyOfEra((-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '4', 10, (-1), 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant8, readableInstant9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) ' ', chronology10);
        boolean boolean13 = dateTime11.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime14 = dateTime11.toLocalDateTime();
        boolean boolean16 = dateTime11.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant18, readableInstant19);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) ' ', chronology20);
        int int22 = dateTime21.getHourOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withYear((int) (short) -1);
        java.lang.String str25 = dateTime21.toString();
        int int26 = dateTime21.getEra();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = dateTime21.toDateTime(dateTimeZone27);
        org.joda.time.DateTime dateTime30 = dateTime21.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone31 = dateTime30.getZone();
        org.joda.time.DateTime dateTime32 = dateTime11.toDateTime(dateTimeZone31);
        org.joda.time.Chronology chronology33 = julianChronology6.withZone(dateTimeZone31);
        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone31);
        try {
            org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(57600, (int) (short) 100, (int) '4', (int) 'a', (int) (byte) 1, dateTimeZone31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(localDateTime14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 16 + "'", int22 == 16);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str25.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(buddhistChronology34);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        int int6 = dateTime4.getWeekOfWeekyear();
        int int7 = dateTime4.getDayOfWeek();
        org.joda.time.DateTime dateTime9 = dateTime4.plusMinutes((int) '#');
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) '#', (int) '4');
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendFractionOfHour((int) 'a', 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.addWeeks((int) (byte) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfCentury();
        mutableDateTime2.setTime(1L);
        java.lang.String str8 = mutableDateTime2.toString();
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-31T00:00:00.001-08:00" + "'", str8.equals("1969-12-31T00:00:00.001-08:00"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) ' ', chronology6);
        boolean boolean9 = dateTime7.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime10 = dateTime7.toLocalDateTime();
        boolean boolean12 = dateTime7.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant14, readableInstant15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) ' ', chronology16);
        int int18 = dateTime17.getHourOfDay();
        org.joda.time.DateTime dateTime20 = dateTime17.withYear((int) (short) -1);
        java.lang.String str21 = dateTime17.toString();
        int int22 = dateTime17.getEra();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = dateTime17.toDateTime(dateTimeZone23);
        org.joda.time.DateTime dateTime26 = dateTime17.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone27 = dateTime26.getZone();
        org.joda.time.DateTime dateTime28 = dateTime7.toDateTime(dateTimeZone27);
        org.joda.time.Chronology chronology29 = julianChronology2.withZone(dateTimeZone27);
        org.joda.time.DurationField durationField30 = julianChronology2.seconds();
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField32 = gJChronology31.seconds();
        long long35 = durationField32.subtract((long) '4', (long) (short) 100);
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField36 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField30, durationField32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 16 + "'", int18 == 16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str21.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-99948L) + "'", long35 == (-99948L));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, number1, (java.lang.Number) 100.0f, (java.lang.Number) 33L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth((int) (short) 10);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYearOfCentury((int) (short) -1, (-10));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("33", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"33/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        int int6 = dateTime4.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime8 = dateTime4.minusDays(10);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, readableInstant11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) ' ', chronology12);
        int int14 = dateTime13.getHourOfDay();
        org.joda.time.DateTime dateTime16 = dateTime13.withYear((int) (short) -1);
        java.lang.String str17 = dateTime13.toString();
        int int18 = dateTime13.getEra();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = dateTime13.toDateTime(dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime13.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime22.getZone();
        long long26 = dateTimeZone23.adjustOffset(10L, false);
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime4, dateTimeZone23);
        mutableDateTime27.addSeconds(960);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 16 + "'", int14 == 16);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str17.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.monthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Instant instant8 = new org.joda.time.Instant(28800000L);
        org.joda.time.Instant instant11 = instant8.withDurationAdded(0L, 0);
        boolean boolean12 = buddhistChronology6.equals((java.lang.Object) 0L);
        org.joda.time.MutableDateTime mutableDateTime13 = mutableDateTime2.toMutableDateTime((org.joda.time.Chronology) buddhistChronology6);
        java.util.Locale locale15 = null;
        java.lang.String str16 = mutableDateTime2.toString("100", locale15);
        org.joda.time.DurationFieldType durationFieldType17 = null;
        try {
            mutableDateTime2.add(durationFieldType17, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "100" + "'", str16.equals("100"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        boolean boolean20 = dateTime18.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        int[] intArray23 = julianChronology13.get((org.joda.time.ReadablePartial) localDateTime21, (-62112150421990L));
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) (byte) 0, locale25);
        int int28 = skipDateTimeField11.get(10L);
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
        long long37 = gJChronology29.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField39 = gJChronology38.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField40 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology29, dateTimeField39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.ReadableInstant readableInstant44 = null;
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.Chronology chronology46 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant44, readableInstant45);
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) ' ', chronology46);
        boolean boolean49 = dateTime47.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime50 = dateTime47.toLocalDateTime();
        int[] intArray52 = julianChronology42.get((org.joda.time.ReadablePartial) localDateTime50, (-62112150421990L));
        java.util.Locale locale54 = null;
        java.lang.String str55 = skipDateTimeField40.getAsShortText((org.joda.time.ReadablePartial) localDateTime50, (int) (byte) 0, locale54);
        java.util.Locale locale56 = null;
        java.lang.String str57 = skipDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDateTime50, locale56);
        long long59 = skipDateTimeField11.roundCeiling((long) 960);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-62112150421990L) + "'", long37 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(chronology46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(localDateTime50);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "0" + "'", str55.equals("0"));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "32" + "'", str57.equals("32"));
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 960L + "'", long59 == 960L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.era();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            mutableDateTime2.add(durationFieldType6, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) '#', (int) '4');
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", "JulianChronology[America/Los_Angeles]", true, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) '4', (int) (byte) 100, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gJChronology0.add(readablePeriod1, (-99948L), 10);
        org.joda.time.DurationField durationField5 = gJChronology0.millis();
        long long8 = durationField5.subtract((long) (short) 1, 28800000L);
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField5, durationFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-99948L) + "'", long4 == (-99948L));
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-28799999L) + "'", long8 == (-28799999L));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((int) (byte) 100, (int) (short) 0, (int) (short) 100, 57600, (int) (byte) -1, (int) (byte) 1, (-3));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        boolean boolean9 = dateTime4.isAfter((-99948L));
        org.joda.time.DateTime.Property property10 = dateTime4.secondOfDay();
        java.lang.String str11 = property10.getAsString();
        org.joda.time.DateTime dateTime13 = property10.addWrapFieldToCopy(0);
        org.joda.time.DateTime dateTime15 = dateTime13.plusDays(200);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "57600" + "'", str11.equals("57600"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        java.lang.String str15 = skipDateTimeField11.getAsShortText((long) 57600);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        long long24 = gJChronology16.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField26);
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant29, readableInstant30);
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) ' ', chronology31);
        boolean boolean34 = dateTime32.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime35 = dateTime32.toLocalDateTime();
        java.util.Locale locale36 = null;
        java.lang.String str37 = skipDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDateTime35, locale36);
        int[] intArray38 = null;
        int int39 = skipDateTimeField11.getMinimumValue((org.joda.time.ReadablePartial) localDateTime35, intArray38);
        boolean boolean41 = skipDateTimeField11.isLeap(100L);
        try {
            long long44 = skipDateTimeField11.set((long) (-1), "16:00:00-08:00");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"16:00:00-08:00\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "600" + "'", str15.equals("600"));
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-62112150421990L) + "'", long24 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(localDateTime35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "32" + "'", str37.equals("32"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone2);
        mutableDateTime3.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime3.monthOfYear();
        mutableDateTime3.setDayOfYear((int) 'a');
        int int11 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "33", 1);
        try {
            mutableDateTime3.setDayOfMonth((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-3) + "'", int11 == (-3));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 0, (org.joda.time.Chronology) gJChronology1, locale2, (java.lang.Integer) 0, 16);
        long long7 = dateTimeParserBucket5.computeMillis(true);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField18);
        java.lang.String str21 = skipDateTimeField19.getAsText((long) (byte) 100);
        dateTimeParserBucket5.saveField((org.joda.time.DateTimeField) skipDateTimeField19, (int) (short) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField19, dateTimeFieldType24);
        int int27 = skipDateTimeField19.getMinimumValue((long) 200);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112150421990L) + "'", long16 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "100" + "'", str21.equals("100"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        org.joda.time.DateTime dateTime9 = dateTime4.withMillisOfDay(0);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(16, 10, (int) (short) 10, (int) (byte) 0, (int) (short) 0, (-3), dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -3 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) '#', (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendDayOfWeek(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', chronology4);
        int int6 = dateTime5.getHourOfDay();
        int int7 = dateTime5.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime5.minusDays(10);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) ' ', chronology13);
        int int15 = dateTime14.getHourOfDay();
        org.joda.time.DateTime dateTime17 = dateTime14.withYear((int) (short) -1);
        java.lang.String str18 = dateTime14.toString();
        int int19 = dateTime14.getEra();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime14.toDateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime14.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone24 = dateTime23.getZone();
        long long27 = dateTimeZone24.adjustOffset(10L, false);
        org.joda.time.MutableDateTime mutableDateTime28 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime5, dateTimeZone24);
        org.joda.time.Chronology chronology29 = buddhistChronology0.withZone(dateTimeZone24);
        org.joda.time.DurationField durationField30 = buddhistChronology0.days();
        long long33 = durationField30.subtract((long) (byte) 0, (-1L));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str18.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 86400000L + "'", long33 == 86400000L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) ' ', chronology5);
        boolean boolean8 = dateTime6.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime9 = dateTime6.toLocalDateTime();
        boolean boolean11 = dateTime6.isAfter((-99948L));
        org.joda.time.DateTime.Property property12 = dateTime6.secondOfDay();
        org.joda.time.DateTime dateTime14 = dateTime6.withMonthOfYear(1);
        int int15 = dateTime6.getSecondOfDay();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 57600 + "'", int15 == 57600);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(97, 97, 0, 0, (int) (byte) 0, 4, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) ' ', chronology5);
        boolean boolean8 = dateTime6.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime9 = dateTime6.toLocalDateTime();
        boolean boolean11 = dateTime6.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) ' ', chronology15);
        int int17 = dateTime16.getHourOfDay();
        org.joda.time.DateTime dateTime19 = dateTime16.withYear((int) (short) -1);
        java.lang.String str20 = dateTime16.toString();
        int int21 = dateTime16.getEra();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime16.toDateTime(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime16.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone26 = dateTime25.getZone();
        org.joda.time.DateTime dateTime27 = dateTime6.toDateTime(dateTimeZone26);
        org.joda.time.Chronology chronology28 = julianChronology1.withZone(dateTimeZone26);
        org.joda.time.DurationField durationField29 = julianChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology1.millisOfDay();
        try {
            long long35 = julianChronology1.getDateTimeMillis(1969, 97, 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str20.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, readableInstant11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) ' ', chronology12);
        boolean boolean15 = dateTime13.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime16 = dateTime13.toLocalDateTime();
        boolean boolean18 = dateTime13.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant20, readableInstant21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) ' ', chronology22);
        int int24 = dateTime23.getHourOfDay();
        org.joda.time.DateTime dateTime26 = dateTime23.withYear((int) (short) -1);
        java.lang.String str27 = dateTime23.toString();
        int int28 = dateTime23.getEra();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = dateTime23.toDateTime(dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime23.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone33 = dateTime32.getZone();
        org.joda.time.DateTime dateTime34 = dateTime13.toDateTime(dateTimeZone33);
        org.joda.time.Chronology chronology35 = julianChronology8.withZone(dateTimeZone33);
        try {
            org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime(1970, (int) (byte) 100, (-10), (int) '#', (int) ' ', 0, 2, dateTimeZone33);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(localDateTime16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 16 + "'", int24 == 16);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str27.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(chronology35);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.era();
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant7, readableInstant8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) ' ', chronology9);
        int int11 = dateTime10.getHourOfDay();
        org.joda.time.DateTime dateTime13 = dateTime10.withYear((int) (short) -1);
        java.lang.String str14 = dateTime10.toString();
        int int15 = dateTime10.getEra();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = dateTime10.toDateTime(dateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime10.minusMillis(999);
        org.joda.time.DateTime dateTime20 = dateTime19.withLaterOffsetAtOverlap();
        try {
            int int21 = property5.getDifference((org.joda.time.ReadableInstant) dateTime19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 16 + "'", int11 == 16);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str14.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gJChronology0.add(readablePeriod1, (-99948L), 10);
        org.joda.time.DurationField durationField5 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology0.centuryOfEra();
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((java.lang.Object) dateTimeField6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-99948L) + "'", long4 == (-99948L));
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "1969-12-31T16:00:00.032-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 0, (org.joda.time.Chronology) gJChronology1, locale2, (java.lang.Integer) 0, 16);
        java.lang.Integer int6 = dateTimeParserBucket5.getOffsetInteger();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        java.util.Locale locale9 = null;
        try {
            dateTimeParserBucket5.saveField(dateTimeFieldType7, "JulianChronology[America/Los_Angeles]", locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNull(int6);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1L, (java.lang.Number) 16, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfCentury((int) (byte) 100, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendHourOfDay(100);
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder6.toParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
        org.joda.time.DateTime dateTime7 = dateTime4.plusMillis(0);
        org.joda.time.DateTime dateTime8 = dateTime4.toDateTimeISO();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.DateTime dateTime11 = dateTime4.withFieldAdded(durationFieldType9, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.monthOfYear();
        mutableDateTime2.setDayOfYear((int) 'a');
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        long long12 = gJChronology8.add(readablePeriod9, (-99948L), 10);
        org.joda.time.DateTime dateTime13 = mutableDateTime2.toDateTime((org.joda.time.Chronology) gJChronology8);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime2.minuteOfHour();
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
        long long23 = gJChronology15.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology24.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology15, dateTimeField25);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant30, readableInstant31);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) ' ', chronology32);
        boolean boolean35 = dateTime33.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime36 = dateTime33.toLocalDateTime();
        int[] intArray38 = julianChronology28.get((org.joda.time.ReadablePartial) localDateTime36, (-62112150421990L));
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipDateTimeField26.getAsShortText((org.joda.time.ReadablePartial) localDateTime36, (int) (byte) 0, locale40);
        int int43 = skipDateTimeField26.get(10L);
        int int44 = skipDateTimeField26.getMaximumValue();
        boolean boolean46 = skipDateTimeField26.isLeap((long) (byte) 0);
        int int48 = skipDateTimeField26.get((-62112150421990L));
        try {
            mutableDateTime2.setRounding((org.joda.time.DateTimeField) skipDateTimeField26, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal rounding mode: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-99948L) + "'", long12 == (-99948L));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62112150421990L) + "'", long23 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(localDateTime36);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "0" + "'", str41.equals("0"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 10 + "'", int43 == 10);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 999 + "'", int44 == 999);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 10 + "'", int48 == 10);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMonthOfYear(31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) ' ', chronology11);
        int int13 = dateTime12.getHourOfDay();
        int int14 = dateTime12.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime16 = dateTime12.minusDays(10);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant18, readableInstant19);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) ' ', chronology20);
        int int22 = dateTime21.getHourOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withYear((int) (short) -1);
        java.lang.String str25 = dateTime21.toString();
        int int26 = dateTime21.getEra();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = dateTime21.toDateTime(dateTimeZone27);
        org.joda.time.DateTime dateTime30 = dateTime21.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone31 = dateTime30.getZone();
        long long34 = dateTimeZone31.adjustOffset(10L, false);
        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime12, dateTimeZone31);
        org.joda.time.Chronology chronology36 = buddhistChronology7.withZone(dateTimeZone31);
        try {
            org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime(2, (int) (byte) -1, (int) 'a', 0, 1969, (int) 'a', 3, chronology36);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 16 + "'", int13 == 16);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 16 + "'", int22 == 16);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str25.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertNotNull(chronology36);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) ' ', chronology5);
        boolean boolean8 = dateTime6.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime9 = dateTime6.toLocalDateTime();
        boolean boolean11 = dateTime6.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) ' ', chronology15);
        int int17 = dateTime16.getHourOfDay();
        org.joda.time.DateTime dateTime19 = dateTime16.withYear((int) (short) -1);
        java.lang.String str20 = dateTime16.toString();
        int int21 = dateTime16.getEra();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime16.toDateTime(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime16.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone26 = dateTime25.getZone();
        org.joda.time.DateTime dateTime27 = dateTime6.toDateTime(dateTimeZone26);
        org.joda.time.Chronology chronology28 = julianChronology1.withZone(dateTimeZone26);
        try {
            org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26, (long) (-3), (-3));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str20.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(chronology28);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.era();
        mutableDateTime2.addWeeks(960);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        boolean boolean20 = dateTime18.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        int[] intArray23 = julianChronology13.get((org.joda.time.ReadablePartial) localDateTime21, (-62112150421990L));
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) (byte) 0, locale25);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.Chronology chronology30 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant28, readableInstant29);
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) ' ', chronology30);
        boolean boolean33 = dateTime31.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime34 = dateTime31.toLocalDateTime();
        int[] intArray38 = new int[] { '4', (short) 1 };
        try {
            int[] intArray40 = skipDateTimeField11.set((org.joda.time.ReadablePartial) localDateTime34, 0, intArray38, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(localDateTime34);
        org.junit.Assert.assertNotNull(intArray38);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (short) 0, (java.lang.Number) (-28799999L), (java.lang.Number) (-10));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
        org.joda.time.DateTime dateTime7 = dateTime4.plusMillis(0);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMinutes(0);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        mutableDateTime2.addDays(1);
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
        try {
            mutableDateTime2.setTime((int) '#', 2, (int) ' ', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime4.minusSeconds(16);
        org.joda.time.DateTime dateTime15 = dateTime4.minusYears((int) (short) 0);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str8.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendWeekyear((-3), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime4.dayOfMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withOffsetParsed();
        java.lang.String str15 = dateTime4.toString(dateTimeFormatter14);
        java.io.Writer writer16 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant18, readableInstant19);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) ' ', chronology20);
        int int22 = dateTime21.getHourOfDay();
        int int23 = dateTime21.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime25 = dateTime21.minusDays(10);
        org.joda.time.DateTime dateTime27 = dateTime25.minusDays(0);
        try {
            dateTimeFormatter14.printTo(writer16, (org.joda.time.ReadableInstant) dateTime27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str8.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "16:00:00-08:00" + "'", str15.equals("16:00:00-08:00"));
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 16 + "'", int22 == 16);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 0, (org.joda.time.Chronology) gJChronology1, locale2, (java.lang.Integer) 0, 16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        java.util.Locale locale7 = dateTimeFormatter6.getLocale();
        boolean boolean8 = dateTimeParserBucket5.restoreState((java.lang.Object) dateTimeFormatter6);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            dateTimeParserBucket5.saveField(dateTimeFieldType9, 200);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNull(locale7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((int) (short) 100, 0, (int) (short) -1, 0, (int) (byte) 10, (-1), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-1), true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) '#', (int) '4');
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendFractionOfSecond(0, 31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(strMap6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        java.lang.String str15 = skipDateTimeField11.getAsShortText((long) 57600);
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField11.getAsText((-62112150421990L), locale17);
        long long20 = skipDateTimeField11.roundHalfCeiling(960L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "600" + "'", str15.equals("600"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10" + "'", str18.equals("10"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 960L + "'", long20 == 960L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        int int6 = dateTime4.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime8 = dateTime4.minusDays(10);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, readableInstant11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) ' ', chronology12);
        int int14 = dateTime13.getHourOfDay();
        org.joda.time.DateTime dateTime16 = dateTime13.withYear((int) (short) -1);
        java.lang.String str17 = dateTime13.toString();
        int int18 = dateTime13.getEra();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = dateTime13.toDateTime(dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime13.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime22.getZone();
        long long26 = dateTimeZone23.adjustOffset(10L, false);
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime4, dateTimeZone23);
        org.joda.time.Instant instant29 = new org.joda.time.Instant(28800000L);
        org.joda.time.Instant instant32 = instant29.withDurationAdded(0L, 0);
        try {
            org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23, (org.joda.time.ReadableInstant) instant32, (-10));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 16 + "'", int14 == 16);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str17.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
        org.junit.Assert.assertNotNull(instant32);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.appendTimeZoneOffset("1969-12-31T16:00:00.032-08:00", false, 2000, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        org.joda.time.DateTime.Property property8 = dateTime4.hourOfDay();
        org.joda.time.DateTime dateTime9 = property8.withMinimumValue();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("hi!", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("600");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"600\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 0, (org.joda.time.Chronology) gJChronology1, locale2, (java.lang.Integer) 0, 16);
        long long7 = dateTimeParserBucket5.computeMillis(true);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField18);
        java.lang.String str21 = skipDateTimeField19.getAsText((long) (byte) 100);
        dateTimeParserBucket5.saveField((org.joda.time.DateTimeField) skipDateTimeField19, (int) (short) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField19, dateTimeFieldType24);
        org.joda.time.ReadablePartial readablePartial26 = null;
        try {
            int int27 = skipDateTimeField19.getMaximumValue(readablePartial26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112150421990L) + "'", long16 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "100" + "'", str21.equals("100"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        int int10 = dateTime4.getSecondOfMinute();
        boolean boolean11 = dateTime4.isAfterNow();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str8.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        int int7 = dateTime4.getMinuteOfDay();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.DateTime dateTime17 = dateTime4.withChronology((org.joda.time.Chronology) gJChronology8);
        try {
            org.joda.time.DateTime dateTime19 = dateTime17.withCenturyOfEra((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for centuryOfEra must be in the range [1,2922790]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 960 + "'", int7 == 960);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112150421990L) + "'", long16 == (-62112150421990L));
        org.junit.Assert.assertNotNull(dateTime17);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560344728795L + "'", long0 == 1560344728795L);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime4.dayOfMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withOffsetParsed();
        java.lang.String str15 = dateTime4.toString(dateTimeFormatter14);
        java.io.Writer writer16 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant18, readableInstant19);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) ' ', chronology20);
        boolean boolean23 = dateTime21.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime24 = dateTime21.toLocalDateTime();
        boolean boolean26 = dateTime21.isAfter((-99948L));
        org.joda.time.DateTime.Property property27 = dateTime21.secondOfDay();
        java.lang.String str28 = property27.getAsString();
        org.joda.time.DateTime dateTime30 = property27.addWrapFieldToCopy(0);
        int int31 = dateTime30.getWeekyear();
        try {
            dateTimeFormatter14.printTo(writer16, (org.joda.time.ReadableInstant) dateTime30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str8.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "16:00:00-08:00" + "'", str15.equals("16:00:00-08:00"));
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(localDateTime24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "57600" + "'", str28.equals("57600"));
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1970 + "'", int31 == 1970);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        boolean boolean20 = dateTime18.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        int[] intArray23 = julianChronology13.get((org.joda.time.ReadablePartial) localDateTime21, (-62112150421990L));
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) (byte) 0, locale25);
        int int28 = skipDateTimeField11.get(10L);
        int int29 = skipDateTimeField11.getMaximumValue();
        boolean boolean31 = skipDateTimeField11.isLeap((long) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.ReadableInstant readableInstant34 = null;
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.Chronology chronology36 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant34, readableInstant35);
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) ' ', chronology36);
        int int38 = dateTime37.getHourOfDay();
        org.joda.time.DateTime dateTime40 = dateTime37.withYear((int) (short) -1);
        java.lang.String str41 = dateTime37.toString();
        int int42 = dateTime37.getEra();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.DateTime dateTime44 = dateTime37.toDateTime(dateTimeZone43);
        org.joda.time.DateTime.Property property45 = dateTime37.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone32, (org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.DateTime.Property property47 = dateTime37.monthOfYear();
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) ' ', chronology51);
        boolean boolean54 = dateTime52.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime55 = dateTime52.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant57 = null;
        org.joda.time.ReadableInstant readableInstant58 = null;
        org.joda.time.Chronology chronology59 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant57, readableInstant58);
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((long) ' ', chronology59);
        boolean boolean62 = dateTime60.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime63 = dateTime60.toLocalDateTime();
        org.joda.time.DateTime dateTime64 = dateTime52.withFields((org.joda.time.ReadablePartial) localDateTime63);
        int int65 = property47.compareTo((org.joda.time.ReadablePartial) localDateTime63);
        int[] intArray70 = new int[] { 57600, (short) -1, 31, (short) -1 };
        int int71 = skipDateTimeField11.getMinimumValue((org.joda.time.ReadablePartial) localDateTime63, intArray70);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 999 + "'", int29 == 999);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 16 + "'", int38 == 16);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str41.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(gJChronology46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(localDateTime55);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(localDateTime63);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.monthOfYear();
        try {
            mutableDateTime2.setMillisOfSecond((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        mutableDateTime2.addDays(1);
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
        mutableDateTime2.setMillisOfSecond(0);
        mutableDateTime2.setTime((long) (short) 100);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 0, (org.joda.time.Chronology) gJChronology1, locale2, (java.lang.Integer) 0, 16);
        java.lang.Integer int6 = dateTimeParserBucket5.getOffsetInteger();
        java.lang.Integer int7 = dateTimeParserBucket5.getOffsetInteger();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNull(int6);
        org.junit.Assert.assertNull(int7);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) ' ', (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) (byte) 10, 16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendDayOfMonth(97);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMillisOfDay((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket((long) (short) 0, (org.joda.time.Chronology) gJChronology2, locale3, (java.lang.Integer) 0, 16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        java.util.Locale locale8 = dateTimeFormatter7.getLocale();
        boolean boolean9 = dateTimeParserBucket6.restoreState((java.lang.Object) dateTimeFormatter7);
        try {
            org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.parse("12/31/69", dateTimeFormatter7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"12/31/69\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNull(locale8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.addWeeks((int) (byte) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfCentury();
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = property5.set("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("1970001T080000.000Z", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"1970001T080000.000Z/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.halfdayOfDay();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) julianChronology2, locale4);
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology2.getZone();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        org.joda.time.DateTime.Property property8 = dateTime4.centuryOfEra();
        org.joda.time.Interval interval9 = property8.toInterval();
        org.joda.time.ReadableInterval readableInterval10 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval9);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        long long19 = gJChronology11.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        try {
            org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((java.lang.Object) readableInterval10, (org.joda.time.Chronology) gJChronology11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.Interval");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNotNull(readableInterval10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-62112150421990L) + "'", long19 == (-62112150421990L));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("57600", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"57600/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        org.joda.time.DateTime.Property property8 = dateTime4.centuryOfEra();
        org.joda.time.Interval interval9 = property8.toInterval();
        java.lang.String str10 = property8.getName();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "centuryOfEra" + "'", str10.equals("centuryOfEra"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField14 = new org.joda.time.field.DividedDateTimeField(dateTimeField10, dateTimeFieldType12, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.monthOfYear();
        mutableDateTime2.setDayOfYear((int) 'a');
        org.joda.time.MutableDateTime mutableDateTime8 = mutableDateTime2.toMutableDateTime();
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "100");
        org.joda.time.IllegalFieldValueException illegalFieldValueException5 = new org.joda.time.IllegalFieldValueException("hi!", "100");
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException5.getDateTimeFieldType();
        org.joda.time.DurationFieldType durationFieldType7 = illegalFieldValueException5.getDurationFieldType();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException5);
        org.junit.Assert.assertNull(dateTimeFieldType6);
        org.junit.Assert.assertNull(durationFieldType7);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, (-10));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 0, (int) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        boolean boolean2 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology1.hourOfHalfday();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("DateTimeField[millisOfSecond]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"DateTimeField[millisOfSecond]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.addWeeks((int) (byte) 0);
        mutableDateTime2.addWeekyears(3);
        mutableDateTime2.addWeekyears((-1));
        int int9 = mutableDateTime2.getMonthOfYear();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        boolean boolean9 = dateTime4.isAfter((-99948L));
        org.joda.time.DateTime.Property property10 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime12 = dateTime4.withMonthOfYear(1);
        try {
            org.joda.time.DateTime dateTime14 = dateTime4.withEra((-10));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 0, (org.joda.time.Chronology) gJChronology1, locale2, (java.lang.Integer) 0, 16);
        long long7 = dateTimeParserBucket5.computeMillis(true);
        org.joda.time.Chronology chronology8 = dateTimeParserBucket5.getChronology();
        long long10 = dateTimeParserBucket5.computeMillis(false);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            dateTimeParserBucket5.saveField(dateTimeFieldType11, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800000L + "'", long10 == 28800000L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) ' ', (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendDayOfWeek(1969);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.era();
        java.lang.String str6 = property5.getName();
        int int7 = property5.getMaximumValue();
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "era" + "'", str6.equals("era"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.monthOfYear();
        java.util.Locale locale11 = null;
        try {
            org.joda.time.DateTime dateTime12 = property9.setCopy("100", locale11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"100\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) '#', (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(16, true);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendFraction(dateTimeFieldType7, 1969, (-10));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.monthOfYear();
        mutableDateTime2.setDayOfYear((int) 'a');
        int int8 = mutableDateTime2.getDayOfYear();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, readableInstant11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) ' ', chronology12);
        int int14 = dateTime13.getHourOfDay();
        int int15 = dateTime13.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime17 = dateTime13.minusDays(10);
        org.joda.time.DateTime dateTime19 = dateTime17.minusDays(0);
        org.joda.time.DateTime dateTime21 = dateTime19.withYear(31);
        mutableDateTime2.setTime((org.joda.time.ReadableInstant) dateTime21);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 16 + "'", int14 == 16);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(1560344728795L, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) ' ', chronology5);
        boolean boolean8 = dateTime6.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime9 = dateTime6.toLocalDateTime();
        boolean boolean11 = dateTime6.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) ' ', chronology15);
        int int17 = dateTime16.getHourOfDay();
        org.joda.time.DateTime dateTime19 = dateTime16.withYear((int) (short) -1);
        java.lang.String str20 = dateTime16.toString();
        int int21 = dateTime16.getEra();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime16.toDateTime(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime16.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone26 = dateTime25.getZone();
        org.joda.time.DateTime dateTime27 = dateTime6.toDateTime(dateTimeZone26);
        org.joda.time.Chronology chronology28 = julianChronology1.withZone(dateTimeZone26);
        org.joda.time.DurationField durationField29 = julianChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology1.millisOfDay();
        org.joda.time.Chronology chronology31 = julianChronology1.withUTC();
        try {
            long long39 = julianChronology1.getDateTimeMillis(2, 10, 4, 10, 999, (-1), (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 999 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str20.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(chronology31);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.monthOfYear();
        mutableDateTime2.setDayOfYear((int) 'a');
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        long long12 = gJChronology8.add(readablePeriod9, (-99948L), 10);
        org.joda.time.DateTime dateTime13 = mutableDateTime2.toDateTime((org.joda.time.Chronology) gJChronology8);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime2.minuteOfHour();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime2.weekOfWeekyear();
        try {
            mutableDateTime2.setWeekOfWeekyear((-3));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -3 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-99948L) + "'", long12 == (-99948L));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(28800000L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((-1), 0, 999, 1, 100, (int) (short) -1, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant6, readableInstant7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) ' ', chronology8);
        int int10 = dateTime9.getHourOfDay();
        org.joda.time.DateTime dateTime12 = dateTime9.withYear((int) (short) -1);
        boolean boolean13 = mutableDateTime2.isEqual((org.joda.time.ReadableInstant) dateTime12);
        try {
            org.joda.time.DateTime dateTime15 = dateTime12.withWeekOfWeekyear((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 16 + "'", int10 == 16);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime9 = property7.add((long) (-3));
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) ' ', chronology13);
        int int15 = dateTime14.getHourOfDay();
        org.joda.time.DateTime dateTime17 = dateTime14.withYear((int) (short) -1);
        java.lang.String str18 = dateTime14.toString();
        int int19 = dateTime14.getEra();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime14.toDateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime14.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone24 = dateTime23.getZone();
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant26, readableInstant27);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) ' ', chronology28);
        boolean boolean31 = dateTime29.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime32 = dateTime29.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant34 = null;
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.Chronology chronology36 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant34, readableInstant35);
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) ' ', chronology36);
        boolean boolean39 = dateTime37.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime40 = dateTime37.toLocalDateTime();
        org.joda.time.DateTime dateTime41 = dateTime29.withFields((org.joda.time.ReadablePartial) localDateTime40);
        boolean boolean42 = dateTimeZone24.isLocalDateTimeGap(localDateTime40);
        org.joda.time.MutableDateTime mutableDateTime43 = mutableDateTime9.toMutableDateTime(dateTimeZone24);
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
        try {
            org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(4, (int) (byte) 0, (int) (short) 100, 3, 0, 200, dateTimeZone24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 200 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str18.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(localDateTime32);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(mutableDateTime43);
        org.junit.Assert.assertNotNull(gJChronology44);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        boolean boolean9 = dateTime4.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) ' ', chronology13);
        int int15 = dateTime14.getHourOfDay();
        org.joda.time.DateTime dateTime17 = dateTime14.withYear((int) (short) -1);
        java.lang.String str18 = dateTime14.toString();
        int int19 = dateTime14.getEra();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime14.toDateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime14.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone24 = dateTime23.getZone();
        org.joda.time.DateTime dateTime25 = dateTime4.toDateTime(dateTimeZone24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime27 = dateTime4.plus(readablePeriod26);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone29);
        mutableDateTime30.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property33 = mutableDateTime30.era();
        org.joda.time.MutableDateTime.Property property34 = mutableDateTime30.monthOfYear();
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        mutableDateTime30.add(readablePeriod35);
        boolean boolean37 = dateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime30);
        try {
            mutableDateTime30.setHourOfDay(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str18.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMinuteOfDay((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', chronology4);
        int int6 = dateTime5.getHourOfDay();
        int int7 = dateTime5.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime5.minusDays(10);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) ' ', chronology13);
        int int15 = dateTime14.getHourOfDay();
        org.joda.time.DateTime dateTime17 = dateTime14.withYear((int) (short) -1);
        java.lang.String str18 = dateTime14.toString();
        int int19 = dateTime14.getEra();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime14.toDateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime14.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone24 = dateTime23.getZone();
        long long27 = dateTimeZone24.adjustOffset(10L, false);
        org.joda.time.MutableDateTime mutableDateTime28 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime5, dateTimeZone24);
        org.joda.time.Chronology chronology29 = buddhistChronology0.withZone(dateTimeZone24);
        java.lang.String str30 = dateTimeZone24.getID();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str18.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "America/Los_Angeles" + "'", str30.equals("America/Los_Angeles"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.monthOfYear();
        mutableDateTime2.setDayOfYear((int) 'a');
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        long long12 = gJChronology8.add(readablePeriod9, (-99948L), 10);
        org.joda.time.DateTime dateTime13 = mutableDateTime2.toDateTime((org.joda.time.Chronology) gJChronology8);
        int int14 = mutableDateTime2.getRoundingMode();
        mutableDateTime2.addHours((int) (short) 0);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-99948L) + "'", long12 == (-99948L));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) 19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) ' ', chronology6);
        boolean boolean9 = dateTime7.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime10 = dateTime7.toLocalDateTime();
        boolean boolean12 = dateTime7.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant14, readableInstant15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) ' ', chronology16);
        int int18 = dateTime17.getHourOfDay();
        org.joda.time.DateTime dateTime20 = dateTime17.withYear((int) (short) -1);
        java.lang.String str21 = dateTime17.toString();
        int int22 = dateTime17.getEra();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = dateTime17.toDateTime(dateTimeZone23);
        org.joda.time.DateTime dateTime26 = dateTime17.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone27 = dateTime26.getZone();
        org.joda.time.DateTime dateTime28 = dateTime7.toDateTime(dateTimeZone27);
        org.joda.time.Chronology chronology29 = julianChronology2.withZone(dateTimeZone27);
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime(0L, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeField dateTimeField31 = julianChronology2.halfdayOfDay();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 16 + "'", int18 == 16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str21.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTimeField31);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("32");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style character: 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, readableInstant11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) ' ', chronology12);
        int int14 = dateTime13.getHourOfDay();
        org.joda.time.DateTime dateTime16 = dateTime13.withYear((int) (short) -1);
        java.lang.String str17 = dateTime13.toString();
        int int18 = dateTime13.getEra();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = dateTime13.toDateTime(dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime13.minusMillis(999);
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.DateTime dateTime24 = dateTime13.plus(readableDuration23);
        boolean boolean25 = dateTime8.isEqual((org.joda.time.ReadableInstant) dateTime13);
        int int26 = dateTime8.getMillisOfDay();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 16 + "'", int14 == 16);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str17.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 57600032 + "'", int26 == 57600032);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.monthOfYear();
        java.util.Locale locale7 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime8 = property5.set("33", locale7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"33\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.millisOfSecond();
        org.joda.time.DateTime dateTime10 = property9.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime11 = dateTime10.toDateTimeISO();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        boolean boolean9 = dateTime4.isAfter((-99948L));
        org.joda.time.DateTime.Property property10 = dateTime4.secondOfDay();
        long long11 = property10.remainder();
        java.lang.String str12 = property10.getAsShortText();
        org.joda.time.DateTime dateTime14 = property10.addToCopy(19);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32L + "'", long11 == 32L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "57600" + "'", str12.equals("57600"));
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        long long15 = gJChronology7.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology7, dateTimeField17);
        org.joda.time.DateTimeField dateTimeField19 = gJChronology7.minuteOfDay();
        try {
            org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((int) (short) 0, 0, 0, (int) (short) 1, (int) (short) 1, 57600, 57600032, (org.joda.time.Chronology) gJChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62112150421990L) + "'", long15 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', chronology4);
        int int6 = dateTime5.getHourOfDay();
        org.joda.time.DateTime dateTime8 = dateTime5.withYear((int) (short) -1);
        java.lang.String str9 = dateTime5.toString();
        int int10 = dateTime5.getEra();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime5.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime.Property property15 = dateTime5.monthOfYear();
        org.joda.time.DateTime dateTime17 = property15.addToCopy(10);
        java.util.Locale locale18 = null;
        int int19 = property15.getMaximumShortTextLength(locale18);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str9.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(9, (int) 'a', 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.monthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Instant instant8 = new org.joda.time.Instant(28800000L);
        org.joda.time.Instant instant11 = instant8.withDurationAdded(0L, 0);
        boolean boolean12 = buddhistChronology6.equals((java.lang.Object) 0L);
        org.joda.time.MutableDateTime mutableDateTime13 = mutableDateTime2.toMutableDateTime((org.joda.time.Chronology) buddhistChronology6);
        mutableDateTime13.setYear(57600);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(mutableDateTime13);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        boolean boolean20 = dateTime18.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        int[] intArray23 = julianChronology13.get((org.joda.time.ReadablePartial) localDateTime21, (-62112150421990L));
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) (byte) 0, locale25);
        long long28 = skipDateTimeField11.remainder((long) 2);
        org.joda.time.ReadablePartial readablePartial29 = null;
        int[] intArray31 = null;
        java.util.Locale locale33 = null;
        try {
            int[] intArray34 = skipDateTimeField11.set(readablePartial29, (int) '#', intArray31, "0", locale33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        org.joda.time.DateTime dateTime11 = dateTime4.plusMillis(200);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str8.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.lang.Number number2 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (-3198336L), number2, (java.lang.Number) (byte) 10);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1L, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DurationField durationField2 = gJChronology0.weekyears();
        long long5 = durationField2.subtract((long) 1970, (int) '#');
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField7 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1104364798030L) + "'", long5 == (-1104364798030L));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((-3198336L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440587L + "'", long1 == 2440587L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(28800000L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28800000 + "'", int1 == 28800000);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.secondOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        mutableDateTime2.add(readableDuration4);
        int int6 = mutableDateTime2.getDayOfYear();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 365 + "'", int6 == 365);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        boolean boolean9 = dateTime4.isAfter((-99948L));
        org.joda.time.DateTime.Property property10 = dateTime4.secondOfDay();
        long long11 = property10.remainder();
        java.lang.String str12 = property10.getAsShortText();
        org.joda.time.Interval interval13 = property10.toInterval();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32L + "'", long11 == 32L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "57600" + "'", str12.equals("57600"));
        org.junit.Assert.assertNotNull(interval13);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("32");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '32' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("DateTimeField[millisOfSecond]");
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("JulianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'JulianChronology[America/Los_Angeles]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology7.hourOfDay();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) (short) 10, 10, 19, (int) (byte) 10, 2, (int) (short) 1, (int) (short) -1, (org.joda.time.Chronology) gJChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        try {
            int[] intArray15 = gJChronology0.get(readablePeriod12, 0L, (long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.addWeeks((int) (byte) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfCentury();
        org.joda.time.MutableDateTime mutableDateTime6 = property5.roundCeiling();
        mutableDateTime6.addDays((int) 'a');
        try {
            mutableDateTime6.setMonthOfYear(1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, readableInstant6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) ' ', chronology7);
        boolean boolean10 = dateTime8.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime11 = dateTime8.toLocalDateTime();
        boolean boolean13 = dateTime8.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        int int19 = dateTime18.getHourOfDay();
        org.joda.time.DateTime dateTime21 = dateTime18.withYear((int) (short) -1);
        java.lang.String str22 = dateTime18.toString();
        int int23 = dateTime18.getEra();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime18.toDateTime(dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime18.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone28 = dateTime27.getZone();
        org.joda.time.DateTime dateTime29 = dateTime8.toDateTime(dateTimeZone28);
        org.joda.time.Chronology chronology30 = julianChronology3.withZone(dateTimeZone28);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter0.withChronology(chronology30);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter31.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(localDateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 16 + "'", int19 == 16);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str22.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) '#', (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(16, true);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendMonthOfYear((-10));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        int int19 = dateTime18.getHourOfDay();
        org.joda.time.DateTime dateTime21 = dateTime18.withYear((int) (short) -1);
        java.lang.String str22 = dateTime18.toString();
        int int23 = dateTime18.getEra();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime18.toDateTime(dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime18.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone28 = dateTime27.getZone();
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant30, readableInstant31);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) ' ', chronology32);
        boolean boolean35 = dateTime33.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime36 = dateTime33.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.Chronology chronology40 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant38, readableInstant39);
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) ' ', chronology40);
        boolean boolean43 = dateTime41.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime44 = dateTime41.toLocalDateTime();
        org.joda.time.DateTime dateTime45 = dateTime33.withFields((org.joda.time.ReadablePartial) localDateTime44);
        boolean boolean46 = dateTimeZone28.isLocalDateTimeGap(localDateTime44);
        java.util.Locale locale47 = null;
        java.lang.String str48 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime44, locale47);
        java.util.Locale locale50 = null;
        java.lang.String str51 = skipDateTimeField11.getAsText(9, locale50);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 16 + "'", int19 == 16);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str22.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(localDateTime36);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(localDateTime44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "32" + "'", str48.equals("32"));
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "9" + "'", str51.equals("9"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        int int6 = dateTime4.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime4.secondOfDay();
        try {
            org.joda.time.DateTime dateTime9 = dateTime4.withEra(4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.era();
        java.lang.String str6 = property5.getName();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.roundHalfFloor();
        try {
            org.joda.time.MutableDateTime mutableDateTime9 = property5.set("10");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"10\" for era is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "era" + "'", str6.equals("era"));
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (short) 1, (long) 999);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-998L) + "'", long2 == (-998L));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("1970001T080000.000Z", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(dateTimeZone10);
        try {
            org.joda.time.DateTime dateTime13 = dateTime4.withMonthOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str8.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
        org.joda.time.DateTime dateTime7 = dateTime4.withMillisOfDay((int) (byte) 100);
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.addWeeks((int) (byte) 0);
        org.joda.time.DateTime dateTime5 = mutableDateTime2.toDateTimeISO();
        boolean boolean6 = dateTime5.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType2);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology0.clockhourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, dateTimeFieldType14, 999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("1970001T080000.000Z", 2169, (int) (short) 10, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2169 for 1970001T080000.000Z must be in the range [10,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        boolean boolean6 = dateTimeFormatterBuilder3.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("33", "");
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (byte) 10, "12/31/69");
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gJChronology0.add(readablePeriod1, (-99948L), 10);
        org.joda.time.DurationField durationField5 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology0.minuteOfDay();
        try {
            long long13 = gJChronology0.getDateTimeMillis(1, (int) (short) 100, 97, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-99948L) + "'", long4 == (-99948L));
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        boolean boolean20 = dateTime18.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        int[] intArray23 = julianChronology13.get((org.joda.time.ReadablePartial) localDateTime21, (-62112150421990L));
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) (byte) 0, locale25);
        int int28 = skipDateTimeField11.get(10L);
        int int29 = skipDateTimeField11.getMaximumValue();
        boolean boolean31 = skipDateTimeField11.isLeap((long) (byte) 0);
        long long33 = skipDateTimeField11.roundFloor((long) (byte) -1);
        int int35 = skipDateTimeField11.getMaximumValue((long) 12);
        try {
            long long38 = skipDateTimeField11.set((long) 97, "16:00:00-08:00");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"16:00:00-08:00\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 999 + "'", int29 == 999);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1L) + "'", long33 == (-1L));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 999 + "'", int35 == 999);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        mutableDateTime2.addDays(1);
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
        try {
            mutableDateTime2.setTime(1970, (int) (byte) 1, 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("era");
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', chronology4);
        int int6 = dateTime5.getHourOfDay();
        org.joda.time.DateTime dateTime8 = dateTime5.withYear((int) (short) -1);
        java.lang.String str9 = dateTime5.toString();
        int int10 = dateTime5.getEra();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime5.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime.Property property15 = dateTime5.monthOfYear();
        java.util.Locale locale16 = null;
        int int17 = property15.getMaximumTextLength(locale16);
        int int18 = property15.getMaximumValueOverall();
        java.lang.String str19 = property15.getAsString();
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str9.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "12" + "'", str19.equals("12"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = gJChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 0, (org.joda.time.Chronology) gJChronology1, locale2, (java.lang.Integer) 0, 16);
        long long7 = dateTimeParserBucket5.computeMillis(true);
        dateTimeParserBucket5.setPivotYear((java.lang.Integer) 9);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("0", (java.lang.Number) (-3198991L), (java.lang.Number) (-998L), (java.lang.Number) (-3));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        boolean boolean9 = dateTime4.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) ' ', chronology13);
        int int15 = dateTime14.getHourOfDay();
        org.joda.time.DateTime dateTime17 = dateTime14.withYear((int) (short) -1);
        java.lang.String str18 = dateTime14.toString();
        int int19 = dateTime14.getEra();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime14.toDateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime14.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone24 = dateTime23.getZone();
        org.joda.time.DateTime dateTime25 = dateTime4.toDateTime(dateTimeZone24);
        java.lang.String str26 = dateTimeZone24.getID();
        java.lang.String str27 = dateTimeZone24.getID();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str18.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "America/Los_Angeles" + "'", str26.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "America/Los_Angeles" + "'", str27.equals("America/Los_Angeles"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        boolean boolean9 = dateTime4.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) ' ', chronology13);
        int int15 = dateTime14.getHourOfDay();
        org.joda.time.DateTime dateTime17 = dateTime14.withYear((int) (short) -1);
        java.lang.String str18 = dateTime14.toString();
        int int19 = dateTime14.getEra();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime14.toDateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime14.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone24 = dateTime23.getZone();
        org.joda.time.DateTime dateTime25 = dateTime4.toDateTime(dateTimeZone24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime27 = dateTime4.plus(readablePeriod26);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone29);
        mutableDateTime30.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property33 = mutableDateTime30.era();
        org.joda.time.MutableDateTime.Property property34 = mutableDateTime30.monthOfYear();
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        mutableDateTime30.add(readablePeriod35);
        boolean boolean37 = dateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime30);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = null;
        try {
            int int39 = mutableDateTime30.get(dateTimeFieldType38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str18.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendSecondOfDay((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfMinute((int) '#', (int) '4');
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatterBuilder7.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.appendOptional(dateTimeParser11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter3, dateTimeParser11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder14.appendFractionOfMinute((int) '#', (int) '4');
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatterBuilder14.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter3, dateTimeParser18);
        try {
            long long21 = dateTimeFormatter19.parseMillis("16:00:00-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"16:00:00-08:00\" is malformed at \":00:00-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gJChronology0.add(readablePeriod1, (-99948L), 10);
        org.joda.time.DurationField durationField5 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology0.weekOfWeekyear();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField9 = gJChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-99948L) + "'", long4 == (-99948L));
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(31L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        try {
            long long2 = dateTimeFormatter0.parseMillis("1969-12-31T16:00:00.032-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-31T16:00:00.032-08:00\" is malformed at \"69-12-31T16:00:00.032-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        java.lang.String str14 = skipDateTimeField11.toString();
        long long17 = skipDateTimeField11.add((long) (byte) 1, 32L);
        java.lang.String str18 = skipDateTimeField11.getName();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str14.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 33L + "'", long17 == 33L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "millisOfSecond" + "'", str18.equals("millisOfSecond"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("", "era", (int) (short) -1, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone13);
        try {
            long long22 = zonedChronology14.getDateTimeMillis(16, (int) (short) 100, (int) (byte) 0, 960, 28800000, (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(zonedChronology14);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 31, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 31L + "'", long2 == 31L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        int int6 = dateTime4.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime8 = dateTime4.minusDays(10);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, readableInstant11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) ' ', chronology12);
        int int14 = dateTime13.getHourOfDay();
        org.joda.time.DateTime dateTime16 = dateTime13.withYear((int) (short) -1);
        java.lang.String str17 = dateTime13.toString();
        int int18 = dateTime13.getEra();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = dateTime13.toDateTime(dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime13.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime22.getZone();
        long long26 = dateTimeZone23.adjustOffset(10L, false);
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime4, dateTimeZone23);
        try {
            mutableDateTime27.setDate(97, 2, 57600032);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600032 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 16 + "'", int14 == 16);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str17.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) ' ', chronology5);
        boolean boolean8 = dateTime6.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime9 = dateTime6.toLocalDateTime();
        boolean boolean11 = dateTime6.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) ' ', chronology15);
        int int17 = dateTime16.getHourOfDay();
        org.joda.time.DateTime dateTime19 = dateTime16.withYear((int) (short) -1);
        java.lang.String str20 = dateTime16.toString();
        int int21 = dateTime16.getEra();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime16.toDateTime(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime16.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone26 = dateTime25.getZone();
        org.joda.time.DateTime dateTime27 = dateTime6.toDateTime(dateTimeZone26);
        org.joda.time.Chronology chronology28 = julianChronology1.withZone(dateTimeZone26);
        org.joda.time.DurationField durationField29 = julianChronology1.seconds();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance();
        long long39 = gJChronology31.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField42 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology31, dateTimeField41);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone43);
        org.joda.time.ReadableInstant readableInstant46 = null;
        org.joda.time.ReadableInstant readableInstant47 = null;
        org.joda.time.Chronology chronology48 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant46, readableInstant47);
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((long) ' ', chronology48);
        boolean boolean51 = dateTime49.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime52 = dateTime49.toLocalDateTime();
        int[] intArray54 = julianChronology44.get((org.joda.time.ReadablePartial) localDateTime52, (-62112150421990L));
        java.util.Locale locale56 = null;
        java.lang.String str57 = skipDateTimeField42.getAsShortText((org.joda.time.ReadablePartial) localDateTime52, (int) (byte) 0, locale56);
        java.lang.String str58 = dateTimeFormatter30.print((org.joda.time.ReadablePartial) localDateTime52);
        int[] intArray63 = new int[] { 2000, 999, 3, 'a' };
        try {
            julianChronology1.validate((org.joda.time.ReadablePartial) localDateTime52, intArray63);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 999 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str20.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-62112150421990L) + "'", long39 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(localDateTime52);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "0" + "'", str57.equals("0"));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "12/31/69" + "'", str58.equals("12/31/69"));
        org.junit.Assert.assertNotNull(intArray63);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) ' ', chronology5);
        boolean boolean8 = dateTime6.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime9 = dateTime6.toLocalDateTime();
        boolean boolean11 = dateTime6.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) ' ', chronology15);
        int int17 = dateTime16.getHourOfDay();
        org.joda.time.DateTime dateTime19 = dateTime16.withYear((int) (short) -1);
        java.lang.String str20 = dateTime16.toString();
        int int21 = dateTime16.getEra();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime16.toDateTime(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime16.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone26 = dateTime25.getZone();
        org.joda.time.DateTime dateTime27 = dateTime6.toDateTime(dateTimeZone26);
        org.joda.time.Chronology chronology28 = julianChronology1.withZone(dateTimeZone26);
        org.joda.time.DurationField durationField29 = julianChronology1.seconds();
        org.joda.time.DurationField durationField30 = julianChronology1.centuries();
        org.joda.time.DateTimeField dateTimeField31 = julianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField32 = julianChronology1.dayOfWeek();
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        long long36 = julianChronology1.add(readablePeriod33, (long) 2169, (int) (byte) 10);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str20.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2169L + "'", long36 == 2169L);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        long long14 = skipDateTimeField11.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
        long long23 = gJChronology15.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology24.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology15, dateTimeField25);
        long long29 = skipDateTimeField26.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = skipDateTimeField26.getType();
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField31 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1960L) + "'", long14 == (-1960L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62112150421990L) + "'", long23 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1960L) + "'", long29 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(1969);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DurationField durationField2 = gJChronology0.weekyears();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        int int6 = dateTime4.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime8 = dateTime4.minusDays(10);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, readableInstant11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) ' ', chronology12);
        int int14 = dateTime13.getHourOfDay();
        org.joda.time.DateTime dateTime16 = dateTime13.withYear((int) (short) -1);
        java.lang.String str17 = dateTime13.toString();
        int int18 = dateTime13.getEra();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = dateTime13.toDateTime(dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime13.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime22.getZone();
        long long26 = dateTimeZone23.adjustOffset(10L, false);
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime4, dateTimeZone23);
        org.joda.time.DateTime dateTime29 = dateTime4.withYearOfCentury(0);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 16 + "'", int14 == 16);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str17.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.addWeeks((int) (byte) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfCentury();
        mutableDateTime2.setMinuteOfDay(10);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        boolean boolean9 = dateTime4.isAfter((-99948L));
        org.joda.time.DateTime.Property property10 = dateTime4.secondOfDay();
        long long11 = property10.remainder();
        org.joda.time.DateTimeField dateTimeField12 = property10.getField();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32L + "'", long11 == 32L);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.monthOfYear();
        mutableDateTime2.setDayOfYear((int) 'a');
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        long long12 = gJChronology8.add(readablePeriod9, (-99948L), 10);
        org.joda.time.DateTime dateTime13 = mutableDateTime2.toDateTime((org.joda.time.Chronology) gJChronology8);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime2.minuteOfHour();
        try {
            mutableDateTime2.setDate(2000, (int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-99948L) + "'", long12 == (-99948L));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.halfdayOfDay();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) julianChronology2, locale4);
        long long7 = dateTimeParserBucket5.computeMillis(true);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800100L + "'", long7 == 28800100L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        int int6 = dateTime4.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime8 = dateTime4.minusDays(10);
        org.joda.time.DateTime dateTime10 = dateTime8.minusDays(0);
        org.joda.time.DateTime dateTime12 = dateTime10.withYear(31);
        org.joda.time.DateTime dateTime13 = dateTime12.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(0, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        long long14 = skipDateTimeField11.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipDateTimeField11.getType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType15, 2169, 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2169 for millisOfSecond must be in the range [0,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1960L) + "'", long14 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        boolean boolean20 = dateTime18.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        int[] intArray23 = julianChronology13.get((org.joda.time.ReadablePartial) localDateTime21, (-62112150421990L));
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) (byte) 0, locale25);
        int int28 = skipDateTimeField11.get(10L);
        long long31 = skipDateTimeField11.add(33L, (long) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.ReadableInstant readableInstant34 = null;
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.Chronology chronology36 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant34, readableInstant35);
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) ' ', chronology36);
        int int38 = dateTime37.getHourOfDay();
        org.joda.time.DateTime dateTime40 = dateTime37.withYear((int) (short) -1);
        java.lang.String str41 = dateTime37.toString();
        int int42 = dateTime37.getEra();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.DateTime dateTime44 = dateTime37.toDateTime(dateTimeZone43);
        org.joda.time.DateTime.Property property45 = dateTime37.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone32, (org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.DateTime.Property property47 = dateTime37.monthOfYear();
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) ' ', chronology51);
        boolean boolean54 = dateTime52.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime55 = dateTime52.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant57 = null;
        org.joda.time.ReadableInstant readableInstant58 = null;
        org.joda.time.Chronology chronology59 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant57, readableInstant58);
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((long) ' ', chronology59);
        boolean boolean62 = dateTime60.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime63 = dateTime60.toLocalDateTime();
        org.joda.time.DateTime dateTime64 = dateTime52.withFields((org.joda.time.ReadablePartial) localDateTime63);
        int int65 = property47.compareTo((org.joda.time.ReadablePartial) localDateTime63);
        java.util.Locale locale67 = null;
        java.lang.String str68 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime63, 12, locale67);
        boolean boolean69 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime63);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 43L + "'", long31 == 43L);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 16 + "'", int38 == 16);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str41.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(gJChronology46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(localDateTime55);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(localDateTime63);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "12" + "'", str68.equals("12"));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) ' ', chronology5);
        boolean boolean8 = dateTime6.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime9 = dateTime6.toLocalDateTime();
        boolean boolean11 = dateTime6.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) ' ', chronology15);
        int int17 = dateTime16.getHourOfDay();
        org.joda.time.DateTime dateTime19 = dateTime16.withYear((int) (short) -1);
        java.lang.String str20 = dateTime16.toString();
        int int21 = dateTime16.getEra();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime16.toDateTime(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime16.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone26 = dateTime25.getZone();
        org.joda.time.DateTime dateTime27 = dateTime6.toDateTime(dateTimeZone26);
        org.joda.time.Chronology chronology28 = julianChronology1.withZone(dateTimeZone26);
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now(dateTimeZone26);
        java.lang.String str30 = dateTimeZone26.toString();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str20.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "America/Los_Angeles" + "'", str30.equals("America/Los_Angeles"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        java.io.Writer writer2 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) ' ', chronology6);
        boolean boolean9 = dateTime7.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime10 = dateTime7.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) ' ', chronology14);
        boolean boolean17 = dateTime15.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime18 = dateTime15.toLocalDateTime();
        org.joda.time.DateTime dateTime19 = dateTime7.withFields((org.joda.time.ReadablePartial) localDateTime18);
        org.joda.time.DateTime.Property property20 = dateTime19.hourOfDay();
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadableInstant) dateTime19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(localDateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        long long11 = gJChronology3.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "era", (int) (short) -1, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology3, (org.joda.time.DateTimeZone) fixedDateTimeZone16);
        try {
            org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((java.lang.Object) dateTimeField2, (org.joda.time.DateTimeZone) fixedDateTimeZone16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62112150421990L) + "'", long11 == (-62112150421990L));
        org.junit.Assert.assertNotNull(zonedChronology17);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendYearOfCentury(960, 16);
        boolean boolean11 = dateTimeFormatterBuilder10.canBuildFormatter();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendYearOfEra(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 0, (org.joda.time.Chronology) gJChronology1, locale2, (java.lang.Integer) 0, 16);
        long long7 = dateTimeParserBucket5.computeMillis(true);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) ' ', chronology11);
        int int13 = dateTime12.getHourOfDay();
        int int14 = dateTime12.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime16 = dateTime12.minusDays(10);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant18, readableInstant19);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) ' ', chronology20);
        int int22 = dateTime21.getHourOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withYear((int) (short) -1);
        java.lang.String str25 = dateTime21.toString();
        int int26 = dateTime21.getEra();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = dateTime21.toDateTime(dateTimeZone27);
        org.joda.time.DateTime dateTime30 = dateTime21.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone31 = dateTime30.getZone();
        long long34 = dateTimeZone31.adjustOffset(10L, false);
        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime12, dateTimeZone31);
        dateTimeParserBucket5.setZone(dateTimeZone31);
        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance();
        long long45 = gJChronology37.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField47 = gJChronology46.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField48 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology37, dateTimeField47);
        org.joda.time.DateTimeField dateTimeField49 = gJChronology37.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField50 = gJChronology37.clockhourOfDay();
        dateTimeParserBucket5.saveField(dateTimeField50, 1970);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 16 + "'", int13 == 16);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 16 + "'", int22 == 16);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str25.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertNotNull(gJChronology37);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-62112150421990L) + "'", long45 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeField50);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime4.minuteOfHour();
        java.util.Locale locale13 = null;
        int int14 = property12.getMaximumShortTextLength(locale13);
        org.joda.time.DateTime dateTime15 = property12.roundCeilingCopy();
        try {
            org.joda.time.DateTime dateTime17 = property12.setCopy((-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str8.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        java.io.Writer writer1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        long long10 = gJChronology2.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant17, readableInstant18);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) ' ', chronology19);
        boolean boolean22 = dateTime20.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime23 = dateTime20.toLocalDateTime();
        int[] intArray25 = julianChronology15.get((org.joda.time.ReadablePartial) localDateTime23, (-62112150421990L));
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipDateTimeField13.getAsShortText((org.joda.time.ReadablePartial) localDateTime23, (int) (byte) 0, locale27);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDateTime23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62112150421990L) + "'", long10 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(localDateTime23);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0" + "'", str28.equals("0"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "era", (int) (short) -1, (int) '#');
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long7 = cachedDateTimeZone5.previousTransition((-1104364798030L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1104364798030L) + "'", long7 == (-1104364798030L));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        boolean boolean20 = dateTime18.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        int[] intArray23 = julianChronology13.get((org.joda.time.ReadablePartial) localDateTime21, (-62112150421990L));
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) (byte) 0, locale25);
        int int28 = skipDateTimeField11.get(10L);
        int int29 = skipDateTimeField11.getMaximumValue();
        boolean boolean31 = skipDateTimeField11.isLeap((long) (byte) 0);
        long long33 = skipDateTimeField11.roundFloor((long) (byte) -1);
        int int35 = skipDateTimeField11.getMaximumValue((long) 12);
        java.lang.String str36 = skipDateTimeField11.getName();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 999 + "'", int29 == 999);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1L) + "'", long33 == (-1L));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 999 + "'", int35 == 999);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "millisOfSecond" + "'", str36.equals("millisOfSecond"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        try {
            org.joda.time.DateTime dateTime12 = dateTime8.withDate(0, (-28800000), 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (short) -1);
        try {
            org.joda.time.LocalDateTime localDateTime4 = dateTimeFormatter2.parseLocalDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(0L, dateTimeZone2);
        try {
            org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 9");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("57600", (java.lang.Number) 57600, (java.lang.Number) 28800000L, (java.lang.Number) 97);
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.era();
        java.lang.String str6 = property5.getName();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.getMutableDateTime();
        java.lang.String str8 = property5.getName();
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "era" + "'", str6.equals("era"));
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "era" + "'", str8.equals("era"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime.Property property6 = dateTime4.dayOfMonth();
        try {
            org.joda.time.DateTime dateTime8 = dateTime4.withMillisOfSecond((-3));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -3 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        long long14 = skipDateTimeField11.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipDateTimeField11.getType();
        int int17 = skipDateTimeField11.getLeapAmount(0L);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = gJChronology18.add(readablePeriod19, (-99948L), 10);
        org.joda.time.DurationField durationField23 = gJChronology18.millis();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology18.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology18.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology18.minuteOfDay();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder27 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone30 = dateTimeZoneBuilder27.toDateTimeZone("12/31/69", false);
        org.joda.time.Chronology chronology31 = gJChronology18.withZone(dateTimeZone30);
        try {
            org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((java.lang.Object) skipDateTimeField11, (org.joda.time.Chronology) gJChronology18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.field.SkipDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1960L) + "'", long14 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-99948L) + "'", long22 == (-99948L));
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(chronology31);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.millisOfSecond();
        org.joda.time.DateTime dateTime10 = property9.roundHalfEvenCopy();
        java.lang.String str11 = property9.toString();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Property[millisOfSecond]" + "'", str11.equals("Property[millisOfSecond]"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        int int6 = dateTime4.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime8 = dateTime4.minusWeeks(0);
        org.joda.time.DateTime dateTime10 = dateTime4.plusSeconds(2000);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone4);
        mutableDateTime5.setTime((long) (short) 0);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) ' ', chronology11);
        int int13 = dateTime12.getHourOfDay();
        org.joda.time.DateTime dateTime15 = dateTime12.withYear((int) (short) -1);
        boolean boolean16 = mutableDateTime5.isEqual((org.joda.time.ReadableInstant) dateTime15);
        int int17 = mutableDateTime2.compareTo((org.joda.time.ReadableInstant) dateTime15);
        mutableDateTime2.addYears((int) ' ');
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 16 + "'", int13 == 16);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("Property[millisOfSecond]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[millisOfSecond]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        org.joda.time.DateTime.Property property8 = dateTime4.hourOfDay();
        int int9 = dateTime4.getCenturyOfEra();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 19 + "'", int9 == 19);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 0, (org.joda.time.Chronology) gJChronology1, locale2, (java.lang.Integer) 0, 16);
        dateTimeParserBucket5.setOffset((int) (short) 1);
        long long9 = dateTimeParserBucket5.computeMillis(false);
        dateTimeParserBucket5.setOffset((-28378000));
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560373543324L + "'", long1 == 1560373543324L);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) ' ', chronology11);
        boolean boolean14 = dateTime12.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime15 = dateTime12.toLocalDateTime();
        org.joda.time.DateTime dateTime16 = dateTime4.withFields((org.joda.time.ReadablePartial) localDateTime15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        boolean boolean18 = dateTime4.isSupported(dateTimeFieldType17);
        int int19 = dateTime4.getCenturyOfEra();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        java.lang.String str21 = dateTime4.toString(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19 + "'", int19 == 19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1969-12-31T16:00:00-08:00" + "'", str21.equals("1969-12-31T16:00:00-08:00"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) '#', (int) '4');
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        int int1 = gJChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray5 = gJChronology0.get(readablePeriod2, (-28800000L), (long) 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(0L, dateTimeZone2);
        boolean boolean5 = dateTime3.isAfter((long) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        boolean boolean9 = dateTime4.isAfter((-99948L));
        org.joda.time.DateTime.Property property10 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime12 = property10.addWrapFieldToCopy((-28378000));
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.era();
        java.lang.String str6 = property5.getName();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.getMutableDateTime();
        try {
            org.joda.time.MutableDateTime mutableDateTime9 = property5.add((long) 2169);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "era" + "'", str6.equals("era"));
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 1, 2000, 200, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.monthOfYear();
        mutableDateTime2.setDayOfYear((int) 'a');
        int int8 = mutableDateTime2.getDayOfYear();
        try {
            mutableDateTime2.setMillisOfDay((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("12/31/69", false);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gJChronology4);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = gJChronology0.withZone(dateTimeZone3);
        try {
            long long13 = gJChronology0.getDateTimeMillis(28800000, (int) (byte) 10, (-10), 365, 960, (-10), (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.era();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.addWrapField((-10));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.weekyear();
        int int10 = property9.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292278993 + "'", int10 == 292278993);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) ' ', chronology5);
        boolean boolean8 = dateTime6.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime9 = dateTime6.toLocalDateTime();
        boolean boolean11 = dateTime6.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) ' ', chronology15);
        int int17 = dateTime16.getHourOfDay();
        org.joda.time.DateTime dateTime19 = dateTime16.withYear((int) (short) -1);
        java.lang.String str20 = dateTime16.toString();
        int int21 = dateTime16.getEra();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime16.toDateTime(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime16.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone26 = dateTime25.getZone();
        org.joda.time.DateTime dateTime27 = dateTime6.toDateTime(dateTimeZone26);
        org.joda.time.Chronology chronology28 = julianChronology1.withZone(dateTimeZone26);
        org.joda.time.DurationField durationField29 = julianChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology1.millisOfDay();
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance();
        long long39 = gJChronology31.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField42 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology31, dateTimeField41);
        org.joda.time.DateTimeField dateTimeField43 = gJChronology31.minuteOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField45 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField43, 57600);
        int int46 = skipUndoDateTimeField45.getMinimumValue();
        try {
            long long49 = skipUndoDateTimeField45.set((-62112150421990L), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfDay must be in the range [1,1439]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str20.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-62112150421990L) + "'", long39 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.era();
        int int6 = property5.getMaximumValueOverall();
        try {
            org.joda.time.MutableDateTime mutableDateTime8 = property5.set("12/31/69");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"12/31/69\" for era is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        mutableDateTime2.addDays(1);
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime2.copy();
        org.joda.time.Chronology chronology8 = null;
        mutableDateTime7.setChronology(chronology8);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField18);
        long long22 = skipDateTimeField19.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType23, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        java.lang.String str29 = julianChronology28.toString();
        org.joda.time.DurationField durationField30 = julianChronology28.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        try {
            long long33 = unsupportedDateTimeField31.roundFloor((long) (-10));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112150421990L) + "'", long16 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1960L) + "'", long22 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str29.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime4.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone14);
        long long17 = dateTimeZone14.convertUTCToLocal(0L);
        int int19 = dateTimeZone14.getOffsetFromLocal((long) (short) 1);
        try {
            org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14, 28800000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 28800000");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str8.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800000L) + "'", long17 == (-28800000L));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28800000) + "'", int19 == (-28800000));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.monthOfYear();
        mutableDateTime2.setDayOfYear((int) 'a');
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        long long12 = gJChronology8.add(readablePeriod9, (-99948L), 10);
        org.joda.time.DateTime dateTime13 = mutableDateTime2.toDateTime((org.joda.time.Chronology) gJChronology8);
        int int14 = mutableDateTime2.getRoundingMode();
        mutableDateTime2.setYear(100);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant20, readableInstant21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) ' ', chronology22);
        boolean boolean25 = dateTime23.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime26 = dateTime23.toLocalDateTime();
        boolean boolean28 = dateTime23.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant30, readableInstant31);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) ' ', chronology32);
        int int34 = dateTime33.getHourOfDay();
        org.joda.time.DateTime dateTime36 = dateTime33.withYear((int) (short) -1);
        java.lang.String str37 = dateTime33.toString();
        int int38 = dateTime33.getEra();
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.DateTime dateTime40 = dateTime33.toDateTime(dateTimeZone39);
        org.joda.time.DateTime dateTime42 = dateTime33.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone43 = dateTime42.getZone();
        org.joda.time.DateTime dateTime44 = dateTime23.toDateTime(dateTimeZone43);
        org.joda.time.Chronology chronology45 = julianChronology18.withZone(dateTimeZone43);
        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone43);
        mutableDateTime2.setZoneRetainFields(dateTimeZone43);
        long long51 = dateTimeZone43.convertLocalToUTC(28800000L, true, 3L);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-99948L) + "'", long12 == (-99948L));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(localDateTime26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 16 + "'", int34 == 16);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str37.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertNotNull(buddhistChronology46);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 57600000L + "'", long51 == 57600000L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField18);
        long long22 = skipDateTimeField19.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType23, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        java.lang.String str29 = julianChronology28.toString();
        org.joda.time.DurationField durationField30 = julianChronology28.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance();
        long long40 = gJChronology32.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology41.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField43 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology32, dateTimeField42);
        java.lang.String str45 = skipDateTimeField43.getAsText((long) (byte) 100);
        org.joda.time.ReadableInstant readableInstant47 = null;
        org.joda.time.ReadableInstant readableInstant48 = null;
        org.joda.time.Chronology chronology49 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant47, readableInstant48);
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) ' ', chronology49);
        int int51 = dateTime50.getHourOfDay();
        org.joda.time.DateTime dateTime53 = dateTime50.withYear((int) (short) -1);
        java.lang.String str54 = dateTime50.toString();
        int int55 = dateTime50.getEra();
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.DateTime dateTime57 = dateTime50.toDateTime(dateTimeZone56);
        org.joda.time.DateTime dateTime59 = dateTime50.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone60 = dateTime59.getZone();
        org.joda.time.ReadableInstant readableInstant62 = null;
        org.joda.time.ReadableInstant readableInstant63 = null;
        org.joda.time.Chronology chronology64 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant62, readableInstant63);
        org.joda.time.DateTime dateTime65 = new org.joda.time.DateTime((long) ' ', chronology64);
        boolean boolean67 = dateTime65.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime68 = dateTime65.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant70 = null;
        org.joda.time.ReadableInstant readableInstant71 = null;
        org.joda.time.Chronology chronology72 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant70, readableInstant71);
        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime((long) ' ', chronology72);
        boolean boolean75 = dateTime73.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime76 = dateTime73.toLocalDateTime();
        org.joda.time.DateTime dateTime77 = dateTime65.withFields((org.joda.time.ReadablePartial) localDateTime76);
        boolean boolean78 = dateTimeZone60.isLocalDateTimeGap(localDateTime76);
        java.util.Locale locale79 = null;
        java.lang.String str80 = skipDateTimeField43.getAsShortText((org.joda.time.ReadablePartial) localDateTime76, locale79);
        java.util.Locale locale81 = null;
        try {
            java.lang.String str82 = unsupportedDateTimeField31.getAsShortText((org.joda.time.ReadablePartial) localDateTime76, locale81);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112150421990L) + "'", long16 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1960L) + "'", long22 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str29.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-62112150421990L) + "'", long40 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "100" + "'", str45.equals("100"));
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 16 + "'", int51 == 16);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str54.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(chronology64);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(localDateTime68);
        org.junit.Assert.assertNotNull(chronology72);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(localDateTime76);
        org.junit.Assert.assertNotNull(dateTime77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "32" + "'", str80.equals("32"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        int int6 = dateTime4.getWeekOfWeekyear();
        int int7 = dateTime4.getDayOfWeek();
        int int8 = dateTime4.getDayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale11 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket14 = new org.joda.time.format.DateTimeParserBucket((long) (short) 0, (org.joda.time.Chronology) gJChronology10, locale11, (java.lang.Integer) 0, 16);
        try {
            org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime((java.lang.Object) int8, (org.joda.time.Chronology) gJChronology10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertNotNull(gJChronology10);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField18);
        long long22 = skipDateTimeField19.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType23, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        java.lang.String str29 = julianChronology28.toString();
        org.joda.time.DurationField durationField30 = julianChronology28.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        try {
            java.lang.String str33 = unsupportedDateTimeField31.getAsShortText((long) 365);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112150421990L) + "'", long16 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1960L) + "'", long22 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str29.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        try {
            long long8 = julianChronology0.getDateTimeMillis(9, 69, (int) (short) 1, (-1), (int) '4', (-3), 999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket(43L, (org.joda.time.Chronology) gJChronology1, locale2);
        java.lang.Object obj4 = dateTimeParserBucket3.saveState();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "era", (int) (short) -1, (int) '#');
        long long6 = fixedDateTimeZone4.nextTransition((long) 200);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        int int9 = fixedDateTimeZone4.getOffsetFromLocal(32L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 200L + "'", long6 == 200L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        int int0 = org.joda.time.MutableDateTime.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) ' ', chronology11);
        boolean boolean14 = dateTime12.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime15 = dateTime12.toLocalDateTime();
        org.joda.time.DateTime dateTime16 = dateTime4.withFields((org.joda.time.ReadablePartial) localDateTime15);
        org.joda.time.DateTime.Property property17 = dateTime16.millisOfSecond();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.addWeeks((int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField5 = null;
        mutableDateTime2.setRounding(dateTimeField5, (-3));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        boolean boolean20 = dateTime18.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        int[] intArray23 = julianChronology13.get((org.joda.time.ReadablePartial) localDateTime21, (-62112150421990L));
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) (byte) 0, locale25);
        long long29 = skipDateTimeField11.set((long) 0, 200);
        long long32 = skipDateTimeField11.getDifferenceAsLong((long) 1970, (long) 292278993);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 200L + "'", long29 == 200L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-292277023L) + "'", long32 == (-292277023L));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfCentury((int) (byte) 100, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.append(dateTimeFormatter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendWeekOfWeekyear((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendFractionOfMinute((int) '#', (int) '4');
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatterBuilder13.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder13.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap19 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder13.appendTimeZoneName(strMap19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder12.appendTimeZoneName(strMap19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(strMap19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfDay((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) '#', (int) '4');
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder3.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendOptional(dateTimeParser7);
        boolean boolean9 = dateTimeFormatterBuilder0.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) ' ', chronology5);
        boolean boolean8 = dateTime6.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime9 = dateTime6.toLocalDateTime();
        boolean boolean11 = dateTime6.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) ' ', chronology15);
        int int17 = dateTime16.getHourOfDay();
        org.joda.time.DateTime dateTime19 = dateTime16.withYear((int) (short) -1);
        java.lang.String str20 = dateTime16.toString();
        int int21 = dateTime16.getEra();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime16.toDateTime(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime16.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone26 = dateTime25.getZone();
        org.joda.time.DateTime dateTime27 = dateTime6.toDateTime(dateTimeZone26);
        org.joda.time.Chronology chronology28 = julianChronology1.withZone(dateTimeZone26);
        org.joda.time.DurationField durationField29 = julianChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology1.millisOfDay();
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance();
        long long39 = gJChronology31.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField42 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology31, dateTimeField41);
        org.joda.time.DateTimeField dateTimeField43 = gJChronology31.minuteOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField45 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField43, 57600);
        org.joda.time.Chronology chronology46 = julianChronology1.withUTC();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str20.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-62112150421990L) + "'", long39 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(chronology46);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        org.joda.time.DateTime.Property property8 = dateTime4.centuryOfEra();
        org.joda.time.DateTime.Property property9 = dateTime4.centuryOfEra();
        try {
            org.joda.time.DateTime dateTime11 = property9.addToCopy((long) 57600032);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 5760003200");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        int int15 = skipDateTimeField11.get(0L);
        int int17 = skipDateTimeField11.getMaximumValue((long) 999);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 999 + "'", int17 == 999);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField18);
        long long22 = skipDateTimeField19.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType23, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        java.lang.String str29 = julianChronology28.toString();
        org.joda.time.DurationField durationField30 = julianChronology28.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField31.getRangeDurationField();
        org.joda.time.ReadableInstant readableInstant34 = null;
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.Chronology chronology36 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant34, readableInstant35);
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) ' ', chronology36);
        int int38 = dateTime37.getHourOfDay();
        org.joda.time.DateTime dateTime40 = dateTime37.withYear((int) (short) -1);
        java.lang.String str41 = dateTime37.toString();
        int int42 = dateTime37.getEra();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.DateTime dateTime44 = dateTime37.toDateTime(dateTimeZone43);
        org.joda.time.DateTime dateTime46 = dateTime37.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone47 = dateTime46.getZone();
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) ' ', chronology51);
        boolean boolean54 = dateTime52.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime55 = dateTime52.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant57 = null;
        org.joda.time.ReadableInstant readableInstant58 = null;
        org.joda.time.Chronology chronology59 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant57, readableInstant58);
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((long) ' ', chronology59);
        boolean boolean62 = dateTime60.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime63 = dateTime60.toLocalDateTime();
        org.joda.time.DateTime dateTime64 = dateTime52.withFields((org.joda.time.ReadablePartial) localDateTime63);
        boolean boolean65 = dateTimeZone47.isLocalDateTimeGap(localDateTime63);
        org.joda.time.DateTimeZone dateTimeZone66 = null;
        org.joda.time.chrono.JulianChronology julianChronology67 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone66);
        org.joda.time.ReadableInstant readableInstant69 = null;
        org.joda.time.ReadableInstant readableInstant70 = null;
        org.joda.time.Chronology chronology71 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant69, readableInstant70);
        org.joda.time.DateTime dateTime72 = new org.joda.time.DateTime((long) ' ', chronology71);
        boolean boolean74 = dateTime72.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime75 = dateTime72.toLocalDateTime();
        int[] intArray77 = julianChronology67.get((org.joda.time.ReadablePartial) localDateTime75, (-62112150421990L));
        try {
            int int78 = unsupportedDateTimeField31.getMinimumValue((org.joda.time.ReadablePartial) localDateTime63, intArray77);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112150421990L) + "'", long16 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1960L) + "'", long22 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str29.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 16 + "'", int38 == 16);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str41.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(localDateTime55);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(localDateTime63);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(julianChronology67);
        org.junit.Assert.assertNotNull(chronology71);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(localDateTime75);
        org.junit.Assert.assertNotNull(intArray77);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        boolean boolean20 = dateTime18.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        int[] intArray23 = julianChronology13.get((org.joda.time.ReadablePartial) localDateTime21, (-62112150421990L));
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) (byte) 0, locale25);
        int int28 = skipDateTimeField11.get(10L);
        org.joda.time.DateTimeField dateTimeField29 = skipDateTimeField11.getWrappedField();
        long long32 = skipDateTimeField11.add(35L, (long) (byte) 1);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 36L + "'", long32 == 36L);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.junit.Assert.assertNotNull(instant0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "era", (int) (short) -1, (int) '#');
        long long6 = fixedDateTimeZone4.nextTransition((long) 200);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        try {
            long long12 = julianChronology7.getDateTimeMillis((int) (byte) 10, 69, (int) (short) 100, 16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 200L + "'", long6 == 200L);
        org.junit.Assert.assertNotNull(julianChronology7);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        boolean boolean9 = dateTime4.isAfter((-99948L));
        org.joda.time.DateTime.Property property10 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime12 = dateTime4.withMonthOfYear(1);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant14, readableInstant15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) ' ', chronology16);
        boolean boolean19 = dateTime17.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime20 = dateTime17.toLocalDateTime();
        boolean boolean22 = dateTime17.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant24, readableInstant25);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) ' ', chronology26);
        int int28 = dateTime27.getHourOfDay();
        org.joda.time.DateTime dateTime30 = dateTime27.withYear((int) (short) -1);
        java.lang.String str31 = dateTime27.toString();
        int int32 = dateTime27.getEra();
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.DateTime dateTime34 = dateTime27.toDateTime(dateTimeZone33);
        org.joda.time.DateTime dateTime36 = dateTime27.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone37 = dateTime36.getZone();
        org.joda.time.DateTime dateTime38 = dateTime17.toDateTime(dateTimeZone37);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.DateTime dateTime40 = dateTime17.plus(readablePeriod39);
        int int41 = dateTime40.getDayOfWeek();
        org.joda.time.DateTime dateTime43 = dateTime40.plusSeconds(0);
        boolean boolean44 = dateTime12.isAfter((org.joda.time.ReadableInstant) dateTime40);
        org.joda.time.DateTime dateTime46 = dateTime12.plusMillis(19);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(localDateTime20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 16 + "'", int28 == 16);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str31.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 3 + "'", int41 == 3);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(dateTime46);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.addWeeks((int) (byte) 0);
        mutableDateTime2.addDays((int) (short) -1);
        mutableDateTime2.addMillis(16);
        int int9 = mutableDateTime2.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        boolean boolean9 = dateTime4.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) ' ', chronology13);
        int int15 = dateTime14.getHourOfDay();
        org.joda.time.DateTime dateTime17 = dateTime14.withYear((int) (short) -1);
        java.lang.String str18 = dateTime14.toString();
        int int19 = dateTime14.getEra();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime14.toDateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime14.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone24 = dateTime23.getZone();
        org.joda.time.DateTime dateTime25 = dateTime4.toDateTime(dateTimeZone24);
        long long28 = dateTimeZone24.convertLocalToUTC(0L, true);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str18.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 28800000L + "'", long28 == 28800000L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) ' ', (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendSecondOfMinute((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        org.joda.time.DateTime.Property property8 = dateTime4.centuryOfEra();
        org.joda.time.Interval interval9 = property8.toInterval();
        int int10 = property8.getMinimumValue();
        org.joda.time.DateTime dateTime12 = property8.addWrapFieldToCopy(97);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        boolean boolean20 = dateTime18.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        int[] intArray23 = julianChronology13.get((org.joda.time.ReadablePartial) localDateTime21, (-62112150421990L));
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) (byte) 0, locale25);
        int int28 = skipDateTimeField11.get(10L);
        int int29 = skipDateTimeField11.getMaximumValue();
        boolean boolean31 = skipDateTimeField11.isLeap((long) (byte) 0);
        long long33 = skipDateTimeField11.roundFloor((long) (byte) -1);
        int int35 = skipDateTimeField11.getMaximumValue((long) 12);
        long long37 = skipDateTimeField11.roundFloor((long) 960);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 999 + "'", int29 == 999);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1L) + "'", long33 == (-1L));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 999 + "'", int35 == 999);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 960L + "'", long37 == 960L);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        java.lang.String str15 = skipDateTimeField11.getAsShortText((long) 57600);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        long long24 = gJChronology16.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField26);
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant29, readableInstant30);
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) ' ', chronology31);
        boolean boolean34 = dateTime32.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime35 = dateTime32.toLocalDateTime();
        java.util.Locale locale36 = null;
        java.lang.String str37 = skipDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDateTime35, locale36);
        int[] intArray38 = null;
        int int39 = skipDateTimeField11.getMinimumValue((org.joda.time.ReadablePartial) localDateTime35, intArray38);
        boolean boolean41 = skipDateTimeField11.isLeap(100L);
        boolean boolean42 = skipDateTimeField11.isLenient();
        org.joda.time.DurationField durationField43 = skipDateTimeField11.getLeapDurationField();
        long long45 = skipDateTimeField11.roundFloor((long) 4);
        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance();
        long long54 = gJChronology46.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology55 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField56 = gJChronology55.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField57 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology46, dateTimeField56);
        org.joda.time.ReadableInstant readableInstant59 = null;
        org.joda.time.ReadableInstant readableInstant60 = null;
        org.joda.time.Chronology chronology61 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant59, readableInstant60);
        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime((long) ' ', chronology61);
        boolean boolean64 = dateTime62.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime65 = dateTime62.toLocalDateTime();
        java.util.Locale locale66 = null;
        java.lang.String str67 = skipDateTimeField57.getAsText((org.joda.time.ReadablePartial) localDateTime65, locale66);
        int int68 = skipDateTimeField11.getMinimumValue((org.joda.time.ReadablePartial) localDateTime65);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "600" + "'", str15.equals("600"));
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-62112150421990L) + "'", long24 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(localDateTime35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "32" + "'", str37.equals("32"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(durationField43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 4L + "'", long45 == 4L);
        org.junit.Assert.assertNotNull(gJChronology46);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-62112150421990L) + "'", long54 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(chronology61);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(localDateTime65);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "32" + "'", str67.equals("32"));
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(28800000L);
        org.joda.time.Instant instant4 = instant1.withDurationAdded(0L, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.Integer int6 = dateTimeFormatter5.getPivotYear();
        java.util.Locale locale7 = dateTimeFormatter5.getLocale();
        java.lang.String str8 = instant1.toString(dateTimeFormatter5);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology9.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        org.joda.time.Chronology chronology14 = gJChronology9.withZone(dateTimeZone12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter5.withZone(dateTimeZone12);
        int int16 = dateTimeFormatter5.getDefaultYear();
        boolean boolean17 = dateTimeFormatter5.isParser();
        java.lang.Integer int18 = dateTimeFormatter5.getPivotYear();
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(int6);
        org.junit.Assert.assertNull(locale7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970001T080000.000Z" + "'", str8.equals("1970001T080000.000Z"));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2000 + "'", int16 == 2000);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(int18);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) ' ', chronology5);
        boolean boolean8 = dateTime6.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime9 = dateTime6.toLocalDateTime();
        boolean boolean11 = dateTime6.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) ' ', chronology15);
        int int17 = dateTime16.getHourOfDay();
        org.joda.time.DateTime dateTime19 = dateTime16.withYear((int) (short) -1);
        java.lang.String str20 = dateTime16.toString();
        int int21 = dateTime16.getEra();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime16.toDateTime(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime16.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone26 = dateTime25.getZone();
        org.joda.time.DateTime dateTime27 = dateTime6.toDateTime(dateTimeZone26);
        org.joda.time.Chronology chronology28 = julianChronology1.withZone(dateTimeZone26);
        org.joda.time.DurationField durationField29 = julianChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology1.millisOfDay();
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance();
        long long39 = gJChronology31.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField42 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology31, dateTimeField41);
        org.joda.time.DateTimeField dateTimeField43 = gJChronology31.minuteOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField45 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField43, 57600);
        int int47 = skipUndoDateTimeField45.get((long) 999);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str20.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-62112150421990L) + "'", long39 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 961 + "'", int47 == 961);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) ' ', chronology15);
        boolean boolean18 = dateTime16.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime19 = dateTime16.toLocalDateTime();
        java.util.Locale locale20 = null;
        java.lang.String str21 = skipDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDateTime19, locale20);
        long long24 = skipDateTimeField11.set(36L, 97);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(localDateTime19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "32" + "'", str21.equals("32"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 97L + "'", long24 == 97L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(0L);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        boolean boolean20 = dateTime18.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        int[] intArray23 = julianChronology13.get((org.joda.time.ReadablePartial) localDateTime21, (-62112150421990L));
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) (byte) 0, locale25);
        int int28 = skipDateTimeField11.get(10L);
        long long31 = skipDateTimeField11.add(33L, (long) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.ReadableInstant readableInstant34 = null;
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.Chronology chronology36 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant34, readableInstant35);
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) ' ', chronology36);
        int int38 = dateTime37.getHourOfDay();
        org.joda.time.DateTime dateTime40 = dateTime37.withYear((int) (short) -1);
        java.lang.String str41 = dateTime37.toString();
        int int42 = dateTime37.getEra();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.DateTime dateTime44 = dateTime37.toDateTime(dateTimeZone43);
        org.joda.time.DateTime.Property property45 = dateTime37.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone32, (org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.DateTime.Property property47 = dateTime37.monthOfYear();
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.Chronology chronology51 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant49, readableInstant50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime((long) ' ', chronology51);
        boolean boolean54 = dateTime52.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime55 = dateTime52.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant57 = null;
        org.joda.time.ReadableInstant readableInstant58 = null;
        org.joda.time.Chronology chronology59 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant57, readableInstant58);
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((long) ' ', chronology59);
        boolean boolean62 = dateTime60.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime63 = dateTime60.toLocalDateTime();
        org.joda.time.DateTime dateTime64 = dateTime52.withFields((org.joda.time.ReadablePartial) localDateTime63);
        int int65 = property47.compareTo((org.joda.time.ReadablePartial) localDateTime63);
        java.util.Locale locale67 = null;
        java.lang.String str68 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime63, 12, locale67);
        org.joda.time.ReadableInstant readableInstant70 = null;
        org.joda.time.ReadableInstant readableInstant71 = null;
        org.joda.time.Chronology chronology72 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant70, readableInstant71);
        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime((long) ' ', chronology72);
        boolean boolean75 = dateTime73.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime76 = dateTime73.toLocalDateTime();
        org.joda.time.DateTimeZone dateTimeZone78 = null;
        org.joda.time.chrono.JulianChronology julianChronology79 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone78);
        org.joda.time.ReadableInstant readableInstant81 = null;
        org.joda.time.ReadableInstant readableInstant82 = null;
        org.joda.time.Chronology chronology83 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant81, readableInstant82);
        org.joda.time.DateTime dateTime84 = new org.joda.time.DateTime((long) ' ', chronology83);
        boolean boolean86 = dateTime84.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime87 = dateTime84.toLocalDateTime();
        int[] intArray89 = julianChronology79.get((org.joda.time.ReadablePartial) localDateTime87, (-62112150421990L));
        java.util.Locale locale91 = null;
        try {
            int[] intArray92 = skipDateTimeField11.set((org.joda.time.ReadablePartial) localDateTime76, (int) (short) 0, intArray89, "Property[secondOfDay]", locale91);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[secondOfDay]\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 43L + "'", long31 == 43L);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 16 + "'", int38 == 16);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str41.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(gJChronology46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(localDateTime55);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(localDateTime63);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "12" + "'", str68.equals("12"));
        org.junit.Assert.assertNotNull(chronology72);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(localDateTime76);
        org.junit.Assert.assertNotNull(julianChronology79);
        org.junit.Assert.assertNotNull(chronology83);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(localDateTime87);
        org.junit.Assert.assertNotNull(intArray89);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfDay((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfDay(999, 28800000);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(16, 'a', (int) (short) 10, (int) (byte) 1, 999, true, 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.setFixedSavings("", 57600);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder0.addCutover(365, '4', 0, 3, 0, false, 200);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-4) + "'", int1 == (-4));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        long long14 = skipDateTimeField11.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipDateTimeField11.getType();
        int int17 = skipDateTimeField11.getLeapAmount(0L);
        boolean boolean18 = skipDateTimeField11.isLenient();
        boolean boolean20 = skipDateTimeField11.isLeap(1560344728795L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1960L) + "'", long14 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField18);
        long long22 = skipDateTimeField19.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType23, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        java.lang.String str29 = julianChronology28.toString();
        org.joda.time.DurationField durationField30 = julianChronology28.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField31.getRangeDurationField();
        long long35 = unsupportedDateTimeField31.add((long) (short) 10, (long) 10);
        try {
            long long37 = unsupportedDateTimeField31.remainder((long) 57600);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112150421990L) + "'", long16 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1960L) + "'", long22 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str29.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 600010L + "'", long35 == 600010L);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendSecondOfDay((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfMinute((int) '#', (int) '4');
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatterBuilder7.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.appendOptional(dateTimeParser11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter3, dateTimeParser11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withDefaultYear((-28800000));
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter13.withLocale(locale16);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "era", (int) (short) -1, (int) '#');
        long long13 = fixedDateTimeZone11.nextTransition((long) 200);
        boolean boolean14 = fixedDateTimeZone11.isFixed();
        java.lang.String str16 = fixedDateTimeZone11.getNameKey((-28799999L));
        java.util.TimeZone timeZone17 = fixedDateTimeZone11.toTimeZone();
        try {
            org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime(28800000, 0, (-10), 1, 12, 100, 4, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 200L + "'", long13 == 200L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "era" + "'", str16.equals("era"));
        org.junit.Assert.assertNotNull(timeZone17);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 43L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) ' ', chronology11);
        boolean boolean14 = dateTime12.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime15 = dateTime12.toLocalDateTime();
        org.joda.time.DateTime dateTime16 = dateTime4.withFields((org.joda.time.ReadablePartial) localDateTime15);
        try {
            org.joda.time.DateTime dateTime18 = dateTime4.withSecondOfMinute((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) ' ', chronology11);
        int int13 = dateTime12.getHourOfDay();
        int int14 = dateTime12.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime16 = dateTime12.minusDays(10);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant18, readableInstant19);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) ' ', chronology20);
        int int22 = dateTime21.getHourOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withYear((int) (short) -1);
        java.lang.String str25 = dateTime21.toString();
        int int26 = dateTime21.getEra();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = dateTime21.toDateTime(dateTimeZone27);
        org.joda.time.DateTime dateTime30 = dateTime21.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone31 = dateTime30.getZone();
        long long34 = dateTimeZone31.adjustOffset(10L, false);
        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime12, dateTimeZone31);
        org.joda.time.DateTime dateTime36 = dateTime4.withZone(dateTimeZone31);
        int int37 = dateTime36.getMinuteOfDay();
        org.joda.time.DateTime dateTime39 = dateTime36.plusYears(2);
        try {
            org.joda.time.DateTime dateTime41 = dateTime39.withYearOfCentury(28800000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 28800000 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 16 + "'", int13 == 16);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 16 + "'", int22 == 16);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str25.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 960 + "'", int37 == 960);
        org.junit.Assert.assertNotNull(dateTime39);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.era();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.addWrapField((-10));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.weekyear();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.set("600");
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField18);
        long long22 = skipDateTimeField19.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType23, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        java.lang.String str29 = julianChronology28.toString();
        org.joda.time.DurationField durationField30 = julianChronology28.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField31.getRangeDurationField();
        try {
            int int34 = unsupportedDateTimeField31.getLeapAmount(33L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112150421990L) + "'", long16 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1960L) + "'", long22 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str29.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNull(durationField32);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        boolean boolean20 = dateTime18.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        int[] intArray23 = julianChronology13.get((org.joda.time.ReadablePartial) localDateTime21, (-62112150421990L));
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) (byte) 0, locale25);
        int int28 = skipDateTimeField11.get(10L);
        int int29 = skipDateTimeField11.getMaximumValue();
        boolean boolean31 = skipDateTimeField11.isLeap((long) (byte) 0);
        int int33 = skipDateTimeField11.get((-62112150421990L));
        org.joda.time.ReadablePartial readablePartial34 = null;
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.chrono.JulianChronology julianChronology37 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone36);
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.ReadableInstant readableInstant40 = null;
        org.joda.time.Chronology chronology41 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant39, readableInstant40);
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) ' ', chronology41);
        boolean boolean44 = dateTime42.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime45 = dateTime42.toLocalDateTime();
        int[] intArray47 = julianChronology37.get((org.joda.time.ReadablePartial) localDateTime45, (-62112150421990L));
        java.util.Locale locale49 = null;
        try {
            int[] intArray50 = skipDateTimeField11.set(readablePartial34, 2169, intArray47, "10", locale49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112150421990L) + "'", long8 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 999 + "'", int29 == 999);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
        org.junit.Assert.assertNotNull(julianChronology37);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(localDateTime45);
        org.junit.Assert.assertNotNull(intArray47);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 0, (org.joda.time.Chronology) gJChronology1, locale2, (java.lang.Integer) 0, 16);
        dateTimeParserBucket5.setOffset((int) (short) 1);
        long long9 = dateTimeParserBucket5.computeMillis(false);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        long long18 = gJChronology10.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField20 = gJChronology19.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField21 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField20);
        java.lang.String str23 = skipDateTimeField21.getAsText((long) (byte) 100);
        java.lang.String str25 = skipDateTimeField21.getAsShortText((long) 57600);
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipDateTimeField21.getAsText((-62112150421990L), locale27);
        java.lang.String str29 = skipDateTimeField21.toString();
        dateTimeParserBucket5.saveField((org.joda.time.DateTimeField) skipDateTimeField21, (-10));
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62112150421990L) + "'", long18 == (-62112150421990L));
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "100" + "'", str23.equals("100"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "600" + "'", str25.equals("600"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10" + "'", str28.equals("10"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str29.equals("DateTimeField[millisOfSecond]"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Chronology must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 0, (org.joda.time.Chronology) gJChronology1, locale2, (java.lang.Integer) 0, 16);
        long long7 = dateTimeParserBucket5.computeMillis(true);
        dateTimeParserBucket5.setPivotYear((java.lang.Integer) 97);
        dateTimeParserBucket5.setOffset((java.lang.Integer) (-3));
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, readableInstant6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) ' ', chronology7);
        boolean boolean10 = dateTime8.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime11 = dateTime8.toLocalDateTime();
        boolean boolean13 = dateTime8.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        int int19 = dateTime18.getHourOfDay();
        org.joda.time.DateTime dateTime21 = dateTime18.withYear((int) (short) -1);
        java.lang.String str22 = dateTime18.toString();
        int int23 = dateTime18.getEra();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime18.toDateTime(dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime18.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone28 = dateTime27.getZone();
        org.joda.time.DateTime dateTime29 = dateTime8.toDateTime(dateTimeZone28);
        org.joda.time.Chronology chronology30 = julianChronology3.withZone(dateTimeZone28);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter0.withChronology(chronology30);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter31.withPivotYear((int) (short) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(localDateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 16 + "'", int19 == 16);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str22.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        boolean boolean9 = dateTime4.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) ' ', chronology13);
        int int15 = dateTime14.getHourOfDay();
        org.joda.time.DateTime dateTime17 = dateTime14.withYear((int) (short) -1);
        java.lang.String str18 = dateTime14.toString();
        int int19 = dateTime14.getEra();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime14.toDateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime14.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone24 = dateTime23.getZone();
        org.joda.time.DateTime dateTime25 = dateTime4.toDateTime(dateTimeZone24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime27 = dateTime4.plus(readablePeriod26);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone29);
        mutableDateTime30.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property33 = mutableDateTime30.era();
        org.joda.time.MutableDateTime.Property property34 = mutableDateTime30.monthOfYear();
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        mutableDateTime30.add(readablePeriod35);
        boolean boolean37 = dateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime30);
        mutableDateTime30.setMillis((long) (-28800000));
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str18.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.monthOfYear();
        mutableDateTime2.setDayOfYear((int) 'a');
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        long long12 = gJChronology8.add(readablePeriod9, (-99948L), 10);
        org.joda.time.DateTime dateTime13 = mutableDateTime2.toDateTime((org.joda.time.Chronology) gJChronology8);
        int int14 = mutableDateTime2.getRoundingMode();
        mutableDateTime2.setYear(100);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant20, readableInstant21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) ' ', chronology22);
        boolean boolean25 = dateTime23.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime26 = dateTime23.toLocalDateTime();
        boolean boolean28 = dateTime23.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant30, readableInstant31);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) ' ', chronology32);
        int int34 = dateTime33.getHourOfDay();
        org.joda.time.DateTime dateTime36 = dateTime33.withYear((int) (short) -1);
        java.lang.String str37 = dateTime33.toString();
        int int38 = dateTime33.getEra();
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.DateTime dateTime40 = dateTime33.toDateTime(dateTimeZone39);
        org.joda.time.DateTime dateTime42 = dateTime33.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone43 = dateTime42.getZone();
        org.joda.time.DateTime dateTime44 = dateTime23.toDateTime(dateTimeZone43);
        org.joda.time.Chronology chronology45 = julianChronology18.withZone(dateTimeZone43);
        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone43);
        mutableDateTime2.setZoneRetainFields(dateTimeZone43);
        int int48 = mutableDateTime2.getMinuteOfHour();
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-99948L) + "'", long12 == (-99948L));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(localDateTime26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 16 + "'", int34 == 16);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1969-12-31T16:00:00.032-08:00" + "'", str37.equals("1969-12-31T16:00:00.032-08:00"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertNotNull(buddhistChronology46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear(999);
        try {
            org.joda.time.DateTime dateTime5 = dateTimeFormatter3.parseDateTime("JulianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"JulianChronology[America/Los_Ang...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(57600032, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 57600032");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        org.joda.time.DateTime.Property property8 = dateTime4.centuryOfEra();
        org.joda.time.DateTime dateTime10 = property8.addToCopy((long) 2);
        org.joda.time.DateTime dateTime12 = property8.addWrapFieldToCopy(0);
        int int13 = dateTime12.getHourOfDay();
        org.joda.time.DateTime.Property property14 = dateTime12.dayOfMonth();
        org.joda.time.Interval interval15 = property14.toInterval();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(interval15);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) ' ', chronology5);
        boolean boolean8 = dateTime6.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime9 = dateTime6.toLocalDateTime();
        boolean boolean11 = dateTime6.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) ' ', chronology15);
        int int17 = dateTime16.getHourOfDay();
        org.joda.time.DateTime dateTime19 = dateTime16.withYear((int) (short) -1);
        java.lang.String str20 = dateTime16.toString();
        int int21 = dateTime16.getEra();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime16.toDateTime(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime16.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone26 = dateTime25.getZone();
        org.joda.time.DateTime dateTime27 = dateTime6.toDateTime(dateTimeZone26);
        org.joda.time.Chronology chronology28 = julianChronology1.withZone(dateTimeZone26);
        org.joda.time.DurationField durationField29 = julianChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology1.millisOfDay();
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance();
        long long39 = gJChronology31.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField42 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology31, dateTimeField41);
        org.joda.time.DateTimeField dateTimeField43 = gJChronology31.minuteOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField45 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField43, 57600);
        int int46 = skipUndoDateTimeField45.getMinimumValue();
        long long49 = skipUndoDateTimeField45.add((long) 999, 97L);
        try {
            long long52 = skipUndoDateTimeField45.set(5820999L, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for minuteOfDay must be in the range [1,1439]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str20.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-62112178799990L) + "'", long39 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 5820999L + "'", long49 == 5820999L);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 0, (org.joda.time.Chronology) gJChronology1, locale2, (java.lang.Integer) 0, 16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        java.util.Locale locale7 = dateTimeFormatter6.getLocale();
        boolean boolean8 = dateTimeParserBucket5.restoreState((java.lang.Object) dateTimeFormatter6);
        boolean boolean9 = dateTimeFormatter6.isParser();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNull(locale7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField18);
        long long22 = skipDateTimeField19.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType23, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        java.lang.String str29 = julianChronology28.toString();
        org.joda.time.DurationField durationField30 = julianChronology28.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        java.util.Locale locale33 = null;
        try {
            java.lang.String str34 = unsupportedDateTimeField31.getAsText(36L, locale33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112178799990L) + "'", long16 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1960L) + "'", long22 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JulianChronology[UTC]" + "'", str29.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(28800000L);
        org.joda.time.Instant instant4 = instant1.withDurationAdded(0L, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.Integer int6 = dateTimeFormatter5.getPivotYear();
        java.util.Locale locale7 = dateTimeFormatter5.getLocale();
        java.lang.String str8 = instant1.toString(dateTimeFormatter5);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Instant instant10 = instant1.minus(readableDuration9);
        org.joda.time.Instant instant11 = instant10.toInstant();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.Instant instant14 = instant11.withDurationAdded(readableDuration12, 0);
        org.joda.time.Instant instant16 = instant14.minus((long) 1969);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(int6);
        org.junit.Assert.assertNull(locale7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970001T080000.000Z" + "'", str8.equals("1970001T080000.000Z"));
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertNotNull(instant14);
        org.junit.Assert.assertNotNull(instant16);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.era();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.monthOfYear();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        mutableDateTime2.add(readablePeriod7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) ' ', chronology14);
        boolean boolean17 = dateTime15.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime18 = dateTime15.toLocalDateTime();
        boolean boolean20 = dateTime15.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant22, readableInstant23);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) ' ', chronology24);
        int int26 = dateTime25.getHourOfDay();
        org.joda.time.DateTime dateTime28 = dateTime25.withYear((int) (short) -1);
        java.lang.String str29 = dateTime25.toString();
        int int30 = dateTime25.getEra();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTime dateTime32 = dateTime25.toDateTime(dateTimeZone31);
        org.joda.time.DateTime dateTime34 = dateTime25.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone35 = dateTime34.getZone();
        org.joda.time.DateTime dateTime36 = dateTime15.toDateTime(dateTimeZone35);
        org.joda.time.Chronology chronology37 = julianChronology10.withZone(dateTimeZone35);
        org.joda.time.DateTimeZone dateTimeZone38 = julianChronology10.getZone();
        mutableDateTime2.setChronology((org.joda.time.Chronology) julianChronology10);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(localDateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str29.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 0, (org.joda.time.Chronology) gJChronology1, locale2, (java.lang.Integer) 0, 16);
        dateTimeParserBucket5.setOffset((int) (short) 1);
        long long9 = dateTimeParserBucket5.computeMillis(false);
        long long11 = dateTimeParserBucket5.computeMillis(true);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        long long14 = skipDateTimeField11.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipDateTimeField11.getType();
        java.lang.String str17 = skipDateTimeField11.getAsShortText((long) 'a');
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1960L) + "'", long14 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "97" + "'", str17.equals("97"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) ' ', chronology5);
        boolean boolean8 = dateTime6.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime9 = dateTime6.toLocalDateTime();
        boolean boolean11 = dateTime6.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) ' ', chronology15);
        int int17 = dateTime16.getHourOfDay();
        org.joda.time.DateTime dateTime19 = dateTime16.withYear((int) (short) -1);
        java.lang.String str20 = dateTime16.toString();
        int int21 = dateTime16.getEra();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime16.toDateTime(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime16.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone26 = dateTime25.getZone();
        org.joda.time.DateTime dateTime27 = dateTime6.toDateTime(dateTimeZone26);
        org.joda.time.Chronology chronology28 = julianChronology1.withZone(dateTimeZone26);
        org.joda.time.DurationField durationField29 = julianChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology1.millisOfDay();
        int int31 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField32 = julianChronology1.hours();
        long long35 = durationField32.subtract((-99948L), 990);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str20.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-3564099948L) + "'", long35 == (-3564099948L));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime4.minusSeconds(16);
        try {
            org.joda.time.DateTime dateTime15 = dateTime4.withSecondOfMinute(28800000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 28800000 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str8.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 0, (org.joda.time.Chronology) gJChronology1, locale2, (java.lang.Integer) 0, 16);
        dateTimeParserBucket5.setOffset((int) (short) 1);
        dateTimeParserBucket5.setOffset((java.lang.Integer) 16);
        org.junit.Assert.assertNotNull(gJChronology1);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipDateTimeField11.getAsShortText(33L, locale15);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale18 = null;
        try {
            java.lang.String str19 = skipDateTimeField11.getAsShortText(readablePartial17, locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "33" + "'", str16.equals("33"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) '#', (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfYear((int) '#');
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendLiteral("JulianChronology[UTC]");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) ' ', chronology6);
        boolean boolean9 = dateTime7.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime10 = dateTime7.toLocalDateTime();
        boolean boolean12 = dateTime7.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant14, readableInstant15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) ' ', chronology16);
        int int18 = dateTime17.getHourOfDay();
        org.joda.time.DateTime dateTime20 = dateTime17.withYear((int) (short) -1);
        java.lang.String str21 = dateTime17.toString();
        int int22 = dateTime17.getEra();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = dateTime17.toDateTime(dateTimeZone23);
        org.joda.time.DateTime dateTime26 = dateTime17.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone27 = dateTime26.getZone();
        org.joda.time.DateTime dateTime28 = dateTime7.toDateTime(dateTimeZone27);
        org.joda.time.Chronology chronology29 = julianChronology2.withZone(dateTimeZone27);
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime(0L, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.ReadableInstant readableInstant31 = null;
        try {
            int int32 = mutableDateTime30.compareTo(readableInstant31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str21.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(chronology29);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.era();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.addWrapField((-10));
        org.joda.time.MutableDateTime mutableDateTime9 = property6.roundHalfEven();
        long long10 = property6.remainder();
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        boolean boolean9 = dateTime4.isAfter((-99948L));
        org.joda.time.DateTime.Property property10 = dateTime4.secondOfDay();
        java.lang.String str11 = property10.getAsString();
        java.lang.String str12 = property10.toString();
        org.joda.time.DateTime dateTime13 = property10.withMinimumValue();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Property[secondOfDay]" + "'", str12.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendDayOfWeekShortText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendTimeZoneOffset("America/Los_Angeles", "12/31/69", true, 292278993, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', chronology4);
        int int6 = dateTime5.getHourOfDay();
        int int7 = dateTime5.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime5.minusDays(10);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) ' ', chronology13);
        int int15 = dateTime14.getHourOfDay();
        org.joda.time.DateTime dateTime17 = dateTime14.withYear((int) (short) -1);
        java.lang.String str18 = dateTime14.toString();
        int int19 = dateTime14.getEra();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime14.toDateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime14.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone24 = dateTime23.getZone();
        long long27 = dateTimeZone24.adjustOffset(10L, false);
        org.joda.time.MutableDateTime mutableDateTime28 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime5, dateTimeZone24);
        org.joda.time.Chronology chronology29 = buddhistChronology0.withZone(dateTimeZone24);
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField31 = julianChronology30.weekyearOfCentury();
        int int32 = julianChronology30.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str18.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("100");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology0.minuteOfHour();
        org.joda.time.DurationField durationField14 = gJChronology0.halfdays();
        try {
            long long19 = gJChronology0.getDateTimeMillis((int) (short) 0, 0, 961, 97);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime4.minuteOfHour();
        java.util.Locale locale13 = null;
        int int14 = property12.getMaximumShortTextLength(locale13);
        org.joda.time.DateTime dateTime15 = property12.roundCeilingCopy();
        int int16 = dateTime15.getYear();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str8.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1970 + "'", int16 == 1970);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', chronology4);
        int int6 = dateTime5.getHourOfDay();
        int int7 = dateTime5.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime5.minusDays(10);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) ' ', chronology13);
        int int15 = dateTime14.getHourOfDay();
        org.joda.time.DateTime dateTime17 = dateTime14.withYear((int) (short) -1);
        java.lang.String str18 = dateTime14.toString();
        int int19 = dateTime14.getEra();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime14.toDateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime14.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone24 = dateTime23.getZone();
        long long27 = dateTimeZone24.adjustOffset(10L, false);
        org.joda.time.MutableDateTime mutableDateTime28 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime5, dateTimeZone24);
        org.joda.time.Chronology chronology29 = buddhistChronology0.withZone(dateTimeZone24);
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeZone dateTimeZone31 = julianChronology30.getZone();
        org.joda.time.DateTimeField dateTimeField32 = julianChronology30.dayOfWeek();
        org.joda.time.ReadableInstant readableInstant34 = null;
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.Chronology chronology36 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant34, readableInstant35);
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) ' ', chronology36);
        int int38 = dateTime37.getHourOfDay();
        int int39 = dateTime37.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime41 = dateTime37.minusDays(10);
        org.joda.time.ReadableInstant readableInstant43 = null;
        org.joda.time.ReadableInstant readableInstant44 = null;
        org.joda.time.Chronology chronology45 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant43, readableInstant44);
        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((long) ' ', chronology45);
        int int47 = dateTime46.getHourOfDay();
        org.joda.time.DateTime dateTime49 = dateTime46.withYear((int) (short) -1);
        java.lang.String str50 = dateTime46.toString();
        int int51 = dateTime46.getEra();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = dateTime46.toDateTime(dateTimeZone52);
        org.joda.time.DateTime dateTime55 = dateTime46.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone56 = dateTime55.getZone();
        long long59 = dateTimeZone56.adjustOffset(10L, false);
        org.joda.time.MutableDateTime mutableDateTime60 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime37, dateTimeZone56);
        java.lang.String str61 = dateTimeZone56.getID();
        org.joda.time.Chronology chronology62 = julianChronology30.withZone(dateTimeZone56);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str18.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str50.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 10L + "'", long59 == 10L);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "UTC" + "'", str61.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology62);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', chronology4);
        int int6 = dateTime5.getHourOfDay();
        int int7 = dateTime5.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime5.minusDays(10);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) ' ', chronology13);
        int int15 = dateTime14.getHourOfDay();
        org.joda.time.DateTime dateTime17 = dateTime14.withYear((int) (short) -1);
        java.lang.String str18 = dateTime14.toString();
        int int19 = dateTime14.getEra();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime14.toDateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime14.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone24 = dateTime23.getZone();
        long long27 = dateTimeZone24.adjustOffset(10L, false);
        org.joda.time.MutableDateTime mutableDateTime28 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime5, dateTimeZone24);
        org.joda.time.Chronology chronology29 = buddhistChronology0.withZone(dateTimeZone24);
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeZone dateTimeZone31 = julianChronology30.getZone();
        org.joda.time.DateTimeField dateTimeField32 = julianChronology30.dayOfWeek();
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
        long long41 = gJChronology33.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField43 = gJChronology42.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology33, dateTimeField43);
        java.lang.String str46 = skipDateTimeField44.getAsText((long) (byte) 100);
        long long48 = skipDateTimeField44.remainder((long) 100);
        long long51 = skipDateTimeField44.set((-3198336L), 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder52.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter54 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder53.append(dateTimeFormatter54);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder55.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder57.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology60 = org.joda.time.chrono.GJChronology.getInstance();
        long long68 = gJChronology60.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology69 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField70 = gJChronology69.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField71 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology60, dateTimeField70);
        long long74 = skipDateTimeField71.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = skipDateTimeField71.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = dateTimeFormatterBuilder59.appendDecimal(dateTimeFieldType75, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone79 = null;
        org.joda.time.chrono.JulianChronology julianChronology80 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone79);
        java.lang.String str81 = julianChronology80.toString();
        org.joda.time.DurationField durationField82 = julianChronology80.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField83 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType75, durationField82);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField85 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField44, dateTimeFieldType75, 31);
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField86 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField32, dateTimeFieldType75);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str18.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-62112178799990L) + "'", long41 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "100" + "'", str46.equals("100"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-3198991L) + "'", long51 == (-3198991L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(dateTimeFormatter54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(gJChronology60);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-62112178799990L) + "'", long68 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-1960L) + "'", long74 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder78);
        org.junit.Assert.assertNotNull(julianChronology80);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "JulianChronology[UTC]" + "'", str81.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField82);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField83);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) ' ', chronology6);
        boolean boolean9 = dateTime7.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime10 = dateTime7.toLocalDateTime();
        boolean boolean12 = dateTime7.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant14, readableInstant15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) ' ', chronology16);
        int int18 = dateTime17.getHourOfDay();
        org.joda.time.DateTime dateTime20 = dateTime17.withYear((int) (short) -1);
        java.lang.String str21 = dateTime17.toString();
        int int22 = dateTime17.getEra();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = dateTime17.toDateTime(dateTimeZone23);
        org.joda.time.DateTime dateTime26 = dateTime17.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone27 = dateTime26.getZone();
        org.joda.time.DateTime dateTime28 = dateTime7.toDateTime(dateTimeZone27);
        org.joda.time.Chronology chronology29 = julianChronology2.withZone(dateTimeZone27);
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime(0L, (org.joda.time.Chronology) julianChronology2);
        try {
            mutableDateTime30.setYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str21.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(chronology29);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.era();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.addWrapField((-10));
        mutableDateTime8.setMillisOfDay((int) (short) 100);
        mutableDateTime8.add((long) 4);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime8.monthOfYear();
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime.Property property6 = dateTime4.dayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.toDateTimeISO();
        try {
            org.joda.time.DateTime dateTime9 = dateTime4.withDayOfMonth(32);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        boolean boolean9 = dateTime4.isAfter((-99948L));
        org.joda.time.DateTime.Property property10 = dateTime4.secondOfDay();
        int int11 = property10.getMinimumValueOverall();
        java.lang.String str12 = property10.toString();
        org.joda.time.DateTime dateTime13 = property10.withMaximumValue();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Property[secondOfDay]" + "'", str12.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "era", (int) (short) -1, (int) '#');
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int7 = cachedDateTimeZone5.getOffset(0L);
        int int9 = cachedDateTimeZone5.getOffset((-99948L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 0, (org.joda.time.Chronology) gJChronology1, locale2, (java.lang.Integer) 0, 16);
        long long7 = dateTimeParserBucket5.computeMillis(true);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField18);
        java.lang.String str21 = skipDateTimeField19.getAsText((long) (byte) 100);
        dateTimeParserBucket5.saveField((org.joda.time.DateTimeField) skipDateTimeField19, (int) (short) 100);
        int int24 = dateTimeParserBucket5.getOffset();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112178799990L) + "'", long16 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "100" + "'", str21.equals("100"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.era();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.addWrapField((-10));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.dayOfMonth();
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(28800000L);
        org.joda.time.Instant instant4 = instant1.withDurationAdded(0L, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.Integer int6 = dateTimeFormatter5.getPivotYear();
        java.util.Locale locale7 = dateTimeFormatter5.getLocale();
        java.lang.String str8 = instant1.toString(dateTimeFormatter5);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Instant instant10 = instant1.minus(readableDuration9);
        org.joda.time.Instant instant11 = instant10.toInstant();
        java.lang.String str12 = instant10.toString();
        org.joda.time.MutableDateTime mutableDateTime13 = instant10.toMutableDateTimeISO();
        org.joda.time.Instant instant15 = instant10.withMillis(100L);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(int6);
        org.junit.Assert.assertNull(locale7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970001T080000.000Z" + "'", str8.equals("1970001T080000.000Z"));
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970-01-01T08:00:00.000Z" + "'", str12.equals("1970-01-01T08:00:00.000Z"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(instant15);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        org.joda.time.DateTime.Property property8 = dateTime4.centuryOfEra();
        org.joda.time.DateTime dateTime10 = property8.addToCopy((long) 2);
        org.joda.time.DateTime dateTime12 = property8.addWrapFieldToCopy(0);
        try {
            org.joda.time.DateTime dateTime14 = dateTime12.withHourOfDay((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("12/31/69", false);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.ReadablePartial readablePartial5 = null;
        try {
            int[] intArray7 = gJChronology4.get(readablePartial5, (-292277023L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gJChronology4);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "100");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType3);
        org.junit.Assert.assertNull(dateTimeFieldType4);
        org.junit.Assert.assertNull(dateTimeFieldType5);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.era();
        java.lang.String str6 = property5.getName();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.roundHalfFloor();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) property5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.MutableDateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "era" + "'", str6.equals("era"));
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.halfdayOfDay();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) julianChronology2, locale4);
        java.lang.String str6 = julianChronology2.toString();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology2.era();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "JulianChronology[UTC]" + "'", str6.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime3 = property1.add((long) (-3));
        org.joda.time.MutableDateTime mutableDateTime4 = mutableDateTime3.copy();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime3 = property1.add((long) (-3));
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, readableInstant6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) ' ', chronology7);
        int int9 = dateTime8.getHourOfDay();
        org.joda.time.DateTime dateTime11 = dateTime8.withYear((int) (short) -1);
        java.lang.String str12 = dateTime8.toString();
        int int13 = dateTime8.getEra();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = dateTime8.toDateTime(dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime8.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone18 = dateTime17.getZone();
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant20, readableInstant21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) ' ', chronology22);
        boolean boolean25 = dateTime23.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime26 = dateTime23.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.Chronology chronology30 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant28, readableInstant29);
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) ' ', chronology30);
        boolean boolean33 = dateTime31.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime34 = dateTime31.toLocalDateTime();
        org.joda.time.DateTime dateTime35 = dateTime23.withFields((org.joda.time.ReadablePartial) localDateTime34);
        boolean boolean36 = dateTimeZone18.isLocalDateTimeGap(localDateTime34);
        org.joda.time.MutableDateTime mutableDateTime37 = mutableDateTime3.toMutableDateTime(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.JulianChronology julianChronology39 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone38);
        org.joda.time.ReadableInstant readableInstant41 = null;
        org.joda.time.ReadableInstant readableInstant42 = null;
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant41, readableInstant42);
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) ' ', chronology43);
        boolean boolean46 = dateTime44.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime47 = dateTime44.toLocalDateTime();
        boolean boolean49 = dateTime44.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant51 = null;
        org.joda.time.ReadableInstant readableInstant52 = null;
        org.joda.time.Chronology chronology53 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant51, readableInstant52);
        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((long) ' ', chronology53);
        int int55 = dateTime54.getHourOfDay();
        org.joda.time.DateTime dateTime57 = dateTime54.withYear((int) (short) -1);
        java.lang.String str58 = dateTime54.toString();
        int int59 = dateTime54.getEra();
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.DateTime dateTime61 = dateTime54.toDateTime(dateTimeZone60);
        org.joda.time.DateTime dateTime63 = dateTime54.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone64 = dateTime63.getZone();
        org.joda.time.DateTime dateTime65 = dateTime44.toDateTime(dateTimeZone64);
        org.joda.time.Chronology chronology66 = julianChronology39.withZone(dateTimeZone64);
        org.joda.time.DurationField durationField67 = julianChronology39.seconds();
        org.joda.time.DateTimeField dateTimeField68 = julianChronology39.millisOfDay();
        org.joda.time.chrono.GJChronology gJChronology69 = org.joda.time.chrono.GJChronology.getInstance();
        long long77 = gJChronology69.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology78 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField79 = gJChronology78.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField80 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology69, dateTimeField79);
        org.joda.time.DateTimeField dateTimeField81 = gJChronology69.minuteOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField83 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology39, dateTimeField81, 57600);
        org.joda.time.MutableDateTime mutableDateTime84 = mutableDateTime37.toMutableDateTime((org.joda.time.Chronology) julianChronology39);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str12.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(localDateTime26);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(localDateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertNotNull(julianChronology39);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(localDateTime47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str58.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTimeZone64);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(chronology66);
        org.junit.Assert.assertNotNull(durationField67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(gJChronology69);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + (-62112178799990L) + "'", long77 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology78);
        org.junit.Assert.assertNotNull(dateTimeField79);
        org.junit.Assert.assertNotNull(dateTimeField81);
        org.junit.Assert.assertNotNull(mutableDateTime84);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        org.joda.time.DateTime.Property property8 = dateTime4.centuryOfEra();
        org.joda.time.DateTime dateTime10 = dateTime4.minusYears(2169);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("ISOChronology[UTC]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: ISOChronology[UTC]");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField18);
        long long22 = skipDateTimeField19.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType23, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        java.lang.String str29 = julianChronology28.toString();
        org.joda.time.DurationField durationField30 = julianChronology28.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        java.util.Locale locale32 = null;
        try {
            int int33 = unsupportedDateTimeField31.getMaximumShortTextLength(locale32);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112178799990L) + "'", long16 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1960L) + "'", long22 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JulianChronology[UTC]" + "'", str29.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        mutableDateTime2.setMinuteOfHour((int) (byte) 0);
        try {
            mutableDateTime2.setSecondOfDay((-28378000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28378000 for secondOfDay must be in the range [0,86399]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        boolean boolean9 = dateTime4.isAfter((-99948L));
        org.joda.time.DateTime.Property property10 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime12 = dateTime4.withMonthOfYear(1);
        java.util.GregorianCalendar gregorianCalendar13 = dateTime12.toGregorianCalendar();
        org.joda.time.DateTime dateTime15 = dateTime12.plusYears((int) (short) 100);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gregorianCalendar13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        try {
            long long6 = gJChronology0.getDateTimeMillis(960, (-3), 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -3 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((-99948L));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        boolean boolean20 = dateTime18.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        int[] intArray23 = julianChronology13.get((org.joda.time.ReadablePartial) localDateTime21, (-62112150421990L));
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) (byte) 0, locale25);
        int int28 = skipDateTimeField11.get(10L);
        org.joda.time.DurationField durationField29 = skipDateTimeField11.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone30);
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.ReadableInstant readableInstant34 = null;
        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant33, readableInstant34);
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) ' ', chronology35);
        boolean boolean38 = dateTime36.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime39 = dateTime36.toLocalDateTime();
        int[] intArray41 = julianChronology31.get((org.joda.time.ReadablePartial) localDateTime39, (-62112150421990L));
        boolean boolean42 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime39);
        java.util.Locale locale43 = null;
        java.lang.String str44 = skipDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDateTime39, locale43);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(julianChronology31);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(localDateTime39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "32" + "'", str44.equals("32"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gJChronology0.add(readablePeriod1, (-99948L), 10);
        org.joda.time.DurationField durationField5 = gJChronology0.millis();
        org.joda.time.DurationField durationField6 = gJChronology0.halfdays();
        long long9 = durationField6.subtract((long) 1, (-99948));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-99948L) + "'", long4 == (-99948L));
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 4317753600001L + "'", long9 == 4317753600001L);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        long long15 = skipDateTimeField11.remainder((long) 100);
        long long18 = skipDateTimeField11.set((-3198336L), 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.append(dateTimeFormatter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        long long35 = gJChronology27.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology36.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField37);
        long long41 = skipDateTimeField38.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipDateTimeField38.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder26.appendDecimal(dateTimeFieldType42, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone46);
        java.lang.String str48 = julianChronology47.toString();
        org.joda.time.DurationField durationField49 = julianChronology47.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField49);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType42, 31);
        int int53 = offsetDateTimeField52.getMinimumValue();
        long long56 = offsetDateTimeField52.getDifferenceAsLong((long) (-10), (-1L));
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = offsetDateTimeField52.getType();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3198991L) + "'", long18 == (-3198991L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62112178799990L) + "'", long35 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1960L) + "'", long41 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "JulianChronology[UTC]" + "'", str48.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 32 + "'", int53 == 32);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-9L) + "'", long56 == (-9L));
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gJChronology0.add(readablePeriod1, (-99948L), 10);
        org.joda.time.DurationField durationField5 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology0.year();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-99948L) + "'", long4 == (-99948L));
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField18);
        long long22 = skipDateTimeField19.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType23, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        java.lang.String str29 = julianChronology28.toString();
        org.joda.time.DurationField durationField30 = julianChronology28.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField31.getRangeDurationField();
        long long35 = unsupportedDateTimeField31.add((long) (short) 10, (long) 10);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
        long long44 = gJChronology36.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField46 = gJChronology45.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField47 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology36, dateTimeField46);
        java.lang.String str49 = skipDateTimeField47.getAsText((long) (byte) 100);
        org.joda.time.ReadableInstant readableInstant51 = null;
        org.joda.time.ReadableInstant readableInstant52 = null;
        org.joda.time.Chronology chronology53 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant51, readableInstant52);
        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((long) ' ', chronology53);
        int int55 = dateTime54.getHourOfDay();
        org.joda.time.DateTime dateTime57 = dateTime54.withYear((int) (short) -1);
        java.lang.String str58 = dateTime54.toString();
        int int59 = dateTime54.getEra();
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.DateTime dateTime61 = dateTime54.toDateTime(dateTimeZone60);
        org.joda.time.DateTime dateTime63 = dateTime54.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone64 = dateTime63.getZone();
        org.joda.time.ReadableInstant readableInstant66 = null;
        org.joda.time.ReadableInstant readableInstant67 = null;
        org.joda.time.Chronology chronology68 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant66, readableInstant67);
        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime((long) ' ', chronology68);
        boolean boolean71 = dateTime69.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime72 = dateTime69.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant74 = null;
        org.joda.time.ReadableInstant readableInstant75 = null;
        org.joda.time.Chronology chronology76 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant74, readableInstant75);
        org.joda.time.DateTime dateTime77 = new org.joda.time.DateTime((long) ' ', chronology76);
        boolean boolean79 = dateTime77.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime80 = dateTime77.toLocalDateTime();
        org.joda.time.DateTime dateTime81 = dateTime69.withFields((org.joda.time.ReadablePartial) localDateTime80);
        boolean boolean82 = dateTimeZone64.isLocalDateTimeGap(localDateTime80);
        java.util.Locale locale83 = null;
        java.lang.String str84 = skipDateTimeField47.getAsShortText((org.joda.time.ReadablePartial) localDateTime80, locale83);
        try {
            int int85 = unsupportedDateTimeField31.getMaximumValue((org.joda.time.ReadablePartial) localDateTime80);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112178799990L) + "'", long16 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1960L) + "'", long22 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JulianChronology[UTC]" + "'", str29.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 600010L + "'", long35 == 600010L);
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-62112178799990L) + "'", long44 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "100" + "'", str49.equals("100"));
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str58.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTimeZone64);
        org.junit.Assert.assertNotNull(chronology68);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(localDateTime72);
        org.junit.Assert.assertNotNull(chronology76);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(localDateTime80);
        org.junit.Assert.assertNotNull(dateTime81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "32" + "'", str84.equals("32"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.secondOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        mutableDateTime2.add(readableDuration4);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant7, readableInstant8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) ' ', chronology9);
        int int11 = dateTime10.getHourOfDay();
        org.joda.time.DateTime dateTime13 = dateTime10.withYear((int) (short) -1);
        java.lang.String str14 = dateTime10.toString();
        mutableDateTime2.setMillis((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime2.year();
        java.util.Locale locale17 = null;
        int int18 = property16.getMaximumTextLength(locale17);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str14.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        boolean boolean9 = dateTime4.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) ' ', chronology13);
        int int15 = dateTime14.getHourOfDay();
        org.joda.time.DateTime dateTime17 = dateTime14.withYear((int) (short) -1);
        java.lang.String str18 = dateTime14.toString();
        int int19 = dateTime14.getEra();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime14.toDateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime14.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone24 = dateTime23.getZone();
        org.joda.time.DateTime dateTime25 = dateTime4.toDateTime(dateTimeZone24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime27 = dateTime4.plus(readablePeriod26);
        int int28 = dateTime27.getDayOfWeek();
        org.joda.time.DateTime dateTime30 = dateTime27.plusSeconds(0);
        try {
            org.joda.time.DateTime dateTime32 = dateTime30.withDayOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str18.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(dateTime30);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gJChronology0.add(readablePeriod1, (-99948L), 10);
        org.joda.time.DurationField durationField5 = gJChronology0.millis();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField7 = new org.joda.time.field.DecoratedDurationField(durationField5, durationFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-99948L) + "'", long4 == (-99948L));
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) ' ', chronology5);
        boolean boolean8 = dateTime6.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime9 = dateTime6.toLocalDateTime();
        boolean boolean11 = dateTime6.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) ' ', chronology15);
        int int17 = dateTime16.getHourOfDay();
        org.joda.time.DateTime dateTime19 = dateTime16.withYear((int) (short) -1);
        java.lang.String str20 = dateTime16.toString();
        int int21 = dateTime16.getEra();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime16.toDateTime(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime16.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone26 = dateTime25.getZone();
        org.joda.time.DateTime dateTime27 = dateTime6.toDateTime(dateTimeZone26);
        org.joda.time.Chronology chronology28 = julianChronology1.withZone(dateTimeZone26);
        org.joda.time.DurationField durationField29 = julianChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology1.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.MutableDateTime mutableDateTime33 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone32);
        mutableDateTime33.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property36 = mutableDateTime33.monthOfYear();
        mutableDateTime33.setDayOfYear((int) 'a');
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod40 = null;
        long long43 = gJChronology39.add(readablePeriod40, (-99948L), 10);
        org.joda.time.DateTime dateTime44 = mutableDateTime33.toDateTime((org.joda.time.Chronology) gJChronology39);
        int int45 = mutableDateTime33.getRoundingMode();
        mutableDateTime33.setYear(100);
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.chrono.JulianChronology julianChronology49 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone48);
        org.joda.time.ReadableInstant readableInstant51 = null;
        org.joda.time.ReadableInstant readableInstant52 = null;
        org.joda.time.Chronology chronology53 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant51, readableInstant52);
        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((long) ' ', chronology53);
        boolean boolean56 = dateTime54.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime57 = dateTime54.toLocalDateTime();
        boolean boolean59 = dateTime54.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant61 = null;
        org.joda.time.ReadableInstant readableInstant62 = null;
        org.joda.time.Chronology chronology63 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant61, readableInstant62);
        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime((long) ' ', chronology63);
        int int65 = dateTime64.getHourOfDay();
        org.joda.time.DateTime dateTime67 = dateTime64.withYear((int) (short) -1);
        java.lang.String str68 = dateTime64.toString();
        int int69 = dateTime64.getEra();
        org.joda.time.DateTimeZone dateTimeZone70 = null;
        org.joda.time.DateTime dateTime71 = dateTime64.toDateTime(dateTimeZone70);
        org.joda.time.DateTime dateTime73 = dateTime64.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone74 = dateTime73.getZone();
        org.joda.time.DateTime dateTime75 = dateTime54.toDateTime(dateTimeZone74);
        org.joda.time.Chronology chronology76 = julianChronology49.withZone(dateTimeZone74);
        org.joda.time.chrono.BuddhistChronology buddhistChronology77 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone74);
        mutableDateTime33.setZoneRetainFields(dateTimeZone74);
        org.joda.time.chrono.ZonedChronology zonedChronology79 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology1, dateTimeZone74);
        java.lang.String str80 = zonedChronology79.toString();
        org.joda.time.MutableDateTime mutableDateTime81 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) zonedChronology79);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str20.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-99948L) + "'", long43 == (-99948L));
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(julianChronology49);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(localDateTime57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(chronology63);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str68.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertNotNull(dateTimeZone74);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertNotNull(chronology76);
        org.junit.Assert.assertNotNull(buddhistChronology77);
        org.junit.Assert.assertNotNull(zonedChronology79);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "ZonedChronology[JulianChronology[UTC], UTC]" + "'", str80.equals("ZonedChronology[JulianChronology[UTC], UTC]"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder5.addCutover(1, 'a', 100, 69, (-28800000), true, (int) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTimeZoneBuilder5.toDateTimeZone("12/31/69", false);
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(2, (int) (byte) 10, 28800000, 961, (-4), dateTimeZone16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 961 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) ' ', chronology5);
        boolean boolean8 = dateTime6.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime9 = dateTime6.toLocalDateTime();
        boolean boolean11 = dateTime6.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) ' ', chronology15);
        int int17 = dateTime16.getHourOfDay();
        org.joda.time.DateTime dateTime19 = dateTime16.withYear((int) (short) -1);
        java.lang.String str20 = dateTime16.toString();
        int int21 = dateTime16.getEra();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime16.toDateTime(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime16.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone26 = dateTime25.getZone();
        org.joda.time.DateTime dateTime27 = dateTime6.toDateTime(dateTimeZone26);
        org.joda.time.Chronology chronology28 = julianChronology1.withZone(dateTimeZone26);
        org.joda.time.DurationField durationField29 = julianChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology1.millisOfDay();
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance();
        long long39 = gJChronology31.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = gJChronology40.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField42 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology31, dateTimeField41);
        org.joda.time.DateTimeField dateTimeField43 = gJChronology31.minuteOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField45 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField43, 57600);
        int int46 = skipUndoDateTimeField45.getMinimumValue();
        try {
            long long49 = skipUndoDateTimeField45.set((long) 31, 1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for minuteOfDay must be in the range [1,1439]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str20.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-62112178799990L) + "'", long39 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.monthOfYear();
        mutableDateTime2.setDayOfYear((int) 'a');
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        long long12 = gJChronology8.add(readablePeriod9, (-99948L), 10);
        org.joda.time.DateTime dateTime13 = mutableDateTime2.toDateTime((org.joda.time.Chronology) gJChronology8);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime2.minuteOfHour();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime2.weekOfWeekyear();
        org.joda.time.MutableDateTime mutableDateTime16 = property15.roundCeiling();
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-99948L) + "'", long12 == (-99948L));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        try {
            long long2 = dateTimeFormatter0.parseMillis("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime4.minuteOfHour();
        org.joda.time.DateTime dateTime13 = property12.getDateTime();
        int int14 = property12.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str8.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) ' ', chronology6);
        int int8 = dateTime7.getHourOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withYear((int) (short) -1);
        java.lang.String str11 = dateTime7.toString();
        int int12 = dateTime7.getEra();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = dateTime7.toDateTime(dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime7.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone17 = dateTime16.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance(chronology2, dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField19 = zonedChronology18.secondOfDay();
        try {
            long long27 = zonedChronology18.getDateTimeMillis(57600032, (int) ' ', 69, 0, (int) (byte) 0, 960, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str11.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology5.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.Chronology chronology10 = gJChronology5.withZone(dateTimeZone8);
        org.joda.time.DurationField durationField11 = gJChronology5.halfdays();
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(0, 100, 1, (int) (byte) 0, (-99948), (org.joda.time.Chronology) gJChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -99948 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        boolean boolean20 = dateTime18.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        int[] intArray23 = julianChronology13.get((org.joda.time.ReadablePartial) localDateTime21, (-62112150421990L));
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) (byte) 0, locale25);
        int int28 = skipDateTimeField11.get(10L);
        int int29 = skipDateTimeField11.getMaximumValue();
        boolean boolean31 = skipDateTimeField11.isLeap((long) (byte) 0);
        long long33 = skipDateTimeField11.roundFloor((long) (byte) -1);
        org.joda.time.DurationField durationField34 = skipDateTimeField11.getLeapDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 999 + "'", int29 == 999);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1L) + "'", long33 == (-1L));
        org.junit.Assert.assertNull(durationField34);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        int int6 = dateTime4.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime4.secondOfDay();
        int int8 = property7.getMaximumValue();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 86399 + "'", int8 == 86399);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfDay((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) '#', (int) '4');
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder3.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendOptional(dateTimeParser7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (short) 1, 960);
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendFractionOfMinute((int) '#', (int) '4');
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatterBuilder13.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder13.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap19 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder13.appendTimeZoneName(strMap19);
        org.joda.time.format.DateTimeParser dateTimeParser21 = dateTimeFormatterBuilder20.toParser();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder0.append(dateTimePrinter12, dateTimeParser21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(strMap19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeParser21);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setWeekOfWeekyear((int) ' ');
        int int5 = mutableDateTime2.getSecondOfMinute();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        mutableDateTime2.add(readablePeriod6);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        boolean boolean9 = dateTime4.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) ' ', chronology13);
        int int15 = dateTime14.getHourOfDay();
        org.joda.time.DateTime dateTime17 = dateTime14.withYear((int) (short) -1);
        java.lang.String str18 = dateTime14.toString();
        int int19 = dateTime14.getEra();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime14.toDateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime14.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone24 = dateTime23.getZone();
        org.joda.time.DateTime dateTime25 = dateTime4.toDateTime(dateTimeZone24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime27 = dateTime4.plus(readablePeriod26);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone29);
        mutableDateTime30.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property33 = mutableDateTime30.era();
        org.joda.time.MutableDateTime.Property property34 = mutableDateTime30.monthOfYear();
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        mutableDateTime30.add(readablePeriod35);
        boolean boolean37 = dateTime4.isEqual((org.joda.time.ReadableInstant) mutableDateTime30);
        mutableDateTime30.setMillisOfSecond(31);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str18.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) ' ', chronology11);
        boolean boolean14 = dateTime12.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime15 = dateTime12.toLocalDateTime();
        boolean boolean17 = dateTime12.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant19, readableInstant20);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) ' ', chronology21);
        int int23 = dateTime22.getHourOfDay();
        org.joda.time.DateTime dateTime25 = dateTime22.withYear((int) (short) -1);
        java.lang.String str26 = dateTime22.toString();
        int int27 = dateTime22.getEra();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = dateTime22.toDateTime(dateTimeZone28);
        org.joda.time.DateTime dateTime31 = dateTime22.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
        org.joda.time.DateTime dateTime33 = dateTime12.toDateTime(dateTimeZone32);
        org.joda.time.Chronology chronology34 = julianChronology7.withZone(dateTimeZone32);
        org.joda.time.chrono.BuddhistChronology buddhistChronology35 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone32);
        try {
            org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((int) (short) 1, 961, (int) '#', 4, (-99948), 1969, (org.joda.time.Chronology) buddhistChronology35);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 961 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str26.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(buddhistChronology35);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) ' ', (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) (byte) 10, 16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendTwoDigitYear(0, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.seconds();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gJChronology0.add(readablePeriod2, (long) 2169, (int) '#');
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2169L + "'", long5 == 2169L);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(28800000L);
        org.joda.time.Instant instant4 = instant1.withDurationAdded(0L, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.Integer int6 = dateTimeFormatter5.getPivotYear();
        java.util.Locale locale7 = dateTimeFormatter5.getLocale();
        java.lang.String str8 = instant1.toString(dateTimeFormatter5);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology9.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        org.joda.time.Chronology chronology14 = gJChronology9.withZone(dateTimeZone12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter5.withZone(dateTimeZone12);
        java.lang.StringBuffer stringBuffer16 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant18, readableInstant19);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) ' ', chronology20);
        int int22 = dateTime21.getHourOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withYear((int) (short) -1);
        java.lang.String str25 = dateTime21.toString();
        int int26 = dateTime21.getEra();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = dateTime21.toDateTime(dateTimeZone27);
        org.joda.time.DateTime dateTime30 = dateTime21.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone31 = dateTime30.getZone();
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.ReadableInstant readableInstant34 = null;
        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant33, readableInstant34);
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) ' ', chronology35);
        boolean boolean38 = dateTime36.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime39 = dateTime36.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant41 = null;
        org.joda.time.ReadableInstant readableInstant42 = null;
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant41, readableInstant42);
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) ' ', chronology43);
        boolean boolean46 = dateTime44.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime47 = dateTime44.toLocalDateTime();
        org.joda.time.DateTime dateTime48 = dateTime36.withFields((org.joda.time.ReadablePartial) localDateTime47);
        boolean boolean49 = dateTimeZone31.isLocalDateTimeGap(localDateTime47);
        try {
            dateTimeFormatter5.printTo(stringBuffer16, (org.joda.time.ReadablePartial) localDateTime47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(int6);
        org.junit.Assert.assertNull(locale7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970001T080000.000Z" + "'", str8.equals("1970001T080000.000Z"));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str25.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(localDateTime39);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(localDateTime47);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField18);
        long long22 = skipDateTimeField19.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType23, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant30, readableInstant31);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) ' ', chronology32);
        boolean boolean35 = dateTime33.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime36 = dateTime33.toLocalDateTime();
        boolean boolean38 = dateTime33.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant40 = null;
        org.joda.time.ReadableInstant readableInstant41 = null;
        org.joda.time.Chronology chronology42 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant40, readableInstant41);
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((long) ' ', chronology42);
        int int44 = dateTime43.getHourOfDay();
        org.joda.time.DateTime dateTime46 = dateTime43.withYear((int) (short) -1);
        java.lang.String str47 = dateTime43.toString();
        int int48 = dateTime43.getEra();
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.DateTime dateTime50 = dateTime43.toDateTime(dateTimeZone49);
        org.joda.time.DateTime dateTime52 = dateTime43.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone53 = dateTime52.getZone();
        org.joda.time.DateTime dateTime54 = dateTime33.toDateTime(dateTimeZone53);
        org.joda.time.Chronology chronology55 = julianChronology28.withZone(dateTimeZone53);
        org.joda.time.DurationField durationField56 = julianChronology28.seconds();
        org.joda.time.DurationField durationField57 = julianChronology28.centuries();
        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod59 = null;
        long long62 = gJChronology58.add(readablePeriod59, (-99948L), 10);
        org.joda.time.DurationField durationField63 = gJChronology58.millis();
        org.joda.time.DateTimeField dateTimeField64 = gJChronology58.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField65 = gJChronology58.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField66 = gJChronology58.minuteOfDay();
        org.joda.time.DurationField durationField67 = gJChronology58.seconds();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField68 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType23, durationField57, durationField67);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112178799990L) + "'", long16 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1960L) + "'", long22 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(localDateTime36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str47.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(chronology55);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertNotNull(durationField57);
        org.junit.Assert.assertNotNull(gJChronology58);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-99948L) + "'", long62 == (-99948L));
        org.junit.Assert.assertNotNull(durationField63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(durationField67);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1.0d, number2, (java.lang.Number) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        boolean boolean20 = dateTime18.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        int[] intArray23 = julianChronology13.get((org.joda.time.ReadablePartial) localDateTime21, (-62112150421990L));
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) (byte) 0, locale25);
        int int28 = skipDateTimeField11.get(10L);
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
        long long37 = gJChronology29.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField39 = gJChronology38.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField40 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology29, dateTimeField39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.ReadableInstant readableInstant44 = null;
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.Chronology chronology46 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant44, readableInstant45);
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) ' ', chronology46);
        boolean boolean49 = dateTime47.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime50 = dateTime47.toLocalDateTime();
        int[] intArray52 = julianChronology42.get((org.joda.time.ReadablePartial) localDateTime50, (-62112150421990L));
        java.util.Locale locale54 = null;
        java.lang.String str55 = skipDateTimeField40.getAsShortText((org.joda.time.ReadablePartial) localDateTime50, (int) (byte) 0, locale54);
        java.util.Locale locale56 = null;
        java.lang.String str57 = skipDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDateTime50, locale56);
        java.util.Locale locale59 = null;
        java.lang.String str60 = skipDateTimeField11.getAsText((long) ' ', locale59);
        int int62 = skipDateTimeField11.getMaximumValue((long) 999);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-62112178799990L) + "'", long37 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(chronology46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(localDateTime50);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "0" + "'", str55.equals("0"));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "32" + "'", str57.equals("32"));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "32" + "'", str60.equals("32"));
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 999 + "'", int62 == 999);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (byte) 100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        boolean boolean9 = dateTime4.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) ' ', chronology13);
        int int15 = dateTime14.getHourOfDay();
        org.joda.time.DateTime dateTime17 = dateTime14.withYear((int) (short) -1);
        java.lang.String str18 = dateTime14.toString();
        int int19 = dateTime14.getEra();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime14.toDateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime14.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone24 = dateTime23.getZone();
        org.joda.time.DateTime dateTime25 = dateTime4.toDateTime(dateTimeZone24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime27 = dateTime4.plus(readablePeriod26);
        int int28 = dateTime27.getDayOfWeek();
        org.joda.time.DateTime dateTime30 = dateTime27.plusSeconds(0);
        org.joda.time.DateTime dateTime32 = dateTime30.plusHours(0);
        org.joda.time.Chronology chronology33 = dateTime30.getChronology();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str18.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(chronology33);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter1.withZoneUTC();
        java.io.Writer writer3 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, readableInstant6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) ' ', chronology7);
        boolean boolean10 = dateTime8.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime11 = dateTime8.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) ' ', chronology15);
        boolean boolean18 = dateTime16.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime19 = dateTime16.toLocalDateTime();
        org.joda.time.DateTime dateTime20 = dateTime8.withFields((org.joda.time.ReadablePartial) localDateTime19);
        try {
            dateTimeFormatter1.printTo(writer3, (org.joda.time.ReadablePartial) localDateTime19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(localDateTime11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(localDateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "era", (int) (short) -1, (int) '#');
        long long6 = fixedDateTimeZone4.nextTransition((long) 200);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        java.lang.String str9 = fixedDateTimeZone4.getNameKey((-28799999L));
        java.util.TimeZone timeZone10 = fixedDateTimeZone4.toTimeZone();
        boolean boolean11 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 200L + "'", long6 == 200L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "era" + "'", str9.equals("era"));
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.monthOfYear();
        mutableDateTime2.setDayOfYear((int) 'a');
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        long long12 = gJChronology8.add(readablePeriod9, (-99948L), 10);
        org.joda.time.DateTime dateTime13 = mutableDateTime2.toDateTime((org.joda.time.Chronology) gJChronology8);
        int int14 = mutableDateTime2.getRoundingMode();
        mutableDateTime2.setYear(100);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant20, readableInstant21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) ' ', chronology22);
        boolean boolean25 = dateTime23.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime26 = dateTime23.toLocalDateTime();
        boolean boolean28 = dateTime23.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant30, readableInstant31);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) ' ', chronology32);
        int int34 = dateTime33.getHourOfDay();
        org.joda.time.DateTime dateTime36 = dateTime33.withYear((int) (short) -1);
        java.lang.String str37 = dateTime33.toString();
        int int38 = dateTime33.getEra();
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.DateTime dateTime40 = dateTime33.toDateTime(dateTimeZone39);
        org.joda.time.DateTime dateTime42 = dateTime33.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone43 = dateTime42.getZone();
        org.joda.time.DateTime dateTime44 = dateTime23.toDateTime(dateTimeZone43);
        org.joda.time.Chronology chronology45 = julianChronology18.withZone(dateTimeZone43);
        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone43);
        mutableDateTime2.setZoneRetainFields(dateTimeZone43);
        org.joda.time.MutableDateTime.Property property48 = mutableDateTime2.yearOfCentury();
        mutableDateTime2.setYear((int) (short) -1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-99948L) + "'", long12 == (-99948L));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(localDateTime26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str37.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertNotNull(buddhistChronology46);
        org.junit.Assert.assertNotNull(property48);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime4.minusSeconds(16);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance();
        long long22 = gJChronology14.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology14, dateTimeField24);
        long long28 = skipDateTimeField25.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = skipDateTimeField25.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, "1970-01-01T08:00:00.000Z");
        int int32 = dateTime4.get(dateTimeFieldType29);
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
        long long41 = gJChronology33.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField43 = gJChronology42.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology33, dateTimeField43);
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.chrono.JulianChronology julianChronology46 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone45);
        org.joda.time.ReadableInstant readableInstant48 = null;
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.Chronology chronology50 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant48, readableInstant49);
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) ' ', chronology50);
        boolean boolean53 = dateTime51.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime54 = dateTime51.toLocalDateTime();
        int[] intArray56 = julianChronology46.get((org.joda.time.ReadablePartial) localDateTime54, (-62112150421990L));
        java.util.Locale locale58 = null;
        java.lang.String str59 = skipDateTimeField44.getAsShortText((org.joda.time.ReadablePartial) localDateTime54, (int) (byte) 0, locale58);
        int int61 = skipDateTimeField44.get(10L);
        org.joda.time.DurationField durationField62 = skipDateTimeField44.getDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField63 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType29, durationField62);
        try {
            int int64 = unsupportedDateTimeField63.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str8.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-62112178799990L) + "'", long22 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-1960L) + "'", long28 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 32 + "'", int32 == 32);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-62112178799990L) + "'", long41 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(julianChronology46);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(localDateTime54);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "0" + "'", str59.equals("0"));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField63);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(28800000L);
        org.joda.time.Instant instant4 = instant1.withDurationAdded(0L, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.Integer int6 = dateTimeFormatter5.getPivotYear();
        java.util.Locale locale7 = dateTimeFormatter5.getLocale();
        java.lang.String str8 = instant1.toString(dateTimeFormatter5);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Instant instant10 = instant1.minus(readableDuration9);
        org.joda.time.Instant instant11 = instant10.toInstant();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.Instant instant14 = instant10.withDurationAdded(readableDuration12, 200);
        org.joda.time.DateTime dateTime15 = instant10.toDateTime();
        long long16 = instant10.getMillis();
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(int6);
        org.junit.Assert.assertNull(locale7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970001T080000.000Z" + "'", str8.equals("1970001T080000.000Z"));
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertNotNull(instant14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28800000L + "'", long16 == 28800000L);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.era();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.addWrapField((-10));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.weekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "era", (int) (short) -1, (int) '#');
        long long16 = fixedDateTimeZone14.nextTransition((long) 200);
        boolean boolean17 = fixedDateTimeZone14.isFixed();
        java.lang.String str19 = fixedDateTimeZone14.getNameKey((-28799999L));
        java.util.TimeZone timeZone20 = fixedDateTimeZone14.toTimeZone();
        org.joda.time.MutableDateTime mutableDateTime21 = mutableDateTime8.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        try {
            mutableDateTime21.setWeekOfWeekyear((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200L + "'", long16 == 200L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "era" + "'", str19.equals("era"));
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(mutableDateTime21);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 0, (org.joda.time.Chronology) gJChronology1, locale2, (java.lang.Integer) 0, 16);
        long long7 = dateTimeParserBucket5.computeMillis(true);
        org.joda.time.Chronology chronology8 = dateTimeParserBucket5.getChronology();
        long long10 = dateTimeParserBucket5.computeMillis(false);
        org.joda.time.Chronology chronology11 = dateTimeParserBucket5.getChronology();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.addWeeks((int) (byte) 0);
        mutableDateTime2.addDays((int) (short) -1);
        mutableDateTime2.addMillis(16);
        mutableDateTime2.add((long) 999);
        mutableDateTime2.addYears((int) 'a');
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        int int15 = skipDateTimeField11.get(0L);
        org.joda.time.DurationField durationField16 = skipDateTimeField11.getDurationField();
        int int18 = skipDateTimeField11.get((long) (-10));
        int int20 = skipDateTimeField11.get(36L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 990 + "'", int18 == 990);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 36 + "'", int20 == 36);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendYearOfCentury(960, 16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter11.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatter13.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendSecondOfDay((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendFractionOfMinute((int) '#', (int) '4');
        org.joda.time.format.DateTimeParser dateTimeParser22 = dateTimeFormatterBuilder18.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder15.appendOptional(dateTimeParser22);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter14, dateTimeParser22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder10.append(dateTimePrinter14);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder10.appendYear((int) '4', (int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimePrinter14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeParser22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        boolean boolean9 = dateTime4.isAfter((-99948L));
        org.joda.time.DateTime.Property property10 = dateTime4.secondOfDay();
        int int11 = property10.getMinimumValueOverall();
        java.lang.String str12 = property10.toString();
        org.joda.time.DateTime dateTime14 = property10.setCopy(16);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone16);
        mutableDateTime17.addWeeks((int) (byte) 0);
        mutableDateTime17.addDays((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(0L, dateTimeZone24);
        mutableDateTime17.setZoneRetainFields(dateTimeZone24);
        try {
            org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((java.lang.Object) 16, dateTimeZone24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Property[secondOfDay]" + "'", str12.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone24);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        mutableDateTime2.addDays(1);
        int int7 = mutableDateTime2.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) ' ', chronology5);
        boolean boolean8 = dateTime6.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime9 = dateTime6.toLocalDateTime();
        boolean boolean11 = dateTime6.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) ' ', chronology15);
        int int17 = dateTime16.getHourOfDay();
        org.joda.time.DateTime dateTime19 = dateTime16.withYear((int) (short) -1);
        java.lang.String str20 = dateTime16.toString();
        int int21 = dateTime16.getEra();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime16.toDateTime(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime16.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone26 = dateTime25.getZone();
        org.joda.time.DateTime dateTime27 = dateTime6.toDateTime(dateTimeZone26);
        org.joda.time.Chronology chronology28 = julianChronology1.withZone(dateTimeZone26);
        org.joda.time.DurationField durationField29 = julianChronology1.seconds();
        org.joda.time.DurationField durationField30 = julianChronology1.centuries();
        org.joda.time.DateTimeField dateTimeField31 = julianChronology1.hourOfDay();
        try {
            long long39 = julianChronology1.getDateTimeMillis(86399, 12, (-4), 200, (-10), 990, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 200 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str20.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        int int10 = dateTime4.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone12);
        mutableDateTime13.addWeeks((int) (byte) 0);
        mutableDateTime13.addDays((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(0L, dateTimeZone20);
        mutableDateTime13.setZoneRetainFields(dateTimeZone20);
        org.joda.time.MutableDateTime mutableDateTime23 = org.joda.time.MutableDateTime.now(dateTimeZone20);
        org.joda.time.MutableDateTime mutableDateTime24 = dateTime4.toMutableDateTime(dateTimeZone20);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str8.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(mutableDateTime24);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField18);
        long long22 = skipDateTimeField19.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType23, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        java.lang.String str29 = julianChronology28.toString();
        org.joda.time.DurationField durationField30 = julianChronology28.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        try {
            int int32 = unsupportedDateTimeField31.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112178799990L) + "'", long16 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1960L) + "'", long22 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JulianChronology[UTC]" + "'", str29.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gJChronology1.withZone(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(obj0, dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone9);
        mutableDateTime10.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime10.era();
        java.lang.String str14 = property13.getName();
        org.joda.time.MutableDateTime mutableDateTime15 = property13.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime16 = property13.roundHalfCeiling();
        int int17 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) mutableDateTime16);
        int int18 = mutableDateTime16.getEra();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "era" + "'", str14.equals("era"));
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        long long15 = skipDateTimeField11.remainder((long) 100);
        long long18 = skipDateTimeField11.set((-3198336L), 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.append(dateTimeFormatter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        long long35 = gJChronology27.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology36.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField37);
        long long41 = skipDateTimeField38.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipDateTimeField38.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder26.appendDecimal(dateTimeFieldType42, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone46);
        java.lang.String str48 = julianChronology47.toString();
        org.joda.time.DurationField durationField49 = julianChronology47.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField49);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType42, 31);
        org.joda.time.ReadablePartial readablePartial53 = null;
        java.util.Locale locale55 = null;
        java.lang.String str56 = offsetDateTimeField52.getAsText(readablePartial53, 16, locale55);
        org.joda.time.DateTimeZone dateTimeZone57 = null;
        org.joda.time.chrono.JulianChronology julianChronology58 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone57);
        org.joda.time.ReadableInstant readableInstant60 = null;
        org.joda.time.ReadableInstant readableInstant61 = null;
        org.joda.time.Chronology chronology62 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant60, readableInstant61);
        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime((long) ' ', chronology62);
        boolean boolean65 = dateTime63.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime66 = dateTime63.toLocalDateTime();
        int[] intArray68 = julianChronology58.get((org.joda.time.ReadablePartial) localDateTime66, (-62112150421990L));
        java.util.Locale locale69 = null;
        java.lang.String str70 = offsetDateTimeField52.getAsShortText((org.joda.time.ReadablePartial) localDateTime66, locale69);
        org.joda.time.chrono.GJChronology gJChronology71 = org.joda.time.chrono.GJChronology.getInstance();
        long long79 = gJChronology71.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology80 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField81 = gJChronology80.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField82 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology71, dateTimeField81);
        org.joda.time.ReadableInstant readableInstant84 = null;
        org.joda.time.ReadableInstant readableInstant85 = null;
        org.joda.time.Chronology chronology86 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant84, readableInstant85);
        org.joda.time.DateTime dateTime87 = new org.joda.time.DateTime((long) ' ', chronology86);
        boolean boolean89 = dateTime87.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime90 = dateTime87.toLocalDateTime();
        java.util.Locale locale91 = null;
        java.lang.String str92 = skipDateTimeField82.getAsText((org.joda.time.ReadablePartial) localDateTime90, locale91);
        int int93 = offsetDateTimeField52.getMinimumValue((org.joda.time.ReadablePartial) localDateTime90);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3198991L) + "'", long18 == (-3198991L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62112178799990L) + "'", long35 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1960L) + "'", long41 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "JulianChronology[UTC]" + "'", str48.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "16" + "'", str56.equals("16"));
        org.junit.Assert.assertNotNull(julianChronology58);
        org.junit.Assert.assertNotNull(chronology62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(localDateTime66);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "32" + "'", str70.equals("32"));
        org.junit.Assert.assertNotNull(gJChronology71);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + (-62112178799990L) + "'", long79 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology80);
        org.junit.Assert.assertNotNull(dateTimeField81);
        org.junit.Assert.assertNotNull(chronology86);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(localDateTime90);
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "32" + "'", str92.equals("32"));
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 32 + "'", int93 == 32);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime4.minusSeconds(16);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance();
        long long22 = gJChronology14.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology14, dateTimeField24);
        long long28 = skipDateTimeField25.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = skipDateTimeField25.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, "1970-01-01T08:00:00.000Z");
        int int32 = dateTime4.get(dateTimeFieldType29);
        org.joda.time.DateTime.Property property33 = dateTime4.minuteOfDay();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str8.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-62112178799990L) + "'", long22 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-1960L) + "'", long28 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 32 + "'", int32 == 32);
        org.junit.Assert.assertNotNull(property33);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(28800000L);
        org.joda.time.Instant instant4 = instant1.withDurationAdded(0L, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.Integer int6 = dateTimeFormatter5.getPivotYear();
        java.util.Locale locale7 = dateTimeFormatter5.getLocale();
        java.lang.String str8 = instant1.toString(dateTimeFormatter5);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Instant instant10 = instant1.minus(readableDuration9);
        org.joda.time.Instant instant11 = instant10.toInstant();
        java.lang.String str12 = instant10.toString();
        org.joda.time.MutableDateTime mutableDateTime13 = instant10.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.dayOfYear();
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime13.weekOfWeekyear();
        mutableDateTime13.addMonths((int) '#');
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(int6);
        org.junit.Assert.assertNull(locale7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970001T080000.000Z" + "'", str8.equals("1970001T080000.000Z"));
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970-01-01T08:00:00.000Z" + "'", str12.equals("1970-01-01T08:00:00.000Z"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        boolean boolean20 = dateTime18.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        int[] intArray23 = julianChronology13.get((org.joda.time.ReadablePartial) localDateTime21, (-62112150421990L));
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) (byte) 0, locale25);
        int int28 = skipDateTimeField11.get(10L);
        org.joda.time.DateTimeField dateTimeField29 = skipDateTimeField11.getWrappedField();
        org.joda.time.DateTimeField dateTimeField30 = skipDateTimeField11.getWrappedField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField18);
        long long22 = skipDateTimeField19.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType23, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        java.lang.String str29 = julianChronology28.toString();
        org.joda.time.DurationField durationField30 = julianChronology28.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField31.getRangeDurationField();
        long long35 = unsupportedDateTimeField31.add((long) (short) 10, (long) 10);
        try {
            int int36 = unsupportedDateTimeField31.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112178799990L) + "'", long16 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1960L) + "'", long22 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JulianChronology[UTC]" + "'", str29.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 600010L + "'", long35 == 600010L);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.junit.Assert.assertNotNull(buddhistChronology0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, readableInstant11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) ' ', chronology12);
        boolean boolean15 = dateTime13.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime16 = dateTime13.toLocalDateTime();
        boolean boolean18 = dateTime13.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant20, readableInstant21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) ' ', chronology22);
        int int24 = dateTime23.getHourOfDay();
        org.joda.time.DateTime dateTime26 = dateTime23.withYear((int) (short) -1);
        java.lang.String str27 = dateTime23.toString();
        int int28 = dateTime23.getEra();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = dateTime23.toDateTime(dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime23.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone33 = dateTime32.getZone();
        org.joda.time.DateTime dateTime34 = dateTime13.toDateTime(dateTimeZone33);
        org.joda.time.Chronology chronology35 = julianChronology8.withZone(dateTimeZone33);
        try {
            org.joda.time.MutableDateTime mutableDateTime36 = new org.joda.time.MutableDateTime(990, (int) (byte) 100, (int) (byte) 100, (int) '4', 990, 0, (-4), dateTimeZone33);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(localDateTime16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str27.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(chronology35);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField18);
        long long22 = skipDateTimeField19.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType23, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        java.lang.String str29 = julianChronology28.toString();
        org.joda.time.DurationField durationField30 = julianChronology28.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField31.getRangeDurationField();
        long long35 = unsupportedDateTimeField31.add((long) (short) 10, (long) 10);
        java.util.Locale locale38 = null;
        try {
            long long39 = unsupportedDateTimeField31.set((long) '#', "16:00:00-08:00", locale38);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112178799990L) + "'", long16 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1960L) + "'", long22 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JulianChronology[UTC]" + "'", str29.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 600010L + "'", long35 == 600010L);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', chronology4);
        int int6 = dateTime5.getHourOfDay();
        int int7 = dateTime5.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime5.minusDays(10);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) ' ', chronology13);
        int int15 = dateTime14.getHourOfDay();
        org.joda.time.DateTime dateTime17 = dateTime14.withYear((int) (short) -1);
        java.lang.String str18 = dateTime14.toString();
        int int19 = dateTime14.getEra();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime14.toDateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime14.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone24 = dateTime23.getZone();
        long long27 = dateTimeZone24.adjustOffset(10L, false);
        org.joda.time.MutableDateTime mutableDateTime28 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime5, dateTimeZone24);
        org.joda.time.Chronology chronology29 = buddhistChronology0.withZone(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField30 = buddhistChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str18.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.MutableDateTime mutableDateTime9 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) ' ', chronology5);
        boolean boolean8 = dateTime6.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime9 = dateTime6.toLocalDateTime();
        boolean boolean11 = dateTime6.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) ' ', chronology15);
        int int17 = dateTime16.getHourOfDay();
        org.joda.time.DateTime dateTime19 = dateTime16.withYear((int) (short) -1);
        java.lang.String str20 = dateTime16.toString();
        int int21 = dateTime16.getEra();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime16.toDateTime(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime16.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone26 = dateTime25.getZone();
        org.joda.time.DateTime dateTime27 = dateTime6.toDateTime(dateTimeZone26);
        org.joda.time.Chronology chronology28 = julianChronology1.withZone(dateTimeZone26);
        org.joda.time.DurationField durationField29 = julianChronology1.seconds();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology1.millisOfDay();
        int int31 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField32 = julianChronology1.hours();
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
        long long41 = gJChronology33.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField43 = gJChronology42.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology33, dateTimeField43);
        java.lang.String str46 = skipDateTimeField44.getAsText((long) (byte) 100);
        long long48 = skipDateTimeField44.remainder((long) 100);
        long long51 = skipDateTimeField44.set((-3198336L), 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder52.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter54 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder53.append(dateTimeFormatter54);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder55.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder57.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology60 = org.joda.time.chrono.GJChronology.getInstance();
        long long68 = gJChronology60.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology69 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField70 = gJChronology69.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField71 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology60, dateTimeField70);
        long long74 = skipDateTimeField71.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = skipDateTimeField71.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = dateTimeFormatterBuilder59.appendDecimal(dateTimeFieldType75, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone79 = null;
        org.joda.time.chrono.JulianChronology julianChronology80 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone79);
        java.lang.String str81 = julianChronology80.toString();
        org.joda.time.DurationField durationField82 = julianChronology80.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField83 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType75, durationField82);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField85 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField44, dateTimeFieldType75, 31);
        java.util.Locale locale86 = null;
        int int87 = offsetDateTimeField85.getMaximumTextLength(locale86);
        long long89 = offsetDateTimeField85.roundHalfFloor((long) 73049);
        org.joda.time.field.SkipDateTimeField skipDateTimeField91 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, (org.joda.time.DateTimeField) offsetDateTimeField85, 365);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str20.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-62112178799990L) + "'", long41 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "100" + "'", str46.equals("100"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-3198991L) + "'", long51 == (-3198991L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(dateTimeFormatter54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(gJChronology60);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-62112178799990L) + "'", long68 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-1960L) + "'", long74 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder78);
        org.junit.Assert.assertNotNull(julianChronology80);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "JulianChronology[UTC]" + "'", str81.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField82);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField83);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 4 + "'", int87 == 4);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 73049L + "'", long89 == 73049L);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        boolean boolean20 = dateTime18.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        int[] intArray23 = julianChronology13.get((org.joda.time.ReadablePartial) localDateTime21, (-62112150421990L));
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) (byte) 0, locale25);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        long long35 = gJChronology27.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology36.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField37);
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.chrono.JulianChronology julianChronology40 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone39);
        org.joda.time.ReadableInstant readableInstant42 = null;
        org.joda.time.ReadableInstant readableInstant43 = null;
        org.joda.time.Chronology chronology44 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant42, readableInstant43);
        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((long) ' ', chronology44);
        boolean boolean47 = dateTime45.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime48 = dateTime45.toLocalDateTime();
        int[] intArray50 = julianChronology40.get((org.joda.time.ReadablePartial) localDateTime48, (-62112150421990L));
        java.util.Locale locale52 = null;
        java.lang.String str53 = skipDateTimeField38.getAsShortText((org.joda.time.ReadablePartial) localDateTime48, (int) (byte) 0, locale52);
        int int55 = skipDateTimeField38.get(10L);
        long long58 = skipDateTimeField38.add(33L, (long) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone59 = null;
        org.joda.time.ReadableInstant readableInstant61 = null;
        org.joda.time.ReadableInstant readableInstant62 = null;
        org.joda.time.Chronology chronology63 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant61, readableInstant62);
        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime((long) ' ', chronology63);
        int int65 = dateTime64.getHourOfDay();
        org.joda.time.DateTime dateTime67 = dateTime64.withYear((int) (short) -1);
        java.lang.String str68 = dateTime64.toString();
        int int69 = dateTime64.getEra();
        org.joda.time.DateTimeZone dateTimeZone70 = null;
        org.joda.time.DateTime dateTime71 = dateTime64.toDateTime(dateTimeZone70);
        org.joda.time.DateTime.Property property72 = dateTime64.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology73 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone59, (org.joda.time.ReadableInstant) dateTime64);
        org.joda.time.DateTime.Property property74 = dateTime64.monthOfYear();
        org.joda.time.ReadableInstant readableInstant76 = null;
        org.joda.time.ReadableInstant readableInstant77 = null;
        org.joda.time.Chronology chronology78 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant76, readableInstant77);
        org.joda.time.DateTime dateTime79 = new org.joda.time.DateTime((long) ' ', chronology78);
        boolean boolean81 = dateTime79.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime82 = dateTime79.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant84 = null;
        org.joda.time.ReadableInstant readableInstant85 = null;
        org.joda.time.Chronology chronology86 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant84, readableInstant85);
        org.joda.time.DateTime dateTime87 = new org.joda.time.DateTime((long) ' ', chronology86);
        boolean boolean89 = dateTime87.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime90 = dateTime87.toLocalDateTime();
        org.joda.time.DateTime dateTime91 = dateTime79.withFields((org.joda.time.ReadablePartial) localDateTime90);
        int int92 = property74.compareTo((org.joda.time.ReadablePartial) localDateTime90);
        java.util.Locale locale94 = null;
        java.lang.String str95 = skipDateTimeField38.getAsShortText((org.joda.time.ReadablePartial) localDateTime90, 12, locale94);
        java.util.Locale locale97 = null;
        java.lang.String str98 = skipDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDateTime90, 97, locale97);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62112178799990L) + "'", long35 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(julianChronology40);
        org.junit.Assert.assertNotNull(chronology44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(localDateTime48);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "0" + "'", str53.equals("0"));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 10 + "'", int55 == 10);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 43L + "'", long58 == 43L);
        org.junit.Assert.assertNotNull(chronology63);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str68.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(property72);
        org.junit.Assert.assertNotNull(gJChronology73);
        org.junit.Assert.assertNotNull(property74);
        org.junit.Assert.assertNotNull(chronology78);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(localDateTime82);
        org.junit.Assert.assertNotNull(chronology86);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(localDateTime90);
        org.junit.Assert.assertNotNull(dateTime91);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "12" + "'", str95.equals("12"));
        org.junit.Assert.assertTrue("'" + str98 + "' != '" + "97" + "'", str98.equals("97"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        long long14 = skipDateTimeField11.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipDateTimeField11.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.append(dateTimeFormatter18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        long long32 = gJChronology24.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField34 = gJChronology33.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField35 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology24, dateTimeField34);
        long long38 = skipDateTimeField35.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = skipDateTimeField35.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder23.appendDecimal(dateTimeFieldType39, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone43);
        java.lang.String str45 = julianChronology44.toString();
        org.joda.time.DurationField durationField46 = julianChronology44.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField47 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField46);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField48 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType15, durationField46);
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.ReadableInstant readableInstant51 = null;
        org.joda.time.Chronology chronology52 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant50, readableInstant51);
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) ' ', chronology52);
        boolean boolean55 = dateTime53.isBefore(10L);
        int int56 = dateTime53.getMinuteOfDay();
        org.joda.time.LocalDateTime localDateTime57 = dateTime53.toLocalDateTime();
        boolean boolean58 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime57);
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.chrono.JulianChronology julianChronology61 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone60);
        org.joda.time.ReadableInstant readableInstant63 = null;
        org.joda.time.ReadableInstant readableInstant64 = null;
        org.joda.time.Chronology chronology65 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant63, readableInstant64);
        org.joda.time.DateTime dateTime66 = new org.joda.time.DateTime((long) ' ', chronology65);
        boolean boolean68 = dateTime66.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime69 = dateTime66.toLocalDateTime();
        int[] intArray71 = julianChronology61.get((org.joda.time.ReadablePartial) localDateTime69, (-62112150421990L));
        try {
            int[] intArray73 = unsupportedDateTimeField48.addWrapPartial((org.joda.time.ReadablePartial) localDateTime57, (int) (short) 0, intArray71, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1960L) + "'", long14 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62112178799990L) + "'", long32 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-1960L) + "'", long38 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "JulianChronology[UTC]" + "'", str45.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField47);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField48);
        org.junit.Assert.assertNotNull(chronology52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(localDateTime57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(julianChronology61);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(localDateTime69);
        org.junit.Assert.assertNotNull(intArray71);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.era();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.monthOfYear();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        mutableDateTime2.add(readablePeriod7);
        int int9 = mutableDateTime2.getDayOfMonth();
        int int10 = mutableDateTime2.getMillisOfDay();
        org.joda.time.DateTime dateTime11 = mutableDateTime2.toDateTime();
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.era();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.addWrapField((-10));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.weekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "era", (int) (short) -1, (int) '#');
        long long16 = fixedDateTimeZone14.nextTransition((long) 200);
        boolean boolean17 = fixedDateTimeZone14.isFixed();
        java.lang.String str19 = fixedDateTimeZone14.getNameKey((-28799999L));
        java.util.TimeZone timeZone20 = fixedDateTimeZone14.toTimeZone();
        org.joda.time.MutableDateTime mutableDateTime21 = mutableDateTime8.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        try {
            org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone14, 57600);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 57600");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200L + "'", long16 == 200L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "era" + "'", str19.equals("era"));
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(mutableDateTime21);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        boolean boolean9 = dateTime4.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) ' ', chronology13);
        int int15 = dateTime14.getHourOfDay();
        org.joda.time.DateTime dateTime17 = dateTime14.withYear((int) (short) -1);
        java.lang.String str18 = dateTime14.toString();
        int int19 = dateTime14.getEra();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime14.toDateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime14.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone24 = dateTime23.getZone();
        org.joda.time.DateTime dateTime25 = dateTime4.toDateTime(dateTimeZone24);
        java.lang.String str26 = dateTimeZone24.getID();
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now(dateTimeZone24);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str18.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UTC" + "'", str26.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 0, (org.joda.time.Chronology) gJChronology1, locale2, (java.lang.Integer) 0, 16);
        long long7 = dateTimeParserBucket5.computeMillis(true);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField18);
        java.lang.String str21 = skipDateTimeField19.getAsText((long) (byte) 100);
        dateTimeParserBucket5.saveField((org.joda.time.DateTimeField) skipDateTimeField19, (int) (short) 100);
        java.lang.String str25 = skipDateTimeField19.getAsShortText((-998L));
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112178799990L) + "'", long16 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "100" + "'", str21.equals("100"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2" + "'", str25.equals("2"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.monthOfYear();
        mutableDateTime2.setDayOfYear((int) 'a');
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        long long12 = gJChronology8.add(readablePeriod9, (-99948L), 10);
        org.joda.time.DateTime dateTime13 = mutableDateTime2.toDateTime((org.joda.time.Chronology) gJChronology8);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime2.minuteOfHour();
        mutableDateTime2.setMinuteOfDay(0);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-99948L) + "'", long12 == (-99948L));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "Property[millisOfSecond]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gJChronology0.add(readablePeriod1, (-99948L), 10);
        org.joda.time.DateTimeField dateTimeField5 = gJChronology0.centuryOfEra();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-99948L) + "'", long4 == (-99948L));
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.millisOfSecond();
        org.joda.time.DateTime dateTime10 = property9.roundHalfEvenCopy();
        try {
            org.joda.time.DateTime dateTime12 = dateTime10.withMinuteOfHour((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) ' ', chronology11);
        boolean boolean14 = dateTime12.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime15 = dateTime12.toLocalDateTime();
        org.joda.time.DateTime dateTime16 = dateTime4.withFields((org.joda.time.ReadablePartial) localDateTime15);
        org.joda.time.DateTime.Property property17 = dateTime16.hourOfDay();
        org.joda.time.DateTime dateTime18 = property17.roundHalfEvenCopy();
        org.joda.time.DurationFieldType durationFieldType19 = null;
        try {
            org.joda.time.DateTime dateTime21 = dateTime18.withFieldAdded(durationFieldType19, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        org.joda.time.DateTime.Property property8 = dateTime4.centuryOfEra();
        org.joda.time.DateTime dateTime10 = property8.addToCopy((long) 2);
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekOfWeekyear(12);
        org.joda.time.DateTime dateTime14 = dateTime10.plusSeconds(0);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        boolean boolean20 = dateTime18.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        int[] intArray23 = julianChronology13.get((org.joda.time.ReadablePartial) localDateTime21, (-62112150421990L));
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) (byte) 0, locale25);
        int int28 = skipDateTimeField11.get(10L);
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
        long long37 = gJChronology29.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField39 = gJChronology38.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField40 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology29, dateTimeField39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.ReadableInstant readableInstant44 = null;
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.Chronology chronology46 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant44, readableInstant45);
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) ' ', chronology46);
        boolean boolean49 = dateTime47.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime50 = dateTime47.toLocalDateTime();
        int[] intArray52 = julianChronology42.get((org.joda.time.ReadablePartial) localDateTime50, (-62112150421990L));
        java.util.Locale locale54 = null;
        java.lang.String str55 = skipDateTimeField40.getAsShortText((org.joda.time.ReadablePartial) localDateTime50, (int) (byte) 0, locale54);
        java.util.Locale locale56 = null;
        java.lang.String str57 = skipDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDateTime50, locale56);
        java.util.Locale locale59 = null;
        java.lang.String str60 = skipDateTimeField11.getAsText((long) ' ', locale59);
        long long62 = skipDateTimeField11.roundHalfCeiling((long) 3);
        boolean boolean63 = skipDateTimeField11.isSupported();
        java.util.Locale locale65 = null;
        java.lang.String str66 = skipDateTimeField11.getAsText((int) (short) 100, locale65);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-62112178799990L) + "'", long37 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(chronology46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(localDateTime50);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "0" + "'", str55.equals("0"));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "32" + "'", str57.equals("32"));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "32" + "'", str60.equals("32"));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 3L + "'", long62 == 3L);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "100" + "'", str66.equals("100"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) '#', (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendHourOfHalfday(5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("1969-12-31T00:00:00.000-08:00", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-31T00:00:00.000-08:00\" is malformed at \"-12-31T00:00:00.000-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        org.joda.time.DateMidnight dateMidnight5 = dateTime4.toDateMidnight();
        org.joda.time.DateTime dateTime7 = dateTime4.withMillisOfDay((int) (byte) 100);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withPeriodAdded(readablePeriod8, 292278993);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) ' ', (int) '#');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTimeZoneShortName(strMap4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendLiteral("1969-12-31T00:00:00.001-08:00");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendHourOfHalfday(2169);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology0.minuteOfHour();
        org.joda.time.Chronology chronology14 = gJChronology0.withUTC();
        org.joda.time.DurationField durationField15 = gJChronology0.days();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        long long9 = gJChronology1.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField11);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant16, readableInstant17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) ' ', chronology18);
        boolean boolean21 = dateTime19.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime22 = dateTime19.toLocalDateTime();
        int[] intArray24 = julianChronology14.get((org.joda.time.ReadablePartial) localDateTime22, (-62112150421990L));
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) localDateTime22, (int) (byte) 0, locale26);
        java.lang.String str28 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDateTime22);
        boolean boolean29 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime22);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62112178799990L) + "'", long9 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(localDateTime22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1/1/70" + "'", str28.equals("1/1/70"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        org.joda.time.DateTime.Property property8 = dateTime4.centuryOfEra();
        org.joda.time.DateTime dateTime10 = property8.addToCopy((long) 2);
        org.joda.time.DateTime.Property property11 = dateTime10.dayOfYear();
        java.lang.String str12 = property11.getAsString();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) ' ', chronology11);
        boolean boolean14 = dateTime12.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime15 = dateTime12.toLocalDateTime();
        org.joda.time.DateTime dateTime16 = dateTime4.withFields((org.joda.time.ReadablePartial) localDateTime15);
        org.joda.time.DateTime.Property property17 = dateTime16.hourOfDay();
        org.joda.time.DateTime dateTime18 = property17.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime20 = property17.setCopy(0);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(28800000L);
        org.joda.time.Instant instant4 = instant1.withDurationAdded(0L, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.Integer int6 = dateTimeFormatter5.getPivotYear();
        java.util.Locale locale7 = dateTimeFormatter5.getLocale();
        java.lang.String str8 = instant1.toString(dateTimeFormatter5);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology9.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        org.joda.time.Chronology chronology14 = gJChronology9.withZone(dateTimeZone12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter5.withZone(dateTimeZone12);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        java.lang.Object obj17 = null;
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
        org.joda.time.Chronology chronology23 = gJChronology18.withZone(dateTimeZone21);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(obj17, dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone26);
        mutableDateTime27.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime27.era();
        java.lang.String str31 = property30.getName();
        org.joda.time.MutableDateTime mutableDateTime32 = property30.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime33 = property30.roundHalfCeiling();
        int int34 = dateTimeZone21.getOffset((org.joda.time.ReadableInstant) mutableDateTime33);
        org.joda.time.Chronology chronology35 = gregorianChronology16.withZone(dateTimeZone21);
        try {
            long long40 = gregorianChronology16.getDateTimeMillis((-3), 4, (-28378000), (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28378000 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(int6);
        org.junit.Assert.assertNull(locale7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970001T080000.000Z" + "'", str8.equals("1970001T080000.000Z"));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "era" + "'", str31.equals("era"));
        org.junit.Assert.assertNotNull(mutableDateTime32);
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(chronology35);
    }
}

