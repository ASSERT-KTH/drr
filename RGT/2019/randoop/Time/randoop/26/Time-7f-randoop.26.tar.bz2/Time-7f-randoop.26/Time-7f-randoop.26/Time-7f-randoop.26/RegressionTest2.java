import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) ' ', chronology11);
        int int13 = dateTime12.getHourOfDay();
        int int14 = dateTime12.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime16 = dateTime12.minusDays(10);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant18, readableInstant19);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) ' ', chronology20);
        int int22 = dateTime21.getHourOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withYear((int) (short) -1);
        java.lang.String str25 = dateTime21.toString();
        int int26 = dateTime21.getEra();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = dateTime21.toDateTime(dateTimeZone27);
        org.joda.time.DateTime dateTime30 = dateTime21.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone31 = dateTime30.getZone();
        long long34 = dateTimeZone31.adjustOffset(10L, false);
        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime12, dateTimeZone31);
        org.joda.time.DateTime dateTime36 = dateTime4.withZone(dateTimeZone31);
        org.joda.time.DateTime dateTime38 = dateTime36.minusYears(960);
        org.joda.time.DateTime.Property property39 = dateTime38.minuteOfHour();
        org.joda.time.DateTime dateTime41 = property39.addToCopy((int) (short) 0);
        org.joda.time.DateTime dateTime42 = dateTime41.toDateTimeISO();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str25.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime42);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) ' ', chronology5);
        boolean boolean8 = dateTime6.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime9 = dateTime6.toLocalDateTime();
        boolean boolean11 = dateTime6.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) ' ', chronology15);
        int int17 = dateTime16.getHourOfDay();
        org.joda.time.DateTime dateTime19 = dateTime16.withYear((int) (short) -1);
        java.lang.String str20 = dateTime16.toString();
        int int21 = dateTime16.getEra();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime16.toDateTime(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime16.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone26 = dateTime25.getZone();
        org.joda.time.DateTime dateTime27 = dateTime6.toDateTime(dateTimeZone26);
        org.joda.time.Chronology chronology28 = julianChronology1.withZone(dateTimeZone26);
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now(dateTimeZone26);
        org.joda.time.DateTime dateTime31 = dateTime29.plusHours((-99948));
        org.joda.time.DateTime dateTime33 = dateTime31.minusWeeks(57600032);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str20.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        mutableDateTime2.setZoneRetainFields(dateTimeZone4);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.era();
        try {
            org.joda.time.MutableDateTime mutableDateTime8 = property6.add((-3198991L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', chronology4);
        int int6 = dateTime5.getHourOfDay();
        int int7 = dateTime5.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime5.minusDays(10);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) ' ', chronology13);
        int int15 = dateTime14.getHourOfDay();
        org.joda.time.DateTime dateTime17 = dateTime14.withYear((int) (short) -1);
        java.lang.String str18 = dateTime14.toString();
        int int19 = dateTime14.getEra();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime14.toDateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime14.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone24 = dateTime23.getZone();
        long long27 = dateTimeZone24.adjustOffset(10L, false);
        org.joda.time.MutableDateTime mutableDateTime28 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime5, dateTimeZone24);
        org.joda.time.Chronology chronology29 = buddhistChronology0.withZone(dateTimeZone24);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant31, readableInstant32);
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) ' ', chronology33);
        boolean boolean36 = dateTime34.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime37 = dateTime34.toLocalDateTime();
        org.joda.time.DateTime dateTime38 = dateTime34.withEarlierOffsetAtOverlap();
        int int39 = dateTimeZone24.getOffset((org.joda.time.ReadableInstant) dateTime38);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str18.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(localDateTime37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(28800000L);
        org.joda.time.Instant instant4 = instant1.withDurationAdded(0L, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.Integer int6 = dateTimeFormatter5.getPivotYear();
        java.util.Locale locale7 = dateTimeFormatter5.getLocale();
        java.lang.String str8 = instant1.toString(dateTimeFormatter5);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Instant instant10 = instant1.minus(readableDuration9);
        org.joda.time.Instant instant11 = instant10.toInstant();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.Instant instant14 = instant10.withDurationAdded(readableDuration12, (int) (short) 0);
        org.joda.time.DateTime dateTime15 = instant14.toDateTime();
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(int6);
        org.junit.Assert.assertNull(locale7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970001T080000.000Z" + "'", str8.equals("1970001T080000.000Z"));
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertNotNull(instant14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.era();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.addWrapField((-10));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.weekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "era", (int) (short) -1, (int) '#');
        long long16 = fixedDateTimeZone14.nextTransition((long) 200);
        boolean boolean17 = fixedDateTimeZone14.isFixed();
        java.lang.String str19 = fixedDateTimeZone14.getNameKey((-28799999L));
        java.util.TimeZone timeZone20 = fixedDateTimeZone14.toTimeZone();
        org.joda.time.MutableDateTime mutableDateTime21 = mutableDateTime8.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        mutableDateTime8.addHours((int) '4');
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 200L + "'", long16 == 200L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "era" + "'", str19.equals("era"));
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(mutableDateTime21);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.monthOfYear();
        mutableDateTime2.setDayOfYear((int) 'a');
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        long long12 = gJChronology8.add(readablePeriod9, (-99948L), 10);
        org.joda.time.DateTime dateTime13 = mutableDateTime2.toDateTime((org.joda.time.Chronology) gJChronology8);
        int int14 = mutableDateTime2.getRoundingMode();
        mutableDateTime2.setYear(100);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant20, readableInstant21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) ' ', chronology22);
        boolean boolean25 = dateTime23.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime26 = dateTime23.toLocalDateTime();
        boolean boolean28 = dateTime23.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant30, readableInstant31);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) ' ', chronology32);
        int int34 = dateTime33.getHourOfDay();
        org.joda.time.DateTime dateTime36 = dateTime33.withYear((int) (short) -1);
        java.lang.String str37 = dateTime33.toString();
        int int38 = dateTime33.getEra();
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.DateTime dateTime40 = dateTime33.toDateTime(dateTimeZone39);
        org.joda.time.DateTime dateTime42 = dateTime33.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone43 = dateTime42.getZone();
        org.joda.time.DateTime dateTime44 = dateTime23.toDateTime(dateTimeZone43);
        org.joda.time.Chronology chronology45 = julianChronology18.withZone(dateTimeZone43);
        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone43);
        mutableDateTime2.setZoneRetainFields(dateTimeZone43);
        org.joda.time.MutableDateTime.Property property48 = mutableDateTime2.yearOfCentury();
        org.joda.time.MutableDateTime mutableDateTime49 = mutableDateTime2.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-99948L) + "'", long12 == (-99948L));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(localDateTime26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str37.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertNotNull(buddhistChronology46);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(mutableDateTime49);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gJChronology0.add(readablePeriod1, (-99948L), 10);
        org.joda.time.DurationField durationField5 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology0.weekOfWeekyear();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gJChronology0);
        int int9 = mutableDateTime8.getMonthOfYear();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime8.hourOfDay();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-99948L) + "'", long4 == (-99948L));
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfSecond(57600, 97);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter11.withPivotYear((int) (short) -1);
        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatter13.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder15.appendSecondOfDay((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendFractionOfMinute((int) '#', (int) '4');
        org.joda.time.format.DateTimeParser dateTimeParser22 = dateTimeFormatterBuilder18.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder15.appendOptional(dateTimeParser22);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter14, dateTimeParser22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.appendFractionOfMinute((int) '#', (int) '4');
        org.joda.time.format.DateTimeParser dateTimeParser29 = dateTimeFormatterBuilder25.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter14, dateTimeParser29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder7.append(dateTimePrinter14);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder32.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.append(dateTimeFormatter34);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder35.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder35.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder39.appendFractionOfSecond(57600, 97);
        org.joda.time.format.DateTimePrinter dateTimePrinter43 = dateTimeFormatterBuilder42.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder7.append(dateTimePrinter43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimePrinter14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeParser22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeParser29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimePrinter43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime.Property property6 = dateTime4.hourOfDay();
        org.joda.time.DateTime.Property property7 = dateTime4.millisOfSecond();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.DateTime dateTime10 = dateTime4.withFieldAdded(durationFieldType8, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(960, 365, 59, (-1971), (int) 'a', (-33), 35);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1971 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField18);
        long long22 = skipDateTimeField19.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType23, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        java.lang.String str29 = julianChronology28.toString();
        org.joda.time.DurationField durationField30 = julianChronology28.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField31.getRangeDurationField();
        long long35 = unsupportedDateTimeField31.add((long) (short) 10, (long) 10);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
        long long44 = gJChronology36.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField46 = gJChronology45.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField47 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology36, dateTimeField46);
        java.lang.String str49 = skipDateTimeField47.getAsText((long) (byte) 100);
        java.lang.String str51 = skipDateTimeField47.getAsShortText((long) 57600);
        org.joda.time.chrono.GJChronology gJChronology52 = org.joda.time.chrono.GJChronology.getInstance();
        long long60 = gJChronology52.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField62 = gJChronology61.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField63 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology52, dateTimeField62);
        org.joda.time.ReadableInstant readableInstant65 = null;
        org.joda.time.ReadableInstant readableInstant66 = null;
        org.joda.time.Chronology chronology67 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant65, readableInstant66);
        org.joda.time.DateTime dateTime68 = new org.joda.time.DateTime((long) ' ', chronology67);
        boolean boolean70 = dateTime68.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime71 = dateTime68.toLocalDateTime();
        java.util.Locale locale72 = null;
        java.lang.String str73 = skipDateTimeField63.getAsText((org.joda.time.ReadablePartial) localDateTime71, locale72);
        int[] intArray74 = null;
        int int75 = skipDateTimeField47.getMinimumValue((org.joda.time.ReadablePartial) localDateTime71, intArray74);
        java.util.Locale locale77 = null;
        try {
            java.lang.String str78 = unsupportedDateTimeField31.getAsText((org.joda.time.ReadablePartial) localDateTime71, 292278993, locale77);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112178799990L) + "'", long16 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1960L) + "'", long22 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JulianChronology[UTC]" + "'", str29.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 600010L + "'", long35 == 600010L);
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-62112178799990L) + "'", long44 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "100" + "'", str49.equals("100"));
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "600" + "'", str51.equals("600"));
        org.junit.Assert.assertNotNull(gJChronology52);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-62112178799990L) + "'", long60 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(chronology67);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(localDateTime71);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "32" + "'", str73.equals("32"));
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        org.joda.time.DateTime.Property property8 = dateTime4.centuryOfEra();
        org.joda.time.DateTime dateTime10 = property8.addToCopy((long) 2);
        org.joda.time.DateTime.Property property11 = dateTime10.secondOfMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        java.lang.String str13 = dateTime10.toString(dateTimeFormatter12);
        org.joda.time.Instant instant15 = new org.joda.time.Instant(28800000L);
        boolean boolean16 = dateTime10.isBefore((org.joda.time.ReadableInstant) instant15);
        boolean boolean17 = dateTime10.isEqualNow();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2170-01-01T00:00:00Z" + "'", str13.equals("2170-01-01T00:00:00Z"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.monthOfYear();
        mutableDateTime2.setDayOfYear((int) 'a');
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        long long12 = gJChronology8.add(readablePeriod9, (-99948L), 10);
        org.joda.time.DateTime dateTime13 = mutableDateTime2.toDateTime((org.joda.time.Chronology) gJChronology8);
        int int14 = mutableDateTime2.getRoundingMode();
        mutableDateTime2.setYear(100);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant20, readableInstant21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) ' ', chronology22);
        boolean boolean25 = dateTime23.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime26 = dateTime23.toLocalDateTime();
        boolean boolean28 = dateTime23.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant30, readableInstant31);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) ' ', chronology32);
        int int34 = dateTime33.getHourOfDay();
        org.joda.time.DateTime dateTime36 = dateTime33.withYear((int) (short) -1);
        java.lang.String str37 = dateTime33.toString();
        int int38 = dateTime33.getEra();
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.DateTime dateTime40 = dateTime33.toDateTime(dateTimeZone39);
        org.joda.time.DateTime dateTime42 = dateTime33.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone43 = dateTime42.getZone();
        org.joda.time.DateTime dateTime44 = dateTime23.toDateTime(dateTimeZone43);
        org.joda.time.Chronology chronology45 = julianChronology18.withZone(dateTimeZone43);
        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone43);
        mutableDateTime2.setZoneRetainFields(dateTimeZone43);
        org.joda.time.MutableDateTime.Property property48 = mutableDateTime2.era();
        org.joda.time.MutableDateTime mutableDateTime49 = property48.roundHalfEven();
        org.joda.time.DateTimeZone dateTimeZone50 = mutableDateTime49.getZone();
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-99948L) + "'", long12 == (-99948L));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(localDateTime26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str37.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertNotNull(buddhistChronology46);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(mutableDateTime49);
        org.junit.Assert.assertNotNull(dateTimeZone50);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 0, (org.joda.time.Chronology) gJChronology1, locale2, (java.lang.Integer) 0, 16);
        org.joda.time.Chronology chronology6 = dateTimeParserBucket5.getChronology();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) ' ', chronology5);
        boolean boolean8 = dateTime6.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime9 = dateTime6.toLocalDateTime();
        boolean boolean11 = dateTime6.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) ' ', chronology15);
        int int17 = dateTime16.getHourOfDay();
        org.joda.time.DateTime dateTime19 = dateTime16.withYear((int) (short) -1);
        java.lang.String str20 = dateTime16.toString();
        int int21 = dateTime16.getEra();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime16.toDateTime(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime16.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone26 = dateTime25.getZone();
        org.joda.time.DateTime dateTime27 = dateTime6.toDateTime(dateTimeZone26);
        org.joda.time.Chronology chronology28 = julianChronology1.withZone(dateTimeZone26);
        org.joda.time.DurationField durationField29 = julianChronology1.seconds();
        org.joda.time.DurationField durationField30 = julianChronology1.centuries();
        org.joda.time.DateTimeField dateTimeField31 = julianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField32 = julianChronology1.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.ReadableInstant readableInstant36 = null;
        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant35, readableInstant36);
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) ' ', chronology37);
        int int39 = dateTime38.getHourOfDay();
        org.joda.time.DateTime dateTime41 = dateTime38.withYear((int) (short) -1);
        java.lang.String str42 = dateTime38.toString();
        int int43 = dateTime38.getEra();
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.DateTime dateTime45 = dateTime38.toDateTime(dateTimeZone44);
        org.joda.time.DateTime.Property property46 = dateTime38.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone33, (org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.DateTimeField dateTimeField48 = gJChronology47.minuteOfHour();
        org.joda.time.field.SkipDateTimeField skipDateTimeField50 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology1, dateTimeField48, 0);
        org.joda.time.DateTimeField dateTimeField51 = julianChronology1.halfdayOfDay();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str20.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str42.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(gJChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeField51);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) ' ', chronology6);
        boolean boolean9 = dateTime7.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime10 = dateTime7.toLocalDateTime();
        boolean boolean12 = dateTime7.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant14, readableInstant15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) ' ', chronology16);
        int int18 = dateTime17.getHourOfDay();
        org.joda.time.DateTime dateTime20 = dateTime17.withYear((int) (short) -1);
        java.lang.String str21 = dateTime17.toString();
        int int22 = dateTime17.getEra();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = dateTime17.toDateTime(dateTimeZone23);
        org.joda.time.DateTime dateTime26 = dateTime17.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone27 = dateTime26.getZone();
        org.joda.time.DateTime dateTime28 = dateTime7.toDateTime(dateTimeZone27);
        org.joda.time.Chronology chronology29 = julianChronology2.withZone(dateTimeZone27);
        org.joda.time.DateTimeZone dateTimeZone30 = julianChronology2.getZone();
        org.joda.time.MutableDateTime mutableDateTime31 = new org.joda.time.MutableDateTime((long) 4, dateTimeZone30);
        org.joda.time.MutableDateTime mutableDateTime32 = new org.joda.time.MutableDateTime(dateTimeZone30);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str21.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.monthOfYear();
        mutableDateTime2.setDayOfYear((int) 'a');
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        long long12 = gJChronology8.add(readablePeriod9, (-99948L), 10);
        org.joda.time.DateTime dateTime13 = mutableDateTime2.toDateTime((org.joda.time.Chronology) gJChronology8);
        int int14 = dateTime13.getSecondOfDay();
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-99948L) + "'", long12 == (-99948L));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2169-12-31T16:00:00-08:00", (java.lang.Number) 19, (java.lang.Number) (-1.0f), (java.lang.Number) 57600);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-860));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        boolean boolean9 = dateTime4.isAfter((-99948L));
        org.joda.time.DateTime.Property property10 = dateTime4.secondOfDay();
        org.joda.time.DateTime dateTime12 = dateTime4.withMonthOfYear(1);
        java.util.GregorianCalendar gregorianCalendar13 = dateTime12.toGregorianCalendar();
        org.joda.time.DateTime dateTime14 = dateTime12.toDateTimeISO();
        int int15 = dateTime14.getDayOfWeek();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gregorianCalendar13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime3 = property1.add((long) (-3));
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, readableInstant6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) ' ', chronology7);
        int int9 = dateTime8.getHourOfDay();
        org.joda.time.DateTime dateTime11 = dateTime8.withYear((int) (short) -1);
        java.lang.String str12 = dateTime8.toString();
        int int13 = dateTime8.getEra();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = dateTime8.toDateTime(dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime8.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone18 = dateTime17.getZone();
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant20, readableInstant21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) ' ', chronology22);
        boolean boolean25 = dateTime23.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime26 = dateTime23.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.Chronology chronology30 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant28, readableInstant29);
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) ' ', chronology30);
        boolean boolean33 = dateTime31.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime34 = dateTime31.toLocalDateTime();
        org.joda.time.DateTime dateTime35 = dateTime23.withFields((org.joda.time.ReadablePartial) localDateTime34);
        boolean boolean36 = dateTimeZone18.isLocalDateTimeGap(localDateTime34);
        org.joda.time.MutableDateTime mutableDateTime37 = mutableDateTime3.toMutableDateTime(dateTimeZone18);
        org.joda.time.MutableDateTime.Property property38 = mutableDateTime3.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime39 = property38.roundHalfEven();
        org.joda.time.MutableDateTime mutableDateTime41 = property38.add((long) 70);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str12.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(localDateTime26);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(localDateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(mutableDateTime41);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime4.minusMillis(999);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.withPeriodAdded(readablePeriod14, 57600);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str8.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime4.minusSeconds(16);
        org.joda.time.DateTime dateTime15 = dateTime13.minusDays(57600);
        try {
            org.joda.time.DateTime dateTime17 = dateTime13.withEra(2169);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2169 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str8.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        try {
            long long3 = dateTimeFormatter0.parseMillis("365");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"365\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        long long14 = skipDateTimeField11.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipDateTimeField11.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.append(dateTimeFormatter18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        long long32 = gJChronology24.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField34 = gJChronology33.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField35 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology24, dateTimeField34);
        long long38 = skipDateTimeField35.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = skipDateTimeField35.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder23.appendDecimal(dateTimeFieldType39, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone43);
        java.lang.String str45 = julianChronology44.toString();
        org.joda.time.DurationField durationField46 = julianChronology44.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField47 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField46);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField48 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType15, durationField46);
        long long51 = unsupportedDateTimeField48.add(1L, 4317753600001L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1960L) + "'", long14 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62112178799990L) + "'", long32 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-1960L) + "'", long38 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "JulianChronology[UTC]" + "'", str45.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField47);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField48);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 259065216000060001L + "'", long51 == 259065216000060001L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) 59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        int int3 = mutableDateTime2.getHourOfDay();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.weekyear();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) ' ', chronology6);
        boolean boolean9 = dateTime7.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime10 = dateTime7.toLocalDateTime();
        boolean boolean12 = dateTime7.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant14, readableInstant15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) ' ', chronology16);
        int int18 = dateTime17.getHourOfDay();
        org.joda.time.DateTime dateTime20 = dateTime17.withYear((int) (short) -1);
        java.lang.String str21 = dateTime17.toString();
        int int22 = dateTime17.getEra();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = dateTime17.toDateTime(dateTimeZone23);
        org.joda.time.DateTime dateTime26 = dateTime17.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone27 = dateTime26.getZone();
        org.joda.time.DateTime dateTime28 = dateTime7.toDateTime(dateTimeZone27);
        org.joda.time.Chronology chronology29 = julianChronology2.withZone(dateTimeZone27);
        org.joda.time.DurationField durationField30 = julianChronology2.seconds();
        org.joda.time.DateTimeField dateTimeField31 = julianChronology2.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone33);
        mutableDateTime34.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property37 = mutableDateTime34.monthOfYear();
        mutableDateTime34.setDayOfYear((int) 'a');
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod41 = null;
        long long44 = gJChronology40.add(readablePeriod41, (-99948L), 10);
        org.joda.time.DateTime dateTime45 = mutableDateTime34.toDateTime((org.joda.time.Chronology) gJChronology40);
        int int46 = mutableDateTime34.getRoundingMode();
        mutableDateTime34.setYear(100);
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.JulianChronology julianChronology50 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone49);
        org.joda.time.ReadableInstant readableInstant52 = null;
        org.joda.time.ReadableInstant readableInstant53 = null;
        org.joda.time.Chronology chronology54 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant52, readableInstant53);
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((long) ' ', chronology54);
        boolean boolean57 = dateTime55.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime58 = dateTime55.toLocalDateTime();
        boolean boolean60 = dateTime55.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant62 = null;
        org.joda.time.ReadableInstant readableInstant63 = null;
        org.joda.time.Chronology chronology64 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant62, readableInstant63);
        org.joda.time.DateTime dateTime65 = new org.joda.time.DateTime((long) ' ', chronology64);
        int int66 = dateTime65.getHourOfDay();
        org.joda.time.DateTime dateTime68 = dateTime65.withYear((int) (short) -1);
        java.lang.String str69 = dateTime65.toString();
        int int70 = dateTime65.getEra();
        org.joda.time.DateTimeZone dateTimeZone71 = null;
        org.joda.time.DateTime dateTime72 = dateTime65.toDateTime(dateTimeZone71);
        org.joda.time.DateTime dateTime74 = dateTime65.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone75 = dateTime74.getZone();
        org.joda.time.DateTime dateTime76 = dateTime55.toDateTime(dateTimeZone75);
        org.joda.time.Chronology chronology77 = julianChronology50.withZone(dateTimeZone75);
        org.joda.time.chrono.BuddhistChronology buddhistChronology78 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone75);
        mutableDateTime34.setZoneRetainFields(dateTimeZone75);
        org.joda.time.chrono.ZonedChronology zonedChronology80 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology2, dateTimeZone75);
        java.util.Locale locale81 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket82 = new org.joda.time.format.DateTimeParserBucket((long) 990, (org.joda.time.Chronology) julianChronology2, locale81);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str21.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-99948L) + "'", long44 == (-99948L));
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(julianChronology50);
        org.junit.Assert.assertNotNull(chronology54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(localDateTime58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(chronology64);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str69.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
        org.junit.Assert.assertNotNull(dateTime72);
        org.junit.Assert.assertNotNull(dateTime74);
        org.junit.Assert.assertNotNull(dateTimeZone75);
        org.junit.Assert.assertNotNull(dateTime76);
        org.junit.Assert.assertNotNull(chronology77);
        org.junit.Assert.assertNotNull(buddhistChronology78);
        org.junit.Assert.assertNotNull(zonedChronology80);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("12/31/69", false);
        long long6 = dateTimeZone3.adjustOffset((long) (-28742400), false);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-28742400L) + "'", long6 == (-28742400L));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
        org.joda.time.DurationField durationField3 = gJChronology0.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("", "era", (int) (short) -1, (int) '#');
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone9);
        boolean boolean12 = cachedDateTimeZone9.isStandardOffset(97L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) ' ', chronology11);
        boolean boolean14 = dateTime12.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime15 = dateTime12.toLocalDateTime();
        org.joda.time.DateTime dateTime16 = dateTime4.withFields((org.joda.time.ReadablePartial) localDateTime15);
        org.joda.time.DateTime.Property property17 = dateTime16.hourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        java.lang.Object obj4 = null;
        boolean boolean5 = iSOChronology0.equals(obj4);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) ' ', chronology11);
        boolean boolean14 = dateTime12.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime15 = dateTime12.toLocalDateTime();
        org.joda.time.DateTime dateTime16 = dateTime4.withFields((org.joda.time.ReadablePartial) localDateTime15);
        org.joda.time.DateTime.Property property17 = dateTime16.hourOfDay();
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant19, readableInstant20);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) ' ', chronology21);
        boolean boolean24 = dateTime22.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime25 = dateTime22.toLocalDateTime();
        org.joda.time.DateTime dateTime26 = dateTime22.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property27 = dateTime22.millisOfSecond();
        org.joda.time.DateTime dateTime28 = property27.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone30);
        org.joda.time.DateTimeField dateTimeField32 = julianChronology31.halfdayOfDay();
        java.util.Locale locale33 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket34 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) julianChronology31, locale33);
        java.lang.String str35 = julianChronology31.toString();
        org.joda.time.DateTimeField dateTimeField36 = julianChronology31.era();
        int int37 = dateTime28.get(dateTimeField36);
        long long38 = property17.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime28);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(localDateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(julianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "JulianChronology[UTC]" + "'", str35.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        long long15 = skipDateTimeField11.remainder((long) 100);
        long long18 = skipDateTimeField11.set((-3198336L), 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.append(dateTimeFormatter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        long long35 = gJChronology27.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology36.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField37);
        long long41 = skipDateTimeField38.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipDateTimeField38.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder26.appendDecimal(dateTimeFieldType42, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone46);
        java.lang.String str48 = julianChronology47.toString();
        org.joda.time.DurationField durationField49 = julianChronology47.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField49);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType42, 31);
        int int53 = offsetDateTimeField52.getMinimumValue();
        java.lang.String str54 = offsetDateTimeField52.getName();
        int int56 = offsetDateTimeField52.get(200L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3198991L) + "'", long18 == (-3198991L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62112178799990L) + "'", long35 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1960L) + "'", long41 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "JulianChronology[UTC]" + "'", str48.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 32 + "'", int53 == 32);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "millisOfSecond" + "'", str54.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 231 + "'", int56 == 231);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.era();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.addWrapField((-10));
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.secondOfDay();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime8.year();
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', chronology4);
        int int6 = dateTime5.getHourOfDay();
        org.joda.time.DateTime dateTime8 = dateTime5.withYear((int) (short) -1);
        java.lang.String str9 = dateTime5.toString();
        int int10 = dateTime5.getEra();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime5.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime.Property property15 = dateTime5.monthOfYear();
        java.util.Locale locale16 = null;
        int int17 = property15.getMaximumTextLength(locale16);
        long long18 = property15.remainder();
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str9.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 32L + "'", long18 == 32L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "365");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("ISOChronology[UTC]");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("ISOChronology[UTC]");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("ISOChronology[UTC]");
        org.joda.time.JodaTimePermission jodaTimePermission8 = new org.joda.time.JodaTimePermission("ISOChronology[UTC]");
        boolean boolean9 = jodaTimePermission6.implies((java.security.Permission) jodaTimePermission8);
        boolean boolean10 = jodaTimePermission3.implies((java.security.Permission) jodaTimePermission6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder11.appendYearOfCentury((int) (byte) 100, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder11.appendHourOfDay(100);
        boolean boolean18 = jodaTimePermission6.equals((java.lang.Object) 100);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        int int10 = dateTime4.getSecondOfMinute();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime4.minus(readablePeriod11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance();
        long long22 = gJChronology14.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology14, dateTimeField24);
        long long28 = skipDateTimeField25.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = skipDateTimeField25.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, "1970-01-01T08:00:00.000Z");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder13.appendShortText(dateTimeFieldType29);
        int int33 = dateTime4.get(dateTimeFieldType29);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType29, 19, 86399, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19 for millisOfSecond must be in the range [86399,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str8.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-62112178799990L) + "'", long22 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-1960L) + "'", long28 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 32 + "'", int33 == 32);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        org.joda.time.DateTime.Property property8 = dateTime4.dayOfMonth();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, readableInstant11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) ' ', chronology12);
        int int14 = dateTime13.getHourOfDay();
        org.joda.time.DateTime dateTime16 = dateTime13.withYear((int) (short) -1);
        java.lang.String str17 = dateTime13.toString();
        int int18 = dateTime13.getEra();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = dateTime13.toDateTime(dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime13.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime22.getZone();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone23);
        boolean boolean26 = dateTimeZone23.isStandardOffset(5L);
        java.lang.String str27 = dateTimeZone23.getID();
        org.joda.time.DateTime dateTime28 = dateTime4.toDateTime(dateTimeZone23);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str17.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "UTC" + "'", str27.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        long long15 = skipDateTimeField11.remainder((long) 100);
        long long18 = skipDateTimeField11.set((-3198336L), 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.append(dateTimeFormatter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        long long35 = gJChronology27.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology36.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField37);
        long long41 = skipDateTimeField38.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipDateTimeField38.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder26.appendDecimal(dateTimeFieldType42, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone46);
        java.lang.String str48 = julianChronology47.toString();
        org.joda.time.DurationField durationField49 = julianChronology47.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField49);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType42, 31);
        org.joda.time.ReadablePartial readablePartial53 = null;
        java.util.Locale locale55 = null;
        java.lang.String str56 = offsetDateTimeField52.getAsText(readablePartial53, 16, locale55);
        org.joda.time.DateTimeZone dateTimeZone57 = null;
        org.joda.time.chrono.JulianChronology julianChronology58 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone57);
        org.joda.time.ReadableInstant readableInstant60 = null;
        org.joda.time.ReadableInstant readableInstant61 = null;
        org.joda.time.Chronology chronology62 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant60, readableInstant61);
        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime((long) ' ', chronology62);
        boolean boolean65 = dateTime63.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime66 = dateTime63.toLocalDateTime();
        int[] intArray68 = julianChronology58.get((org.joda.time.ReadablePartial) localDateTime66, (-62112150421990L));
        java.util.Locale locale69 = null;
        java.lang.String str70 = offsetDateTimeField52.getAsShortText((org.joda.time.ReadablePartial) localDateTime66, locale69);
        int int71 = offsetDateTimeField52.getOffset();
        org.joda.time.DurationField durationField72 = offsetDateTimeField52.getDurationField();
        int int73 = offsetDateTimeField52.getOffset();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3198991L) + "'", long18 == (-3198991L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62112178799990L) + "'", long35 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1960L) + "'", long41 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "JulianChronology[UTC]" + "'", str48.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "16" + "'", str56.equals("16"));
        org.junit.Assert.assertNotNull(julianChronology58);
        org.junit.Assert.assertNotNull(chronology62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(localDateTime66);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "32" + "'", str70.equals("32"));
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 31 + "'", int71 == 31);
        org.junit.Assert.assertNotNull(durationField72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 31 + "'", int73 == 31);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        int int3 = mutableDateTime2.getHourOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone5);
        mutableDateTime6.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.era();
        mutableDateTime2.setTime((org.joda.time.ReadableInstant) mutableDateTime6);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        mutableDateTime6.add(readablePeriod11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        org.joda.time.DateTime.Property property8 = dateTime4.centuryOfEra();
        org.joda.time.Interval interval9 = property8.toInterval();
        int int10 = property8.getMinimumValue();
        org.joda.time.DateTime dateTime11 = property8.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime12 = property8.roundCeilingCopy();
        try {
            org.joda.time.Instant instant13 = new org.joda.time.Instant((java.lang.Object) property8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.DateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
        long long6 = gJChronology0.add((long) '#', (long) 0, (int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone8);
        mutableDateTime9.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.monthOfYear();
        mutableDateTime9.setDayOfYear((int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        long long19 = gJChronology15.add(readablePeriod16, (-99948L), 10);
        org.joda.time.DateTime dateTime20 = mutableDateTime9.toDateTime((org.joda.time.Chronology) gJChronology15);
        int int21 = mutableDateTime9.getRoundingMode();
        mutableDateTime9.setYear(100);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant27, readableInstant28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) ' ', chronology29);
        boolean boolean32 = dateTime30.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime33 = dateTime30.toLocalDateTime();
        boolean boolean35 = dateTime30.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.Chronology chronology39 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant37, readableInstant38);
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((long) ' ', chronology39);
        int int41 = dateTime40.getHourOfDay();
        org.joda.time.DateTime dateTime43 = dateTime40.withYear((int) (short) -1);
        java.lang.String str44 = dateTime40.toString();
        int int45 = dateTime40.getEra();
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.DateTime dateTime47 = dateTime40.toDateTime(dateTimeZone46);
        org.joda.time.DateTime dateTime49 = dateTime40.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone50 = dateTime49.getZone();
        org.joda.time.DateTime dateTime51 = dateTime30.toDateTime(dateTimeZone50);
        org.joda.time.Chronology chronology52 = julianChronology25.withZone(dateTimeZone50);
        org.joda.time.chrono.BuddhistChronology buddhistChronology53 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone50);
        mutableDateTime9.setZoneRetainFields(dateTimeZone50);
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.ReadableInstant readableInstant57 = null;
        org.joda.time.Chronology chronology58 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant56, readableInstant57);
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) ' ', chronology58);
        int int60 = dateTime59.getHourOfDay();
        org.joda.time.DateTime dateTime62 = dateTime59.withYear((int) (short) -1);
        org.joda.time.DateTime.Property property63 = dateTime59.centuryOfEra();
        org.joda.time.DateTime dateTime65 = property63.addToCopy((long) 2);
        org.joda.time.DateTime.Property property66 = dateTime65.dayOfYear();
        org.joda.time.ReadableInstant readableInstant68 = null;
        org.joda.time.ReadableInstant readableInstant69 = null;
        org.joda.time.Chronology chronology70 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant68, readableInstant69);
        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((long) ' ', chronology70);
        org.joda.time.DateMidnight dateMidnight72 = dateTime71.toDateMidnight();
        org.joda.time.DateTime dateTime74 = dateTime71.plusMillis(0);
        int int75 = property66.getDifference((org.joda.time.ReadableInstant) dateTime71);
        org.joda.time.DateMidnight dateMidnight76 = dateTime71.toDateMidnight();
        org.joda.time.chrono.LimitChronology limitChronology77 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.ReadableDateTime) mutableDateTime9, (org.joda.time.ReadableDateTime) dateMidnight76);
        java.lang.String str78 = limitChronology77.toString();
        try {
            long long83 = limitChronology77.getDateTimeMillis(2170, 28800000, 73049, 70);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 28800000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-99948L) + "'", long19 == (-99948L));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(localDateTime33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str44.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(chronology52);
        org.junit.Assert.assertNotNull(buddhistChronology53);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertNotNull(chronology70);
        org.junit.Assert.assertNotNull(dateMidnight72);
        org.junit.Assert.assertNotNull(dateTime74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 73049 + "'", int75 == 73049);
        org.junit.Assert.assertNotNull(dateMidnight76);
        org.junit.Assert.assertNotNull(limitChronology77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "LimitChronology[GJChronology[UTC], 0100-04-07T00:00:00.000Z, 1970-01-01T00:00:00.000Z]" + "'", str78.equals("LimitChronology[GJChronology[UTC], 0100-04-07T00:00:00.000Z, 1970-01-01T00:00:00.000Z]"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 0, (org.joda.time.Chronology) gJChronology1, locale2, (java.lang.Integer) 0, 16);
        long long7 = dateTimeParserBucket5.computeMillis(true);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField18);
        java.lang.String str21 = skipDateTimeField19.getAsText((long) (byte) 100);
        dateTimeParserBucket5.saveField((org.joda.time.DateTimeField) skipDateTimeField19, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendDayOfMonth((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder24.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder27.appendTimeZoneId();
        boolean boolean29 = dateTimeParserBucket5.restoreState((java.lang.Object) dateTimeFormatterBuilder27);
        java.lang.Integer int30 = dateTimeParserBucket5.getPivotYear();
        dateTimeParserBucket5.setOffset(131);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112178799990L) + "'", long16 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "100" + "'", str21.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30.equals(0));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.addWeeks((int) (byte) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfCentury();
        org.joda.time.MutableDateTime mutableDateTime6 = property5.roundCeiling();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.roundHalfCeiling();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        mutableDateTime7.add(readablePeriod8, 97);
        try {
            mutableDateTime7.setDayOfYear(961);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 961 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        java.lang.String str14 = skipDateTimeField11.toString();
        long long16 = skipDateTimeField11.roundHalfEven((long) 2000);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter17.withDefaultYear((int) (short) 100);
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance();
        long long28 = gJChronology20.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField31 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology20, dateTimeField30);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone32);
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.ReadableInstant readableInstant36 = null;
        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant35, readableInstant36);
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) ' ', chronology37);
        boolean boolean40 = dateTime38.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime41 = dateTime38.toLocalDateTime();
        int[] intArray43 = julianChronology33.get((org.joda.time.ReadablePartial) localDateTime41, (-62112150421990L));
        java.util.Locale locale45 = null;
        java.lang.String str46 = skipDateTimeField31.getAsShortText((org.joda.time.ReadablePartial) localDateTime41, (int) (byte) 0, locale45);
        int int48 = skipDateTimeField31.get(10L);
        long long51 = skipDateTimeField31.add(33L, (long) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.ReadableInstant readableInstant54 = null;
        org.joda.time.ReadableInstant readableInstant55 = null;
        org.joda.time.Chronology chronology56 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant54, readableInstant55);
        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime((long) ' ', chronology56);
        int int58 = dateTime57.getHourOfDay();
        org.joda.time.DateTime dateTime60 = dateTime57.withYear((int) (short) -1);
        java.lang.String str61 = dateTime57.toString();
        int int62 = dateTime57.getEra();
        org.joda.time.DateTimeZone dateTimeZone63 = null;
        org.joda.time.DateTime dateTime64 = dateTime57.toDateTime(dateTimeZone63);
        org.joda.time.DateTime.Property property65 = dateTime57.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology66 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone52, (org.joda.time.ReadableInstant) dateTime57);
        org.joda.time.DateTime.Property property67 = dateTime57.monthOfYear();
        org.joda.time.ReadableInstant readableInstant69 = null;
        org.joda.time.ReadableInstant readableInstant70 = null;
        org.joda.time.Chronology chronology71 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant69, readableInstant70);
        org.joda.time.DateTime dateTime72 = new org.joda.time.DateTime((long) ' ', chronology71);
        boolean boolean74 = dateTime72.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime75 = dateTime72.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant77 = null;
        org.joda.time.ReadableInstant readableInstant78 = null;
        org.joda.time.Chronology chronology79 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant77, readableInstant78);
        org.joda.time.DateTime dateTime80 = new org.joda.time.DateTime((long) ' ', chronology79);
        boolean boolean82 = dateTime80.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime83 = dateTime80.toLocalDateTime();
        org.joda.time.DateTime dateTime84 = dateTime72.withFields((org.joda.time.ReadablePartial) localDateTime83);
        int int85 = property67.compareTo((org.joda.time.ReadablePartial) localDateTime83);
        java.util.Locale locale87 = null;
        java.lang.String str88 = skipDateTimeField31.getAsShortText((org.joda.time.ReadablePartial) localDateTime83, 12, locale87);
        java.lang.String str89 = dateTimeFormatter19.print((org.joda.time.ReadablePartial) localDateTime83);
        java.util.Locale locale91 = null;
        java.lang.String str92 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime83, 0, locale91);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str14.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2000L + "'", long16 == 2000L);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62112178799990L) + "'", long28 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(julianChronology33);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(localDateTime41);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "0" + "'", str46.equals("0"));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 10 + "'", int48 == 10);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 43L + "'", long51 == 43L);
        org.junit.Assert.assertNotNull(chronology56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str61.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertNotNull(gJChronology66);
        org.junit.Assert.assertNotNull(property67);
        org.junit.Assert.assertNotNull(chronology71);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(localDateTime75);
        org.junit.Assert.assertNotNull(chronology79);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(localDateTime83);
        org.junit.Assert.assertNotNull(dateTime84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "12" + "'", str88.equals("12"));
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "T00:00:00.032" + "'", str89.equals("T00:00:00.032"));
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "0" + "'", str92.equals("0"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(obj0, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.era();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            mutableDateTime3.add(durationFieldType5, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        int int6 = dateTime4.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime8 = dateTime4.minusDays(10);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, readableInstant11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) ' ', chronology12);
        int int14 = dateTime13.getHourOfDay();
        org.joda.time.DateTime dateTime16 = dateTime13.withYear((int) (short) -1);
        java.lang.String str17 = dateTime13.toString();
        int int18 = dateTime13.getEra();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = dateTime13.toDateTime(dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime13.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime22.getZone();
        long long26 = dateTimeZone23.adjustOffset(10L, false);
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime4, dateTimeZone23);
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone23);
        java.lang.String str29 = buddhistChronology28.toString();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str17.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "BuddhistChronology[UTC]" + "'", str29.equals("BuddhistChronology[UTC]"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        boolean boolean20 = dateTime18.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        int[] intArray23 = julianChronology13.get((org.joda.time.ReadablePartial) localDateTime21, (-62112150421990L));
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) (byte) 0, locale25);
        int int28 = skipDateTimeField11.get(10L);
        long long31 = skipDateTimeField11.getDifferenceAsLong((-28799999L), (long) 2169);
        int int32 = skipDateTimeField11.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-28802168L) + "'", long31 == (-28802168L));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(1, 'a', 100, 69, (-28800000), true, (int) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeZoneBuilder0.toDateTimeZone("millisOfSecond", true);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder0.addRecurringSavings("97", (-28378000), 19, 32, '#', 2000, 2169, 19, true, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gJChronology0.add(readablePeriod1, (-99948L), 10);
        org.joda.time.DurationField durationField5 = gJChronology0.millis();
        org.joda.time.Instant instant6 = gJChronology0.getGregorianCutover();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-99948L) + "'", long4 == (-99948L));
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(28800000L);
        org.joda.time.Instant instant4 = instant1.withDurationAdded(0L, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.Integer int6 = dateTimeFormatter5.getPivotYear();
        java.util.Locale locale7 = dateTimeFormatter5.getLocale();
        java.lang.String str8 = instant1.toString(dateTimeFormatter5);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology9.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        org.joda.time.Chronology chronology14 = gJChronology9.withZone(dateTimeZone12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter5.withZone(dateTimeZone12);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        java.lang.Object obj17 = null;
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
        org.joda.time.Chronology chronology23 = gJChronology18.withZone(dateTimeZone21);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(obj17, dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone26);
        mutableDateTime27.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime27.era();
        java.lang.String str31 = property30.getName();
        org.joda.time.MutableDateTime mutableDateTime32 = property30.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime33 = property30.roundHalfCeiling();
        int int34 = dateTimeZone21.getOffset((org.joda.time.ReadableInstant) mutableDateTime33);
        org.joda.time.Chronology chronology35 = gregorianChronology16.withZone(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime36 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property37 = mutableDateTime36.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime39 = property37.add((long) (-3));
        org.joda.time.ReadableInstant readableInstant41 = null;
        org.joda.time.ReadableInstant readableInstant42 = null;
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant41, readableInstant42);
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) ' ', chronology43);
        int int45 = dateTime44.getHourOfDay();
        org.joda.time.DateTime dateTime47 = dateTime44.withYear((int) (short) -1);
        java.lang.String str48 = dateTime44.toString();
        int int49 = dateTime44.getEra();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = dateTime44.toDateTime(dateTimeZone50);
        org.joda.time.DateTime dateTime53 = dateTime44.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone54 = dateTime53.getZone();
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.ReadableInstant readableInstant57 = null;
        org.joda.time.Chronology chronology58 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant56, readableInstant57);
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) ' ', chronology58);
        boolean boolean61 = dateTime59.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime62 = dateTime59.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant64 = null;
        org.joda.time.ReadableInstant readableInstant65 = null;
        org.joda.time.Chronology chronology66 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant64, readableInstant65);
        org.joda.time.DateTime dateTime67 = new org.joda.time.DateTime((long) ' ', chronology66);
        boolean boolean69 = dateTime67.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime70 = dateTime67.toLocalDateTime();
        org.joda.time.DateTime dateTime71 = dateTime59.withFields((org.joda.time.ReadablePartial) localDateTime70);
        boolean boolean72 = dateTimeZone54.isLocalDateTimeGap(localDateTime70);
        org.joda.time.MutableDateTime mutableDateTime73 = mutableDateTime39.toMutableDateTime(dateTimeZone54);
        org.joda.time.DateTimeZone dateTimeZone74 = org.joda.time.DateTimeUtils.getZone(dateTimeZone54);
        org.joda.time.Chronology chronology75 = gregorianChronology16.withZone(dateTimeZone74);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(int6);
        org.junit.Assert.assertNull(locale7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970001T080000.000Z" + "'", str8.equals("1970001T080000.000Z"));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "era" + "'", str31.equals("era"));
        org.junit.Assert.assertNotNull(mutableDateTime32);
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str48.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(localDateTime62);
        org.junit.Assert.assertNotNull(chronology66);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(localDateTime70);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(mutableDateTime73);
        org.junit.Assert.assertNotNull(dateTimeZone74);
        org.junit.Assert.assertNotNull(chronology75);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        long long15 = skipDateTimeField11.remainder((long) 100);
        long long18 = skipDateTimeField11.set((-3198336L), 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.append(dateTimeFormatter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        long long35 = gJChronology27.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology36.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField37);
        long long41 = skipDateTimeField38.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipDateTimeField38.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder26.appendDecimal(dateTimeFieldType42, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone46);
        java.lang.String str48 = julianChronology47.toString();
        org.joda.time.DurationField durationField49 = julianChronology47.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField49);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType42, 31);
        org.joda.time.ReadablePartial readablePartial53 = null;
        java.util.Locale locale55 = null;
        java.lang.String str56 = offsetDateTimeField52.getAsText(readablePartial53, 16, locale55);
        org.joda.time.DateTimeZone dateTimeZone57 = null;
        org.joda.time.chrono.JulianChronology julianChronology58 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone57);
        org.joda.time.ReadableInstant readableInstant60 = null;
        org.joda.time.ReadableInstant readableInstant61 = null;
        org.joda.time.Chronology chronology62 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant60, readableInstant61);
        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime((long) ' ', chronology62);
        boolean boolean65 = dateTime63.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime66 = dateTime63.toLocalDateTime();
        int[] intArray68 = julianChronology58.get((org.joda.time.ReadablePartial) localDateTime66, (-62112150421990L));
        java.util.Locale locale69 = null;
        java.lang.String str70 = offsetDateTimeField52.getAsShortText((org.joda.time.ReadablePartial) localDateTime66, locale69);
        int int71 = offsetDateTimeField52.getOffset();
        boolean boolean73 = offsetDateTimeField52.isLeap((long) 59);
        long long76 = offsetDateTimeField52.add((long) 365, (long) 3);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3198991L) + "'", long18 == (-3198991L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62112178799990L) + "'", long35 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1960L) + "'", long41 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "JulianChronology[UTC]" + "'", str48.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "16" + "'", str56.equals("16"));
        org.junit.Assert.assertNotNull(julianChronology58);
        org.junit.Assert.assertNotNull(chronology62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(localDateTime66);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "32" + "'", str70.equals("32"));
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 31 + "'", int71 == 31);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 368L + "'", long76 == 368L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
        long long6 = gJChronology0.add((long) '#', (long) 0, (int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone8);
        mutableDateTime9.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.monthOfYear();
        mutableDateTime9.setDayOfYear((int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        long long19 = gJChronology15.add(readablePeriod16, (-99948L), 10);
        org.joda.time.DateTime dateTime20 = mutableDateTime9.toDateTime((org.joda.time.Chronology) gJChronology15);
        int int21 = mutableDateTime9.getRoundingMode();
        mutableDateTime9.setYear(100);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant27, readableInstant28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) ' ', chronology29);
        boolean boolean32 = dateTime30.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime33 = dateTime30.toLocalDateTime();
        boolean boolean35 = dateTime30.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.Chronology chronology39 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant37, readableInstant38);
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((long) ' ', chronology39);
        int int41 = dateTime40.getHourOfDay();
        org.joda.time.DateTime dateTime43 = dateTime40.withYear((int) (short) -1);
        java.lang.String str44 = dateTime40.toString();
        int int45 = dateTime40.getEra();
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.DateTime dateTime47 = dateTime40.toDateTime(dateTimeZone46);
        org.joda.time.DateTime dateTime49 = dateTime40.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone50 = dateTime49.getZone();
        org.joda.time.DateTime dateTime51 = dateTime30.toDateTime(dateTimeZone50);
        org.joda.time.Chronology chronology52 = julianChronology25.withZone(dateTimeZone50);
        org.joda.time.chrono.BuddhistChronology buddhistChronology53 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone50);
        mutableDateTime9.setZoneRetainFields(dateTimeZone50);
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.ReadableInstant readableInstant57 = null;
        org.joda.time.Chronology chronology58 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant56, readableInstant57);
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) ' ', chronology58);
        int int60 = dateTime59.getHourOfDay();
        org.joda.time.DateTime dateTime62 = dateTime59.withYear((int) (short) -1);
        org.joda.time.DateTime.Property property63 = dateTime59.centuryOfEra();
        org.joda.time.DateTime dateTime65 = property63.addToCopy((long) 2);
        org.joda.time.DateTime.Property property66 = dateTime65.dayOfYear();
        org.joda.time.ReadableInstant readableInstant68 = null;
        org.joda.time.ReadableInstant readableInstant69 = null;
        org.joda.time.Chronology chronology70 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant68, readableInstant69);
        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((long) ' ', chronology70);
        org.joda.time.DateMidnight dateMidnight72 = dateTime71.toDateMidnight();
        org.joda.time.DateTime dateTime74 = dateTime71.plusMillis(0);
        int int75 = property66.getDifference((org.joda.time.ReadableInstant) dateTime71);
        org.joda.time.DateMidnight dateMidnight76 = dateTime71.toDateMidnight();
        org.joda.time.chrono.LimitChronology limitChronology77 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.ReadableDateTime) mutableDateTime9, (org.joda.time.ReadableDateTime) dateMidnight76);
        try {
            long long83 = limitChronology77.getDateTimeMillis(0L, (int) ' ', 19, 5, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is above the supported maximum of 1970-01-01T00:00:00.000Z (GJChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-99948L) + "'", long19 == (-99948L));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(localDateTime33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str44.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(chronology52);
        org.junit.Assert.assertNotNull(buddhistChronology53);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertNotNull(chronology70);
        org.junit.Assert.assertNotNull(dateMidnight72);
        org.junit.Assert.assertNotNull(dateTime74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 73049 + "'", int75 == 73049);
        org.junit.Assert.assertNotNull(dateMidnight76);
        org.junit.Assert.assertNotNull(limitChronology77);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField18);
        long long22 = skipDateTimeField19.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType23, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        java.lang.String str29 = julianChronology28.toString();
        org.joda.time.DurationField durationField30 = julianChronology28.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField31.getRangeDurationField();
        long long35 = unsupportedDateTimeField31.add((long) (short) 10, (long) 10);
        long long38 = unsupportedDateTimeField31.getDifferenceAsLong((long) 100, 0L);
        org.joda.time.ReadablePartial readablePartial39 = null;
        try {
            int int40 = unsupportedDateTimeField31.getMaximumValue(readablePartial39);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112178799990L) + "'", long16 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1960L) + "'", long22 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JulianChronology[UTC]" + "'", str29.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 600010L + "'", long35 == 600010L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        long long10 = gJChronology2.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField12);
        org.joda.time.DateTimeField dateTimeField14 = gJChronology2.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology2.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField15);
        int int17 = skipUndoDateTimeField16.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62112178799990L) + "'", long10 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatterBuilder1.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder1.appendCenturyOfEra(1030, 97);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.Appendable appendable1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        long long10 = gJChronology2.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField12);
        java.lang.String str15 = skipDateTimeField13.getAsText((long) (byte) 100);
        long long17 = skipDateTimeField13.remainder((long) 100);
        long long20 = skipDateTimeField13.set((-3198336L), 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder21.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.append(dateTimeFormatter23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
        long long37 = gJChronology29.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField39 = gJChronology38.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField40 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology29, dateTimeField39);
        long long43 = skipDateTimeField40.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = skipDateTimeField40.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder28.appendDecimal(dateTimeFieldType44, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.chrono.JulianChronology julianChronology49 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone48);
        java.lang.String str50 = julianChronology49.toString();
        org.joda.time.DurationField durationField51 = julianChronology49.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField52 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType44, durationField51);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField13, dateTimeFieldType44, 31);
        boolean boolean55 = offsetDateTimeField54.isLenient();
        org.joda.time.DurationField durationField56 = offsetDateTimeField54.getLeapDurationField();
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance();
        long long65 = gJChronology57.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology66 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField67 = gJChronology66.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField68 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology57, dateTimeField67);
        org.joda.time.ReadableInstant readableInstant70 = null;
        org.joda.time.ReadableInstant readableInstant71 = null;
        org.joda.time.Chronology chronology72 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant70, readableInstant71);
        org.joda.time.DateTime dateTime73 = new org.joda.time.DateTime((long) ' ', chronology72);
        boolean boolean75 = dateTime73.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime76 = dateTime73.toLocalDateTime();
        java.util.Locale locale77 = null;
        java.lang.String str78 = skipDateTimeField68.getAsText((org.joda.time.ReadablePartial) localDateTime76, locale77);
        int[] intArray79 = null;
        int int80 = offsetDateTimeField54.getMaximumValue((org.joda.time.ReadablePartial) localDateTime76, intArray79);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDateTime76);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62112178799990L) + "'", long10 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100" + "'", str15.equals("100"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-3198991L) + "'", long20 == (-3198991L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-62112178799990L) + "'", long37 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-1960L) + "'", long43 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(julianChronology49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "JulianChronology[UTC]" + "'", str50.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNull(durationField56);
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-62112178799990L) + "'", long65 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(chronology72);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(localDateTime76);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "32" + "'", str78.equals("32"));
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1030 + "'", int80 == 1030);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "era", (int) (short) -1, (int) '#');
        long long7 = fixedDateTimeZone5.nextTransition((long) 200);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean9 = fixedDateTimeZone5.isFixed();
        long long11 = fixedDateTimeZone5.convertUTCToLocal(1560344728795L);
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(3L, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        int int14 = fixedDateTimeZone5.getOffsetFromLocal((long) 1969);
        long long16 = fixedDateTimeZone5.previousTransition(10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 200L + "'", long7 == 200L);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560344728794L + "'", long11 == 1560344728794L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        int int7 = dateTime4.getMinuteOfDay();
        org.joda.time.LocalDateTime localDateTime8 = dateTime4.toLocalDateTime();
        org.joda.time.DateTime dateTime10 = dateTime4.minusYears(69);
        int int11 = dateTime4.getMillisOfDay();
        org.joda.time.DateTime.Property property12 = dateTime4.yearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance();
        long long21 = gJChronology13.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = gJChronology22.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology13, dateTimeField23);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField24.getAsText((int) ' ', locale26);
        int int29 = skipDateTimeField24.getMaximumValue(0L);
        boolean boolean31 = skipDateTimeField24.isLeap((long) 5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder32.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.append(dateTimeFormatter34);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder35.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder37.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance();
        long long48 = gJChronology40.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology49 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField50 = gJChronology49.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField51 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology40, dateTimeField50);
        long long54 = skipDateTimeField51.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = skipDateTimeField51.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder39.appendDecimal(dateTimeFieldType55, 10, 57600);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField24, dateTimeFieldType55, 1970);
        int int61 = dateTime4.get(dateTimeFieldType55);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(localDateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62112178799990L) + "'", long21 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "32" + "'", str27.equals("32"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 999 + "'", int29 == 999);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-62112178799990L) + "'", long48 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-1960L) + "'", long54 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 32 + "'", int61 == 32);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', chronology4);
        int int6 = dateTime5.getHourOfDay();
        org.joda.time.DateTime dateTime8 = dateTime5.withYear((int) (short) -1);
        java.lang.String str9 = dateTime5.toString();
        int int10 = dateTime5.getEra();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime5.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime.Property property15 = dateTime5.monthOfYear();
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant17, readableInstant18);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) ' ', chronology19);
        boolean boolean22 = dateTime20.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime23 = dateTime20.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant25, readableInstant26);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) ' ', chronology27);
        boolean boolean30 = dateTime28.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime31 = dateTime28.toLocalDateTime();
        org.joda.time.DateTime dateTime32 = dateTime20.withFields((org.joda.time.ReadablePartial) localDateTime31);
        int int33 = property15.compareTo((org.joda.time.ReadablePartial) localDateTime31);
        org.joda.time.DateTimeField dateTimeField34 = property15.getField();
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.MutableDateTime mutableDateTime37 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone36);
        mutableDateTime37.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime37.monthOfYear();
        mutableDateTime37.setDayOfYear((int) 'a');
        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod44 = null;
        long long47 = gJChronology43.add(readablePeriod44, (-99948L), 10);
        org.joda.time.DateTime dateTime48 = mutableDateTime37.toDateTime((org.joda.time.Chronology) gJChronology43);
        int int49 = mutableDateTime37.getRoundingMode();
        mutableDateTime37.setYear(100);
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.chrono.JulianChronology julianChronology53 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone52);
        org.joda.time.ReadableInstant readableInstant55 = null;
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.Chronology chronology57 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant55, readableInstant56);
        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime((long) ' ', chronology57);
        boolean boolean60 = dateTime58.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime61 = dateTime58.toLocalDateTime();
        boolean boolean63 = dateTime58.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant65 = null;
        org.joda.time.ReadableInstant readableInstant66 = null;
        org.joda.time.Chronology chronology67 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant65, readableInstant66);
        org.joda.time.DateTime dateTime68 = new org.joda.time.DateTime((long) ' ', chronology67);
        int int69 = dateTime68.getHourOfDay();
        org.joda.time.DateTime dateTime71 = dateTime68.withYear((int) (short) -1);
        java.lang.String str72 = dateTime68.toString();
        int int73 = dateTime68.getEra();
        org.joda.time.DateTimeZone dateTimeZone74 = null;
        org.joda.time.DateTime dateTime75 = dateTime68.toDateTime(dateTimeZone74);
        org.joda.time.DateTime dateTime77 = dateTime68.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone78 = dateTime77.getZone();
        org.joda.time.DateTime dateTime79 = dateTime58.toDateTime(dateTimeZone78);
        org.joda.time.Chronology chronology80 = julianChronology53.withZone(dateTimeZone78);
        org.joda.time.chrono.BuddhistChronology buddhistChronology81 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone78);
        mutableDateTime37.setZoneRetainFields(dateTimeZone78);
        try {
            org.joda.time.MutableDateTime mutableDateTime83 = new org.joda.time.MutableDateTime((java.lang.Object) dateTimeField34, dateTimeZone78);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.GJMonthOfYearDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str9.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(localDateTime23);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(localDateTime31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(gJChronology43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-99948L) + "'", long47 == (-99948L));
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(julianChronology53);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(localDateTime61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(chronology67);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str72.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertNotNull(dateTime77);
        org.junit.Assert.assertNotNull(dateTimeZone78);
        org.junit.Assert.assertNotNull(dateTime79);
        org.junit.Assert.assertNotNull(chronology80);
        org.junit.Assert.assertNotNull(buddhistChronology81);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        int int6 = dateTime4.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime8 = dateTime4.minusWeeks(0);
        org.joda.time.Instant instant9 = dateTime8.toInstant();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Instant instant11 = instant9.minus(readableDuration10);
        long long12 = instant11.getMillis();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatterBuilder3.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendWeekyear(365, 990);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendTwoDigitYear(19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        boolean boolean20 = dateTime18.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        int[] intArray23 = julianChronology13.get((org.joda.time.ReadablePartial) localDateTime21, (-62112150421990L));
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) (byte) 0, locale25);
        int int28 = skipDateTimeField11.get(10L);
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance();
        long long37 = gJChronology29.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField39 = gJChronology38.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField40 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology29, dateTimeField39);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.JulianChronology julianChronology42 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41);
        org.joda.time.ReadableInstant readableInstant44 = null;
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.Chronology chronology46 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant44, readableInstant45);
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) ' ', chronology46);
        boolean boolean49 = dateTime47.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime50 = dateTime47.toLocalDateTime();
        int[] intArray52 = julianChronology42.get((org.joda.time.ReadablePartial) localDateTime50, (-62112150421990L));
        java.util.Locale locale54 = null;
        java.lang.String str55 = skipDateTimeField40.getAsShortText((org.joda.time.ReadablePartial) localDateTime50, (int) (byte) 0, locale54);
        java.util.Locale locale56 = null;
        java.lang.String str57 = skipDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDateTime50, locale56);
        java.util.Locale locale59 = null;
        java.lang.String str60 = skipDateTimeField11.getAsText((long) ' ', locale59);
        long long62 = skipDateTimeField11.roundHalfCeiling((long) 3);
        org.joda.time.DurationField durationField63 = skipDateTimeField11.getLeapDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-62112178799990L) + "'", long37 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(julianChronology42);
        org.junit.Assert.assertNotNull(chronology46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(localDateTime50);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "0" + "'", str55.equals("0"));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "32" + "'", str57.equals("32"));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "32" + "'", str60.equals("32"));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 3L + "'", long62 == 3L);
        org.junit.Assert.assertNull(durationField63);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        long long15 = skipDateTimeField11.remainder((long) 100);
        long long18 = skipDateTimeField11.set((-3198336L), 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.append(dateTimeFormatter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        long long35 = gJChronology27.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology36.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField37);
        long long41 = skipDateTimeField38.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipDateTimeField38.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder26.appendDecimal(dateTimeFieldType42, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone46);
        java.lang.String str48 = julianChronology47.toString();
        org.joda.time.DurationField durationField49 = julianChronology47.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField49);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType42, 31);
        java.util.Locale locale53 = null;
        int int54 = offsetDateTimeField52.getMaximumTextLength(locale53);
        long long56 = offsetDateTimeField52.roundHalfFloor((long) 73049);
        org.joda.time.DateTimeZone dateTimeZone57 = null;
        org.joda.time.ReadableInstant readableInstant59 = null;
        org.joda.time.ReadableInstant readableInstant60 = null;
        org.joda.time.Chronology chronology61 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant59, readableInstant60);
        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime((long) ' ', chronology61);
        int int63 = dateTime62.getHourOfDay();
        org.joda.time.DateTime dateTime65 = dateTime62.withYear((int) (short) -1);
        java.lang.String str66 = dateTime62.toString();
        int int67 = dateTime62.getEra();
        org.joda.time.DateTimeZone dateTimeZone68 = null;
        org.joda.time.DateTime dateTime69 = dateTime62.toDateTime(dateTimeZone68);
        org.joda.time.DateTime.Property property70 = dateTime62.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology71 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone57, (org.joda.time.ReadableInstant) dateTime62);
        org.joda.time.DateTime.Property property72 = dateTime62.monthOfYear();
        org.joda.time.ReadableInstant readableInstant74 = null;
        org.joda.time.ReadableInstant readableInstant75 = null;
        org.joda.time.Chronology chronology76 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant74, readableInstant75);
        org.joda.time.DateTime dateTime77 = new org.joda.time.DateTime((long) ' ', chronology76);
        boolean boolean79 = dateTime77.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime80 = dateTime77.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant82 = null;
        org.joda.time.ReadableInstant readableInstant83 = null;
        org.joda.time.Chronology chronology84 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant82, readableInstant83);
        org.joda.time.DateTime dateTime85 = new org.joda.time.DateTime((long) ' ', chronology84);
        boolean boolean87 = dateTime85.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime88 = dateTime85.toLocalDateTime();
        org.joda.time.DateTime dateTime89 = dateTime77.withFields((org.joda.time.ReadablePartial) localDateTime88);
        int int90 = property72.compareTo((org.joda.time.ReadablePartial) localDateTime88);
        boolean boolean91 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime88);
        boolean boolean92 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime88);
        java.util.Locale locale94 = null;
        java.lang.String str95 = offsetDateTimeField52.getAsText((org.joda.time.ReadablePartial) localDateTime88, (-33), locale94);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3198991L) + "'", long18 == (-3198991L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62112178799990L) + "'", long35 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1960L) + "'", long41 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "JulianChronology[UTC]" + "'", str48.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 4 + "'", int54 == 4);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 73049L + "'", long56 == 73049L);
        org.junit.Assert.assertNotNull(chronology61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str66.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertNotNull(property70);
        org.junit.Assert.assertNotNull(gJChronology71);
        org.junit.Assert.assertNotNull(property72);
        org.junit.Assert.assertNotNull(chronology76);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(localDateTime80);
        org.junit.Assert.assertNotNull(chronology84);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(localDateTime88);
        org.junit.Assert.assertNotNull(dateTime89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "-33" + "'", str95.equals("-33"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime4.dayOfMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter13.withOffsetParsed();
        java.lang.String str15 = dateTime4.toString(dateTimeFormatter14);
        java.lang.String str17 = dateTimeFormatter14.print((long) 365);
        int int18 = dateTimeFormatter14.getDefaultYear();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str8.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "00:00:00Z" + "'", str15.equals("00:00:00Z"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "00:00:00Z" + "'", str17.equals("00:00:00Z"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2000 + "'", int18 == 2000);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.addWeeks((int) (byte) 0);
        mutableDateTime2.addDays((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(0L, dateTimeZone9);
        mutableDateTime2.setZoneRetainFields(dateTimeZone9);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime2.millisOfSecond();
        java.lang.String str13 = property12.getAsString();
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "16" + "'", str13.equals("16"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        org.joda.time.DateTime.Property property8 = dateTime4.hourOfDay();
        org.joda.time.DateTime dateTime10 = dateTime4.minusMinutes(19);
        org.joda.time.DateTime dateTime12 = dateTime10.plusMonths(0);
        try {
            org.joda.time.DateTime dateTime14 = dateTime12.withEra((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) (short) 0, (org.joda.time.Chronology) gJChronology1, locale2, (java.lang.Integer) 0, 16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        java.util.Locale locale7 = dateTimeFormatter6.getLocale();
        boolean boolean8 = dateTimeParserBucket5.restoreState((java.lang.Object) dateTimeFormatter6);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTimeParserBucket5.getZone();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNull(locale7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.secondOfDay();
        org.joda.time.ReadableDuration readableDuration4 = null;
        mutableDateTime2.add(readableDuration4);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant7, readableInstant8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) ' ', chronology9);
        int int11 = dateTime10.getHourOfDay();
        org.joda.time.DateTime dateTime13 = dateTime10.withYear((int) (short) -1);
        java.lang.String str14 = dateTime10.toString();
        mutableDateTime2.setMillis((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone17);
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime18.secondOfDay();
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime10, (org.joda.time.ReadableInstant) mutableDateTime18);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
        try {
            mutableDateTime18.set(dateTimeFieldType21, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str14.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(chronology20);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(28800000L);
        org.joda.time.Instant instant4 = instant1.withDurationAdded(0L, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.Integer int6 = dateTimeFormatter5.getPivotYear();
        java.util.Locale locale7 = dateTimeFormatter5.getLocale();
        java.lang.String str8 = instant1.toString(dateTimeFormatter5);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology9.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        org.joda.time.Chronology chronology14 = gJChronology9.withZone(dateTimeZone12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter5.withZone(dateTimeZone12);
        int int16 = dateTimeFormatter5.getDefaultYear();
        java.util.Locale locale17 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter5.withLocale(locale17);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(int6);
        org.junit.Assert.assertNull(locale7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970001T080000.000Z" + "'", str8.equals("1970001T080000.000Z"));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2000 + "'", int16 == 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        long long15 = skipDateTimeField11.remainder((long) 100);
        long long18 = skipDateTimeField11.set((-3198336L), 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.append(dateTimeFormatter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        long long35 = gJChronology27.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology36.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField37);
        long long41 = skipDateTimeField38.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipDateTimeField38.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder26.appendDecimal(dateTimeFieldType42, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone46);
        java.lang.String str48 = julianChronology47.toString();
        org.joda.time.DurationField durationField49 = julianChronology47.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField49);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType42, 31);
        org.joda.time.DurationField durationField53 = offsetDateTimeField52.getLeapDurationField();
        long long55 = offsetDateTimeField52.roundCeiling((long) (byte) 100);
        int int56 = offsetDateTimeField52.getMaximumValue();
        long long58 = offsetDateTimeField52.remainder((long) 86399);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3198991L) + "'", long18 == (-3198991L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62112178799990L) + "'", long35 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1960L) + "'", long41 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "JulianChronology[UTC]" + "'", str48.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
        org.junit.Assert.assertNull(durationField53);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 100L + "'", long55 == 100L);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1030 + "'", int56 == 1030);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.addWeeks((int) (byte) 0);
        mutableDateTime2.addDays((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 10);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(0L, dateTimeZone9);
        mutableDateTime2.setZoneRetainFields(dateTimeZone9);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime2.millisOfSecond();
        try {
            mutableDateTime2.setDayOfMonth((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime3 = property1.add((long) (-3));
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, readableInstant6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) ' ', chronology7);
        int int9 = dateTime8.getHourOfDay();
        org.joda.time.DateTime dateTime11 = dateTime8.withYear((int) (short) -1);
        java.lang.String str12 = dateTime8.toString();
        int int13 = dateTime8.getEra();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = dateTime8.toDateTime(dateTimeZone14);
        org.joda.time.DateTime dateTime17 = dateTime8.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone18 = dateTime17.getZone();
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant20, readableInstant21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) ' ', chronology22);
        boolean boolean25 = dateTime23.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime26 = dateTime23.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.Chronology chronology30 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant28, readableInstant29);
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) ' ', chronology30);
        boolean boolean33 = dateTime31.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime34 = dateTime31.toLocalDateTime();
        org.joda.time.DateTime dateTime35 = dateTime23.withFields((org.joda.time.ReadablePartial) localDateTime34);
        boolean boolean36 = dateTimeZone18.isLocalDateTimeGap(localDateTime34);
        org.joda.time.MutableDateTime mutableDateTime37 = mutableDateTime3.toMutableDateTime(dateTimeZone18);
        org.joda.time.MutableDateTime.Property property38 = mutableDateTime3.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime39 = property38.roundHalfEven();
        org.joda.time.MutableDateTime mutableDateTime40 = property38.getMutableDateTime();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str12.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(localDateTime26);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(localDateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(mutableDateTime40);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.halfdayOfDay();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket5 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) julianChronology2, locale4);
        java.lang.String str6 = julianChronology2.toString();
        java.lang.String str7 = julianChronology2.toString();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "JulianChronology[UTC]" + "'", str6.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "JulianChronology[UTC]" + "'", str7.equals("JulianChronology[UTC]"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = gJChronology0.add(readablePeriod1, (-99948L), 10);
        org.joda.time.DurationField durationField5 = gJChronology0.millis();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology0.weekOfWeekyear();
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DurationField durationField9 = gJChronology0.weeks();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-99948L) + "'", long4 == (-99948L));
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(28800000L);
        org.joda.time.Instant instant4 = instant1.withDurationAdded(0L, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.Integer int6 = dateTimeFormatter5.getPivotYear();
        java.util.Locale locale7 = dateTimeFormatter5.getLocale();
        java.lang.String str8 = instant1.toString(dateTimeFormatter5);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Instant instant10 = instant1.minus(readableDuration9);
        org.joda.time.Instant instant11 = instant10.toInstant();
        java.lang.String str12 = instant10.toString();
        org.joda.time.MutableDateTime mutableDateTime13 = instant10.toMutableDateTimeISO();
        mutableDateTime13.addWeekyears((-28742400));
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(int6);
        org.junit.Assert.assertNull(locale7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970001T080000.000Z" + "'", str8.equals("1970001T080000.000Z"));
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970-01-01T08:00:00.000Z" + "'", str12.equals("1970-01-01T08:00:00.000Z"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setWeekOfWeekyear((int) ' ');
        long long5 = mutableDateTime2.getMillis();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 18748800016L + "'", long5 == 18748800016L);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYearOfCentury((int) (byte) 100, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(200, 961);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 200");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "Property[secondOfDay]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
        long long6 = gJChronology0.add((long) '#', (long) 0, (int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone8);
        mutableDateTime9.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.monthOfYear();
        mutableDateTime9.setDayOfYear((int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        long long19 = gJChronology15.add(readablePeriod16, (-99948L), 10);
        org.joda.time.DateTime dateTime20 = mutableDateTime9.toDateTime((org.joda.time.Chronology) gJChronology15);
        int int21 = mutableDateTime9.getRoundingMode();
        mutableDateTime9.setYear(100);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant27, readableInstant28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) ' ', chronology29);
        boolean boolean32 = dateTime30.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime33 = dateTime30.toLocalDateTime();
        boolean boolean35 = dateTime30.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.Chronology chronology39 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant37, readableInstant38);
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((long) ' ', chronology39);
        int int41 = dateTime40.getHourOfDay();
        org.joda.time.DateTime dateTime43 = dateTime40.withYear((int) (short) -1);
        java.lang.String str44 = dateTime40.toString();
        int int45 = dateTime40.getEra();
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.DateTime dateTime47 = dateTime40.toDateTime(dateTimeZone46);
        org.joda.time.DateTime dateTime49 = dateTime40.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone50 = dateTime49.getZone();
        org.joda.time.DateTime dateTime51 = dateTime30.toDateTime(dateTimeZone50);
        org.joda.time.Chronology chronology52 = julianChronology25.withZone(dateTimeZone50);
        org.joda.time.chrono.BuddhistChronology buddhistChronology53 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone50);
        mutableDateTime9.setZoneRetainFields(dateTimeZone50);
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.ReadableInstant readableInstant57 = null;
        org.joda.time.Chronology chronology58 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant56, readableInstant57);
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) ' ', chronology58);
        int int60 = dateTime59.getHourOfDay();
        org.joda.time.DateTime dateTime62 = dateTime59.withYear((int) (short) -1);
        org.joda.time.DateTime.Property property63 = dateTime59.centuryOfEra();
        org.joda.time.DateTime dateTime65 = property63.addToCopy((long) 2);
        org.joda.time.DateTime.Property property66 = dateTime65.dayOfYear();
        org.joda.time.ReadableInstant readableInstant68 = null;
        org.joda.time.ReadableInstant readableInstant69 = null;
        org.joda.time.Chronology chronology70 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant68, readableInstant69);
        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((long) ' ', chronology70);
        org.joda.time.DateMidnight dateMidnight72 = dateTime71.toDateMidnight();
        org.joda.time.DateTime dateTime74 = dateTime71.plusMillis(0);
        int int75 = property66.getDifference((org.joda.time.ReadableInstant) dateTime71);
        org.joda.time.DateMidnight dateMidnight76 = dateTime71.toDateMidnight();
        org.joda.time.chrono.LimitChronology limitChronology77 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.ReadableDateTime) mutableDateTime9, (org.joda.time.ReadableDateTime) dateMidnight76);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone82 = new org.joda.time.tz.FixedDateTimeZone("", "era", (int) (short) -1, (int) '#');
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone83 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone82);
        int int85 = cachedDateTimeZone83.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone86 = cachedDateTimeZone83.getUncachedZone();
        java.lang.String str87 = cachedDateTimeZone83.getID();
        long long89 = cachedDateTimeZone83.nextTransition((long) 5);
        org.joda.time.MutableDateTime mutableDateTime90 = mutableDateTime9.toMutableDateTime((org.joda.time.DateTimeZone) cachedDateTimeZone83);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-99948L) + "'", long19 == (-99948L));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(localDateTime33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str44.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(chronology52);
        org.junit.Assert.assertNotNull(buddhistChronology53);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertNotNull(chronology70);
        org.junit.Assert.assertNotNull(dateMidnight72);
        org.junit.Assert.assertNotNull(dateTime74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 73049 + "'", int75 == 73049);
        org.junit.Assert.assertNotNull(dateMidnight76);
        org.junit.Assert.assertNotNull(limitChronology77);
        org.junit.Assert.assertNotNull(cachedDateTimeZone83);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-1) + "'", int85 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone86);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "" + "'", str87.equals(""));
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 5L + "'", long89 == 5L);
        org.junit.Assert.assertNotNull(mutableDateTime90);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField18);
        long long22 = skipDateTimeField19.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType23, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        java.lang.String str29 = julianChronology28.toString();
        org.joda.time.DurationField durationField30 = julianChronology28.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField31.getRangeDurationField();
        long long35 = unsupportedDateTimeField31.add((long) (short) 10, (long) 10);
        org.joda.time.DurationField durationField36 = unsupportedDateTimeField31.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112178799990L) + "'", long16 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1960L) + "'", long22 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JulianChronology[UTC]" + "'", str29.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 600010L + "'", long35 == 600010L);
        org.junit.Assert.assertNull(durationField36);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) ' ', (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', chronology4);
        int int6 = dateTime5.getHourOfDay();
        int int7 = dateTime5.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime5.minusDays(10);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) ' ', chronology13);
        int int15 = dateTime14.getHourOfDay();
        org.joda.time.DateTime dateTime17 = dateTime14.withYear((int) (short) -1);
        java.lang.String str18 = dateTime14.toString();
        int int19 = dateTime14.getEra();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime14.toDateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime14.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone24 = dateTime23.getZone();
        long long27 = dateTimeZone24.adjustOffset(10L, false);
        org.joda.time.MutableDateTime mutableDateTime28 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime5, dateTimeZone24);
        org.joda.time.Chronology chronology29 = buddhistChronology0.withZone(dateTimeZone24);
        org.joda.time.DurationField durationField30 = buddhistChronology0.days();
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        org.joda.time.Chronology chronology33 = buddhistChronology0.withZone(dateTimeZone32);
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone32);
        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property36 = mutableDateTime35.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime38 = property36.add((long) (-3));
        org.joda.time.ReadableInstant readableInstant40 = null;
        org.joda.time.ReadableInstant readableInstant41 = null;
        org.joda.time.Chronology chronology42 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant40, readableInstant41);
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((long) ' ', chronology42);
        int int44 = dateTime43.getHourOfDay();
        org.joda.time.DateTime dateTime46 = dateTime43.withYear((int) (short) -1);
        java.lang.String str47 = dateTime43.toString();
        int int48 = dateTime43.getEra();
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.DateTime dateTime50 = dateTime43.toDateTime(dateTimeZone49);
        org.joda.time.DateTime dateTime52 = dateTime43.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone53 = dateTime52.getZone();
        org.joda.time.ReadableInstant readableInstant55 = null;
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.Chronology chronology57 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant55, readableInstant56);
        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime((long) ' ', chronology57);
        boolean boolean60 = dateTime58.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime61 = dateTime58.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant63 = null;
        org.joda.time.ReadableInstant readableInstant64 = null;
        org.joda.time.Chronology chronology65 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant63, readableInstant64);
        org.joda.time.DateTime dateTime66 = new org.joda.time.DateTime((long) ' ', chronology65);
        boolean boolean68 = dateTime66.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime69 = dateTime66.toLocalDateTime();
        org.joda.time.DateTime dateTime70 = dateTime58.withFields((org.joda.time.ReadablePartial) localDateTime69);
        boolean boolean71 = dateTimeZone53.isLocalDateTimeGap(localDateTime69);
        org.joda.time.MutableDateTime mutableDateTime72 = mutableDateTime38.toMutableDateTime(dateTimeZone53);
        org.joda.time.chrono.GJChronology gJChronology73 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone53);
        org.joda.time.Chronology chronology74 = gregorianChronology34.withZone(dateTimeZone53);
        org.joda.time.DurationField durationField75 = gregorianChronology34.halfdays();
        org.joda.time.DurationField durationField76 = gregorianChronology34.seconds();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str18.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(mutableDateTime38);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str47.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(localDateTime61);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(localDateTime69);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(mutableDateTime72);
        org.junit.Assert.assertNotNull(gJChronology73);
        org.junit.Assert.assertNotNull(chronology74);
        org.junit.Assert.assertNotNull(durationField75);
        org.junit.Assert.assertNotNull(durationField76);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "era", (int) (short) -1, (int) '#');
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int7 = cachedDateTimeZone5.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone8 = cachedDateTimeZone5.getUncachedZone();
        java.lang.String str9 = cachedDateTimeZone5.getID();
        long long11 = cachedDateTimeZone5.nextTransition((long) 5);
        java.lang.String str13 = cachedDateTimeZone5.getNameKey((long) (-28378000));
        org.joda.time.Instant instant15 = new org.joda.time.Instant(28800000L);
        org.joda.time.Instant instant18 = instant15.withDurationAdded(0L, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.Integer int20 = dateTimeFormatter19.getPivotYear();
        java.util.Locale locale21 = dateTimeFormatter19.getLocale();
        java.lang.String str22 = instant15.toString(dateTimeFormatter19);
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.Instant instant24 = instant15.minus(readableDuration23);
        org.joda.time.Instant instant25 = instant24.toInstant();
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.Instant instant27 = instant24.minus(readableDuration26);
        boolean boolean28 = cachedDateTimeZone5.equals((java.lang.Object) instant27);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 5L + "'", long11 == 5L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "era" + "'", str13.equals("era"));
        org.junit.Assert.assertNotNull(instant18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNull(int20);
        org.junit.Assert.assertNull(locale21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970001T080000.000Z" + "'", str22.equals("1970001T080000.000Z"));
        org.junit.Assert.assertNotNull(instant24);
        org.junit.Assert.assertNotNull(instant25);
        org.junit.Assert.assertNotNull(instant27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        java.lang.String str14 = skipDateTimeField11.toString();
        int int15 = skipDateTimeField11.getMinimumValue();
        long long17 = skipDateTimeField11.remainder((long) (byte) 10);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str14.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.addWeeks((int) (byte) 0);
        mutableDateTime2.addDays((int) (short) -1);
        mutableDateTime2.addMillis(16);
        mutableDateTime2.add((long) 999);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.append(dateTimeFormatter13);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance();
        long long27 = gJChronology19.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField29 = gJChronology28.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField30 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology19, dateTimeField29);
        long long33 = skipDateTimeField30.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = skipDateTimeField30.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder18.appendDecimal(dateTimeFieldType34, 10, 57600);
        int int38 = mutableDateTime2.get(dateTimeFieldType34);
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 4L, (java.lang.Number) (-28742400), (java.lang.Number) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-62112178799990L) + "'", long27 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1960L) + "'", long33 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 31 + "'", int38 == 31);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        long long15 = skipDateTimeField11.remainder((long) 100);
        long long18 = skipDateTimeField11.set((-3198336L), 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.append(dateTimeFormatter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        long long35 = gJChronology27.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology36.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField37);
        long long41 = skipDateTimeField38.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipDateTimeField38.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder26.appendDecimal(dateTimeFieldType42, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone46);
        java.lang.String str48 = julianChronology47.toString();
        org.joda.time.DurationField durationField49 = julianChronology47.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField49);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType42, 31);
        org.joda.time.DurationField durationField53 = offsetDateTimeField52.getLeapDurationField();
        org.joda.time.DurationField durationField54 = offsetDateTimeField52.getLeapDurationField();
        int int56 = offsetDateTimeField52.getLeapAmount((long) 0);
        int int59 = offsetDateTimeField52.getDifference(0L, (long) 33);
        org.joda.time.DateTimeField dateTimeField60 = offsetDateTimeField52.getWrappedField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3198991L) + "'", long18 == (-3198991L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62112178799990L) + "'", long35 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1960L) + "'", long41 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "JulianChronology[UTC]" + "'", str48.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
        org.junit.Assert.assertNull(durationField53);
        org.junit.Assert.assertNull(durationField54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-33) + "'", int59 == (-33));
        org.junit.Assert.assertNotNull(dateTimeField60);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "era", (int) (short) -1, (int) '#');
        long long6 = fixedDateTimeZone4.nextTransition((long) 200);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean8 = fixedDateTimeZone4.isFixed();
        long long10 = fixedDateTimeZone4.convertUTCToLocal(1560344728795L);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        long long15 = gJChronology11.add(readablePeriod12, (-99948L), 10);
        org.joda.time.DurationField durationField16 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology11.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology11.weekOfWeekyear();
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gJChronology11);
        org.joda.time.DateTimeZone dateTimeZone20 = gJChronology11.getZone();
        org.joda.time.DateTimeField dateTimeField21 = gJChronology11.era();
        boolean boolean22 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeField21);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 200L + "'", long6 == 200L);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560344728794L + "'", long10 == 1560344728794L);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-99948L) + "'", long15 == (-99948L));
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.era();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime8 = property6.addWrapField((-10));
        int int9 = mutableDateTime8.getWeekyear();
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1970 + "'", int9 == 1970);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', chronology4);
        int int6 = dateTime5.getHourOfDay();
        org.joda.time.DateTime dateTime8 = dateTime5.withYear((int) (short) -1);
        java.lang.String str9 = dateTime5.toString();
        int int10 = dateTime5.getEra();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone11);
        org.joda.time.DateTime.Property property13 = dateTime5.dayOfMonth();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime.Property property15 = dateTime5.monthOfYear();
        org.joda.time.DateTime dateTime17 = property15.addToCopy(10);
        boolean boolean19 = dateTime17.isBefore(33L);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str9.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.joda.time.ReadableInstant readableInstant1 = null;
        java.lang.String str2 = dateTimeFormatter0.print(readableInstant1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-01-01T00:00:00Z" + "'", str2.equals("1970-01-01T00:00:00Z"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "100");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.String str5 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertNull(dateTimeFieldType3);
        org.junit.Assert.assertNull(dateTimeFieldType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.monthOfYear();
        mutableDateTime2.setDayOfYear((int) 'a');
        try {
            mutableDateTime2.setMinuteOfDay((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfDay must be in the range [0,1439]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) ' ', chronology5);
        int int7 = dateTime6.getHourOfDay();
        int int8 = dateTime6.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime6.minusDays(10);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant12, readableInstant13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) ' ', chronology14);
        int int16 = dateTime15.getHourOfDay();
        org.joda.time.DateTime dateTime18 = dateTime15.withYear((int) (short) -1);
        java.lang.String str19 = dateTime15.toString();
        int int20 = dateTime15.getEra();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = dateTime15.toDateTime(dateTimeZone21);
        org.joda.time.DateTime dateTime24 = dateTime15.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone25 = dateTime24.getZone();
        long long28 = dateTimeZone25.adjustOffset(10L, false);
        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime6, dateTimeZone25);
        org.joda.time.Chronology chronology30 = buddhistChronology1.withZone(dateTimeZone25);
        org.joda.time.DurationField durationField31 = buddhistChronology1.days();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeUtils.getZone(dateTimeZone32);
        org.joda.time.Chronology chronology34 = buddhistChronology1.withZone(dateTimeZone33);
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33);
        org.joda.time.MutableDateTime mutableDateTime36 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property37 = mutableDateTime36.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime39 = property37.add((long) (-3));
        org.joda.time.ReadableInstant readableInstant41 = null;
        org.joda.time.ReadableInstant readableInstant42 = null;
        org.joda.time.Chronology chronology43 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant41, readableInstant42);
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) ' ', chronology43);
        int int45 = dateTime44.getHourOfDay();
        org.joda.time.DateTime dateTime47 = dateTime44.withYear((int) (short) -1);
        java.lang.String str48 = dateTime44.toString();
        int int49 = dateTime44.getEra();
        org.joda.time.DateTimeZone dateTimeZone50 = null;
        org.joda.time.DateTime dateTime51 = dateTime44.toDateTime(dateTimeZone50);
        org.joda.time.DateTime dateTime53 = dateTime44.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone54 = dateTime53.getZone();
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.ReadableInstant readableInstant57 = null;
        org.joda.time.Chronology chronology58 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant56, readableInstant57);
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) ' ', chronology58);
        boolean boolean61 = dateTime59.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime62 = dateTime59.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant64 = null;
        org.joda.time.ReadableInstant readableInstant65 = null;
        org.joda.time.Chronology chronology66 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant64, readableInstant65);
        org.joda.time.DateTime dateTime67 = new org.joda.time.DateTime((long) ' ', chronology66);
        boolean boolean69 = dateTime67.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime70 = dateTime67.toLocalDateTime();
        org.joda.time.DateTime dateTime71 = dateTime59.withFields((org.joda.time.ReadablePartial) localDateTime70);
        boolean boolean72 = dateTimeZone54.isLocalDateTimeGap(localDateTime70);
        org.joda.time.MutableDateTime mutableDateTime73 = mutableDateTime39.toMutableDateTime(dateTimeZone54);
        org.joda.time.chrono.GJChronology gJChronology74 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone54);
        org.joda.time.Chronology chronology75 = gregorianChronology35.withZone(dateTimeZone54);
        org.joda.time.DurationField durationField76 = gregorianChronology35.halfdays();
        org.joda.time.DateTimeZone dateTimeZone77 = gregorianChronology35.getZone();
        long long79 = dateTimeZone0.getMillisKeepLocal(dateTimeZone77, (-292277023L));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str19.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str48.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(localDateTime62);
        org.junit.Assert.assertNotNull(chronology66);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(localDateTime70);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(mutableDateTime73);
        org.junit.Assert.assertNotNull(gJChronology74);
        org.junit.Assert.assertNotNull(chronology75);
        org.junit.Assert.assertNotNull(durationField76);
        org.junit.Assert.assertNotNull(dateTimeZone77);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + (-292277023L) + "'", long79 == (-292277023L));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gJChronology1.add(readablePeriod2, (-99948L), 10);
        org.joda.time.DurationField durationField6 = gJChronology1.millis();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology1.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology1.minuteOfDay();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone13 = dateTimeZoneBuilder10.toDateTimeZone("12/31/69", false);
        org.joda.time.Chronology chronology14 = gJChronology1.withZone(dateTimeZone13);
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket((-3650L), (org.joda.time.Chronology) gJChronology1, locale15);
        org.joda.time.DateTimeZone dateTimeZone17 = dateTimeParserBucket16.getZone();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-99948L) + "'", long5 == (-99948L));
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeZone17);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        org.joda.time.DateTime.Property property8 = dateTime4.centuryOfEra();
        org.joda.time.Interval interval9 = property8.toInterval();
        int int10 = property8.getMinimumValue();
        org.joda.time.DateTime dateTime11 = property8.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime13 = dateTime11.plus((long) 2169);
        org.joda.time.DateTime.Property property14 = dateTime11.secondOfMinute();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(2170, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 2170");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) ' ', chronology11);
        int int13 = dateTime12.getHourOfDay();
        int int14 = dateTime12.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime16 = dateTime12.minusDays(10);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant18, readableInstant19);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) ' ', chronology20);
        int int22 = dateTime21.getHourOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withYear((int) (short) -1);
        java.lang.String str25 = dateTime21.toString();
        int int26 = dateTime21.getEra();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = dateTime21.toDateTime(dateTimeZone27);
        org.joda.time.DateTime dateTime30 = dateTime21.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone31 = dateTime30.getZone();
        long long34 = dateTimeZone31.adjustOffset(10L, false);
        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime12, dateTimeZone31);
        org.joda.time.Chronology chronology36 = buddhistChronology7.withZone(dateTimeZone31);
        long long38 = dateTimeZone31.convertUTCToLocal((-28799999L));
        try {
            org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((int) (byte) 100, 28800001, (int) '4', (-33), (-33), 28800001, (-4), dateTimeZone31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -33 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str25.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-28799999L) + "'", long38 == (-28799999L));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) ' ', (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.append(dateTimeFormatter6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        long long20 = gJChronology12.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology12, dateTimeField22);
        long long26 = skipDateTimeField23.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = skipDateTimeField23.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder11.appendDecimal(dateTimeFieldType27, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone31);
        java.lang.String str33 = julianChronology32.toString();
        org.joda.time.DurationField durationField34 = julianChronology32.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField35 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField34);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType27, 28800000);
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstance();
        long long46 = gJChronology38.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField48 = gJChronology47.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField49 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology38, dateTimeField48);
        java.lang.String str51 = skipDateTimeField49.getAsText((long) (byte) 100);
        long long53 = skipDateTimeField49.remainder((long) 100);
        long long56 = skipDateTimeField49.set((-3198336L), 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder57.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter59 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = dateTimeFormatterBuilder58.append(dateTimeFormatter59);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder60.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder62.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology65 = org.joda.time.chrono.GJChronology.getInstance();
        long long73 = gJChronology65.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology74 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField75 = gJChronology74.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField76 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology65, dateTimeField75);
        long long79 = skipDateTimeField76.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType80 = skipDateTimeField76.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder83 = dateTimeFormatterBuilder64.appendDecimal(dateTimeFieldType80, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone84 = null;
        org.joda.time.chrono.JulianChronology julianChronology85 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone84);
        java.lang.String str86 = julianChronology85.toString();
        org.joda.time.DurationField durationField87 = julianChronology85.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField88 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType80, durationField87);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField90 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField49, dateTimeFieldType80, 31);
        boolean boolean91 = offsetDateTimeField90.isLenient();
        org.joda.time.DurationField durationField92 = offsetDateTimeField90.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType93 = offsetDateTimeField90.getType();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder95 = dateTimeFormatterBuilder0.appendFixedDecimal(dateTimeFieldType93, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal number of digits: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-62112178799990L) + "'", long20 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1960L) + "'", long26 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "JulianChronology[UTC]" + "'", str33.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-62112178799990L) + "'", long46 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "100" + "'", str51.equals("100"));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-3198991L) + "'", long56 == (-3198991L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertNotNull(dateTimeFormatter59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder60);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(gJChronology65);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-62112178799990L) + "'", long73 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology74);
        org.junit.Assert.assertNotNull(dateTimeField75);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + (-1960L) + "'", long79 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType80);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder83);
        org.junit.Assert.assertNotNull(julianChronology85);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "JulianChronology[UTC]" + "'", str86.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField87);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField88);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNull(durationField92);
        org.junit.Assert.assertNotNull(dateTimeFieldType93);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        long long15 = skipDateTimeField11.remainder((long) 100);
        long long18 = skipDateTimeField11.set((-3198336L), 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.append(dateTimeFormatter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        long long35 = gJChronology27.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology36.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField37);
        long long41 = skipDateTimeField38.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipDateTimeField38.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder26.appendDecimal(dateTimeFieldType42, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone46);
        java.lang.String str48 = julianChronology47.toString();
        org.joda.time.DurationField durationField49 = julianChronology47.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField49);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType42, 31);
        int int53 = offsetDateTimeField52.getMinimumValue();
        long long56 = offsetDateTimeField52.getDifferenceAsLong((long) (-10), (-1L));
        org.joda.time.format.DateTimeFormatter dateTimeFormatter57 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstance();
        long long66 = gJChronology58.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology67 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField68 = gJChronology67.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField69 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology58, dateTimeField68);
        org.joda.time.DateTimeZone dateTimeZone70 = null;
        org.joda.time.chrono.JulianChronology julianChronology71 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone70);
        org.joda.time.ReadableInstant readableInstant73 = null;
        org.joda.time.ReadableInstant readableInstant74 = null;
        org.joda.time.Chronology chronology75 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant73, readableInstant74);
        org.joda.time.DateTime dateTime76 = new org.joda.time.DateTime((long) ' ', chronology75);
        boolean boolean78 = dateTime76.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime79 = dateTime76.toLocalDateTime();
        int[] intArray81 = julianChronology71.get((org.joda.time.ReadablePartial) localDateTime79, (-62112150421990L));
        java.util.Locale locale83 = null;
        java.lang.String str84 = skipDateTimeField69.getAsShortText((org.joda.time.ReadablePartial) localDateTime79, (int) (byte) 0, locale83);
        java.lang.String str85 = dateTimeFormatter57.print((org.joda.time.ReadablePartial) localDateTime79);
        int int86 = offsetDateTimeField52.getMaximumValue((org.joda.time.ReadablePartial) localDateTime79);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3198991L) + "'", long18 == (-3198991L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62112178799990L) + "'", long35 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1960L) + "'", long41 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "JulianChronology[UTC]" + "'", str48.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 32 + "'", int53 == 32);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-9L) + "'", long56 == (-9L));
        org.junit.Assert.assertNotNull(dateTimeFormatter57);
        org.junit.Assert.assertNotNull(gJChronology58);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-62112178799990L) + "'", long66 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(julianChronology71);
        org.junit.Assert.assertNotNull(chronology75);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(localDateTime79);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "0" + "'", str84.equals("0"));
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "1/1/70" + "'", str85.equals("1/1/70"));
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1030 + "'", int86 == 1030);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(28800000L);
        org.joda.time.Instant instant4 = instant1.withDurationAdded(0L, 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.Integer int6 = dateTimeFormatter5.getPivotYear();
        java.util.Locale locale7 = dateTimeFormatter5.getLocale();
        java.lang.String str8 = instant1.toString(dateTimeFormatter5);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Instant instant10 = instant1.minus(readableDuration9);
        org.joda.time.Instant instant11 = instant10.toInstant();
        org.joda.time.Instant instant13 = instant11.plus((-99948L));
        org.joda.time.MutableDateTime mutableDateTime14 = instant11.toMutableDateTime();
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(int6);
        org.junit.Assert.assertNull(locale7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970001T080000.000Z" + "'", str8.equals("1970001T080000.000Z"));
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(instant11);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, readableInstant11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) ' ', chronology12);
        boolean boolean15 = dateTime13.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime16 = dateTime13.toLocalDateTime();
        boolean boolean18 = dateTime13.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant20, readableInstant21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) ' ', chronology22);
        int int24 = dateTime23.getHourOfDay();
        org.joda.time.DateTime dateTime26 = dateTime23.withYear((int) (short) -1);
        java.lang.String str27 = dateTime23.toString();
        int int28 = dateTime23.getEra();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = dateTime23.toDateTime(dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime23.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone33 = dateTime32.getZone();
        org.joda.time.DateTime dateTime34 = dateTime13.toDateTime(dateTimeZone33);
        org.joda.time.Chronology chronology35 = julianChronology8.withZone(dateTimeZone33);
        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone33);
        java.lang.Object obj37 = null;
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField39 = gJChronology38.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField40 = gJChronology38.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeUtils.getZone(dateTimeZone41);
        org.joda.time.Chronology chronology43 = gJChronology38.withZone(dateTimeZone41);
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(obj37, dateTimeZone41);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.MutableDateTime mutableDateTime47 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone46);
        mutableDateTime47.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property50 = mutableDateTime47.era();
        java.lang.String str51 = property50.getName();
        org.joda.time.MutableDateTime mutableDateTime52 = property50.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime53 = property50.roundHalfCeiling();
        int int54 = dateTimeZone41.getOffset((org.joda.time.ReadableInstant) mutableDateTime53);
        org.joda.time.Chronology chronology55 = buddhistChronology36.withZone(dateTimeZone41);
        java.lang.String str56 = dateTimeZone41.getID();
        try {
            org.joda.time.MutableDateTime mutableDateTime57 = new org.joda.time.MutableDateTime(28800001, 0, 32, 31, (int) (byte) 0, (-33), (int) (short) 100, dateTimeZone41);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(localDateTime16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str27.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(buddhistChronology36);
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "era" + "'", str51.equals("era"));
        org.junit.Assert.assertNotNull(mutableDateTime52);
        org.junit.Assert.assertNotNull(mutableDateTime53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(chronology55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "UTC" + "'", str56.equals("UTC"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        int int6 = dateTime4.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime4.secondOfDay();
        boolean boolean8 = dateTime4.isBeforeNow();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        long long17 = gJChronology9.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField19);
        long long23 = skipDateTimeField20.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = skipDateTimeField20.getType();
        org.joda.time.DateTime.Property property25 = dateTime4.property(dateTimeFieldType24);
        org.joda.time.LocalTime localTime26 = dateTime4.toLocalTime();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62112178799990L) + "'", long17 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1960L) + "'", long23 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(localTime26);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) '#', (int) '4');
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap6);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(strMap6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime4.minusSeconds(16);
        org.joda.time.DateTime dateTime15 = dateTime13.minusDays(57600);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone16);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant19, readableInstant20);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) ' ', chronology21);
        boolean boolean24 = dateTime22.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime25 = dateTime22.toLocalDateTime();
        boolean boolean27 = dateTime22.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant29, readableInstant30);
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) ' ', chronology31);
        int int33 = dateTime32.getHourOfDay();
        org.joda.time.DateTime dateTime35 = dateTime32.withYear((int) (short) -1);
        java.lang.String str36 = dateTime32.toString();
        int int37 = dateTime32.getEra();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.DateTime dateTime39 = dateTime32.toDateTime(dateTimeZone38);
        org.joda.time.DateTime dateTime41 = dateTime32.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone42 = dateTime41.getZone();
        org.joda.time.DateTime dateTime43 = dateTime22.toDateTime(dateTimeZone42);
        org.joda.time.Chronology chronology44 = julianChronology17.withZone(dateTimeZone42);
        org.joda.time.DateTimeZone dateTimeZone45 = julianChronology17.getZone();
        org.joda.time.DateTime dateTime46 = dateTime13.withZoneRetainFields(dateTimeZone45);
        org.joda.time.DateTime dateTime48 = dateTime46.plusMillis(12);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str8.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(localDateTime25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str36.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(chronology44);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.DateTime.Property property7 = dateTime4.dayOfWeek();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) ' ', chronology11);
        boolean boolean14 = dateTime12.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime15 = dateTime12.toLocalDateTime();
        org.joda.time.DateTime dateTime16 = dateTime4.withFields((org.joda.time.ReadablePartial) localDateTime15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        boolean boolean18 = dateTime4.isSupported(dateTimeFieldType17);
        int int19 = dateTime4.getCenturyOfEra();
        org.joda.time.DateTime.Property property20 = dateTime4.minuteOfDay();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 19 + "'", int19 == 19);
        org.junit.Assert.assertNotNull(property20);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) ' ', chronology6);
        boolean boolean9 = dateTime7.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime10 = dateTime7.toLocalDateTime();
        boolean boolean12 = dateTime7.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant14, readableInstant15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) ' ', chronology16);
        int int18 = dateTime17.getHourOfDay();
        org.joda.time.DateTime dateTime20 = dateTime17.withYear((int) (short) -1);
        java.lang.String str21 = dateTime17.toString();
        int int22 = dateTime17.getEra();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = dateTime17.toDateTime(dateTimeZone23);
        org.joda.time.DateTime dateTime26 = dateTime17.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone27 = dateTime26.getZone();
        org.joda.time.DateTime dateTime28 = dateTime7.toDateTime(dateTimeZone27);
        org.joda.time.Chronology chronology29 = julianChronology2.withZone(dateTimeZone27);
        org.joda.time.DateTimeZone dateTimeZone30 = julianChronology2.getZone();
        long long34 = julianChronology2.add((long) (-28800000), (long) ' ', 0);
        org.joda.time.DateTimeZone dateTimeZone35 = julianChronology2.getZone();
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime(4317753600001L, dateTimeZone35);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str21.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-28800000L) + "'", long34 == (-28800000L));
        org.junit.Assert.assertNotNull(dateTimeZone35);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        org.joda.time.DateTime dateTime8 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime4.millisOfSecond();
        org.joda.time.DateTime dateTime10 = property9.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.halfdayOfDay();
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket((long) 100, (org.joda.time.Chronology) julianChronology13, locale15);
        java.lang.String str17 = julianChronology13.toString();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology13.era();
        int int19 = dateTime10.get(dateTimeField18);
        org.joda.time.DateTime dateTime21 = dateTime10.minusWeeks(999);
        org.joda.time.DateTime dateTime22 = dateTime10.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "JulianChronology[UTC]" + "'", str17.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, readableInstant3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) ' ', chronology4);
        int int6 = dateTime5.getHourOfDay();
        int int7 = dateTime5.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime5.minusDays(10);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant11, readableInstant12);
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) ' ', chronology13);
        int int15 = dateTime14.getHourOfDay();
        org.joda.time.DateTime dateTime17 = dateTime14.withYear((int) (short) -1);
        java.lang.String str18 = dateTime14.toString();
        int int19 = dateTime14.getEra();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = dateTime14.toDateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime14.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone24 = dateTime23.getZone();
        long long27 = dateTimeZone24.adjustOffset(10L, false);
        org.joda.time.MutableDateTime mutableDateTime28 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime5, dateTimeZone24);
        org.joda.time.Chronology chronology29 = buddhistChronology0.withZone(dateTimeZone24);
        org.joda.time.DurationField durationField30 = buddhistChronology0.days();
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        org.joda.time.Chronology chronology33 = buddhistChronology0.withZone(dateTimeZone32);
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone32);
        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property36 = mutableDateTime35.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime38 = property36.add((long) (-3));
        org.joda.time.ReadableInstant readableInstant40 = null;
        org.joda.time.ReadableInstant readableInstant41 = null;
        org.joda.time.Chronology chronology42 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant40, readableInstant41);
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((long) ' ', chronology42);
        int int44 = dateTime43.getHourOfDay();
        org.joda.time.DateTime dateTime46 = dateTime43.withYear((int) (short) -1);
        java.lang.String str47 = dateTime43.toString();
        int int48 = dateTime43.getEra();
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.DateTime dateTime50 = dateTime43.toDateTime(dateTimeZone49);
        org.joda.time.DateTime dateTime52 = dateTime43.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone53 = dateTime52.getZone();
        org.joda.time.ReadableInstant readableInstant55 = null;
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.Chronology chronology57 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant55, readableInstant56);
        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime((long) ' ', chronology57);
        boolean boolean60 = dateTime58.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime61 = dateTime58.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant63 = null;
        org.joda.time.ReadableInstant readableInstant64 = null;
        org.joda.time.Chronology chronology65 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant63, readableInstant64);
        org.joda.time.DateTime dateTime66 = new org.joda.time.DateTime((long) ' ', chronology65);
        boolean boolean68 = dateTime66.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime69 = dateTime66.toLocalDateTime();
        org.joda.time.DateTime dateTime70 = dateTime58.withFields((org.joda.time.ReadablePartial) localDateTime69);
        boolean boolean71 = dateTimeZone53.isLocalDateTimeGap(localDateTime69);
        org.joda.time.MutableDateTime mutableDateTime72 = mutableDateTime38.toMutableDateTime(dateTimeZone53);
        org.joda.time.chrono.GJChronology gJChronology73 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone53);
        org.joda.time.Chronology chronology74 = gregorianChronology34.withZone(dateTimeZone53);
        org.joda.time.DateTimeField dateTimeField75 = gregorianChronology34.secondOfMinute();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str18.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(mutableDateTime38);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str47.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(localDateTime61);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(localDateTime69);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(mutableDateTime72);
        org.junit.Assert.assertNotNull(gJChronology73);
        org.junit.Assert.assertNotNull(chronology74);
        org.junit.Assert.assertNotNull(dateTimeField75);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        long long9 = gJChronology1.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "era", (int) (short) -1, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket((long) 97, (org.joda.time.Chronology) gJChronology1, locale16, (java.lang.Integer) 961);
        org.joda.time.DateTimeField dateTimeField19 = gJChronology1.secondOfDay();
        org.joda.time.DateTimeField dateTimeField20 = gJChronology1.hourOfHalfday();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62112178799990L) + "'", long9 == (-62112178799990L));
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        java.lang.String str15 = skipDateTimeField11.getAsShortText((long) 57600);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        long long24 = gJChronology16.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology25.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField26);
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant29, readableInstant30);
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) ' ', chronology31);
        boolean boolean34 = dateTime32.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime35 = dateTime32.toLocalDateTime();
        java.util.Locale locale36 = null;
        java.lang.String str37 = skipDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDateTime35, locale36);
        int[] intArray38 = null;
        int int39 = skipDateTimeField11.getMinimumValue((org.joda.time.ReadablePartial) localDateTime35, intArray38);
        try {
            long long42 = skipDateTimeField11.set((-99948L), (-10));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for millisOfSecond must be in the range [1,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "600" + "'", str15.equals("600"));
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-62112178799990L) + "'", long24 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(localDateTime35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "32" + "'", str37.equals("32"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        long long15 = skipDateTimeField11.remainder((long) 100);
        long long18 = skipDateTimeField11.set((-3198336L), 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.append(dateTimeFormatter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        long long35 = gJChronology27.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology36.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField37);
        long long41 = skipDateTimeField38.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipDateTimeField38.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder26.appendDecimal(dateTimeFieldType42, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone46);
        java.lang.String str48 = julianChronology47.toString();
        org.joda.time.DurationField durationField49 = julianChronology47.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField49);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType42, 31);
        org.joda.time.ReadablePartial readablePartial53 = null;
        java.util.Locale locale55 = null;
        java.lang.String str56 = offsetDateTimeField52.getAsText(readablePartial53, 16, locale55);
        org.joda.time.DateTimeZone dateTimeZone57 = null;
        org.joda.time.chrono.JulianChronology julianChronology58 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone57);
        org.joda.time.ReadableInstant readableInstant60 = null;
        org.joda.time.ReadableInstant readableInstant61 = null;
        org.joda.time.Chronology chronology62 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant60, readableInstant61);
        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime((long) ' ', chronology62);
        boolean boolean65 = dateTime63.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime66 = dateTime63.toLocalDateTime();
        int[] intArray68 = julianChronology58.get((org.joda.time.ReadablePartial) localDateTime66, (-62112150421990L));
        java.util.Locale locale69 = null;
        java.lang.String str70 = offsetDateTimeField52.getAsShortText((org.joda.time.ReadablePartial) localDateTime66, locale69);
        int int71 = offsetDateTimeField52.getOffset();
        java.util.Locale locale72 = null;
        int int73 = offsetDateTimeField52.getMaximumShortTextLength(locale72);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3198991L) + "'", long18 == (-3198991L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62112178799990L) + "'", long35 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1960L) + "'", long41 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "JulianChronology[UTC]" + "'", str48.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "16" + "'", str56.equals("16"));
        org.junit.Assert.assertNotNull(julianChronology58);
        org.junit.Assert.assertNotNull(chronology62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(localDateTime66);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "32" + "'", str70.equals("32"));
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 31 + "'", int71 == 31);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 4 + "'", int73 == 4);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.addWeeks((int) (byte) 0);
        org.joda.time.DateTime dateTime5 = mutableDateTime2.toDateTimeISO();
        try {
            mutableDateTime2.setTime((-28800000), (int) (byte) 10, 33, 69);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        int int5 = mutableDateTime2.getYearOfEra();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.minuteOfHour();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime2.dayOfWeek();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.secondOfDay();
        boolean boolean2 = property1.isLeap();
        org.joda.time.DurationField durationField3 = property1.getLeapDurationField();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(durationField3);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) ' ', chronology6);
        boolean boolean9 = dateTime7.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime10 = dateTime7.toLocalDateTime();
        boolean boolean12 = dateTime7.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant14, readableInstant15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) ' ', chronology16);
        int int18 = dateTime17.getHourOfDay();
        org.joda.time.DateTime dateTime20 = dateTime17.withYear((int) (short) -1);
        java.lang.String str21 = dateTime17.toString();
        int int22 = dateTime17.getEra();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = dateTime17.toDateTime(dateTimeZone23);
        org.joda.time.DateTime dateTime26 = dateTime17.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone27 = dateTime26.getZone();
        org.joda.time.DateTime dateTime28 = dateTime7.toDateTime(dateTimeZone27);
        org.joda.time.Chronology chronology29 = julianChronology2.withZone(dateTimeZone27);
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime(0L, (org.joda.time.Chronology) julianChronology2);
        int int31 = julianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology32 = julianChronology2.withUTC();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str21.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(chronology32);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        long long15 = skipDateTimeField11.remainder((long) 100);
        long long18 = skipDateTimeField11.set((-3198336L), 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.append(dateTimeFormatter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        long long35 = gJChronology27.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology36.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField37);
        long long41 = skipDateTimeField38.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipDateTimeField38.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder26.appendDecimal(dateTimeFieldType42, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone46);
        java.lang.String str48 = julianChronology47.toString();
        org.joda.time.DurationField durationField49 = julianChronology47.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField49);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType42, 31);
        int int53 = offsetDateTimeField52.getMinimumValue();
        int int56 = offsetDateTimeField52.getDifference((-99948L), 0L);
        java.util.Locale locale57 = null;
        int int58 = offsetDateTimeField52.getMaximumTextLength(locale57);
        org.joda.time.ReadablePartial readablePartial59 = null;
        int int60 = offsetDateTimeField52.getMinimumValue(readablePartial59);
        int int63 = offsetDateTimeField52.getDifference((long) (byte) 10, 292278993L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3198991L) + "'", long18 == (-3198991L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62112178799990L) + "'", long35 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1960L) + "'", long41 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "JulianChronology[UTC]" + "'", str48.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 32 + "'", int53 == 32);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-99948) + "'", int56 == (-99948));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 4 + "'", int58 == 4);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 32 + "'", int60 == 32);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-292278983) + "'", int63 == (-292278983));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        org.joda.time.DateTime dateTime10 = dateTime4.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str8.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField11.getAsText((int) ' ', locale13);
        int int16 = skipDateTimeField11.getMaximumValue(0L);
        boolean boolean18 = skipDateTimeField11.isLeap((long) 5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.append(dateTimeFormatter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        long long35 = gJChronology27.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology36.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField37);
        long long41 = skipDateTimeField38.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipDateTimeField38.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder26.appendDecimal(dateTimeFieldType42, 10, 57600);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType42, 1970);
        java.util.Locale locale49 = null;
        java.lang.String str50 = offsetDateTimeField47.getAsText(86400100L, locale49);
        java.util.Locale locale53 = null;
        try {
            long long54 = offsetDateTimeField47.set((long) ' ', "America/Los_Angeles", locale53);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"America/Los_Angeles\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "32" + "'", str14.equals("32"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 999 + "'", int16 == 999);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62112178799990L) + "'", long35 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1960L) + "'", long41 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "2070" + "'", str50.equals("2070"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField18);
        long long22 = skipDateTimeField19.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType23, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        java.lang.String str29 = julianChronology28.toString();
        org.joda.time.DurationField durationField30 = julianChronology28.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField31.getRangeDurationField();
        long long35 = unsupportedDateTimeField31.add((long) ' ', 6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112178799990L) + "'", long16 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1960L) + "'", long22 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JulianChronology[UTC]" + "'", str29.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 360032L + "'", long35 == 360032L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        int int3 = mutableDateTime2.getHourOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone5);
        mutableDateTime6.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime6.era();
        mutableDateTime2.setTime((org.joda.time.ReadableInstant) mutableDateTime6);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone12);
        mutableDateTime13.setTime((long) (short) 0);
        int int16 = mutableDateTime13.getYearOfEra();
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant18, readableInstant19);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) ' ', chronology20);
        int int22 = dateTime21.getHourOfDay();
        org.joda.time.DateTime dateTime24 = dateTime21.withYear((int) (short) -1);
        java.lang.String str25 = dateTime21.toString();
        int int26 = dateTime21.getEra();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = dateTime21.toDateTime(dateTimeZone27);
        org.joda.time.DateTime dateTime30 = dateTime21.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone31 = dateTime30.getZone();
        long long34 = dateTimeZone31.adjustOffset(10L, false);
        long long38 = dateTimeZone31.convertLocalToUTC((long) 0, false, (long) 97);
        mutableDateTime13.setZoneRetainFields(dateTimeZone31);
        org.joda.time.MutableDateTime.Property property40 = mutableDateTime13.dayOfMonth();
        boolean boolean41 = mutableDateTime6.isBefore((org.joda.time.ReadableInstant) mutableDateTime13);
        java.lang.Object obj42 = mutableDateTime13.clone();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1970 + "'", int16 == 1970);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str25.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(obj42);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.Chronology chronology6 = gJChronology1.withZone(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(obj0, dateTimeZone4);
        java.util.GregorianCalendar gregorianCalendar8 = dateTime7.toGregorianCalendar();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(gregorianCalendar8);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField18);
        long long22 = skipDateTimeField19.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType23, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        java.lang.String str29 = julianChronology28.toString();
        org.joda.time.DurationField durationField30 = julianChronology28.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField31.getRangeDurationField();
        boolean boolean33 = unsupportedDateTimeField31.isSupported();
        java.util.Locale locale36 = null;
        try {
            long long37 = unsupportedDateTimeField31.set(37L, "-33", locale36);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112178799990L) + "'", long16 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1960L) + "'", long22 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JulianChronology[UTC]" + "'", str29.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(200L, 4L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 196L + "'", long2 == 196L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        mutableDateTime2.addDays(1);
        mutableDateTime2.addDays((int) '4');
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime2.yearOfCentury();
        mutableDateTime2.addHours(2000);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime4.minusMillis(999);
        org.joda.time.DateTime dateTime15 = dateTime13.withWeekyear((-3));
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant17, readableInstant18);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) ' ', chronology19);
        int int21 = dateTime20.getHourOfDay();
        org.joda.time.DateTime dateTime23 = dateTime20.withYear((int) (short) -1);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant25, readableInstant26);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) ' ', chronology27);
        int int29 = dateTime28.getHourOfDay();
        int int30 = dateTime28.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime32 = dateTime28.minusDays(10);
        org.joda.time.ReadableInstant readableInstant34 = null;
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.Chronology chronology36 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant34, readableInstant35);
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) ' ', chronology36);
        int int38 = dateTime37.getHourOfDay();
        org.joda.time.DateTime dateTime40 = dateTime37.withYear((int) (short) -1);
        java.lang.String str41 = dateTime37.toString();
        int int42 = dateTime37.getEra();
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.DateTime dateTime44 = dateTime37.toDateTime(dateTimeZone43);
        org.joda.time.DateTime dateTime46 = dateTime37.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone47 = dateTime46.getZone();
        long long50 = dateTimeZone47.adjustOffset(10L, false);
        org.joda.time.MutableDateTime mutableDateTime51 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime28, dateTimeZone47);
        org.joda.time.DateTime dateTime52 = dateTime20.withZone(dateTimeZone47);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone47);
        org.joda.time.MutableDateTime mutableDateTime54 = dateTime15.toMutableDateTime(dateTimeZone47);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str8.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str41.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 10L + "'", long50 == 10L);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(mutableDateTime54);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "era", (int) (short) -1, (int) '#');
        long long8 = fixedDateTimeZone6.nextTransition((long) 200);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        boolean boolean10 = fixedDateTimeZone6.isFixed();
        org.joda.time.Chronology chronology11 = buddhistChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DurationField durationField12 = buddhistChronology0.centuries();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 200L + "'", long8 == 200L);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = gJChronology0.withZone(dateTimeZone3);
        org.joda.time.DurationField durationField6 = gJChronology0.halfdays();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance();
        long long15 = gJChronology7.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology7, dateTimeField17);
        java.lang.String str20 = skipDateTimeField18.getAsText((long) (byte) 100);
        long long22 = skipDateTimeField18.remainder((long) 100);
        long long25 = skipDateTimeField18.set((-3198336L), 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder26.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder27.append(dateTimeFormatter28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance();
        long long42 = gJChronology34.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField44 = gJChronology43.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology34, dateTimeField44);
        long long48 = skipDateTimeField45.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = skipDateTimeField45.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder33.appendDecimal(dateTimeFieldType49, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.chrono.JulianChronology julianChronology54 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone53);
        java.lang.String str55 = julianChronology54.toString();
        org.joda.time.DurationField durationField56 = julianChronology54.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField57 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType49, durationField56);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField18, dateTimeFieldType49, 31);
        org.joda.time.ReadablePartial readablePartial60 = null;
        java.util.Locale locale62 = null;
        java.lang.String str63 = offsetDateTimeField59.getAsText(readablePartial60, 16, locale62);
        org.joda.time.DateTimeZone dateTimeZone64 = null;
        org.joda.time.chrono.JulianChronology julianChronology65 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone64);
        org.joda.time.ReadableInstant readableInstant67 = null;
        org.joda.time.ReadableInstant readableInstant68 = null;
        org.joda.time.Chronology chronology69 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant67, readableInstant68);
        org.joda.time.DateTime dateTime70 = new org.joda.time.DateTime((long) ' ', chronology69);
        boolean boolean72 = dateTime70.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime73 = dateTime70.toLocalDateTime();
        int[] intArray75 = julianChronology65.get((org.joda.time.ReadablePartial) localDateTime73, (-62112150421990L));
        java.util.Locale locale76 = null;
        java.lang.String str77 = offsetDateTimeField59.getAsShortText((org.joda.time.ReadablePartial) localDateTime73, locale76);
        int[] intArray79 = gJChronology0.get((org.joda.time.ReadablePartial) localDateTime73, (long) (short) 1);
        org.joda.time.chrono.GJChronology gJChronology80 = org.joda.time.chrono.GJChronology.getInstance();
        long long88 = gJChronology80.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology89 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField90 = gJChronology89.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField91 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology80, dateTimeField90);
        java.lang.String str93 = skipDateTimeField91.getAsText((long) (byte) 100);
        java.lang.String str94 = skipDateTimeField91.toString();
        long long97 = skipDateTimeField91.add((long) (byte) 1, 32L);
        org.joda.time.field.SkipDateTimeField skipDateTimeField99 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipDateTimeField91, (-860));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62112178799990L) + "'", long15 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-3198991L) + "'", long25 == (-3198991L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-62112178799990L) + "'", long42 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-1960L) + "'", long48 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(julianChronology54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "JulianChronology[UTC]" + "'", str55.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField57);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "16" + "'", str63.equals("16"));
        org.junit.Assert.assertNotNull(julianChronology65);
        org.junit.Assert.assertNotNull(chronology69);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(localDateTime73);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "32" + "'", str77.equals("32"));
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertNotNull(gJChronology80);
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + (-62112178799990L) + "'", long88 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology89);
        org.junit.Assert.assertNotNull(dateTimeField90);
        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "100" + "'", str93.equals("100"));
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str94.equals("DateTimeField[millisOfSecond]"));
        org.junit.Assert.assertTrue("'" + long97 + "' != '" + 33L + "'", long97 == 33L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfDay((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) '#', (int) '4');
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder3.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendOptional(dateTimeParser7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) (short) 1, 960);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatter13.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder15.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.append(dateTimeFormatter17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance();
        long long31 = gJChronology23.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = gJChronology32.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology23, dateTimeField33);
        long long37 = skipDateTimeField34.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = skipDateTimeField34.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder22.appendDecimal(dateTimeFieldType38, 10, 57600);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder42.appendFractionOfMinute((int) '#', (int) '4');
        org.joda.time.format.DateTimeParser dateTimeParser46 = dateTimeFormatterBuilder42.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder22.appendOptional(dateTimeParser46);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder11.append(dateTimePrinter14, dateTimeParser46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimePrinter14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-62112178799990L) + "'", long31 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-1960L) + "'", long37 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(dateTimeParser46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        long long15 = skipDateTimeField11.remainder((long) 100);
        long long18 = skipDateTimeField11.set((-3198336L), 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.append(dateTimeFormatter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        long long35 = gJChronology27.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology36.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField37);
        long long41 = skipDateTimeField38.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipDateTimeField38.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder26.appendDecimal(dateTimeFieldType42, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone46);
        java.lang.String str48 = julianChronology47.toString();
        org.joda.time.DurationField durationField49 = julianChronology47.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField49);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType42, 31);
        java.util.Locale locale53 = null;
        int int54 = offsetDateTimeField52.getMaximumTextLength(locale53);
        int int57 = offsetDateTimeField52.getDifference((long) (byte) 100, (long) 960);
        long long60 = offsetDateTimeField52.addWrapField(33L, 4);
        long long63 = offsetDateTimeField52.add((long) 59, 4);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3198991L) + "'", long18 == (-3198991L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62112178799990L) + "'", long35 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1960L) + "'", long41 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "JulianChronology[UTC]" + "'", str48.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 4 + "'", int54 == 4);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-860) + "'", int57 == (-860));
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 37L + "'", long60 == 37L);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 63L + "'", long63 == 63L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        long long14 = skipDateTimeField11.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipDateTimeField11.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.append(dateTimeFormatter18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance();
        long long32 = gJChronology24.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField34 = gJChronology33.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField35 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology24, dateTimeField34);
        long long38 = skipDateTimeField35.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = skipDateTimeField35.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder23.appendDecimal(dateTimeFieldType39, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone43 = null;
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone43);
        java.lang.String str45 = julianChronology44.toString();
        org.joda.time.DurationField durationField46 = julianChronology44.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField47 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType39, durationField46);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField48 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType15, durationField46);
        org.joda.time.DurationFieldType durationFieldType49 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField50 = new org.joda.time.field.DecoratedDurationField(durationField46, durationFieldType49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1960L) + "'", long14 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62112178799990L) + "'", long32 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-1960L) + "'", long38 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "JulianChronology[UTC]" + "'", str45.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField47);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField48);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        int int6 = dateTime4.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime8 = dateTime4.minusDays(10);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, readableInstant11);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) ' ', chronology12);
        int int14 = dateTime13.getHourOfDay();
        org.joda.time.DateTime dateTime16 = dateTime13.withYear((int) (short) -1);
        java.lang.String str17 = dateTime13.toString();
        int int18 = dateTime13.getEra();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = dateTime13.toDateTime(dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime13.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime22.getZone();
        long long26 = dateTimeZone23.adjustOffset(10L, false);
        org.joda.time.MutableDateTime mutableDateTime27 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime4, dateTimeZone23);
        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone23);
        org.joda.time.Chronology chronology29 = buddhistChronology28.withUTC();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str17.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
        org.junit.Assert.assertNotNull(buddhistChronology28);
        org.junit.Assert.assertNotNull(chronology29);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("", "era", (int) (short) -1, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = gJChronology0.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 2169);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        int int6 = dateTime4.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime8 = dateTime4.minusDays(10);
        org.joda.time.DateTime dateTime10 = dateTime8.minusDays(0);
        org.joda.time.DateTime dateTime11 = dateTime10.toDateTimeISO();
        org.joda.time.DateTime.Property property12 = dateTime10.minuteOfDay();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        java.lang.Appendable appendable1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.shortDate();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance();
        long long11 = gJChronology3.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField13);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant18, readableInstant19);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) ' ', chronology20);
        boolean boolean23 = dateTime21.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime24 = dateTime21.toLocalDateTime();
        int[] intArray26 = julianChronology16.get((org.joda.time.ReadablePartial) localDateTime24, (-62112150421990L));
        java.util.Locale locale28 = null;
        java.lang.String str29 = skipDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) localDateTime24, (int) (byte) 0, locale28);
        java.lang.String str30 = dateTimeFormatter2.print((org.joda.time.ReadablePartial) localDateTime24);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDateTime24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62112178799990L) + "'", long11 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(localDateTime24);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1/1/70" + "'", str30.equals("1/1/70"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfMinute((int) '#', (int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfHour(63, 28800000);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendYearOfCentury((-33), 86399);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfDay((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        dateTimeFormatterBuilder3.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance();
        long long10 = gJChronology2.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField12);
        org.joda.time.DateTimeField dateTimeField14 = gJChronology2.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology2.minuteOfHour();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, dateTimeField15);
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.parse("32");
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant20, readableInstant21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) ' ', chronology22);
        int int24 = dateTime23.getHourOfDay();
        org.joda.time.DateTime dateTime26 = dateTime23.withYear((int) (short) -1);
        java.lang.String str27 = dateTime23.toString();
        int int28 = dateTime23.getEra();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = dateTime23.toDateTime(dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime23.minusSeconds(16);
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance();
        long long41 = gJChronology33.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField43 = gJChronology42.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology33, dateTimeField43);
        long long47 = skipDateTimeField44.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = skipDateTimeField44.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException50 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType48, "1970-01-01T08:00:00.000Z");
        int int51 = dateTime23.get(dateTimeFieldType48);
        org.joda.time.DateTime.Property property52 = dateTime18.property(dateTimeFieldType48);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField53 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField16, dateTimeFieldType48);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62112178799990L) + "'", long10 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str27.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-62112178799990L) + "'", long41 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-1960L) + "'", long47 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 32 + "'", int51 == 32);
        org.junit.Assert.assertNotNull(property52);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        boolean boolean20 = dateTime18.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        int[] intArray23 = julianChronology13.get((org.joda.time.ReadablePartial) localDateTime21, (-62112150421990L));
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) (byte) 0, locale25);
        int int28 = skipDateTimeField11.get(10L);
        long long31 = skipDateTimeField11.getDifferenceAsLong((-28799999L), (long) 2169);
        boolean boolean32 = skipDateTimeField11.isLenient();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-28802168L) + "'", long31 == (-28802168L));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        boolean boolean6 = dateTime4.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime7 = dateTime4.toLocalDateTime();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, readableInstant10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) ' ', chronology11);
        boolean boolean14 = dateTime12.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime15 = dateTime12.toLocalDateTime();
        org.joda.time.DateTime dateTime16 = dateTime4.withFields((org.joda.time.ReadablePartial) localDateTime15);
        org.joda.time.DateTime.Property property17 = dateTime4.yearOfEra();
        org.joda.time.DateTime dateTime19 = dateTime4.minus(10L);
        org.joda.time.DateTime dateTime21 = dateTime4.withSecondOfMinute(0);
        org.joda.time.DateTime.Property property22 = dateTime4.millisOfSecond();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "era", (int) (short) -1, (int) '#');
        long long6 = fixedDateTimeZone4.nextTransition((long) 200);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        java.lang.String str9 = fixedDateTimeZone4.getNameKey((-28799999L));
        java.lang.String str11 = fixedDateTimeZone4.getNameKey(10L);
        org.joda.time.Instant instant13 = new org.joda.time.Instant((long) 4);
        int int14 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) instant13);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 200L + "'", long6 == 200L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "era" + "'", str9.equals("era"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "era" + "'", str11.equals("era"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(16, 'a', (int) (short) 10, (int) (byte) 1, 999, true, 0);
        java.io.DataOutput dataOutput10 = null;
        try {
            dateTimeZoneBuilder8.writeTo("T00:00:00.032", dataOutput10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket(43L, (org.joda.time.Chronology) gJChronology1, locale2);
        long long8 = gJChronology1.getDateTimeMillis((-33), (int) (byte) 1, (int) (short) 1, 5);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-63177235199995L) + "'", long8 == (-63177235199995L));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone2);
        mutableDateTime3.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime3.monthOfYear();
        mutableDateTime3.setDayOfYear((int) 'a');
        int int11 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "33", 1);
        java.util.Locale locale12 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter0.withLocale(locale12);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-3) + "'", int11 == (-3));
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("12/31/69", false);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant7, readableInstant8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) ' ', chronology9);
        int int11 = dateTime10.getHourOfDay();
        int int12 = dateTime10.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime14 = dateTime10.minusDays(10);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant16, readableInstant17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) ' ', chronology18);
        int int20 = dateTime19.getHourOfDay();
        org.joda.time.DateTime dateTime22 = dateTime19.withYear((int) (short) -1);
        java.lang.String str23 = dateTime19.toString();
        int int24 = dateTime19.getEra();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = dateTime19.toDateTime(dateTimeZone25);
        org.joda.time.DateTime dateTime28 = dateTime19.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone29 = dateTime28.getZone();
        long long32 = dateTimeZone29.adjustOffset(10L, false);
        org.joda.time.MutableDateTime mutableDateTime33 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime10, dateTimeZone29);
        org.joda.time.Chronology chronology34 = buddhistChronology5.withZone(dateTimeZone29);
        long long36 = dateTimeZone29.convertUTCToLocal((-28799999L));
        org.joda.time.chrono.ZonedChronology zonedChronology37 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology4, dateTimeZone29);
        try {
            long long42 = zonedChronology37.getDateTimeMillis((int) (short) 100, (int) '#', 961, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str23.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-28799999L) + "'", long36 == (-28799999L));
        org.junit.Assert.assertNotNull(zonedChronology37);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfDay((int) ' ', (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) (byte) 10, 16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendTwoDigitYear(73049, true);
        dateTimeFormatterBuilder9.clear();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendPattern("GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: r");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime4.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone14);
        long long17 = dateTimeZone14.convertUTCToLocal(0L);
        long long21 = dateTimeZone14.convertLocalToUTC((long) 999, false, (long) (short) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str8.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 999L + "'", long21 == 999L);
        org.junit.Assert.assertNotNull(gregorianChronology22);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        long long9 = gJChronology1.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "era", (int) (short) -1, (int) '#');
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeZone) fixedDateTimeZone14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket((long) 97, (org.joda.time.Chronology) gJChronology1, locale16, (java.lang.Integer) 961);
        org.joda.time.DateTimeField dateTimeField19 = gJChronology1.secondOfDay();
        org.joda.time.DurationField durationField20 = gJChronology1.weekyears();
        org.joda.time.DateTimeZone dateTimeZone21 = gJChronology1.getZone();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62112178799990L) + "'", long9 == (-62112178799990L));
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.millisOfSecond();
        long long6 = gJChronology0.add((long) '#', (long) 0, (int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone8);
        mutableDateTime9.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime9.monthOfYear();
        mutableDateTime9.setDayOfYear((int) 'a');
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        long long19 = gJChronology15.add(readablePeriod16, (-99948L), 10);
        org.joda.time.DateTime dateTime20 = mutableDateTime9.toDateTime((org.joda.time.Chronology) gJChronology15);
        int int21 = mutableDateTime9.getRoundingMode();
        mutableDateTime9.setYear(100);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant27, readableInstant28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) ' ', chronology29);
        boolean boolean32 = dateTime30.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime33 = dateTime30.toLocalDateTime();
        boolean boolean35 = dateTime30.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant37 = null;
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.Chronology chronology39 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant37, readableInstant38);
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((long) ' ', chronology39);
        int int41 = dateTime40.getHourOfDay();
        org.joda.time.DateTime dateTime43 = dateTime40.withYear((int) (short) -1);
        java.lang.String str44 = dateTime40.toString();
        int int45 = dateTime40.getEra();
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.DateTime dateTime47 = dateTime40.toDateTime(dateTimeZone46);
        org.joda.time.DateTime dateTime49 = dateTime40.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone50 = dateTime49.getZone();
        org.joda.time.DateTime dateTime51 = dateTime30.toDateTime(dateTimeZone50);
        org.joda.time.Chronology chronology52 = julianChronology25.withZone(dateTimeZone50);
        org.joda.time.chrono.BuddhistChronology buddhistChronology53 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone50);
        mutableDateTime9.setZoneRetainFields(dateTimeZone50);
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.ReadableInstant readableInstant57 = null;
        org.joda.time.Chronology chronology58 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant56, readableInstant57);
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) ' ', chronology58);
        int int60 = dateTime59.getHourOfDay();
        org.joda.time.DateTime dateTime62 = dateTime59.withYear((int) (short) -1);
        org.joda.time.DateTime.Property property63 = dateTime59.centuryOfEra();
        org.joda.time.DateTime dateTime65 = property63.addToCopy((long) 2);
        org.joda.time.DateTime.Property property66 = dateTime65.dayOfYear();
        org.joda.time.ReadableInstant readableInstant68 = null;
        org.joda.time.ReadableInstant readableInstant69 = null;
        org.joda.time.Chronology chronology70 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant68, readableInstant69);
        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((long) ' ', chronology70);
        org.joda.time.DateMidnight dateMidnight72 = dateTime71.toDateMidnight();
        org.joda.time.DateTime dateTime74 = dateTime71.plusMillis(0);
        int int75 = property66.getDifference((org.joda.time.ReadableInstant) dateTime71);
        org.joda.time.DateMidnight dateMidnight76 = dateTime71.toDateMidnight();
        org.joda.time.chrono.LimitChronology limitChronology77 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology0, (org.joda.time.ReadableDateTime) mutableDateTime9, (org.joda.time.ReadableDateTime) dateMidnight76);
        org.joda.time.Chronology chronology78 = limitChronology77.withUTC();
        org.joda.time.DateTime dateTime79 = limitChronology77.getUpperLimit();
        java.lang.String str80 = limitChronology77.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-99948L) + "'", long19 == (-99948L));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(localDateTime33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str44.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(chronology52);
        org.junit.Assert.assertNotNull(buddhistChronology53);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertNotNull(chronology70);
        org.junit.Assert.assertNotNull(dateMidnight72);
        org.junit.Assert.assertNotNull(dateTime74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 73049 + "'", int75 == 73049);
        org.junit.Assert.assertNotNull(dateMidnight76);
        org.junit.Assert.assertNotNull(limitChronology77);
        org.junit.Assert.assertNotNull(chronology78);
        org.junit.Assert.assertNotNull(dateTime79);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "LimitChronology[GJChronology[UTC], 0100-04-07T00:00:00.000Z, 1970-01-01T00:00:00.000Z]" + "'", str80.equals("LimitChronology[GJChronology[UTC], 0100-04-07T00:00:00.000Z, 1970-01-01T00:00:00.000Z]"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        boolean boolean20 = dateTime18.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        int[] intArray23 = julianChronology13.get((org.joda.time.ReadablePartial) localDateTime21, (-62112150421990L));
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) (byte) 0, locale25);
        int int28 = skipDateTimeField11.get(10L);
        org.joda.time.DateTimeField dateTimeField29 = skipDateTimeField11.getWrappedField();
        long long31 = skipDateTimeField11.roundHalfEven(1560344728795L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560344728795L + "'", long31 == 1560344728795L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = gJChronology0.withZone(dateTimeZone3);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        java.util.Locale locale8 = dateTimeFormatter7.getLocale();
        boolean boolean9 = buddhistChronology6.equals((java.lang.Object) locale8);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        long long14 = gJChronology10.add(readablePeriod11, (-99948L), 10);
        org.joda.time.DurationField durationField15 = gJChronology10.millis();
        org.joda.time.DurationField durationField16 = gJChronology10.seconds();
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology10.getZone();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone17);
        org.joda.time.Chronology chronology19 = buddhistChronology6.withZone(dateTimeZone17);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNull(locale8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-99948L) + "'", long14 == (-99948L));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.addWeeks((int) (byte) 0);
        mutableDateTime2.addWeekyears(3);
        mutableDateTime2.addWeekyears((-1));
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        long long17 = gJChronology9.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField19);
        java.lang.String str22 = skipDateTimeField20.getAsText((long) (byte) 100);
        long long24 = skipDateTimeField20.remainder((long) 100);
        long long27 = skipDateTimeField20.set((-3198336L), 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder28.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.append(dateTimeFormatter30);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
        long long44 = gJChronology36.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField46 = gJChronology45.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField47 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology36, dateTimeField46);
        long long50 = skipDateTimeField47.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = skipDateTimeField47.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder35.appendDecimal(dateTimeFieldType51, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.chrono.JulianChronology julianChronology56 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone55);
        java.lang.String str57 = julianChronology56.toString();
        org.joda.time.DurationField durationField58 = julianChronology56.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField59 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType51, durationField58);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField61 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField20, dateTimeFieldType51, 31);
        org.joda.time.DurationField durationField62 = offsetDateTimeField61.getLeapDurationField();
        int int63 = offsetDateTimeField61.getOffset();
        mutableDateTime2.setRounding((org.joda.time.DateTimeField) offsetDateTimeField61);
        java.lang.String str66 = offsetDateTimeField61.getAsShortText((long) 3);
        long long68 = offsetDateTimeField61.roundFloor((long) 1969);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62112178799990L) + "'", long17 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "100" + "'", str22.equals("100"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-3198991L) + "'", long27 == (-3198991L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-62112178799990L) + "'", long44 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-1960L) + "'", long50 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(julianChronology56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "JulianChronology[UTC]" + "'", str57.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField58);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField59);
        org.junit.Assert.assertNull(durationField62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 31 + "'", int63 == 31);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "34" + "'", str66.equals("34"));
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1969L + "'", long68 == 1969L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, readableInstant5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) ' ', chronology6);
        boolean boolean9 = dateTime7.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime10 = dateTime7.toLocalDateTime();
        boolean boolean12 = dateTime7.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant14, readableInstant15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) ' ', chronology16);
        int int18 = dateTime17.getHourOfDay();
        org.joda.time.DateTime dateTime20 = dateTime17.withYear((int) (short) -1);
        java.lang.String str21 = dateTime17.toString();
        int int22 = dateTime17.getEra();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = dateTime17.toDateTime(dateTimeZone23);
        org.joda.time.DateTime dateTime26 = dateTime17.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone27 = dateTime26.getZone();
        org.joda.time.DateTime dateTime28 = dateTime7.toDateTime(dateTimeZone27);
        org.joda.time.Chronology chronology29 = julianChronology2.withZone(dateTimeZone27);
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime(0L, (org.joda.time.Chronology) julianChronology2);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone31);
        org.joda.time.ReadableInstant readableInstant34 = null;
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.Chronology chronology36 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant34, readableInstant35);
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) ' ', chronology36);
        boolean boolean39 = dateTime37.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime40 = dateTime37.toLocalDateTime();
        boolean boolean42 = dateTime37.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant44 = null;
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.Chronology chronology46 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant44, readableInstant45);
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) ' ', chronology46);
        int int48 = dateTime47.getHourOfDay();
        org.joda.time.DateTime dateTime50 = dateTime47.withYear((int) (short) -1);
        java.lang.String str51 = dateTime47.toString();
        int int52 = dateTime47.getEra();
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.DateTime dateTime54 = dateTime47.toDateTime(dateTimeZone53);
        org.joda.time.DateTime dateTime56 = dateTime47.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone57 = dateTime56.getZone();
        org.joda.time.DateTime dateTime58 = dateTime37.toDateTime(dateTimeZone57);
        org.joda.time.Chronology chronology59 = julianChronology32.withZone(dateTimeZone57);
        org.joda.time.DateTimeZone dateTimeZone60 = julianChronology32.getZone();
        org.joda.time.DateTime dateTime61 = mutableDateTime30.toDateTime(dateTimeZone60);
        org.joda.time.MutableDateTime.Property property62 = mutableDateTime30.weekyear();
        int int63 = mutableDateTime30.getSecondOfMinute();
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str21.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(chronology46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str51.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        long long9 = gJChronology1.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField11);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant16, readableInstant17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) ' ', chronology18);
        boolean boolean21 = dateTime19.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime22 = dateTime19.toLocalDateTime();
        int[] intArray24 = julianChronology14.get((org.joda.time.ReadablePartial) localDateTime22, (-62112150421990L));
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) localDateTime22, (int) (byte) 0, locale26);
        int int29 = skipDateTimeField12.get(10L);
        long long32 = skipDateTimeField12.getDifferenceAsLong((-28799999L), (long) 2169);
        long long35 = skipDateTimeField12.add((long) 31, (long) (short) 0);
        mutableDateTime0.setRounding((org.joda.time.DateTimeField) skipDateTimeField12);
        org.joda.time.MutableDateTime.Property property37 = mutableDateTime0.centuryOfEra();
        int int38 = property37.get();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62112178799990L) + "'", long9 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(localDateTime22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-28802168L) + "'", long32 == (-28802168L));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 31L + "'", long35 == 31L);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 19 + "'", int38 == 19);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        long long14 = skipDateTimeField11.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = skipDateTimeField11.getType();
        int int17 = skipDateTimeField11.getLeapAmount(0L);
        boolean boolean18 = skipDateTimeField11.isLenient();
        int int20 = skipDateTimeField11.get(86400100L);
        int int22 = skipDateTimeField11.get((long) 16);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1960L) + "'", long14 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 16 + "'", int22 == 16);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.era();
        org.joda.time.Chronology chronology4 = gJChronology0.withUTC();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        long long15 = skipDateTimeField11.remainder((long) 100);
        long long18 = skipDateTimeField11.set((-3198336L), 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.append(dateTimeFormatter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        long long35 = gJChronology27.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology36.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField37);
        long long41 = skipDateTimeField38.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipDateTimeField38.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder26.appendDecimal(dateTimeFieldType42, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone46);
        java.lang.String str48 = julianChronology47.toString();
        org.joda.time.DurationField durationField49 = julianChronology47.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField49);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType42, 31);
        boolean boolean53 = offsetDateTimeField52.isLenient();
        long long55 = offsetDateTimeField52.roundHalfEven((long) 3);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3198991L) + "'", long18 == (-3198991L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62112178799990L) + "'", long35 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1960L) + "'", long41 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "JulianChronology[UTC]" + "'", str48.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 3L + "'", long55 == 3L);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime4.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone14);
        java.lang.String str16 = dateTimeZone14.getID();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str8.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UTC" + "'", str16.equals("UTC"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("10", (java.lang.Number) 100, (java.lang.Number) 1969L, (java.lang.Number) (-57599999L));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.era();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.monthOfYear();
        java.lang.String str7 = mutableDateTime2.toString();
        try {
            mutableDateTime2.setMinuteOfDay(57600);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for minuteOfDay must be in the range [0,1439]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01T00:00:00.000Z" + "'", str7.equals("1970-01-01T00:00:00.000Z"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, readableInstant4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) ' ', chronology5);
        boolean boolean8 = dateTime6.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime9 = dateTime6.toLocalDateTime();
        boolean boolean11 = dateTime6.isAfter((-99948L));
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, readableInstant14);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) ' ', chronology15);
        int int17 = dateTime16.getHourOfDay();
        org.joda.time.DateTime dateTime19 = dateTime16.withYear((int) (short) -1);
        java.lang.String str20 = dateTime16.toString();
        int int21 = dateTime16.getEra();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime16.toDateTime(dateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime16.plusHours((int) '4');
        org.joda.time.DateTimeZone dateTimeZone26 = dateTime25.getZone();
        org.joda.time.DateTime dateTime27 = dateTime6.toDateTime(dateTimeZone26);
        org.joda.time.Chronology chronology28 = julianChronology1.withZone(dateTimeZone26);
        org.joda.time.DurationField durationField29 = julianChronology1.seconds();
        org.joda.time.DurationField durationField30 = julianChronology1.centuries();
        org.joda.time.DateTimeField dateTimeField31 = julianChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField32 = julianChronology1.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField33 = julianChronology1.hourOfHalfday();
        org.joda.time.DurationField durationField34 = julianChronology1.months();
        int int35 = julianChronology1.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str20.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendMillisOfDay(69);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneName();
        org.joda.time.Chronology chronology8 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime((java.lang.Object) dateTimeFormatterBuilder6, chronology8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatterBuilder");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        long long15 = skipDateTimeField11.remainder((long) 100);
        long long18 = skipDateTimeField11.set((-3198336L), 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.append(dateTimeFormatter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        long long35 = gJChronology27.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology36.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField37);
        long long41 = skipDateTimeField38.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipDateTimeField38.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder26.appendDecimal(dateTimeFieldType42, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone46);
        java.lang.String str48 = julianChronology47.toString();
        org.joda.time.DurationField durationField49 = julianChronology47.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField49);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType42, 31);
        org.joda.time.DurationField durationField53 = offsetDateTimeField52.getLeapDurationField();
        org.joda.time.DurationField durationField54 = offsetDateTimeField52.getLeapDurationField();
        long long56 = offsetDateTimeField52.roundHalfEven((long) 990);
        long long58 = offsetDateTimeField52.roundHalfFloor(10L);
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = offsetDateTimeField52.getType();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3198991L) + "'", long18 == (-3198991L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62112178799990L) + "'", long35 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1960L) + "'", long41 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "JulianChronology[UTC]" + "'", str48.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
        org.junit.Assert.assertNull(durationField53);
        org.junit.Assert.assertNull(durationField54);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 990L + "'", long56 == 990L);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 10L + "'", long58 == 10L);
        org.junit.Assert.assertNotNull(dateTimeFieldType59);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone1);
        mutableDateTime2.addWeeks((int) (byte) 0);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfCentury();
        boolean boolean7 = mutableDateTime2.isEqual((long) (short) 10);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant15, readableInstant16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) ' ', chronology17);
        boolean boolean20 = dateTime18.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime21 = dateTime18.toLocalDateTime();
        int[] intArray23 = julianChronology13.get((org.joda.time.ReadablePartial) localDateTime21, (-62112150421990L));
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) (byte) 0, locale25);
        int int28 = skipDateTimeField11.get(10L);
        int int29 = skipDateTimeField11.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone30);
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.ReadableInstant readableInstant34 = null;
        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant33, readableInstant34);
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) ' ', chronology35);
        boolean boolean38 = dateTime36.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime39 = dateTime36.toLocalDateTime();
        int[] intArray41 = julianChronology31.get((org.joda.time.ReadablePartial) localDateTime39, (-62112150421990L));
        boolean boolean42 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime39);
        java.util.Locale locale44 = null;
        java.lang.String str45 = skipDateTimeField11.getAsText((org.joda.time.ReadablePartial) localDateTime39, 0, locale44);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 10 + "'", int28 == 10);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 999 + "'", int29 == 999);
        org.junit.Assert.assertNotNull(julianChronology31);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(localDateTime39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "0" + "'", str45.equals("0"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("19", "41");
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        long long9 = gJChronology1.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField11);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone13);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant16, readableInstant17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) ' ', chronology18);
        boolean boolean21 = dateTime19.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime22 = dateTime19.toLocalDateTime();
        int[] intArray24 = julianChronology14.get((org.joda.time.ReadablePartial) localDateTime22, (-62112150421990L));
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) localDateTime22, (int) (byte) 0, locale26);
        int int29 = skipDateTimeField12.get(10L);
        long long32 = skipDateTimeField12.getDifferenceAsLong((-28799999L), (long) 2169);
        long long35 = skipDateTimeField12.add((long) 31, (long) (short) 0);
        mutableDateTime0.setRounding((org.joda.time.DateTimeField) skipDateTimeField12);
        org.joda.time.MutableDateTime.Property property37 = mutableDateTime0.year();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62112178799990L) + "'", long9 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(localDateTime22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-28802168L) + "'", long32 == (-28802168L));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 31L + "'", long35 == 31L);
        org.junit.Assert.assertNotNull(property37);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField18);
        long long22 = skipDateTimeField19.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType23, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        java.lang.String str29 = julianChronology28.toString();
        org.joda.time.DurationField durationField30 = julianChronology28.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        try {
            long long33 = unsupportedDateTimeField31.roundCeiling(990L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112178799990L) + "'", long16 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1960L) + "'", long22 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JulianChronology[UTC]" + "'", str29.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfSecond(57600, 97);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendWeekyear(6, 73049);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder13.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfMonth((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitYear(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTimeZoneShortName(strMap7);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(strMap7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((long) 16, dateTimeZone2);
        mutableDateTime3.setTime((long) (short) 0);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime3.era();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime3.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime9 = property7.addWrapField((-10));
        org.joda.time.MutableDateTime mutableDateTime10 = property7.roundHalfEven();
        org.joda.time.DateTimeField dateTimeField11 = property7.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField11);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) ' ', chronology3);
        int int5 = dateTime4.getHourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime4.withYear((int) (short) -1);
        java.lang.String str8 = dateTime4.toString();
        int int9 = dateTime4.getEra();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime4.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime4.dayOfMonth();
        org.joda.time.DateTime dateTime13 = property12.roundHalfCeilingCopy();
        java.util.Locale locale14 = null;
        java.lang.String str15 = property12.getAsShortText(locale14);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str8.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        try {
            org.joda.time.LocalDate localDate3 = dateTimeFormatter0.parseLocalDate("2");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField18);
        long long22 = skipDateTimeField19.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType23, 10, 57600);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, (java.lang.Number) (byte) 10, "1969-12-31T16:00:00-08:00");
        illegalFieldValueException29.prependMessage("GJChronology[UTC]");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112178799990L) + "'", long16 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1960L) + "'", long22 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.append(dateTimeFormatter2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance();
        long long16 = gJChronology8.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology17.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology8, dateTimeField18);
        long long22 = skipDateTimeField19.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = skipDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder7.appendDecimal(dateTimeFieldType23, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone27);
        java.lang.String str29 = julianChronology28.toString();
        org.joda.time.DurationField durationField30 = julianChronology28.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField30);
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField31.getRangeDurationField();
        long long35 = unsupportedDateTimeField31.add((long) (short) 10, (long) 10);
        long long38 = unsupportedDateTimeField31.getDifferenceAsLong((long) 100, 0L);
        int int41 = unsupportedDateTimeField31.getDifference((long) (-10), (long) (short) 10);
        org.joda.time.ReadableInstant readableInstant43 = null;
        org.joda.time.ReadableInstant readableInstant44 = null;
        org.joda.time.Chronology chronology45 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant43, readableInstant44);
        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((long) ' ', chronology45);
        int int47 = dateTime46.getHourOfDay();
        org.joda.time.DateTime dateTime49 = dateTime46.withYear((int) (short) -1);
        java.lang.String str50 = dateTime46.toString();
        int int51 = dateTime46.getEra();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = dateTime46.toDateTime(dateTimeZone52);
        org.joda.time.TimeOfDay timeOfDay54 = dateTime53.toTimeOfDay();
        try {
            int int55 = unsupportedDateTimeField31.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay54);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62112178799990L) + "'", long16 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1960L) + "'", long22 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JulianChronology[UTC]" + "'", str29.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 600010L + "'", long35 == 600010L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "1970-01-01T00:00:00.032Z" + "'", str50.equals("1970-01-01T00:00:00.032Z"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(timeOfDay54);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        long long15 = skipDateTimeField11.remainder((long) 100);
        long long18 = skipDateTimeField11.set((-3198336L), 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.append(dateTimeFormatter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        long long35 = gJChronology27.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology36.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField37);
        long long41 = skipDateTimeField38.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipDateTimeField38.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder26.appendDecimal(dateTimeFieldType42, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone46);
        java.lang.String str48 = julianChronology47.toString();
        org.joda.time.DurationField durationField49 = julianChronology47.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField49);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType42, 31);
        org.joda.time.ReadablePartial readablePartial53 = null;
        java.util.Locale locale55 = null;
        java.lang.String str56 = offsetDateTimeField52.getAsText(readablePartial53, 16, locale55);
        org.joda.time.DateTimeZone dateTimeZone57 = null;
        org.joda.time.chrono.JulianChronology julianChronology58 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone57);
        org.joda.time.ReadableInstant readableInstant60 = null;
        org.joda.time.ReadableInstant readableInstant61 = null;
        org.joda.time.Chronology chronology62 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant60, readableInstant61);
        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime((long) ' ', chronology62);
        boolean boolean65 = dateTime63.isBefore(10L);
        org.joda.time.LocalDateTime localDateTime66 = dateTime63.toLocalDateTime();
        int[] intArray68 = julianChronology58.get((org.joda.time.ReadablePartial) localDateTime66, (-62112150421990L));
        java.util.Locale locale69 = null;
        java.lang.String str70 = offsetDateTimeField52.getAsShortText((org.joda.time.ReadablePartial) localDateTime66, locale69);
        int int71 = offsetDateTimeField52.getOffset();
        org.joda.time.DurationField durationField72 = offsetDateTimeField52.getDurationField();
        long long75 = offsetDateTimeField52.add((long) ' ', 100L);
        long long77 = offsetDateTimeField52.roundHalfCeiling((long) 3);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3198991L) + "'", long18 == (-3198991L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62112178799990L) + "'", long35 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1960L) + "'", long41 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "JulianChronology[UTC]" + "'", str48.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "16" + "'", str56.equals("16"));
        org.junit.Assert.assertNotNull(julianChronology58);
        org.junit.Assert.assertNotNull(chronology62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(localDateTime66);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "32" + "'", str70.equals("32"));
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 31 + "'", int71 == 31);
        org.junit.Assert.assertNotNull(durationField72);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 132L + "'", long75 == 132L);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 3L + "'", long77 == 3L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        long long8 = gJChronology0.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField10);
        java.lang.String str13 = skipDateTimeField11.getAsText((long) (byte) 100);
        long long15 = skipDateTimeField11.remainder((long) 100);
        long long18 = skipDateTimeField11.set((-3198336L), 9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.DateTimeFormat.fullDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.append(dateTimeFormatter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendMinuteOfHour(3);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance();
        long long35 = gJChronology27.getDateTimeMillis((int) (short) 1, 10, 1, 1, (int) (short) 0, (int) (short) 0, (int) (short) 10);
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology36.millisOfSecond();
        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField37);
        long long41 = skipDateTimeField38.getDifferenceAsLong((long) 10, (long) 1970);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipDateTimeField38.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder26.appendDecimal(dateTimeFieldType42, 10, 57600);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.chrono.JulianChronology julianChronology47 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone46);
        java.lang.String str48 = julianChronology47.toString();
        org.joda.time.DurationField durationField49 = julianChronology47.minutes();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType42, durationField49);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType42, 31);
        int int53 = offsetDateTimeField52.getMinimumValue();
        java.util.Locale locale54 = null;
        int int55 = offsetDateTimeField52.getMaximumShortTextLength(locale54);
        java.lang.String str56 = offsetDateTimeField52.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField52, dateTimeFieldType57, 70);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62112178799990L) + "'", long8 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3198991L) + "'", long18 == (-3198991L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-62112178799990L) + "'", long35 == (-62112178799990L));
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1960L) + "'", long41 == (-1960L));
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(julianChronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "JulianChronology[UTC]" + "'", str48.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 32 + "'", int53 == 32);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 4 + "'", int55 == 4);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str56.equals("DateTimeField[millisOfSecond]"));
    }
}

