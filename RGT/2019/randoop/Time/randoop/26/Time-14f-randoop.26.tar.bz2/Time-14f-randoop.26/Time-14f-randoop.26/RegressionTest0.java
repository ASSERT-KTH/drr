import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 0, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.util.Calendar calendar0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.fromCalendarFields(calendar0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The calendar must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = null;
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(100L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test006");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560633160155L + "'", long0 == 1560633160155L);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        try {
            org.joda.time.DateTime dateTime3 = dateTime1.withCenturyOfEra((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for centuryOfEra must be in the range [0,2922789]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = org.joda.time.field.MillisDurationField.INSTANCE;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField2 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) ' ');
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        try {
            long long8 = gJChronology0.getDateTimeMillis((-1), (int) (short) -1, (int) (short) 100, 0, (int) (byte) 100, (int) 'a', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField3 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, dateTimeFieldType1, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        boolean boolean5 = property4.isLeap();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: hi!");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("-00:00:00.001", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: -00:00:00.001");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) ' ', (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "", (int) (short) 100, (int) (short) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        try {
            long long10 = gregorianChronology5.getDateTimeMillis((int) (byte) 100, (int) (byte) 100, 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField7 = new org.joda.time.field.DividedDateTimeField(dateTimeField4, dateTimeFieldType5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology3);
        org.joda.time.DurationField durationField5 = gJChronology3.hours();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField6 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) 'a');
        int int10 = dateTime7.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime7.plus(readablePeriod11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime15 = dateTime7.withPeriodAdded(readablePeriod13, (int) 'a');
        boolean boolean16 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime7);
        try {
            org.joda.time.DateTime dateTime18 = dateTime1.withHourOfDay((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (-1L), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gJChronology0);
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gJChronology0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(monthDay2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (byte) 100, number2, (java.lang.Number) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        java.io.Writer writer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology(chronology3);
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) gJChronology1, chronology4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.GJChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.ReadWritableInstant readWritableInstant1 = null;
        try {
            int int4 = dateTimeFormatter0.parseInto(readWritableInstant1, "1", (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        try {
            org.joda.time.DateTime dateTime8 = property4.addToCopy((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "AD" + "'", str6.equals("AD"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.fullDate();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("BuddhistChronology[-00:00:00.001]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"BuddhistChronology[-00:00:00.001]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) '#', (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 87 + "'", int2 == 87);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        java.util.Locale locale6 = null;
        try {
            org.joda.time.DateTime dateTime7 = property4.setCopy("1", locale6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1\" for era is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology2, dateTimeZone4);
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay8 = monthDay6.plus(readablePeriod7);
        org.joda.time.MonthDay.Property property9 = monthDay6.monthOfYear();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property9.getAsText(locale10);
        org.joda.time.MonthDay monthDay13 = property9.addWrapFieldToCopy((int) ' ');
        int[] intArray17 = new int[] { (short) 100, 9, 60 };
        try {
            buddhistChronology2.validate((org.joda.time.ReadablePartial) monthDay13, intArray17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "January" + "'", str11.equals("January"));
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray17);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.ReadWritableInstant readWritableInstant2 = null;
        try {
            int int5 = dateTimeFormatter1.parseInto(readWritableInstant2, "", (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant6 = null;
        long long7 = property5.getDifferenceAsLong(readableInstant6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property5.getFieldType();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType8 };
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList10 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList10, dateTimeFieldTypeArray9);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList10, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No valid format for fields: [centuryOfEra]");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.util.Date date0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.fromDateFields(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The date must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMinuteOfHour((int) (byte) 1);
        boolean boolean5 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime6 = monthDay0.toDateTime((org.joda.time.ReadableInstant) dateTime4);
        java.util.Locale locale8 = null;
        try {
            java.lang.String str9 = monthDay0.toString("AD", locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: A");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        try {
            org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.parse("January", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"January\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        try {
            org.joda.time.MonthDay monthDay5 = monthDay0.withMonthOfYear((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        try {
            org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 60, dateTimeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology3.getZone();
        org.joda.time.Chronology chronology6 = gJChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology3.dayOfWeek();
        try {
            org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((int) ' ', 10, (org.joda.time.Chronology) gJChronology3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (short) -1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        int int1 = dateTime0.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone2.getShortName((long) 0, locale4);
        java.lang.String str6 = dateTimeZone2.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone2);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(dateTimeZone2);
        org.joda.time.Chronology chronology9 = null;
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) dateTimeZone2, chronology9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.FixedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-00:00:00.001" + "'", str5.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.001" + "'", str6.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology7);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, 60, 12, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 60 + "'", int4 == 60);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        try {
            long long12 = gJChronology1.getDateTimeMillis(1, (int) (short) 100, 100, 0, 4, 0, 82919);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 82919 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay monthDay4 = monthDay0.plusDays(0);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay7 = monthDay5.plus(readablePeriod6);
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        boolean boolean9 = monthDay0.isBefore((org.joda.time.ReadablePartial) monthDay5);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime15 = dateTime13.plusHours((int) 'a');
        int int16 = dateTime13.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime13.plus(readablePeriod17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime21 = dateTime13.withPeriodAdded(readablePeriod19, (int) 'a');
        org.joda.time.DateTime.Property property22 = dateTime13.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
        org.joda.time.DateTime dateTime26 = dateTime24.withMinuteOfHour((int) (byte) 1);
        boolean boolean27 = dateTime26.isEqualNow();
        org.joda.time.DateTime.Property property28 = dateTime26.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant29 = null;
        long long30 = property28.getDifferenceAsLong(readableInstant29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property28.getFieldType();
        boolean boolean32 = dateTime13.isSupported(dateTimeFieldType31);
        try {
            org.joda.time.MonthDay.Property property33 = monthDay5.property(dateTimeFieldType31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'centuryOfEra' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test050");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 31");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant6 = null;
        long long7 = property5.getDifferenceAsLong(readableInstant6);
        int int8 = property5.getMaximumValueOverall();
        org.joda.time.DateTime dateTime9 = property5.withMaximumValue();
        org.joda.time.DateTime dateTime11 = dateTime9.plusWeeks((int) 'a');
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2922789 + "'", int8 == 2922789);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.Chronology chronology8 = monthDay7.getChronology();
        org.joda.time.DateTime dateTime9 = dateTime3.toDateTime(chronology8);
        org.joda.time.DateTime.Property property10 = dateTime9.weekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "", (int) (short) 100, (int) (short) -1);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '-00:00:00.001' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        org.joda.time.MonthDay monthDay7 = property3.setCopy((int) (byte) 10);
        java.util.Locale locale8 = null;
        int int9 = property3.getMaximumTextLength(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property3.getAsText(locale10);
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property3.getFieldType();
        try {
            org.joda.time.MonthDay monthDay14 = property3.setCopy("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "December" + "'", str5.equals("December"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "December" + "'", str11.equals("December"));
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        int int5 = dateTimeZone2.getOffsetFromLocal(100L);
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone2);
        java.lang.String str8 = dateTimeZone2.getID();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-00:00:00.001" + "'", str8.equals("-00:00:00.001"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant6 = null;
        long long7 = property5.getDifferenceAsLong(readableInstant6);
        int int8 = property5.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField9 = property5.getField();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property5.getAsText(locale10);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2922789 + "'", int8 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "19" + "'", str11.equals("19"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.Chronology chronology8 = monthDay7.getChronology();
        org.joda.time.DateTime dateTime9 = dateTime3.toDateTime(chronology8);
        try {
            org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((java.lang.Object) chronology8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.chrono.GJChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.Chronology chronology4 = gJChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime11 = dateTime9.plusHours((int) 'a');
        int int12 = dateTime9.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime9.plus(readablePeriod13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime9.withPeriodAdded(readablePeriod15, (int) 'a');
        org.joda.time.DateTime.Property property18 = dateTime9.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime20.withMinuteOfHour((int) (byte) 1);
        boolean boolean23 = dateTime22.isEqualNow();
        org.joda.time.DateTime.Property property24 = dateTime22.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant25 = null;
        long long26 = property24.getDifferenceAsLong(readableInstant25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property24.getFieldType();
        boolean boolean28 = dateTime9.isSupported(dateTimeFieldType27);
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField29 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField5, dateTimeFieldType27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("--09-01");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"--09-01\" is malformed at \"-09-01\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        org.joda.time.MonthDay monthDay7 = property3.setCopy((int) (byte) 10);
        java.util.Locale locale8 = null;
        int int9 = property3.getMaximumTextLength(locale8);
        java.util.Locale locale11 = null;
        try {
            org.joda.time.MonthDay monthDay12 = property3.setCopy("AD", locale11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"AD\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "December" + "'", str5.equals("December"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        org.joda.time.MonthDay monthDay7 = property3.setCopy((int) (byte) 10);
        try {
            org.joda.time.MonthDay monthDay9 = monthDay7.withMonthOfYear(69);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "December" + "'", str5.equals("December"));
        org.junit.Assert.assertNotNull(monthDay7);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay0.getFieldType(12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 12");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        int int5 = dateTimeZone2.getOffsetFromLocal(100L);
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.joda.time.Chronology chronology8 = dateTimeFormatter7.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNull(chronology8);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getShortName((long) 0, locale3);
        java.lang.String str5 = dateTimeZone1.getID();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        boolean boolean8 = gregorianChronology6.equals((java.lang.Object) "monthOfYear");
        try {
            long long16 = gregorianChronology6.getDateTimeMillis(0, (int) (short) -1, 0, (int) (byte) 100, (int) '#', (int) ' ', 82919);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-00:00:00.001" + "'", str5.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        org.joda.time.MonthDay monthDay4 = property3.getMonthDay();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property3.getAsText(locale5);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "December" + "'", str6.equals("December"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        org.joda.time.MonthDay monthDay7 = property3.setCopy((int) (byte) 10);
        java.util.Locale locale8 = null;
        int int9 = property3.getMaximumTextLength(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property3.getAsText(locale10);
        int int12 = property3.get();
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "December" + "'", str5.equals("December"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "December" + "'", str11.equals("December"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        int int4 = dateTimeZone1.getOffsetFromLocal(100L);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.Chronology chronology9 = julianChronology5.withZone(dateTimeZone7);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getChronology(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        org.joda.time.DateTime dateTime8 = dateTime6.plusWeeks((int) (short) 10);
        int int9 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime.Property property10 = dateTime6.millisOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 82919 + "'", int9 == 82919);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) 'a');
        org.joda.time.DateTime.Property property6 = dateTime3.hourOfDay();
        org.joda.time.DateTime dateTime8 = dateTime3.plusYears((int) (short) 0);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology10);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone14);
        int int17 = dateTimeZone14.getOffsetFromLocal(100L);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone14);
        org.joda.time.Chronology chronology19 = gJChronology10.withZone(dateTimeZone14);
        org.joda.time.DateTime dateTime20 = dateTime3.withZone(dateTimeZone14);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 1, (long) 59);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59 + "'", int2 == 59);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        org.joda.time.MonthDay monthDay7 = property3.setCopy((int) (byte) 10);
        java.util.Locale locale8 = null;
        int int9 = property3.getMaximumTextLength(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property3.getAsText(locale10);
        org.joda.time.MonthDay monthDay12 = property3.getMonthDay();
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "December" + "'", str5.equals("December"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "December" + "'", str11.equals("December"));
        org.junit.Assert.assertNotNull(monthDay12);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "", (int) (short) 100, (int) (short) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField11);
        long long14 = skipUndoDateTimeField12.roundFloor(32L);
        org.joda.time.MonthDay monthDay15 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.MonthDay monthDay17 = monthDay15.plus(readablePeriod16);
        org.joda.time.MonthDay.Property property18 = monthDay15.monthOfYear();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property18.getAsText(locale19);
        org.joda.time.MonthDay monthDay22 = property18.setCopy((int) (byte) 10);
        int[] intArray24 = new int[] {};
        java.util.Locale locale26 = null;
        try {
            int[] intArray27 = skipUndoDateTimeField12.set((org.joda.time.ReadablePartial) monthDay22, (int) (short) 10, intArray24, "0.0", locale26);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"0.0\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str6.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "December" + "'", str20.equals("December"));
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) 'a');
        int int10 = dateTime7.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime7.plus(readablePeriod11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime15 = dateTime7.withPeriodAdded(readablePeriod13, (int) 'a');
        boolean boolean16 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime18 = dateTime7.minus(0L);
        long long19 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime7);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-3480001L) + "'", long19 == (-3480001L));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (short) 1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        int int4 = dateTimeZone1.getOffsetFromLocal(100L);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        try {
            long long13 = julianChronology5.getDateTimeMillis((int) '#', 10, 0, 1969, (int) (byte) 10, (int) ' ', (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(julianChronology5);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "1");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.DurationFieldType durationFieldType3 = null;
        try {
            org.joda.time.MonthDay monthDay5 = monthDay2.withFieldAdded(durationFieldType3, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.DurationField durationField4 = gJChronology2.hours();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (byte) 10, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.weekyear();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "org.joda.time.IllegalFieldValueException: Value 0.0 for ZonedChronology[BuddhistChronology[UTC], -00:00:00.001] must not be smaller than 82919");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        int int4 = dateTimeZone1.getOffsetFromLocal(100L);
        try {
            org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField3 = gJChronology1.hours();
        org.joda.time.DurationField durationField4 = gJChronology1.millis();
        java.lang.Object obj5 = null;
        boolean boolean6 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField4, obj5);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField9 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType7, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
        int int9 = dateTimeZone6.getOffsetFromLocal(100L);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology11 = gJChronology2.withZone(dateTimeZone6);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) monthDay0, chronology11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.MonthDay");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 100, 20, 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test090");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
//        boolean boolean2 = dateTimeFormatter0.isParser();
//        java.lang.Appendable appendable3 = null;
//        org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.MonthDay monthDay6 = monthDay4.plus(readablePeriod5);
//        org.joda.time.MonthDay.Property property7 = monthDay4.monthOfYear();
//        org.joda.time.MonthDay monthDay8 = property7.getMonthDay();
//        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.MonthDay monthDay11 = monthDay9.plus(readablePeriod10);
//        org.joda.time.MonthDay.Property property12 = monthDay9.monthOfYear();
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = property12.getAsText(locale13);
//        org.joda.time.MonthDay monthDay16 = property12.addWrapFieldToCopy((int) ' ');
//        java.lang.String str17 = monthDay16.toString();
//        int int18 = monthDay8.compareTo((org.joda.time.ReadablePartial) monthDay16);
//        try {
//            dateTimeFormatter0.printTo(appendable3, (org.joda.time.ReadablePartial) monthDay8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(monthDay4);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(monthDay8);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June" + "'", str14.equals("June"));
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "--02-15" + "'", str17.equals("--02-15"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        org.joda.time.MonthDay monthDay4 = property3.getMonthDay();
        java.util.Locale locale5 = null;
        int int6 = property3.getMaximumShortTextLength(locale5);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField3 = gJChronology1.hours();
        int int4 = gJChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray7 = gJChronology1.get(readablePeriod5, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int0 = org.joda.time.MonthDay.DAY_OF_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology7, dateTimeZone9);
        java.lang.String str11 = zonedChronology10.toString();
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(3, 9, (int) (short) 0, (int) (short) 100, (int) '#', (org.joda.time.Chronology) zonedChronology10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ZonedChronology[BuddhistChronology[UTC], -00:00:00.001]" + "'", str11.equals("ZonedChronology[BuddhistChronology[UTC], -00:00:00.001]"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
        long long16 = skipDateTimeField11.addWrapField((long) (short) 0, (int) '4');
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 52000L + "'", long16 == 52000L);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "", (int) (short) 100, (int) (short) -1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        java.lang.String str6 = gregorianChronology5.toString();
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology8);
//        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology8.getZone();
//        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField11);
//        long long14 = skipUndoDateTimeField12.roundFloor(32L);
//        long long17 = skipUndoDateTimeField12.add((long) (short) 10, (int) ' ');
//        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.MonthDay monthDay20 = monthDay18.plus(readablePeriod19);
//        org.joda.time.MonthDay.Property property21 = monthDay18.monthOfYear();
//        org.joda.time.MonthDay monthDay22 = property21.getMonthDay();
//        org.joda.time.MonthDay monthDay23 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.MonthDay monthDay25 = monthDay23.plus(readablePeriod24);
//        org.joda.time.MonthDay.Property property26 = monthDay23.monthOfYear();
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = property26.getAsText(locale27);
//        org.joda.time.MonthDay monthDay30 = property26.addWrapFieldToCopy((int) ' ');
//        java.lang.String str31 = monthDay30.toString();
//        int int32 = monthDay22.compareTo((org.joda.time.ReadablePartial) monthDay30);
//        int[] intArray37 = new int[] { (byte) 10, 4, 20 };
//        try {
//            int[] intArray39 = skipUndoDateTimeField12.set((org.joda.time.ReadablePartial) monthDay30, (int) (short) 0, intArray37, 3480);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3480 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str6.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 32010L + "'", long17 == 32010L);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(monthDay23);
//        org.junit.Assert.assertNotNull(monthDay25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "June" + "'", str28.equals("June"));
//        org.junit.Assert.assertNotNull(monthDay30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "--02-15" + "'", str31.equals("--02-15"));
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(intArray37);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        org.joda.time.MonthDay monthDay7 = property3.addToCopy((int) (short) 10);
        int int8 = property3.get();
        org.joda.time.DurationField durationField9 = property3.getRangeDurationField();
        java.lang.String str10 = property3.getName();
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June" + "'", str5.equals("June"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "monthOfYear" + "'", str10.equals("monthOfYear"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        org.joda.time.MonthDay monthDay7 = property3.setCopy((int) (byte) 10);
        org.joda.time.DateTimeField dateTimeField8 = property3.getField();
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June" + "'", str5.equals("June"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology2, dateTimeZone4);
        java.lang.String str6 = buddhistChronology2.toString();
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.MonthDay monthDay9 = monthDay7.plus(readablePeriod8);
        org.joda.time.MonthDay monthDay11 = monthDay7.plusDays(0);
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay14 = monthDay12.plus(readablePeriod13);
        org.joda.time.MonthDay.Property property15 = monthDay12.monthOfYear();
        boolean boolean16 = monthDay7.isBefore((org.joda.time.ReadablePartial) monthDay12);
        org.joda.time.MonthDay.Property property17 = monthDay7.dayOfMonth();
        int[] intArray19 = new int[] { 12 };
        try {
            buddhistChronology2.validate((org.joda.time.ReadablePartial) monthDay7, intArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "BuddhistChronology[-00:00:00.001]" + "'", str6.equals("BuddhistChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "", (int) (short) 100, (int) (short) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int6 = gregorianChronology5.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("1", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime.Property property4 = dateTime3.era();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
//        org.joda.time.Chronology chronology8 = monthDay7.getChronology();
//        org.joda.time.DateTime dateTime9 = dateTime3.toDateTime(chronology8);
//        int int10 = dateTime3.getSecondOfMinute();
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime3.withTime(69, 3, 75714, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 56 + "'", int10 == 56);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        org.joda.time.MonthDay monthDay7 = property3.addToCopy((int) (short) 10);
        int int8 = property3.get();
        org.joda.time.ReadablePartial readablePartial9 = null;
        try {
            int int10 = property3.compareTo(readablePartial9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June" + "'", str5.equals("June"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withWeekOfWeekyear((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) 'a');
//        int int10 = dateTime7.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime7.plus(readablePeriod11);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime7.withPeriodAdded(readablePeriod13, (int) 'a');
//        boolean boolean16 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime18 = dateTime7.minus(0L);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
//        org.joda.time.DateTime dateTime22 = dateTime20.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime24 = dateTime22.plusHours((int) 'a');
//        int int25 = dateTime22.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod26 = null;
//        org.joda.time.DateTime dateTime27 = dateTime22.plus(readablePeriod26);
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime30 = dateTime22.withPeriodAdded(readablePeriod28, (int) 'a');
//        org.joda.time.DateTime.Property property31 = dateTime22.dayOfMonth();
//        boolean boolean32 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime22);
//        try {
//            org.joda.time.DateTime dateTime34 = dateTime7.withDayOfWeek(10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for dayOfWeek must be in the range [1,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 24 + "'", int25 == 24);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(100L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField3 = gJChronology1.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour((int) (byte) 1);
        boolean boolean8 = dateTime7.isEqualNow();
        org.joda.time.DateTime.Property property9 = dateTime7.centuryOfEra();
        org.joda.time.DateTime dateTime10 = property9.withMaximumValue();
        org.joda.time.DateTime dateTime12 = dateTime10.plusWeeks((int) (short) 10);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime15 = dateTime10.withDurationAdded(readableDuration13, (int) (short) -1);
        boolean boolean16 = gJChronology1.equals((java.lang.Object) (short) -1);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        long long20 = gJChronology1.add(readablePeriod17, (long) 4, 3);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 4L + "'", long20 == 4L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getShortName((long) 0, locale18);
        java.lang.String str20 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology14, dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.MonthDay monthDay24 = monthDay22.plusMonths(82919);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay24, (int) (byte) -1, locale26);
        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay30 = monthDay28.plus(readablePeriod29);
        org.joda.time.MonthDay.Property property31 = monthDay28.monthOfYear();
        org.joda.time.MonthDay monthDay32 = property31.getMonthDay();
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.MonthDay monthDay35 = monthDay33.plus(readablePeriod34);
        org.joda.time.MonthDay.Property property36 = monthDay33.monthOfYear();
        java.util.Locale locale37 = null;
        java.lang.String str38 = property36.getAsText(locale37);
        org.joda.time.MonthDay monthDay40 = property36.setCopy((int) (byte) 10);
        java.util.Locale locale41 = null;
        int int42 = property36.getMaximumTextLength(locale41);
        java.util.Locale locale43 = null;
        java.lang.String str44 = property36.getAsText(locale43);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property36.getFieldType();
        org.joda.time.MonthDay.Property property46 = monthDay32.property(dateTimeFieldType45);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType45, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay51 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology50);
        org.joda.time.Chronology chronology52 = monthDay51.getChronology();
        org.joda.time.MonthDay monthDay54 = monthDay51.minusMonths(3);
        int[] intArray57 = new int[] { (short) 0 };
        try {
            int[] intArray59 = offsetDateTimeField48.addWrapField((org.joda.time.ReadablePartial) monthDay51, 6, intArray57, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-00:00:00.001" + "'", str20.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-1" + "'", str27.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June" + "'", str38.equals("June"));
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June" + "'", str44.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(gJChronology50);
        org.junit.Assert.assertNotNull(chronology52);
        org.junit.Assert.assertNotNull(monthDay54);
        org.junit.Assert.assertNotNull(intArray57);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getShortName((long) 0, locale3);
        java.lang.String str5 = dateTimeZone1.getID();
        try {
            org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (long) 69, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 31");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-00:00:00.001" + "'", str5.equals("-00:00:00.001"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("BuddhistChronology[-00:00:00.001]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"BuddhistChronology[-00:00:00.001]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getShortName((long) 0, locale3);
        java.lang.String str5 = dateTimeZone1.getID();
        java.util.TimeZone timeZone6 = dateTimeZone1.toTimeZone();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeField dateTimeField10 = gJChronology8.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone12);
        int int15 = dateTimeZone12.getOffsetFromLocal(100L);
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.joda.time.Chronology chronology17 = gJChronology8.withZone(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField18 = gJChronology8.minuteOfHour();
        try {
            org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((java.lang.Object) timeZone6, (org.joda.time.Chronology) gJChronology8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.util.SimpleTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-00:00:00.001" + "'", str5.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("--09-01");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"--09-01\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant6 = null;
        long long7 = property5.getDifferenceAsLong(readableInstant6);
        int int8 = property5.getMaximumValueOverall();
        org.joda.time.DateTimeField dateTimeField9 = property5.getField();
        java.lang.String str10 = property5.getAsString();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2922789 + "'", int8 == 2922789);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "20" + "'", str10.equals("20"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant6 = null;
        long long7 = property5.getDifferenceAsLong(readableInstant6);
        int int8 = property5.getMaximumValueOverall();
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.MonthDay monthDay11 = monthDay9.plus(readablePeriod10);
        org.joda.time.MonthDay.Property property12 = monthDay9.monthOfYear();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.MonthDay monthDay14 = monthDay9.withChronologyRetainFields(chronology13);
        boolean boolean15 = property5.equals((java.lang.Object) monthDay14);
        org.joda.time.DurationField durationField16 = property5.getDurationField();
        org.joda.time.DateTime dateTime18 = property5.addToCopy((long) (byte) 1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2922789 + "'", int8 == 2922789);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.centuryOfEra();
        try {
            long long8 = gJChronology1.getDateTimeMillis((int) (short) 100, 82919, 24, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 82919 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "", (int) (short) 100, (int) (short) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField11);
        int int14 = skipUndoDateTimeField12.getMaximumValue((long) (byte) 10);
        java.lang.String str16 = skipUndoDateTimeField12.getAsText((long) 'a');
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.MonthDay monthDay19 = monthDay17.plus(readablePeriod18);
        org.joda.time.MonthDay.Property property20 = monthDay17.monthOfYear();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay17.withChronologyRetainFields(chronology21);
        int[] intArray24 = null;
        try {
            int[] intArray26 = skipUndoDateTimeField12.addWrapPartial((org.joda.time.ReadablePartial) monthDay22, (int) (byte) 0, intArray24, 82919);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str6.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(monthDay22);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        org.joda.time.MonthDay monthDay7 = property3.addToCopy((int) (short) 10);
        java.util.Locale locale9 = null;
        try {
            java.lang.String str10 = monthDay7.toString("December", locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: c");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June" + "'", str5.equals("June"));
        org.junit.Assert.assertNotNull(monthDay7);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(100, 87);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 87");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime7.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusHours((int) 'a');
//        int int12 = dateTime9.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime9.plus(readablePeriod13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime9.withPeriodAdded(readablePeriod15, (int) 'a');
//        boolean boolean18 = dateTime3.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        java.lang.String str19 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime9);
//        java.io.Writer writer20 = null;
//        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod22 = null;
//        org.joda.time.MonthDay monthDay23 = monthDay21.plus(readablePeriod22);
//        org.joda.time.MonthDay.Property property24 = monthDay21.monthOfYear();
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = property24.getAsText(locale25);
//        org.joda.time.MonthDay monthDay28 = property24.setCopy((int) (byte) 10);
//        java.util.Locale locale29 = null;
//        int int30 = property24.getMaximumTextLength(locale29);
//        java.util.Locale locale31 = null;
//        java.lang.String str32 = property24.getAsText(locale31);
//        int int33 = property24.getMinimumValueOverall();
//        org.joda.time.MonthDay monthDay34 = property24.getMonthDay();
//        try {
//            dateTimeFormatter1.printTo(writer20, (org.joda.time.ReadablePartial) monthDay34);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019-06-15T21:01" + "'", str19.equals("2019-06-15T21:01"));
//        org.junit.Assert.assertNotNull(monthDay21);
//        org.junit.Assert.assertNotNull(monthDay23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "June" + "'", str26.equals("June"));
//        org.junit.Assert.assertNotNull(monthDay28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "June" + "'", str32.equals("June"));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(monthDay34);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[-00:00:00.001]" + "'", str1.equals("ISOChronology[-00:00:00.001]"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant6 = null;
        long long7 = property5.getDifferenceAsLong(readableInstant6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property5.getFieldType();
        org.joda.time.DateTime dateTime10 = property5.addToCopy((long) 1969);
        try {
            org.joda.time.DateTime dateTime12 = dateTime10.withDayOfMonth((int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "", (int) (short) 100, (int) (short) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField11);
        java.util.Locale locale15 = null;
        try {
            long long16 = skipUndoDateTimeField12.set((long) '4', "2922789", locale15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2922789 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str6.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        long long14 = skipDateTimeField11.add((long) '4', (int) (short) 1);
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((long) 20);
        java.util.Locale locale17 = null;
        try {
            java.lang.String str18 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay16, locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfMinute' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1052L + "'", long14 == 1052L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (short) 0, 69, (int) (short) 1, 24, (int) (short) 1, 75718, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (short) 100, (long) 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 103L + "'", long2 == 103L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test131");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) 'a');
//        int int6 = dateTime3.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime3.plus(readablePeriod7);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime11 = dateTime3.withPeriodAdded(readablePeriod9, (int) 'a');
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter12.withOffsetParsed();
//        java.lang.String str14 = dateTime11.toString(dateTimeFormatter13);
//        java.io.Writer writer15 = null;
//        try {
//            dateTimeFormatter13.printTo(writer15, (long) (short) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019-W24-6T21:01:01.611-00:00:00.001" + "'", str14.equals("2019-W24-6T21:01:01.611-00:00:00.001"));
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        dateTimeFormatterBuilder0.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getShortName((long) 0, locale18);
        java.lang.String str20 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology14, dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.MonthDay monthDay24 = monthDay22.plusMonths(82919);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay24, (int) (byte) -1, locale26);
        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay30 = monthDay28.plus(readablePeriod29);
        org.joda.time.MonthDay.Property property31 = monthDay28.monthOfYear();
        org.joda.time.MonthDay monthDay32 = property31.getMonthDay();
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.MonthDay monthDay35 = monthDay33.plus(readablePeriod34);
        org.joda.time.MonthDay.Property property36 = monthDay33.monthOfYear();
        java.util.Locale locale37 = null;
        java.lang.String str38 = property36.getAsText(locale37);
        org.joda.time.MonthDay monthDay40 = property36.setCopy((int) (byte) 10);
        java.util.Locale locale41 = null;
        int int42 = property36.getMaximumTextLength(locale41);
        java.util.Locale locale43 = null;
        java.lang.String str44 = property36.getAsText(locale43);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property36.getFieldType();
        org.joda.time.MonthDay.Property property46 = monthDay32.property(dateTimeFieldType45);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType45, (int) (byte) 1);
        long long51 = offsetDateTimeField48.add((long) 4, 59);
        long long54 = offsetDateTimeField48.getDifferenceAsLong(103L, (long) (byte) 10);
        org.joda.time.ReadablePartial readablePartial55 = null;
        int[] intArray60 = new int[] { (short) 0, 9, 87 };
        try {
            int[] intArray62 = offsetDateTimeField48.add(readablePartial55, 87, intArray60, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 87");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-00:00:00.001" + "'", str20.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-1" + "'", str27.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June" + "'", str38.equals("June"));
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June" + "'", str44.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 59004L + "'", long51 == 59004L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertNotNull(intArray60);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) 'a');
//        int int6 = dateTime3.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime3.plus(readablePeriod7);
//        org.joda.time.DateTime.Property property9 = dateTime3.era();
//        try {
//            org.joda.time.DateTime dateTime11 = property9.addToCopy((long) 4);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.Chronology chronology4 = gJChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology1.yearOfEra();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withWeekOfWeekyear((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) 'a');
//        int int10 = dateTime7.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime7.plus(readablePeriod11);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime7.withPeriodAdded(readablePeriod13, (int) 'a');
//        boolean boolean16 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime18 = dateTime7.minus(0L);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
//        org.joda.time.DateTime dateTime22 = dateTime20.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime24 = dateTime22.plusHours((int) 'a');
//        int int25 = dateTime22.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod26 = null;
//        org.joda.time.DateTime dateTime27 = dateTime22.plus(readablePeriod26);
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime30 = dateTime22.withPeriodAdded(readablePeriod28, (int) 'a');
//        org.joda.time.DateTime.Property property31 = dateTime22.dayOfMonth();
//        boolean boolean32 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeUtils.getZone(dateTimeZone34);
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = dateTimeZone35.getShortName((long) 0, locale37);
//        java.lang.String str39 = dateTimeZone35.getID();
//        org.joda.time.chrono.ZonedChronology zonedChronology40 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology33, dateTimeZone35);
//        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay43 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology42);
//        org.joda.time.DateTimeZone dateTimeZone44 = gJChronology42.getZone();
//        org.joda.time.DateTimeField dateTimeField45 = gJChronology42.secondOfMinute();
//        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay48 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology47);
//        org.joda.time.DateTimeZone dateTimeZone49 = gJChronology47.getZone();
//        org.joda.time.DateTimeField dateTimeField50 = gJChronology47.secondOfMinute();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField52 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology42, dateTimeField50, (int) ' ');
//        int int54 = skipDateTimeField52.getMaximumValue((long) 0);
//        org.joda.time.chrono.GJChronology gJChronology55 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone56 = null;
//        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeUtils.getZone(dateTimeZone56);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = dateTimeZone57.getShortName((long) 0, locale59);
//        java.lang.String str61 = dateTimeZone57.getID();
//        org.joda.time.chrono.ZonedChronology zonedChronology62 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology55, dateTimeZone57);
//        org.joda.time.MonthDay monthDay63 = new org.joda.time.MonthDay(dateTimeZone57);
//        org.joda.time.MonthDay monthDay65 = monthDay63.plusMonths(82919);
//        java.util.Locale locale67 = null;
//        java.lang.String str68 = skipDateTimeField52.getAsShortText((org.joda.time.ReadablePartial) monthDay65, (int) (byte) -1, locale67);
//        org.joda.time.MonthDay monthDay69 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod70 = null;
//        org.joda.time.MonthDay monthDay71 = monthDay69.plus(readablePeriod70);
//        org.joda.time.MonthDay.Property property72 = monthDay69.monthOfYear();
//        org.joda.time.MonthDay monthDay73 = property72.getMonthDay();
//        org.joda.time.MonthDay monthDay74 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod75 = null;
//        org.joda.time.MonthDay monthDay76 = monthDay74.plus(readablePeriod75);
//        org.joda.time.MonthDay.Property property77 = monthDay74.monthOfYear();
//        java.util.Locale locale78 = null;
//        java.lang.String str79 = property77.getAsText(locale78);
//        org.joda.time.MonthDay monthDay81 = property77.setCopy((int) (byte) 10);
//        java.util.Locale locale82 = null;
//        int int83 = property77.getMaximumTextLength(locale82);
//        java.util.Locale locale84 = null;
//        java.lang.String str85 = property77.getAsText(locale84);
//        org.joda.time.DateTimeFieldType dateTimeFieldType86 = property77.getFieldType();
//        org.joda.time.MonthDay.Property property87 = monthDay73.property(dateTimeFieldType86);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField89 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField52, dateTimeFieldType86, (int) (byte) 1);
//        long long92 = offsetDateTimeField89.add((long) 4, 59);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField93 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology33, (org.joda.time.DateTimeField) offsetDateTimeField89);
//        org.joda.time.DateTime dateTime94 = dateTime7.toDateTime((org.joda.time.Chronology) gJChronology33);
//        try {
//            org.joda.time.DateTime dateTime96 = dateTime94.withSecondOfMinute(75718);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 75718 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 24 + "'", int25 == 24);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "-00:00:00.001" + "'", str38.equals("-00:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "-00:00:00.001" + "'", str39.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(zonedChronology40);
//        org.junit.Assert.assertNotNull(gJChronology42);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(gJChronology47);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 59 + "'", int54 == 59);
//        org.junit.Assert.assertNotNull(gJChronology55);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "-00:00:00.001" + "'", str60.equals("-00:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "-00:00:00.001" + "'", str61.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(zonedChronology62);
//        org.junit.Assert.assertNotNull(monthDay65);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "-1" + "'", str68.equals("-1"));
//        org.junit.Assert.assertNotNull(monthDay69);
//        org.junit.Assert.assertNotNull(monthDay71);
//        org.junit.Assert.assertNotNull(property72);
//        org.junit.Assert.assertNotNull(monthDay73);
//        org.junit.Assert.assertNotNull(monthDay74);
//        org.junit.Assert.assertNotNull(monthDay76);
//        org.junit.Assert.assertNotNull(property77);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "June" + "'", str79.equals("June"));
//        org.junit.Assert.assertNotNull(monthDay81);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 9 + "'", int83 == 9);
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "June" + "'", str85.equals("June"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType86);
//        org.junit.Assert.assertNotNull(property87);
//        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 59004L + "'", long92 == 59004L);
//        org.junit.Assert.assertNotNull(dateTime94);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        int int4 = dateTimeZone1.getOffsetFromLocal(100L);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.Chronology chronology9 = julianChronology5.withZone(dateTimeZone7);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(100, 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 109 + "'", int2 == 109);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("ZonedChronology[BuddhistChronology[UTC], -00:00:00.001]", (java.lang.Number) 0.0d, (java.lang.Number) 82919, number3);
        java.lang.String str5 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str7 = illegalFieldValueException4.toString();
        illegalFieldValueException4.prependMessage("");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0.0" + "'", str5.equals("0.0"));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 0.0 for ZonedChronology[BuddhistChronology[UTC], -00:00:00.001] must not be smaller than 82919" + "'", str7.equals("org.joda.time.IllegalFieldValueException: Value 0.0 for ZonedChronology[BuddhistChronology[UTC], -00:00:00.001] must not be smaller than 82919"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay monthDay4 = monthDay0.plusDays(0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray5 = monthDay4.getFieldTypes();
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay8 = monthDay6.plus(readablePeriod7);
        org.joda.time.MonthDay monthDay10 = monthDay6.plusDays(0);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology12);
        org.joda.time.Chronology chronology14 = monthDay13.getChronology();
        org.joda.time.MonthDay monthDay16 = monthDay13.minusMonths(3);
        boolean boolean17 = monthDay10.isEqual((org.joda.time.ReadablePartial) monthDay13);
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.MonthDay monthDay20 = monthDay18.plus(readablePeriod19);
        org.joda.time.MonthDay monthDay22 = monthDay18.minusDays(1);
        boolean boolean23 = monthDay10.isBefore((org.joda.time.ReadablePartial) monthDay22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology25);
        org.joda.time.DateTimeZone dateTimeZone27 = gJChronology25.getZone();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology25.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay31 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology30);
        org.joda.time.DateTimeZone dateTimeZone32 = gJChronology30.getZone();
        org.joda.time.DateTimeField dateTimeField33 = gJChronology30.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField35 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField33, (int) ' ');
        int int37 = skipDateTimeField35.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeUtils.getZone(dateTimeZone39);
        java.util.Locale locale42 = null;
        java.lang.String str43 = dateTimeZone40.getShortName((long) 0, locale42);
        java.lang.String str44 = dateTimeZone40.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology45 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology38, dateTimeZone40);
        org.joda.time.MonthDay monthDay46 = new org.joda.time.MonthDay(dateTimeZone40);
        org.joda.time.MonthDay monthDay48 = monthDay46.plusMonths(82919);
        java.util.Locale locale50 = null;
        java.lang.String str51 = skipDateTimeField35.getAsShortText((org.joda.time.ReadablePartial) monthDay48, (int) (byte) -1, locale50);
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = skipDateTimeField35.getType();
        boolean boolean53 = monthDay10.isSupported(dateTimeFieldType52);
        try {
            org.joda.time.MonthDay.Property property54 = monthDay4.property(dateTimeFieldType52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfMinute' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray5);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 59 + "'", int37 == 59);
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "-00:00:00.001" + "'", str43.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "-00:00:00.001" + "'", str44.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology45);
        org.junit.Assert.assertNotNull(monthDay48);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "-1" + "'", str51.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone2.getShortName((long) 0, locale4);
        java.lang.String str6 = dateTimeZone2.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone2);
        org.joda.time.Instant instant8 = gJChronology0.getGregorianCutover();
        long long9 = instant8.getMillis();
        org.joda.time.DateTime dateTime10 = instant8.toDateTimeISO();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            int int12 = instant8.get(dateTimeFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-00:00:00.001" + "'", str5.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.001" + "'", str6.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-12219292800000L) + "'", long9 == (-12219292800000L));
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime7 = dateTime5.plusHours((int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime5.hourOfDay();
        org.joda.time.DateTime dateTime9 = property8.withMaximumValue();
        java.util.Date date10 = dateTime9.toDate();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipDateTimeField11.getAsShortText((long) (byte) 10, locale13);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) 'a');
//        int int6 = dateTime3.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime3.plus(readablePeriod7);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime11 = dateTime3.withPeriodAdded(readablePeriod9, (int) 'a');
//        org.joda.time.DateTime.Property property12 = dateTime3.dayOfMonth();
//        java.lang.String str13 = property12.getAsString();
//        int int14 = property12.getMaximumValueOverall();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "15" + "'", str13.equals("15"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getShortName((long) 0, locale18);
        java.lang.String str20 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology14, dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.MonthDay monthDay24 = monthDay22.plusMonths(82919);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay24, (int) (byte) -1, locale26);
        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay30 = monthDay28.plus(readablePeriod29);
        org.joda.time.MonthDay.Property property31 = monthDay28.monthOfYear();
        org.joda.time.MonthDay monthDay32 = property31.getMonthDay();
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.MonthDay monthDay35 = monthDay33.plus(readablePeriod34);
        org.joda.time.MonthDay.Property property36 = monthDay33.monthOfYear();
        java.util.Locale locale37 = null;
        java.lang.String str38 = property36.getAsText(locale37);
        org.joda.time.MonthDay monthDay40 = property36.setCopy((int) (byte) 10);
        java.util.Locale locale41 = null;
        int int42 = property36.getMaximumTextLength(locale41);
        java.util.Locale locale43 = null;
        java.lang.String str44 = property36.getAsText(locale43);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property36.getFieldType();
        org.joda.time.MonthDay.Property property46 = monthDay32.property(dateTimeFieldType45);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType45, (int) (byte) 1);
        long long51 = offsetDateTimeField48.add((long) 4, 59);
        long long54 = offsetDateTimeField48.add(0L, (long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = offsetDateTimeField48.getType();
        java.util.Locale locale57 = null;
        java.lang.String str58 = offsetDateTimeField48.getAsShortText(1560633156L, locale57);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-00:00:00.001" + "'", str20.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-1" + "'", str27.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June" + "'", str38.equals("June"));
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June" + "'", str44.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 59004L + "'", long51 == 59004L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-1000L) + "'", long54 == (-1000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "34" + "'", str58.equals("34"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getShortName((long) 0, locale18);
        java.lang.String str20 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology14, dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.MonthDay monthDay24 = monthDay22.plusMonths(82919);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay24, (int) (byte) -1, locale26);
        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay30 = monthDay28.plus(readablePeriod29);
        org.joda.time.MonthDay.Property property31 = monthDay28.monthOfYear();
        org.joda.time.MonthDay monthDay32 = property31.getMonthDay();
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.MonthDay monthDay35 = monthDay33.plus(readablePeriod34);
        org.joda.time.MonthDay.Property property36 = monthDay33.monthOfYear();
        java.util.Locale locale37 = null;
        java.lang.String str38 = property36.getAsText(locale37);
        org.joda.time.MonthDay monthDay40 = property36.setCopy((int) (byte) 10);
        java.util.Locale locale41 = null;
        int int42 = property36.getMaximumTextLength(locale41);
        java.util.Locale locale43 = null;
        java.lang.String str44 = property36.getAsText(locale43);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property36.getFieldType();
        org.joda.time.MonthDay.Property property46 = monthDay32.property(dateTimeFieldType45);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType45, (int) (byte) 1);
        java.lang.String str50 = offsetDateTimeField48.getAsText(101L);
        long long53 = offsetDateTimeField48.add(1L, (long) (byte) 10);
        int int55 = offsetDateTimeField48.getMinimumValue((long) 87);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-00:00:00.001" + "'", str20.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-1" + "'", str27.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June" + "'", str38.equals("June"));
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June" + "'", str44.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "0" + "'", str50.equals("0"));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 10001L + "'", long53 == 10001L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTimeZone dateTimeZone4 = gJChronology2.getZone();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology7);
        org.joda.time.DateTimeZone dateTimeZone9 = gJChronology7.getZone();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology7.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField10, (int) ' ');
        int int14 = skipDateTimeField12.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
        java.util.Locale locale19 = null;
        java.lang.String str20 = dateTimeZone17.getShortName((long) 0, locale19);
        java.lang.String str21 = dateTimeZone17.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology15, dateTimeZone17);
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay(dateTimeZone17);
        org.joda.time.MonthDay monthDay25 = monthDay23.plusMonths(82919);
        java.util.Locale locale27 = null;
        java.lang.String str28 = skipDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) monthDay25, (int) (byte) -1, locale27);
        org.joda.time.MonthDay monthDay29 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.MonthDay monthDay31 = monthDay29.plus(readablePeriod30);
        org.joda.time.MonthDay.Property property32 = monthDay29.monthOfYear();
        org.joda.time.MonthDay monthDay33 = property32.getMonthDay();
        org.joda.time.MonthDay monthDay34 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.MonthDay monthDay36 = monthDay34.plus(readablePeriod35);
        org.joda.time.MonthDay.Property property37 = monthDay34.monthOfYear();
        java.util.Locale locale38 = null;
        java.lang.String str39 = property37.getAsText(locale38);
        org.joda.time.MonthDay monthDay41 = property37.setCopy((int) (byte) 10);
        java.util.Locale locale42 = null;
        int int43 = property37.getMaximumTextLength(locale42);
        java.util.Locale locale44 = null;
        java.lang.String str45 = property37.getAsText(locale44);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property37.getFieldType();
        org.joda.time.MonthDay.Property property47 = monthDay33.property(dateTimeFieldType46);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField12, dateTimeFieldType46, (int) (byte) 1);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField50 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-00:00:00.001" + "'", str20.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "-00:00:00.001" + "'", str21.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-1" + "'", str28.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(monthDay36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "June" + "'", str39.equals("June"));
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 9 + "'", int43 == 9);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "June" + "'", str45.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(property47);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone2.getShortName((long) 0, locale4);
        java.lang.String str6 = dateTimeZone2.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone2);
        org.joda.time.Instant instant8 = gJChronology0.getGregorianCutover();
        long long12 = gJChronology0.add((long) 2, (long) (short) 1, (int) (byte) 0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-00:00:00.001" + "'", str5.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.001" + "'", str6.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("ZonedChronology[BuddhistChronology[UTC], -00:00:00.001]", (java.lang.Number) 0.0d, (java.lang.Number) 82919, number3);
        java.lang.String str5 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number6 = illegalFieldValueException4.getLowerBound();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0.0" + "'", str5.equals("0.0"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 82919 + "'", number6.equals(82919));
        org.junit.Assert.assertNull(dateTimeFieldType7);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology2, dateTimeZone4);
        org.joda.time.Chronology chronology6 = zonedChronology5.withUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        long long12 = dateTimeZone8.convertLocalToUTC((long) (byte) 100, false, (long) 'a');
        org.joda.time.Chronology chronology13 = zonedChronology5.withZone(dateTimeZone8);
        java.lang.String str14 = zonedChronology5.toString();
        try {
            long long20 = zonedChronology5.getDateTimeMillis((long) 24, 0, (int) (byte) 100, 66, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 101L + "'", long12 == 101L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[BuddhistChronology[UTC], -00:00:00.001]" + "'", str14.equals("ZonedChronology[BuddhistChronology[UTC], -00:00:00.001]"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        org.joda.time.MonthDay monthDay7 = property3.setCopy((int) (byte) 10);
        java.util.Locale locale8 = null;
        int int9 = property3.getMaximumTextLength(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property3.getAsText(locale10);
        int int12 = property3.getMinimumValueOverall();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone14);
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now(dateTimeZone14);
        boolean boolean17 = property3.equals((java.lang.Object) dateTimeZone14);
        int int18 = property3.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June" + "'", str5.equals("June"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June" + "'", str11.equals("June"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology2, dateTimeZone4);
        java.lang.String str6 = buddhistChronology2.toString();
        java.lang.String str7 = buddhistChronology2.toString();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology9);
        org.joda.time.Chronology chronology11 = monthDay10.getChronology();
        org.joda.time.MonthDay monthDay13 = monthDay10.minusMonths(3);
        int[] intArray19 = new int[] { 75666, (byte) -1, 87, '4', 2 };
        try {
            buddhistChronology2.validate((org.joda.time.ReadablePartial) monthDay13, intArray19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 75666 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "BuddhistChronology[-00:00:00.001]" + "'", str6.equals("BuddhistChronology[-00:00:00.001]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "BuddhistChronology[-00:00:00.001]" + "'", str7.equals("BuddhistChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("ZonedChronology[BuddhistChronology[UTC], -00:00:00.001]", (java.lang.Number) 0.0d, (java.lang.Number) 82919, number3);
        java.lang.String str5 = illegalFieldValueException4.getIllegalValueAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException4.getDateTimeFieldType();
        illegalFieldValueException4.prependMessage("2019-06-15T21:01");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0.0" + "'", str5.equals("0.0"));
        org.junit.Assert.assertNull(dateTimeFieldType6);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "", (int) (short) 100, (int) (short) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField11);
        long long14 = skipUndoDateTimeField12.roundFloor(32L);
        long long17 = skipUndoDateTimeField12.getDifferenceAsLong(0L, (long) 75662);
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.MonthDay monthDay20 = monthDay18.plus(readablePeriod19);
        org.joda.time.MonthDay.Property property21 = monthDay18.monthOfYear();
        org.joda.time.MonthDay monthDay22 = property21.getMonthDay();
        org.joda.time.MonthDay monthDay23 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.MonthDay monthDay25 = monthDay23.plus(readablePeriod24);
        org.joda.time.MonthDay.Property property26 = monthDay23.monthOfYear();
        java.util.Locale locale27 = null;
        java.lang.String str28 = property26.getAsText(locale27);
        org.joda.time.MonthDay monthDay30 = property26.setCopy((int) (byte) 10);
        java.util.Locale locale31 = null;
        int int32 = property26.getMaximumTextLength(locale31);
        java.util.Locale locale33 = null;
        java.lang.String str34 = property26.getAsText(locale33);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property26.getFieldType();
        org.joda.time.MonthDay.Property property36 = monthDay22.property(dateTimeFieldType35);
        int[] intArray43 = new int[] { 3, 2, 0, 12, (short) 10 };
        try {
            int[] intArray45 = skipUndoDateTimeField12.set((org.joda.time.ReadablePartial) monthDay22, 12, intArray43, 109);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 109 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str6.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-75L) + "'", long17 == (-75L));
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "June" + "'", str28.equals("June"));
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 9 + "'", int32 == 9);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "June" + "'", str34.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(intArray43);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.date();
        try {
            org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.parse("AD", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"AD\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("--09-01", (int) (short) -1, 82919, (int) '#', ' ', 31, 1, 0, true, (int) (byte) 10);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder22 = dateTimeZoneBuilder0.addRecurringSavings("T000000.000-0000", 82919, 6, 75714, ' ', (int) (byte) 100, 24, (int) (byte) -1, true, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay monthDay4 = monthDay0.plusDays(0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.Chronology chronology8 = monthDay7.getChronology();
        org.joda.time.MonthDay monthDay10 = monthDay7.minusMonths(3);
        boolean boolean11 = monthDay4.isEqual((org.joda.time.ReadablePartial) monthDay7);
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay14 = monthDay12.plus(readablePeriod13);
        org.joda.time.MonthDay monthDay16 = monthDay12.minusDays(1);
        boolean boolean17 = monthDay4.isBefore((org.joda.time.ReadablePartial) monthDay16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.MonthDay monthDay20 = monthDay4.withPeriodAdded(readablePeriod18, 75718);
        try {
            org.joda.time.MonthDay monthDay22 = monthDay20.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(monthDay20);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        org.joda.time.MonthDay monthDay4 = property3.getMonthDay();
        boolean boolean5 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay4);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant6 = null;
        long long7 = property5.getDifferenceAsLong(readableInstant6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property5.getFieldType();
        org.joda.time.DateTime dateTime10 = property5.addToCopy((long) 1969);
        java.lang.String str11 = property5.toString();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Property[centuryOfEra]" + "'", str11.equals("Property[centuryOfEra]"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "", (int) (short) 100, (int) (short) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.lang.String str7 = gregorianChronology6.toString();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology9);
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology9.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12);
        boolean boolean14 = copticChronology0.equals((java.lang.Object) dateTimeField12);
        try {
            long long22 = copticChronology0.getDateTimeMillis((int) 'a', 58, 109, (int) (short) 0, (int) (byte) 100, 109, 109);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str7.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.MonthDay monthDay3 = monthDay1.plus(readablePeriod2);
        org.joda.time.MonthDay.Property property4 = monthDay1.monthOfYear();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.MonthDay monthDay6 = monthDay1.withChronologyRetainFields(chronology5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.time();
        java.lang.String str8 = monthDay1.toString(dateTimeFormatter7);
        try {
            org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.parse("��:��:��.000", dateTimeFormatter7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"��:��:��.000\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "��:��:��.000" + "'", str8.equals("��:��:��.000"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (byte) -1, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((-75L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-75) + "'", int1 == (-75));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant6 = null;
        long long7 = property5.getDifferenceAsLong(readableInstant6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        int int9 = property5.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime dateTime11 = dateTime8.plusWeeks((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = dateTimeZone13.getShortName((long) 0, locale15);
        java.lang.String str17 = dateTimeZone13.getID();
        org.joda.time.LocalDateTime localDateTime18 = null;
        boolean boolean19 = dateTimeZone13.isLocalDateTimeGap(localDateTime18);
        org.joda.time.MutableDateTime mutableDateTime20 = dateTime11.toMutableDateTime(dateTimeZone13);
        long long24 = dateTimeZone13.convertLocalToUTC((long) 75666, false, (-1L));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-00:00:00.001" + "'", str16.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-00:00:00.001" + "'", str17.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 75667L + "'", long24 == 75667L);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test170");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) 'a');
//        int int6 = dateTime3.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime3.plus(readablePeriod7);
//        int int9 = dateTime8.getSecondOfDay();
//        int int10 = dateTime8.getMonthOfYear();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 75671 + "'", int9 == 75671);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "", "-1");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "monthOfYear", "2019-06-15T21:01");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone2.getShortName((long) 0, locale4);
        java.lang.String str6 = dateTimeZone2.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology9);
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology9.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology14);
        org.joda.time.DateTimeZone dateTimeZone16 = gJChronology14.getZone();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology14.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField17, (int) ' ');
        int int21 = skipDateTimeField19.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        java.util.Locale locale26 = null;
        java.lang.String str27 = dateTimeZone24.getShortName((long) 0, locale26);
        java.lang.String str28 = dateTimeZone24.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology22, dateTimeZone24);
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay(dateTimeZone24);
        org.joda.time.MonthDay monthDay32 = monthDay30.plusMonths(82919);
        java.util.Locale locale34 = null;
        java.lang.String str35 = skipDateTimeField19.getAsShortText((org.joda.time.ReadablePartial) monthDay32, (int) (byte) -1, locale34);
        org.joda.time.MonthDay monthDay36 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.MonthDay monthDay38 = monthDay36.plus(readablePeriod37);
        org.joda.time.MonthDay.Property property39 = monthDay36.monthOfYear();
        org.joda.time.MonthDay monthDay40 = property39.getMonthDay();
        org.joda.time.MonthDay monthDay41 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod42 = null;
        org.joda.time.MonthDay monthDay43 = monthDay41.plus(readablePeriod42);
        org.joda.time.MonthDay.Property property44 = monthDay41.monthOfYear();
        java.util.Locale locale45 = null;
        java.lang.String str46 = property44.getAsText(locale45);
        org.joda.time.MonthDay monthDay48 = property44.setCopy((int) (byte) 10);
        java.util.Locale locale49 = null;
        int int50 = property44.getMaximumTextLength(locale49);
        java.util.Locale locale51 = null;
        java.lang.String str52 = property44.getAsText(locale51);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property44.getFieldType();
        org.joda.time.MonthDay.Property property54 = monthDay40.property(dateTimeFieldType53);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField19, dateTimeFieldType53, (int) (byte) 1);
        long long59 = offsetDateTimeField56.add((long) 4, 59);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField60 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) offsetDateTimeField56);
        int int62 = offsetDateTimeField56.getLeapAmount((long) 75662);
        org.joda.time.MonthDay monthDay63 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod64 = null;
        org.joda.time.MonthDay monthDay65 = monthDay63.plus(readablePeriod64);
        org.joda.time.MonthDay.Property property66 = monthDay63.monthOfYear();
        java.util.Locale locale67 = null;
        java.lang.String str68 = property66.getAsText(locale67);
        org.joda.time.MonthDay monthDay70 = property66.addWrapFieldToCopy((int) ' ');
        int[] intArray72 = null;
        try {
            int[] intArray74 = offsetDateTimeField56.addWrapField((org.joda.time.ReadablePartial) monthDay70, 21, intArray72, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-00:00:00.001" + "'", str5.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.001" + "'", str6.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-00:00:00.001" + "'", str27.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-00:00:00.001" + "'", str28.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "-1" + "'", str35.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay36);
        org.junit.Assert.assertNotNull(monthDay38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertNotNull(monthDay43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "June" + "'", str46.equals("June"));
        org.junit.Assert.assertNotNull(monthDay48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 9 + "'", int50 == 9);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "June" + "'", str52.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 59004L + "'", long59 == 59004L);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(monthDay63);
        org.junit.Assert.assertNotNull(monthDay65);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "June" + "'", str68.equals("June"));
        org.junit.Assert.assertNotNull(monthDay70);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "", (int) (short) 100, (int) (short) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField11);
        int int14 = skipUndoDateTimeField12.getMaximumValue((long) (byte) 10);
        java.lang.String str16 = skipUndoDateTimeField12.getAsText((long) 'a');
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray19 = new int[] {};
        try {
            int[] intArray21 = skipUndoDateTimeField12.set(readablePartial17, (int) (byte) 100, intArray19, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str6.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("--09-01", (int) (short) -1, 82919, (int) '#', ' ', 31, 1, 0, true, (int) (byte) 10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder11.setFixedSavings("GregorianChronology[-00:00:00.001]", 0);
        java.io.OutputStream outputStream16 = null;
        try {
            dateTimeZoneBuilder14.writeTo("--08-31", outputStream16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant6 = null;
        long long7 = property5.getDifferenceAsLong(readableInstant6);
        int int8 = property5.getMaximumValueOverall();
        java.lang.String str9 = property5.getAsShortText();
        java.util.Locale locale10 = null;
        int int11 = property5.getMaximumTextLength(locale10);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2922789 + "'", int8 == 2922789);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "20" + "'", str9.equals("20"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 7 + "'", int11 == 7);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("AD");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: A");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) '#', 75671);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 75706 + "'", int2 == 75706);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay monthDay4 = monthDay0.plusDays(0);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay7 = monthDay5.plus(readablePeriod6);
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        boolean boolean9 = monthDay0.isBefore((org.joda.time.ReadablePartial) monthDay5);
        org.joda.time.DateTimeField[] dateTimeFieldArray10 = monthDay5.getFields();
        try {
            org.joda.time.MonthDay monthDay12 = monthDay5.withDayOfMonth(75662);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 75662 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldArray10);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = dateTimeZone10.getShortName((long) 0, locale12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        long long16 = dateTimeZone10.getMillisKeepLocal(dateTimeZone14, (long) (byte) -1);
        long long18 = dateTimeZone7.getMillisKeepLocal(dateTimeZone14, (long) (short) 100);
        try {
            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(59, 10, (int) (short) -1, 0, (int) (short) 1, (int) (byte) 1, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-00:00:00.001" + "'", str13.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime6 = dateTime3.withSecondOfMinute(0);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.minus(readablePeriod7);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay monthDay4 = monthDay0.plusDays(0);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray5 = monthDay4.getFieldTypes();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.MonthDay monthDay8 = monthDay4.withFieldAdded(durationFieldType6, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray5);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("0");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"0/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology11);
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology11.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology11.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField14, (int) ' ');
        int int18 = skipDateTimeField16.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
        java.util.Locale locale23 = null;
        java.lang.String str24 = dateTimeZone21.getShortName((long) 0, locale23);
        java.lang.String str25 = dateTimeZone21.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology26 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology19, dateTimeZone21);
        org.joda.time.MonthDay monthDay27 = new org.joda.time.MonthDay(dateTimeZone21);
        org.joda.time.MonthDay monthDay29 = monthDay27.plusMonths(82919);
        java.util.Locale locale31 = null;
        java.lang.String str32 = skipDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) monthDay29, (int) (byte) -1, locale31);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = skipDateTimeField16.getType();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder4.appendFraction(dateTimeFieldType33, (-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 59 + "'", int18 == 59);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "-00:00:00.001" + "'", str24.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "-00:00:00.001" + "'", str25.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology26);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "-1" + "'", str32.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "", (int) (short) 100, (int) (short) -1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
//        java.lang.String str7 = gregorianChronology6.toString();
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology9);
//        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology9.getZone();
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology9.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12);
//        boolean boolean14 = copticChronology0.equals((java.lang.Object) dateTimeField12);
//        org.joda.time.DateTimeZone dateTimeZone15 = copticChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime19 = dateTime17.withWeekOfWeekyear((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
//        org.joda.time.DateTime dateTime23 = dateTime21.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime25 = dateTime23.plusHours((int) 'a');
//        int int26 = dateTime23.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime23.plus(readablePeriod27);
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.DateTime dateTime31 = dateTime23.withPeriodAdded(readablePeriod29, (int) 'a');
//        boolean boolean32 = dateTime17.isBefore((org.joda.time.ReadableInstant) dateTime23);
//        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod34 = null;
//        org.joda.time.MonthDay monthDay35 = monthDay33.plus(readablePeriod34);
//        org.joda.time.MonthDay monthDay37 = monthDay33.minusDays(1);
//        int int38 = monthDay33.getDayOfMonth();
//        org.joda.time.DateTime dateTime39 = dateTime23.withFields((org.joda.time.ReadablePartial) monthDay33);
//        boolean boolean40 = copticChronology0.equals((java.lang.Object) dateTime23);
//        try {
//            org.joda.time.DateTime dateTime42 = dateTime23.withEra((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for era must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str7.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 24 + "'", int26 == 24);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(monthDay33);
//        org.junit.Assert.assertNotNull(monthDay35);
//        org.junit.Assert.assertNotNull(monthDay37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "1969-12-31T23:01");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test186");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withWeekOfWeekyear((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) 'a');
//        int int10 = dateTime7.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime7.plus(readablePeriod11);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime7.withPeriodAdded(readablePeriod13, (int) 'a');
//        boolean boolean16 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime18 = dateTime7.minus(0L);
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
//        org.joda.time.DateTime dateTime22 = dateTime20.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime24 = dateTime22.plusHours((int) 'a');
//        int int25 = dateTime22.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod26 = null;
//        org.joda.time.DateTime dateTime27 = dateTime22.plus(readablePeriod26);
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime30 = dateTime22.withPeriodAdded(readablePeriod28, (int) 'a');
//        org.joda.time.DateTime.Property property31 = dateTime22.dayOfMonth();
//        boolean boolean32 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime22);
//        int int33 = dateTime7.getMonthOfYear();
//        org.joda.time.DateTime dateTime35 = dateTime7.withMillis((long) 7);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 24 + "'", int25 == 24);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
//        org.junit.Assert.assertNotNull(dateTime35);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "", (int) (short) 100, (int) (short) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField11);
        long long14 = skipUndoDateTimeField12.roundFloor(32L);
        long long17 = skipUndoDateTimeField12.getDifferenceAsLong(0L, (long) 75662);
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipUndoDateTimeField12.getAsShortText(0L, locale19);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str6.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-75L) + "'", long17 == (-75L));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0" + "'", str20.equals("0"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "", "-1");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "3480", "hi!");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = null;
        org.joda.time.format.DateTimeParser dateTimeParser5 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.append(dateTimePrinter4, dateTimeParser5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 4L, (java.lang.Number) 0, (java.lang.Number) 75667L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getShortName((long) 0, locale18);
        java.lang.String str20 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology14, dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.MonthDay monthDay24 = monthDay22.plusMonths(82919);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay24, (int) (byte) -1, locale26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = skipDateTimeField11.getType();
        long long31 = skipDateTimeField11.add((long) (short) 100, 31);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-00:00:00.001" + "'", str20.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-1" + "'", str27.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31100L + "'", long31 == 31100L);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
//        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
//        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
//        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = dateTimeZone16.getShortName((long) 0, locale18);
//        java.lang.String str20 = dateTimeZone16.getID();
//        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology14, dateTimeZone16);
//        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone16);
//        org.joda.time.MonthDay monthDay24 = monthDay22.plusMonths(82919);
//        java.util.Locale locale26 = null;
//        java.lang.String str27 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay24, (int) (byte) -1, locale26);
//        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod29 = null;
//        org.joda.time.MonthDay monthDay30 = monthDay28.plus(readablePeriod29);
//        org.joda.time.MonthDay.Property property31 = monthDay28.monthOfYear();
//        org.joda.time.MonthDay monthDay32 = property31.getMonthDay();
//        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod34 = null;
//        org.joda.time.MonthDay monthDay35 = monthDay33.plus(readablePeriod34);
//        org.joda.time.MonthDay.Property property36 = monthDay33.monthOfYear();
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = property36.getAsText(locale37);
//        org.joda.time.MonthDay monthDay40 = property36.setCopy((int) (byte) 10);
//        java.util.Locale locale41 = null;
//        int int42 = property36.getMaximumTextLength(locale41);
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = property36.getAsText(locale43);
//        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property36.getFieldType();
//        org.joda.time.MonthDay.Property property46 = monthDay32.property(dateTimeFieldType45);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType45, (int) (byte) 1);
//        org.joda.time.MonthDay monthDay49 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod50 = null;
//        org.joda.time.MonthDay monthDay51 = monthDay49.plus(readablePeriod50);
//        org.joda.time.DateTimeFieldType dateTimeFieldType53 = monthDay49.getFieldType(0);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField54 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField48, dateTimeFieldType53);
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(dateTimeZone55);
//        org.joda.time.DateTime dateTime58 = dateTime56.withWeekOfWeekyear((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone59 = null;
//        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime(dateTimeZone59);
//        org.joda.time.DateTime dateTime62 = dateTime60.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime64 = dateTime62.plusHours((int) 'a');
//        int int65 = dateTime62.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod66 = null;
//        org.joda.time.DateTime dateTime67 = dateTime62.plus(readablePeriod66);
//        org.joda.time.ReadablePeriod readablePeriod68 = null;
//        org.joda.time.DateTime dateTime70 = dateTime62.withPeriodAdded(readablePeriod68, (int) 'a');
//        boolean boolean71 = dateTime56.isBefore((org.joda.time.ReadableInstant) dateTime62);
//        org.joda.time.MonthDay monthDay72 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod73 = null;
//        org.joda.time.MonthDay monthDay74 = monthDay72.plus(readablePeriod73);
//        org.joda.time.MonthDay monthDay76 = monthDay72.minusDays(1);
//        int int77 = monthDay72.getDayOfMonth();
//        org.joda.time.DateTime dateTime78 = dateTime62.withFields((org.joda.time.ReadablePartial) monthDay72);
//        int[] intArray83 = new int[] { (short) 10, 109, (short) 100, 75662 };
//        int int84 = offsetDateTimeField48.getMinimumValue((org.joda.time.ReadablePartial) monthDay72, intArray83);
//        long long87 = offsetDateTimeField48.getDifferenceAsLong((long) 2, 0L);
//        java.util.Locale locale89 = null;
//        java.lang.String str90 = offsetDateTimeField48.getAsText(3, locale89);
//        long long93 = offsetDateTimeField48.getDifferenceAsLong((long) (short) 1, 1560632466320L);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-00:00:00.001" + "'", str20.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(zonedChronology21);
//        org.junit.Assert.assertNotNull(monthDay24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-1" + "'", str27.equals("-1"));
//        org.junit.Assert.assertNotNull(monthDay28);
//        org.junit.Assert.assertNotNull(monthDay30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(monthDay32);
//        org.junit.Assert.assertNotNull(monthDay33);
//        org.junit.Assert.assertNotNull(monthDay35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June" + "'", str38.equals("June"));
//        org.junit.Assert.assertNotNull(monthDay40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June" + "'", str44.equals("June"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(monthDay49);
//        org.junit.Assert.assertNotNull(monthDay51);
//        org.junit.Assert.assertNotNull(dateTimeFieldType53);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 24 + "'", int65 == 24);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertNotNull(monthDay72);
//        org.junit.Assert.assertNotNull(monthDay74);
//        org.junit.Assert.assertNotNull(monthDay76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 15 + "'", int77 == 15);
//        org.junit.Assert.assertNotNull(dateTime78);
//        org.junit.Assert.assertNotNull(intArray83);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
//        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 0L + "'", long87 == 0L);
//        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "3" + "'", str90.equals("3"));
//        org.junit.Assert.assertTrue("'" + long93 + "' != '" + (-1560632466L) + "'", long93 == (-1560632466L));
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        boolean boolean5 = dateTime3.equals((java.lang.Object) 1.0f);
        org.joda.time.DateTime.Property property6 = dateTime3.weekyear();
        int int7 = property6.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-292275054) + "'", int7 == (-292275054));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        org.joda.time.MonthDay monthDay7 = property3.setCopy((int) (byte) 10);
        java.util.Locale locale8 = null;
        int int9 = property3.getMaximumTextLength(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property3.getAsText(locale10);
        int int12 = property3.getMinimumValueOverall();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone14);
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now(dateTimeZone14);
        boolean boolean17 = property3.equals((java.lang.Object) dateTimeZone14);
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now(dateTimeZone14);
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology20);
        org.joda.time.DateTimeZone dateTimeZone22 = gJChronology20.getZone();
        org.joda.time.DateTimeField dateTimeField23 = gJChronology20.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology25);
        org.joda.time.DateTimeZone dateTimeZone27 = gJChronology25.getZone();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology25.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField30 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology20, dateTimeField28, (int) ' ');
        int int32 = skipDateTimeField30.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeUtils.getZone(dateTimeZone34);
        java.util.Locale locale37 = null;
        java.lang.String str38 = dateTimeZone35.getShortName((long) 0, locale37);
        java.lang.String str39 = dateTimeZone35.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology40 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology33, dateTimeZone35);
        org.joda.time.MonthDay monthDay41 = new org.joda.time.MonthDay(dateTimeZone35);
        org.joda.time.MonthDay monthDay43 = monthDay41.plusMonths(82919);
        java.util.Locale locale45 = null;
        java.lang.String str46 = skipDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) monthDay43, (int) (byte) -1, locale45);
        org.joda.time.MonthDay monthDay47 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod48 = null;
        org.joda.time.MonthDay monthDay49 = monthDay47.plus(readablePeriod48);
        org.joda.time.MonthDay.Property property50 = monthDay47.monthOfYear();
        org.joda.time.MonthDay monthDay51 = property50.getMonthDay();
        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod53 = null;
        org.joda.time.MonthDay monthDay54 = monthDay52.plus(readablePeriod53);
        org.joda.time.MonthDay.Property property55 = monthDay52.monthOfYear();
        java.util.Locale locale56 = null;
        java.lang.String str57 = property55.getAsText(locale56);
        org.joda.time.MonthDay monthDay59 = property55.setCopy((int) (byte) 10);
        java.util.Locale locale60 = null;
        int int61 = property55.getMaximumTextLength(locale60);
        java.util.Locale locale62 = null;
        java.lang.String str63 = property55.getAsText(locale62);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = property55.getFieldType();
        org.joda.time.MonthDay.Property property65 = monthDay51.property(dateTimeFieldType64);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField30, dateTimeFieldType64, (int) (byte) 1);
        long long70 = offsetDateTimeField67.add((long) 4, 59);
        long long73 = offsetDateTimeField67.add(0L, (long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType74 = offsetDateTimeField67.getType();
        try {
            org.joda.time.MonthDay monthDay76 = monthDay18.withField(dateTimeFieldType74, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June" + "'", str5.equals("June"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June" + "'", str11.equals("June"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 59 + "'", int32 == 59);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "-00:00:00.001" + "'", str38.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "-00:00:00.001" + "'", str39.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology40);
        org.junit.Assert.assertNotNull(monthDay43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "-1" + "'", str46.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay47);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(monthDay51);
        org.junit.Assert.assertNotNull(monthDay52);
        org.junit.Assert.assertNotNull(monthDay54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "June" + "'", str57.equals("June"));
        org.junit.Assert.assertNotNull(monthDay59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 9 + "'", int61 == 9);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "June" + "'", str63.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertNotNull(property65);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 59004L + "'", long70 == 59004L);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-1000L) + "'", long73 == (-1000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType74);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        org.joda.time.MonthDay monthDay7 = property3.setCopy((int) (byte) 10);
        java.util.Locale locale8 = null;
        int int9 = property3.getMaximumTextLength(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property3.getAsText(locale10);
        int int12 = property3.getMinimumValueOverall();
        org.joda.time.MonthDay monthDay14 = property3.addToCopy(2922789);
        int int15 = property3.getMinimumValue();
        java.lang.String str16 = property3.getAsShortText();
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June" + "'", str5.equals("June"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June" + "'", str11.equals("June"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Jun" + "'", str16.equals("Jun"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getShortName((long) 0, locale18);
        java.lang.String str20 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology14, dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.MonthDay monthDay24 = monthDay22.plusMonths(82919);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay24, (int) (byte) -1, locale26);
        long long29 = skipDateTimeField11.roundFloor((long) (short) -1);
        java.util.Locale locale31 = null;
        java.lang.String str32 = skipDateTimeField11.getAsShortText(0, locale31);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-00:00:00.001" + "'", str20.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-1" + "'", str27.equals("-1"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1000L) + "'", long29 == (-1000L));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "0" + "'", str32.equals("0"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getShortName((long) 0, locale3);
        java.lang.String str5 = dateTimeZone1.getID();
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone1.isLocalDateTimeGap(localDateTime6);
        java.lang.String str8 = dateTimeZone1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-00:00:00.001" + "'", str4.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-00:00:00.001" + "'", str5.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-00:00:00.001" + "'", str8.equals("-00:00:00.001"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) 'a');
        org.joda.time.DateTime.Property property6 = dateTime3.hourOfDay();
        org.joda.time.DateTime dateTime8 = dateTime3.plusYears((int) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone10);
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime3.toDateTime(dateTimeZone10);
        java.util.Locale locale14 = null;
        java.util.Calendar calendar15 = dateTime13.toCalendar(locale14);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(calendar15);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getShortName((long) 0, locale18);
        java.lang.String str20 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology14, dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.MonthDay monthDay24 = monthDay22.plusMonths(82919);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay24, (int) (byte) -1, locale26);
        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay30 = monthDay28.plus(readablePeriod29);
        org.joda.time.MonthDay.Property property31 = monthDay28.monthOfYear();
        org.joda.time.MonthDay monthDay32 = property31.getMonthDay();
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.MonthDay monthDay35 = monthDay33.plus(readablePeriod34);
        org.joda.time.MonthDay.Property property36 = monthDay33.monthOfYear();
        java.util.Locale locale37 = null;
        java.lang.String str38 = property36.getAsText(locale37);
        org.joda.time.MonthDay monthDay40 = property36.setCopy((int) (byte) 10);
        java.util.Locale locale41 = null;
        int int42 = property36.getMaximumTextLength(locale41);
        java.util.Locale locale43 = null;
        java.lang.String str44 = property36.getAsText(locale43);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property36.getFieldType();
        org.joda.time.MonthDay.Property property46 = monthDay32.property(dateTimeFieldType45);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType45, (int) (byte) 1);
        long long51 = offsetDateTimeField48.add((long) 4, 59);
        long long54 = offsetDateTimeField48.add(0L, (long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = offsetDateTimeField48.getType();
        try {
            long long58 = offsetDateTimeField48.set((long) 82919, "December");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"December\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-00:00:00.001" + "'", str20.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-1" + "'", str27.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June" + "'", str38.equals("June"));
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June" + "'", str44.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 59004L + "'", long51 == 59004L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-1000L) + "'", long54 == (-1000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime7.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusHours((int) 'a');
//        int int12 = dateTime9.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime9.plus(readablePeriod13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime9.withPeriodAdded(readablePeriod15, (int) 'a');
//        boolean boolean18 = dateTime3.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        java.lang.String str19 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTimeZone dateTimeZone20 = dateTimeFormatter1.getZone();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter1.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = dateTimeZone25.getShortName((long) 0, locale27);
//        java.lang.String str29 = dateTimeZone25.getID();
//        org.joda.time.chrono.ZonedChronology zonedChronology30 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology23, dateTimeZone25);
//        org.joda.time.Instant instant31 = gJChronology23.getGregorianCutover();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology23);
//        java.io.Writer writer33 = null;
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone34);
//        org.joda.time.DateTime dateTime37 = dateTime35.withMinuteOfHour((int) (byte) 1);
//        boolean boolean38 = dateTime37.isEqualNow();
//        int int39 = dateTime37.getYearOfCentury();
//        try {
//            dateTimeFormatter32.printTo(writer33, (org.joda.time.ReadableInstant) dateTime37);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019-06-15T21:01" + "'", str19.equals("2019-06-15T21:01"));
//        org.junit.Assert.assertNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter22);
//        org.junit.Assert.assertNotNull(gJChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-00:00:00.001" + "'", str28.equals("-00:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "-00:00:00.001" + "'", str29.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(zonedChronology30);
//        org.junit.Assert.assertNotNull(instant31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter32);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 19 + "'", int39 == 19);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        int int4 = dateTimeZone1.getOffsetFromLocal(100L);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.Chronology chronology9 = julianChronology5.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.withMinuteOfHour((int) (byte) 1);
        boolean boolean14 = dateTime13.isEqualNow();
        org.joda.time.DateTime.Property property15 = dateTime13.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant16 = null;
        long long17 = property15.getDifferenceAsLong(readableInstant16);
        int int18 = property15.getMaximumValueOverall();
        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.MonthDay monthDay21 = monthDay19.plus(readablePeriod20);
        org.joda.time.MonthDay.Property property22 = monthDay19.monthOfYear();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.MonthDay monthDay24 = monthDay19.withChronologyRetainFields(chronology23);
        boolean boolean25 = property15.equals((java.lang.Object) monthDay24);
        boolean boolean26 = julianChronology5.equals((java.lang.Object) property15);
        java.lang.String str27 = julianChronology5.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2922789 + "'", int18 == 2922789);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "JulianChronology[-00:00:00.001]" + "'", str27.equals("JulianChronology[-00:00:00.001]"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay0.getFieldType(0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.hours();
        org.joda.time.DurationField durationField9 = gJChronology6.millis();
        java.lang.Object obj10 = null;
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField9, obj10);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField12 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField9);
        java.util.Locale locale13 = null;
        try {
            int int14 = unsupportedDateTimeField12.getMaximumShortTextLength(locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField12);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        org.joda.time.MonthDay monthDay7 = property3.setCopy((int) (byte) 10);
        java.util.Locale locale8 = null;
        int int9 = property3.getMaximumTextLength(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property3.getAsText(locale10);
        int int12 = property3.getMinimumValueOverall();
        org.joda.time.MonthDay monthDay14 = property3.addToCopy(2922789);
        java.lang.Object obj15 = null;
        boolean boolean16 = property3.equals(obj15);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June" + "'", str5.equals("June"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June" + "'", str11.equals("June"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.MonthDay monthDay16 = monthDay14.plus(readablePeriod15);
        org.joda.time.MonthDay.Property property17 = monthDay14.monthOfYear();
        int[] intArray24 = new int[] { 66, 20, 10, 'a', 75662, 75666 };
        int int25 = skipDateTimeField11.getMinimumValue((org.joda.time.ReadablePartial) monthDay14, intArray24);
        boolean boolean26 = skipDateTimeField11.isSupported();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
//        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.MonthDay monthDay7 = property3.addWrapFieldToCopy((int) ' ');
//        java.lang.String str8 = monthDay7.toString();
//        try {
//            org.joda.time.Instant instant9 = new org.joda.time.Instant((java.lang.Object) monthDay7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.MonthDay");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(monthDay0);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June" + "'", str5.equals("June"));
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "--02-15" + "'", str8.equals("--02-15"));
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "", (int) (short) 100, (int) (short) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.lang.String str7 = gregorianChronology6.toString();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology9);
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology9.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12);
        boolean boolean14 = copticChronology0.equals((java.lang.Object) dateTimeField12);
        try {
            long long19 = copticChronology0.getDateTimeMillis((-1), 75671436, (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 75671436 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str7.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        org.joda.time.DurationField durationField7 = property5.getRangeDurationField();
        org.joda.time.DurationField durationField8 = property5.getLeapDurationField();
        org.joda.time.DurationField durationField9 = property5.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertNull(durationField9);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
        int int8 = dateTimeZone5.getOffsetFromLocal(100L);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology10 = gJChronology1.withZone(dateTimeZone5);
        long long15 = gJChronology1.getDateTimeMillis(75666, 10, 2, 2019);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2325644870402019L + "'", long15 == 2325644870402019L);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
//        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime7.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusHours((int) 'a');
//        int int12 = dateTime9.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime9.plus(readablePeriod13);
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime9.withPeriodAdded(readablePeriod15, (int) 'a');
//        boolean boolean18 = dateTime3.isBefore((org.joda.time.ReadableInstant) dateTime9);
//        java.lang.String str19 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTimeZone dateTimeZone20 = dateTimeFormatter1.getZone();
//        org.joda.time.Chronology chronology21 = dateTimeFormatter1.getChronolgy();
//        java.io.Writer writer22 = null;
//        org.joda.time.MonthDay monthDay23 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.MonthDay monthDay25 = monthDay23.plus(readablePeriod24);
//        org.joda.time.MonthDay monthDay27 = monthDay23.withDayOfMonth((int) (short) 1);
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.MonthDay monthDay29 = monthDay27.minus(readablePeriod28);
//        try {
//            dateTimeFormatter1.printTo(writer22, (org.joda.time.ReadablePartial) monthDay29);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019-06-15T21:01" + "'", str19.equals("2019-06-15T21:01"));
//        org.junit.Assert.assertNull(dateTimeZone20);
//        org.junit.Assert.assertNull(chronology21);
//        org.junit.Assert.assertNotNull(monthDay23);
//        org.junit.Assert.assertNotNull(monthDay25);
//        org.junit.Assert.assertNotNull(monthDay27);
//        org.junit.Assert.assertNotNull(monthDay29);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        java.util.Locale locale2 = null;
        try {
            java.lang.String str3 = dateTime0.toString("1969-12-31T23:01", locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        int int4 = dateTimeZone1.getOffsetFromLocal(100L);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone7);
        org.joda.time.Chronology chronology9 = julianChronology5.withZone(dateTimeZone7);
        try {
            long long17 = julianChronology5.getDateTimeMillis(75678, 24, (int) (short) 1, 4, 0, (-292275054), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275054 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology9);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test218");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
//        boolean boolean4 = dateTime3.isEqualNow();
//        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
//        org.joda.time.ReadableInstant readableInstant6 = null;
//        long long7 = property5.getDifferenceAsLong(readableInstant6);
//        int int8 = property5.getMaximumValueOverall();
//        java.lang.String str9 = property5.getAsShortText();
//        long long10 = property5.remainder();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2922789 + "'", int8 == 2922789);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "20" + "'", str9.equals("20"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1595127517531L) + "'", long10 == (-1595127517531L));
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay0.getFieldType(0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.hours();
        org.joda.time.DurationField durationField9 = gJChronology6.millis();
        java.lang.Object obj10 = null;
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField9, obj10);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField12 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField9);
        try {
            long long14 = unsupportedDateTimeField12.remainder((long) 75666);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField12);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant6 = null;
        long long7 = property5.getDifferenceAsLong(readableInstant6);
        org.joda.time.DateTime dateTime9 = property5.addToCopy((long) 6);
        org.joda.time.DateTime dateTime11 = dateTime9.minusDays(100);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = dateTimeZone14.getShortName((long) 0, locale16);
        java.lang.String str18 = dateTimeZone14.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology12, dateTimeZone14);
        org.joda.time.Instant instant20 = gJChronology12.getGregorianCutover();
        long long21 = instant20.getMillis();
        org.joda.time.DateTime dateTime22 = instant20.toDateTimeISO();
        boolean boolean23 = dateTime11.isEqual((org.joda.time.ReadableInstant) instant20);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-00:00:00.001" + "'", str17.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-00:00:00.001" + "'", str18.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(instant20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-12219292800000L) + "'", long21 == (-12219292800000L));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("ZonedChronology[BuddhistChronology[UTC], -00:00:00.001]", (java.lang.Number) 0.0d, (java.lang.Number) 82919, number3);
        java.lang.String str5 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number6 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number7 = illegalFieldValueException4.getUpperBound();
        java.lang.Number number11 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException("ZonedChronology[BuddhistChronology[UTC], -00:00:00.001]", (java.lang.Number) 0.0d, (java.lang.Number) 82919, number11);
        java.lang.String str13 = illegalFieldValueException12.getIllegalValueAsString();
        java.lang.String str14 = illegalFieldValueException12.getIllegalStringValue();
        java.lang.String str15 = illegalFieldValueException12.toString();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException12);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0.0" + "'", str5.equals("0.0"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 82919 + "'", number6.equals(82919));
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0.0" + "'", str13.equals("0.0"));
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 0.0 for ZonedChronology[BuddhistChronology[UTC], -00:00:00.001] must not be smaller than 82919" + "'", str15.equals("org.joda.time.IllegalFieldValueException: Value 0.0 for ZonedChronology[BuddhistChronology[UTC], -00:00:00.001] must not be smaller than 82919"));
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
//        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.MonthDay monthDay7 = property3.addWrapFieldToCopy((int) ' ');
//        java.lang.String str8 = monthDay7.toString();
//        try {
//            java.lang.String str10 = monthDay7.toString("T000000.057-0000");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(monthDay0);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June" + "'", str5.equals("June"));
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "--02-15" + "'", str8.equals("--02-15"));
//    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) 'a');
//        int int6 = dateTime3.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime3.plus(readablePeriod7);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime11 = dateTime3.withPeriodAdded(readablePeriod9, (int) 'a');
//        org.joda.time.DateTime.Property property12 = dateTime3.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        org.joda.time.DateTime dateTime16 = dateTime14.withMinuteOfHour((int) (byte) 1);
//        boolean boolean17 = dateTime16.isEqualNow();
//        org.joda.time.DateTime.Property property18 = dateTime16.centuryOfEra();
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        long long20 = property18.getDifferenceAsLong(readableInstant19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property18.getFieldType();
//        boolean boolean22 = dateTime3.isSupported(dateTimeFieldType21);
//        long long23 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.DateTime.Property property24 = dateTime3.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone25);
//        org.joda.time.DateTime dateTime28 = dateTime26.withMinuteOfHour((int) (byte) 1);
//        boolean boolean29 = dateTime28.isEqualNow();
//        org.joda.time.DateTime.Property property30 = dateTime28.centuryOfEra();
//        org.joda.time.ReadableInstant readableInstant31 = null;
//        long long32 = property30.getDifferenceAsLong(readableInstant31);
//        org.joda.time.DateTime dateTime34 = property30.addToCopy((long) 6);
//        org.joda.time.DateTime dateTime36 = dateTime34.minusDays(100);
//        int int37 = property24.compareTo((org.joda.time.ReadableInstant) dateTime34);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560632483169L + "'", long23 == 1560632483169L);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 'a', dateTimeZone1);
        int int3 = dateTime2.getEra();
        int int4 = dateTime2.getHourOfDay();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant6 = null;
        long long7 = property5.getDifferenceAsLong(readableInstant6);
        int int8 = property5.getMaximumValueOverall();
        org.joda.time.DateTime dateTime9 = property5.withMaximumValue();
        org.joda.time.DurationField durationField10 = property5.getDurationField();
        org.joda.time.DateTime dateTime11 = property5.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2922789 + "'", int8 == 2922789);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder3.appendMonthOfYearShortText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendPattern("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("ZonedChronology[BuddhistChronology[UTC], -00:00:00.001]", (java.lang.Number) 0.0d, (java.lang.Number) 82919, number3);
        java.lang.String str5 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str7 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0.0" + "'", str5.equals("0.0"));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.0" + "'", str7.equals("0.0"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant6 = null;
        long long7 = property5.getDifferenceAsLong(readableInstant6);
        int int8 = property5.getMaximumValueOverall();
        org.joda.time.DateTime dateTime9 = property5.withMaximumValue();
        org.joda.time.DurationField durationField10 = property5.getDurationField();
        org.joda.time.DateTime dateTime11 = property5.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2922789 + "'", int8 == 2922789);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMinuteOfHour((int) (byte) 1);
        boolean boolean5 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime6 = monthDay0.toDateTime((org.joda.time.ReadableInstant) dateTime4);
        try {
            org.joda.time.DateTime dateTime10 = dateTime4.withDate(100, (int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getShortName((long) 0, locale18);
        java.lang.String str20 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology14, dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.MonthDay monthDay24 = monthDay22.plusMonths(82919);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay24, (int) (byte) -1, locale26);
        java.util.Locale locale29 = null;
        java.lang.String str30 = skipDateTimeField11.getAsText(3480, locale29);
        int int32 = skipDateTimeField11.get(1052L);
        java.lang.String str33 = skipDateTimeField11.toString();
        java.util.Locale locale36 = null;
        try {
            long long37 = skipDateTimeField11.set((long) '#', "0.0", locale36);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"0.0\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-00:00:00.001" + "'", str20.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-1" + "'", str27.equals("-1"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "3480" + "'", str30.equals("3480"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "DateTimeField[secondOfMinute]" + "'", str33.equals("DateTimeField[secondOfMinute]"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay0.getFieldType(0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.hours();
        org.joda.time.DurationField durationField9 = gJChronology6.millis();
        java.lang.Object obj10 = null;
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField9, obj10);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField12 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField9);
        boolean boolean13 = unsupportedDateTimeField12.isLenient();
        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.MonthDay monthDay16 = monthDay14.plus(readablePeriod15);
        org.joda.time.MonthDay monthDay18 = monthDay14.minusDays(1);
        java.util.Locale locale19 = null;
        try {
            java.lang.String str20 = unsupportedDateTimeField12.getAsText((org.joda.time.ReadablePartial) monthDay14, locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(monthDay18);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay0.getFieldType(0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.hours();
        org.joda.time.DurationField durationField9 = gJChronology6.millis();
        java.lang.Object obj10 = null;
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField9, obj10);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField12 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField9);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = unsupportedDateTimeField12.getType();
        try {
            long long16 = unsupportedDateTimeField12.set(32010L, "June");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getShortName((long) 0, locale18);
        java.lang.String str20 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology14, dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.MonthDay monthDay24 = monthDay22.plusMonths(82919);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay24, (int) (byte) -1, locale26);
        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay30 = monthDay28.plus(readablePeriod29);
        org.joda.time.MonthDay.Property property31 = monthDay28.monthOfYear();
        org.joda.time.MonthDay monthDay32 = property31.getMonthDay();
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.MonthDay monthDay35 = monthDay33.plus(readablePeriod34);
        org.joda.time.MonthDay.Property property36 = monthDay33.monthOfYear();
        java.util.Locale locale37 = null;
        java.lang.String str38 = property36.getAsText(locale37);
        org.joda.time.MonthDay monthDay40 = property36.setCopy((int) (byte) 10);
        java.util.Locale locale41 = null;
        int int42 = property36.getMaximumTextLength(locale41);
        java.util.Locale locale43 = null;
        java.lang.String str44 = property36.getAsText(locale43);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property36.getFieldType();
        org.joda.time.MonthDay.Property property46 = monthDay32.property(dateTimeFieldType45);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType45, (int) (byte) 1);
        long long51 = offsetDateTimeField48.add((long) 4, 59);
        long long54 = offsetDateTimeField48.getDifferenceAsLong(10L, (long) 20);
        int int55 = offsetDateTimeField48.getMaximumValue();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-00:00:00.001" + "'", str20.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-1" + "'", str27.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June" + "'", str38.equals("June"));
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June" + "'", str44.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 59004L + "'", long51 == 59004L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 60 + "'", int55 == 60);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("Dec", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
//        int int5 = dateTimeZone2.getOffsetFromLocal(100L);
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone2);
//        java.lang.String str9 = dateTimeFormatter7.print((long) (byte) 1);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
//        org.joda.time.DateTime dateTime13 = dateTime11.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime15 = dateTime13.plusHours((int) 'a');
//        int int16 = dateTime13.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime13.plus(readablePeriod17);
//        java.lang.String str19 = dateTimeFormatter7.print((org.joda.time.ReadableInstant) dateTime18);
//        int int20 = dateTime18.getCenturyOfEra();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "T000000.000-0000" + "'", str9.equals("T000000.000-0000"));
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 24 + "'", int16 == 24);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "T210124.112-0000" + "'", str19.equals("T210124.112-0000"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 20 + "'", int20 == 20);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendMillisOfSecond(31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendCenturyOfEra(75714, 58);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.DateTime dateTime4 = dateTime2.withWeekOfWeekyear((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime10 = dateTime8.plusHours((int) 'a');
//        int int11 = dateTime8.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime8.plus(readablePeriod12);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime16 = dateTime8.withPeriodAdded(readablePeriod14, (int) 'a');
//        boolean boolean17 = dateTime2.isBefore((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.MonthDay monthDay20 = monthDay18.plus(readablePeriod19);
//        org.joda.time.MonthDay monthDay22 = monthDay18.minusDays(1);
//        int int23 = monthDay18.getDayOfMonth();
//        org.joda.time.DateTime dateTime24 = dateTime8.withFields((org.joda.time.ReadablePartial) monthDay18);
//        org.joda.time.DateTime dateTime26 = dateTime24.withWeekyear(10);
//        java.lang.String str27 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(monthDay18);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 15 + "'", int23 == 15);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0010-06-19" + "'", str27.equals("0010-06-19"));
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        int int5 = dateTimeZone2.getOffsetFromLocal(100L);
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone2);
        long long10 = dateTimeZone2.convertLocalToUTC((long) 12, true);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 13L + "'", long10 == 13L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getShortName((long) 0, locale18);
        java.lang.String str20 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology14, dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.MonthDay monthDay24 = monthDay22.plusMonths(82919);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay24, (int) (byte) -1, locale26);
        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay30 = monthDay28.plus(readablePeriod29);
        org.joda.time.MonthDay.Property property31 = monthDay28.monthOfYear();
        org.joda.time.MonthDay monthDay32 = property31.getMonthDay();
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.MonthDay monthDay35 = monthDay33.plus(readablePeriod34);
        org.joda.time.MonthDay.Property property36 = monthDay33.monthOfYear();
        java.util.Locale locale37 = null;
        java.lang.String str38 = property36.getAsText(locale37);
        org.joda.time.MonthDay monthDay40 = property36.setCopy((int) (byte) 10);
        java.util.Locale locale41 = null;
        int int42 = property36.getMaximumTextLength(locale41);
        java.util.Locale locale43 = null;
        java.lang.String str44 = property36.getAsText(locale43);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property36.getFieldType();
        org.joda.time.MonthDay.Property property46 = monthDay32.property(dateTimeFieldType45);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType45, (int) (byte) 1);
        long long51 = offsetDateTimeField48.add((long) 4, 59);
        long long54 = offsetDateTimeField48.add(0L, (long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = offsetDateTimeField48.getType();
        long long58 = offsetDateTimeField48.add(0L, (int) (byte) 1);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-00:00:00.001" + "'", str20.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-1" + "'", str27.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June" + "'", str38.equals("June"));
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June" + "'", str44.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 59004L + "'", long51 == 59004L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-1000L) + "'", long54 == (-1000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1000L + "'", long58 == 1000L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendHourOfHalfday((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendWeekyear(24, 3);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology14);
        org.joda.time.DateTimeZone dateTimeZone16 = gJChronology14.getZone();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology14.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology19);
        org.joda.time.DateTimeZone dateTimeZone21 = gJChronology19.getZone();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology19.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology14, dateTimeField22, (int) ' ');
        int int26 = skipDateTimeField24.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        java.util.Locale locale31 = null;
        java.lang.String str32 = dateTimeZone29.getShortName((long) 0, locale31);
        java.lang.String str33 = dateTimeZone29.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology34 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology27, dateTimeZone29);
        org.joda.time.MonthDay monthDay35 = new org.joda.time.MonthDay(dateTimeZone29);
        org.joda.time.MonthDay monthDay37 = monthDay35.plusMonths(82919);
        java.util.Locale locale39 = null;
        java.lang.String str40 = skipDateTimeField24.getAsShortText((org.joda.time.ReadablePartial) monthDay37, (int) (byte) -1, locale39);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = skipDateTimeField24.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder7.appendShortText(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType41);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder0.appendMonthOfYear(160);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 59 + "'", int26 == 59);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "-00:00:00.001" + "'", str32.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "-00:00:00.001" + "'", str33.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology34);
        org.junit.Assert.assertNotNull(monthDay37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "-1" + "'", str40.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        org.joda.time.MonthDay monthDay7 = property3.setCopy((int) (byte) 10);
        java.util.Locale locale8 = null;
        int int9 = property3.getMaximumTextLength(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property3.getAsText(locale10);
        int int12 = property3.getMinimumValueOverall();
        org.joda.time.MonthDay monthDay14 = property3.addToCopy(2922789);
        try {
            org.joda.time.MonthDay monthDay16 = property3.setCopy("0010-06-19");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"0010-06-19\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June" + "'", str5.equals("June"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June" + "'", str11.equals("June"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(monthDay14);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant6 = null;
        long long7 = property5.getDifferenceAsLong(readableInstant6);
        int int8 = property5.getMaximumValueOverall();
        org.joda.time.DateTime dateTime9 = property5.withMaximumValue();
        org.joda.time.DurationField durationField10 = property5.getDurationField();
        long long13 = durationField10.subtract((long) (byte) 10, (-1L));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2922789 + "'", int8 == 2922789);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3155760000010L + "'", long13 == 3155760000010L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) 'a');
        try {
            java.lang.String str7 = dateTime5.toString("December");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: c");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getShortName((long) 0, locale18);
        java.lang.String str20 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology14, dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.MonthDay monthDay24 = monthDay22.plusMonths(82919);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay24, (int) (byte) -1, locale26);
        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay30 = monthDay28.plus(readablePeriod29);
        org.joda.time.MonthDay.Property property31 = monthDay28.monthOfYear();
        org.joda.time.MonthDay monthDay32 = property31.getMonthDay();
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.MonthDay monthDay35 = monthDay33.plus(readablePeriod34);
        org.joda.time.MonthDay.Property property36 = monthDay33.monthOfYear();
        java.util.Locale locale37 = null;
        java.lang.String str38 = property36.getAsText(locale37);
        org.joda.time.MonthDay monthDay40 = property36.setCopy((int) (byte) 10);
        java.util.Locale locale41 = null;
        int int42 = property36.getMaximumTextLength(locale41);
        java.util.Locale locale43 = null;
        java.lang.String str44 = property36.getAsText(locale43);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property36.getFieldType();
        org.joda.time.MonthDay.Property property46 = monthDay32.property(dateTimeFieldType45);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType45, (int) (byte) 1);
        org.joda.time.MonthDay monthDay49 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod50 = null;
        org.joda.time.MonthDay monthDay51 = monthDay49.plus(readablePeriod50);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = monthDay49.getFieldType(0);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField54 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField48, dateTimeFieldType53);
        long long57 = offsetDateTimeField48.add((long) '#', (long) 60);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-00:00:00.001" + "'", str20.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-1" + "'", str27.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June" + "'", str38.equals("June"));
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June" + "'", str44.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(monthDay51);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 60035L + "'", long57 == 60035L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.Chronology chronology4 = gJChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.centuryOfEra();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay monthDay4 = monthDay0.minusDays(1);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay7 = monthDay5.plus(readablePeriod6);
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        java.util.Locale locale9 = null;
        java.lang.String str10 = property8.getAsText(locale9);
        org.joda.time.MonthDay monthDay12 = property8.addToCopy((int) (short) 10);
        boolean boolean13 = monthDay4.isAfter((org.joda.time.ReadablePartial) monthDay12);
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology15);
        org.joda.time.DurationField durationField17 = gJChronology15.hours();
        try {
            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((java.lang.Object) monthDay4, (org.joda.time.Chronology) gJChronology15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.MonthDay");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June" + "'", str10.equals("June"));
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getShortName((long) 0, locale18);
        java.lang.String str20 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology14, dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.MonthDay monthDay24 = monthDay22.plusMonths(82919);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay24, (int) (byte) -1, locale26);
        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay30 = monthDay28.plus(readablePeriod29);
        org.joda.time.MonthDay.Property property31 = monthDay28.monthOfYear();
        org.joda.time.MonthDay monthDay32 = property31.getMonthDay();
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.MonthDay monthDay35 = monthDay33.plus(readablePeriod34);
        org.joda.time.MonthDay.Property property36 = monthDay33.monthOfYear();
        java.util.Locale locale37 = null;
        java.lang.String str38 = property36.getAsText(locale37);
        org.joda.time.MonthDay monthDay40 = property36.setCopy((int) (byte) 10);
        java.util.Locale locale41 = null;
        int int42 = property36.getMaximumTextLength(locale41);
        java.util.Locale locale43 = null;
        java.lang.String str44 = property36.getAsText(locale43);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property36.getFieldType();
        org.joda.time.MonthDay.Property property46 = monthDay32.property(dateTimeFieldType45);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType45, (int) (byte) 1);
        org.joda.time.MonthDay monthDay49 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod50 = null;
        org.joda.time.MonthDay monthDay51 = monthDay49.plus(readablePeriod50);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = monthDay49.getFieldType(0);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField54 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField48, dateTimeFieldType53);
        org.joda.time.MonthDay monthDay55 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod56 = null;
        org.joda.time.MonthDay monthDay57 = monthDay55.plus(readablePeriod56);
        org.joda.time.MonthDay monthDay59 = monthDay55.plusDays(0);
        org.joda.time.MonthDay monthDay60 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod61 = null;
        org.joda.time.MonthDay monthDay62 = monthDay60.plus(readablePeriod61);
        org.joda.time.MonthDay.Property property63 = monthDay60.monthOfYear();
        boolean boolean64 = monthDay55.isBefore((org.joda.time.ReadablePartial) monthDay60);
        org.joda.time.chrono.GJChronology gJChronology67 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay68 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology67);
        org.joda.time.DateTimeZone dateTimeZone69 = gJChronology67.getZone();
        org.joda.time.DateTimeField dateTimeField70 = gJChronology67.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology72 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay73 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology72);
        org.joda.time.DateTimeZone dateTimeZone74 = gJChronology72.getZone();
        org.joda.time.DateTimeField dateTimeField75 = gJChronology72.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField77 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology67, dateTimeField75, (int) ' ');
        int int79 = skipDateTimeField77.getMaximumValue((long) 0);
        org.joda.time.MonthDay monthDay80 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod81 = null;
        org.joda.time.MonthDay monthDay82 = monthDay80.plus(readablePeriod81);
        org.joda.time.MonthDay.Property property83 = monthDay80.monthOfYear();
        int[] intArray90 = new int[] { 66, 20, 10, 'a', 75662, 75666 };
        int int91 = skipDateTimeField77.getMinimumValue((org.joda.time.ReadablePartial) monthDay80, intArray90);
        try {
            int[] intArray93 = offsetDateTimeField48.add((org.joda.time.ReadablePartial) monthDay60, 75671436, intArray90, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 75671436");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-00:00:00.001" + "'", str20.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-1" + "'", str27.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June" + "'", str38.equals("June"));
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June" + "'", str44.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(monthDay51);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertNotNull(monthDay55);
        org.junit.Assert.assertNotNull(monthDay57);
        org.junit.Assert.assertNotNull(monthDay59);
        org.junit.Assert.assertNotNull(monthDay60);
        org.junit.Assert.assertNotNull(monthDay62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(gJChronology67);
        org.junit.Assert.assertNotNull(dateTimeZone69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(gJChronology72);
        org.junit.Assert.assertNotNull(dateTimeZone74);
        org.junit.Assert.assertNotNull(dateTimeField75);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 59 + "'", int79 == 59);
        org.junit.Assert.assertNotNull(monthDay80);
        org.junit.Assert.assertNotNull(monthDay82);
        org.junit.Assert.assertNotNull(property83);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "", (int) (short) 100, (int) (short) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField11);
        int int14 = skipUndoDateTimeField12.getMaximumValue((long) (byte) 10);
        java.lang.String str16 = skipUndoDateTimeField12.getAsText((long) 'a');
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.MonthDay monthDay19 = monthDay17.plus(readablePeriod18);
        org.joda.time.MonthDay.Property property20 = monthDay17.monthOfYear();
        org.joda.time.MonthDay monthDay21 = property20.getMonthDay();
        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.MonthDay monthDay24 = monthDay22.plus(readablePeriod23);
        org.joda.time.MonthDay.Property property25 = monthDay22.monthOfYear();
        java.util.Locale locale26 = null;
        java.lang.String str27 = property25.getAsText(locale26);
        org.joda.time.MonthDay monthDay29 = property25.setCopy((int) (byte) 10);
        java.util.Locale locale30 = null;
        int int31 = property25.getMaximumTextLength(locale30);
        java.util.Locale locale32 = null;
        java.lang.String str33 = property25.getAsText(locale32);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property25.getFieldType();
        org.joda.time.MonthDay.Property property35 = monthDay21.property(dateTimeFieldType34);
        int[] intArray38 = new int[] { (byte) 1 };
        try {
            int[] intArray40 = skipUndoDateTimeField12.set((org.joda.time.ReadablePartial) monthDay21, 25, intArray38, 75714);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str6.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "June" + "'", str27.equals("June"));
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 9 + "'", int31 == 9);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June" + "'", str33.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(intArray38);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        org.joda.time.MonthDay monthDay7 = property3.setCopy((int) (byte) 10);
        java.util.Locale locale8 = null;
        int int9 = property3.getMaximumTextLength(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property3.getAsText(locale10);
        int int12 = property3.getMinimumValueOverall();
        org.joda.time.MonthDay monthDay14 = property3.addToCopy(2922789);
        java.lang.String str15 = property3.getName();
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June" + "'", str5.equals("June"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June" + "'", str11.equals("June"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "monthOfYear" + "'", str15.equals("monthOfYear"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        org.joda.time.MonthDay monthDay7 = property3.setCopy((int) (byte) 10);
        java.util.Locale locale8 = null;
        int int9 = property3.getMaximumTextLength(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property3.getAsText(locale10);
        int int12 = property3.getMinimumValueOverall();
        java.lang.String str13 = property3.getName();
        org.joda.time.DateTimeField dateTimeField14 = property3.getField();
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June" + "'", str5.equals("June"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June" + "'", str11.equals("June"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "monthOfYear" + "'", str13.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("-00:00:00.001");
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) 'a');
//        int int6 = dateTime3.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime3.plus(readablePeriod7);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime11 = dateTime3.withPeriodAdded(readablePeriod9, (int) 'a');
//        org.joda.time.DateTime.Property property12 = dateTime3.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        org.joda.time.DateTime dateTime16 = dateTime14.withMinuteOfHour((int) (byte) 1);
//        boolean boolean17 = dateTime16.isEqualNow();
//        org.joda.time.DateTime.Property property18 = dateTime16.centuryOfEra();
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        long long20 = property18.getDifferenceAsLong(readableInstant19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property18.getFieldType();
//        boolean boolean22 = dateTime3.isSupported(dateTimeFieldType21);
//        org.joda.time.DateTime dateTime24 = dateTime3.plusMillis(58);
//        java.lang.String str25 = dateTime3.toString();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019-06-15T21:01:27.003-00:00:00.001" + "'", str25.equals("2019-06-15T21:01:27.003-00:00:00.001"));
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay0.getFieldType(0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.hours();
        org.joda.time.DurationField durationField9 = gJChronology6.millis();
        java.lang.Object obj10 = null;
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField9, obj10);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField12 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField9);
        java.util.Locale locale15 = null;
        try {
            long long16 = unsupportedDateTimeField12.set((long) (short) 100, "0.0", locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField12);
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime.Property property4 = dateTime3.era();
//        org.joda.time.DateTime dateTime6 = dateTime3.withSecondOfMinute(0);
//        org.joda.time.DateTime dateTime8 = dateTime3.plus(32L);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        org.joda.time.DateTime dateTime12 = dateTime10.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime14 = dateTime12.plusHours((int) 'a');
//        int int15 = dateTime12.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime12.plus(readablePeriod16);
//        int int18 = dateTime17.getSecondOfDay();
//        org.joda.time.DateTime dateTime20 = dateTime17.withCenturyOfEra((int) (short) 10);
//        org.joda.time.DateTime dateTime22 = dateTime20.plusMillis(3);
//        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime8, (org.joda.time.ReadableInstant) dateTime20);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 75687 + "'", int18 == 75687);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(chronology23);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay monthDay4 = monthDay0.plusDays(0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.Chronology chronology8 = monthDay7.getChronology();
        org.joda.time.MonthDay monthDay10 = monthDay7.minusMonths(3);
        boolean boolean11 = monthDay4.isEqual((org.joda.time.ReadablePartial) monthDay7);
        org.joda.time.MonthDay.Property property12 = monthDay7.dayOfMonth();
        int int13 = property12.get();
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 100, false, (long) 'a');
        try {
            org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 101L + "'", long5 == 101L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getShortName((long) 0, locale18);
        java.lang.String str20 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology14, dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.MonthDay monthDay24 = monthDay22.plusMonths(82919);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay24, (int) (byte) -1, locale26);
        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay30 = monthDay28.plus(readablePeriod29);
        org.joda.time.MonthDay.Property property31 = monthDay28.monthOfYear();
        org.joda.time.MonthDay monthDay32 = property31.getMonthDay();
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.MonthDay monthDay35 = monthDay33.plus(readablePeriod34);
        org.joda.time.MonthDay.Property property36 = monthDay33.monthOfYear();
        java.util.Locale locale37 = null;
        java.lang.String str38 = property36.getAsText(locale37);
        org.joda.time.MonthDay monthDay40 = property36.setCopy((int) (byte) 10);
        java.util.Locale locale41 = null;
        int int42 = property36.getMaximumTextLength(locale41);
        java.util.Locale locale43 = null;
        java.lang.String str44 = property36.getAsText(locale43);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property36.getFieldType();
        org.joda.time.MonthDay.Property property46 = monthDay32.property(dateTimeFieldType45);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType45, (int) (byte) 1);
        long long51 = offsetDateTimeField48.add((long) 4, 59);
        long long54 = offsetDateTimeField48.add(0L, (long) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = offsetDateTimeField48.getType();
        int int57 = offsetDateTimeField48.getMinimumValue((long) (short) -1);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-00:00:00.001" + "'", str20.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-1" + "'", str27.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June" + "'", str38.equals("June"));
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June" + "'", str44.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 59004L + "'", long51 == 59004L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-1000L) + "'", long54 == (-1000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withWeekOfWeekyear((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) 'a');
//        int int10 = dateTime7.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime7.plus(readablePeriod11);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime7.withPeriodAdded(readablePeriod13, (int) 'a');
//        boolean boolean16 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.MonthDay monthDay19 = monthDay17.plus(readablePeriod18);
//        org.joda.time.MonthDay monthDay21 = monthDay17.minusDays(1);
//        int int22 = monthDay17.getDayOfMonth();
//        org.joda.time.DateTime dateTime23 = dateTime7.withFields((org.joda.time.ReadablePartial) monthDay17);
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = dateTimeZone26.getShortName((long) 0, locale28);
//        java.lang.String str30 = dateTimeZone26.getID();
//        org.joda.time.chrono.ZonedChronology zonedChronology31 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology24, dateTimeZone26);
//        org.joda.time.MutableDateTime mutableDateTime32 = dateTime7.toMutableDateTime(dateTimeZone26);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(monthDay17);
//        org.junit.Assert.assertNotNull(monthDay19);
//        org.junit.Assert.assertNotNull(monthDay21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 15 + "'", int22 == 15);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "-00:00:00.001" + "'", str29.equals("-00:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "-00:00:00.001" + "'", str30.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(zonedChronology31);
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay0.getFieldType(0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.hours();
        org.joda.time.DurationField durationField9 = gJChronology6.millis();
        java.lang.Object obj10 = null;
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField9, obj10);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField12 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField9);
        java.util.Locale locale15 = null;
        try {
            long long16 = unsupportedDateTimeField12.set(32L, "1970-01-01T00:01", locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField12);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendYear((int) '4', 7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeParser dateTimeParser8 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendOptional(dateTimeParser8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 'a', dateTimeZone1);
        int int3 = dateTime2.getWeekOfWeekyear();
        boolean boolean4 = dateTime2.isAfterNow();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
//        boolean boolean2 = dateTimeFormatter0.isParser();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) 'a');
//        org.joda.time.DateTime dateTime10 = dateTime6.withMillisOfSecond((int) (byte) 100);
//        java.lang.String str11 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withOffsetParsed();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019-06-15T21:01" + "'", str11.equals("2019-06-15T21:01"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(75714, (-292275054));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: -292275054");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "", (int) (short) 100, (int) (short) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField11);
        long long14 = skipUndoDateTimeField12.roundFloor(32L);
        org.joda.time.MonthDay monthDay15 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.MonthDay monthDay17 = monthDay15.plus(readablePeriod16);
        org.joda.time.MonthDay monthDay19 = monthDay15.plusDays(0);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology21);
        org.joda.time.Chronology chronology23 = monthDay22.getChronology();
        org.joda.time.MonthDay monthDay25 = monthDay22.minusMonths(3);
        boolean boolean26 = monthDay19.isEqual((org.joda.time.ReadablePartial) monthDay22);
        int[] intArray32 = new int[] { 60, 75671436, 59, 15 };
        try {
            int[] intArray34 = skipUndoDateTimeField12.add((org.joda.time.ReadablePartial) monthDay19, (int) (short) 100, intArray32, 24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 60 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str6.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(intArray32);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withWeekOfWeekyear((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) 'a');
//        int int10 = dateTime7.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime7.plus(readablePeriod11);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime7.withPeriodAdded(readablePeriod13, (int) 'a');
//        boolean boolean16 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime18 = dateTime7.minus(0L);
//        try {
//            org.joda.time.DateTime dateTime23 = dateTime7.withTime(2922789, 3, 12, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2922789 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getShortName((long) 0, locale18);
        java.lang.String str20 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology14, dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.MonthDay monthDay24 = monthDay22.plusMonths(82919);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay24, (int) (byte) -1, locale26);
        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay30 = monthDay28.plus(readablePeriod29);
        org.joda.time.MonthDay.Property property31 = monthDay28.monthOfYear();
        org.joda.time.MonthDay monthDay32 = property31.getMonthDay();
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.MonthDay monthDay35 = monthDay33.plus(readablePeriod34);
        org.joda.time.MonthDay.Property property36 = monthDay33.monthOfYear();
        java.util.Locale locale37 = null;
        java.lang.String str38 = property36.getAsText(locale37);
        org.joda.time.MonthDay monthDay40 = property36.setCopy((int) (byte) 10);
        java.util.Locale locale41 = null;
        int int42 = property36.getMaximumTextLength(locale41);
        java.util.Locale locale43 = null;
        java.lang.String str44 = property36.getAsText(locale43);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property36.getFieldType();
        org.joda.time.MonthDay.Property property46 = monthDay32.property(dateTimeFieldType45);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType45, (int) (byte) 1);
        long long51 = offsetDateTimeField48.add((long) 4, 59);
        long long53 = offsetDateTimeField48.remainder((long) 75666);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-00:00:00.001" + "'", str20.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-1" + "'", str27.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June" + "'", str38.equals("June"));
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June" + "'", str44.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 59004L + "'", long51 == 59004L);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 666L + "'", long53 == 666L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = gJChronology1.add(readablePeriod5, (long) 3, 2);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3L + "'", long8 == 3L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology2, dateTimeZone4);
        org.joda.time.Chronology chronology6 = zonedChronology5.withUTC();
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.MonthDay monthDay9 = monthDay7.plus(readablePeriod8);
        org.joda.time.MonthDay monthDay11 = monthDay7.plusDays(0);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology13);
        org.joda.time.Chronology chronology15 = monthDay14.getChronology();
        org.joda.time.MonthDay monthDay17 = monthDay14.minusMonths(3);
        boolean boolean18 = monthDay11.isEqual((org.joda.time.ReadablePartial) monthDay14);
        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.MonthDay monthDay21 = monthDay19.plus(readablePeriod20);
        org.joda.time.MonthDay monthDay23 = monthDay19.minusDays(1);
        boolean boolean24 = monthDay11.isBefore((org.joda.time.ReadablePartial) monthDay23);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay27 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology26);
        org.joda.time.DateTimeZone dateTimeZone28 = gJChronology26.getZone();
        org.joda.time.DateTimeField dateTimeField29 = gJChronology26.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology31);
        org.joda.time.DateTimeZone dateTimeZone33 = gJChronology31.getZone();
        org.joda.time.DateTimeField dateTimeField34 = gJChronology31.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology26, dateTimeField34, (int) ' ');
        int int38 = skipDateTimeField36.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeUtils.getZone(dateTimeZone40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = dateTimeZone41.getShortName((long) 0, locale43);
        java.lang.String str45 = dateTimeZone41.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology46 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology39, dateTimeZone41);
        org.joda.time.MonthDay monthDay47 = new org.joda.time.MonthDay(dateTimeZone41);
        org.joda.time.MonthDay monthDay49 = monthDay47.plusMonths(82919);
        java.util.Locale locale51 = null;
        java.lang.String str52 = skipDateTimeField36.getAsShortText((org.joda.time.ReadablePartial) monthDay49, (int) (byte) -1, locale51);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = skipDateTimeField36.getType();
        boolean boolean54 = monthDay11.isSupported(dateTimeFieldType53);
        int[] intArray56 = zonedChronology5.get((org.joda.time.ReadablePartial) monthDay11, 1000L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 59 + "'", int38 == 59);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "-00:00:00.001" + "'", str44.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "-00:00:00.001" + "'", str45.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology46);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "-1" + "'", str52.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(intArray56);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.millisOfSecond();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
//        boolean boolean4 = dateTime3.isEqualNow();
//        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
//        org.joda.time.ReadableInstant readableInstant6 = null;
//        long long7 = property5.getDifferenceAsLong(readableInstant6);
//        int int8 = property5.getMaximumValueOverall();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        org.joda.time.DateTime dateTime12 = dateTime10.withWeekOfWeekyear((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        org.joda.time.DateTime dateTime16 = dateTime14.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime18 = dateTime16.plusHours((int) 'a');
//        int int19 = dateTime16.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime16.plus(readablePeriod20);
//        org.joda.time.ReadablePeriod readablePeriod22 = null;
//        org.joda.time.DateTime dateTime24 = dateTime16.withPeriodAdded(readablePeriod22, (int) 'a');
//        boolean boolean25 = dateTime10.isBefore((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime dateTime27 = dateTime16.minus(0L);
//        int int28 = property5.getDifference((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime dateTime30 = dateTime16.minusMillis(1969);
//        boolean boolean32 = dateTime16.isAfter((long) 29);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2922789 + "'", int8 == 2922789);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 24 + "'", int19 == 24);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMonthOfYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.Chronology chronology3 = monthDay2.getChronology();
        org.joda.time.Chronology chronology4 = monthDay2.getChronology();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(chronology4);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
//        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property3.getAsText(locale4);
//        org.joda.time.MonthDay monthDay7 = property3.addWrapFieldToCopy((int) ' ');
//        java.lang.String str8 = monthDay7.toString();
//        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        org.joda.time.MonthDay monthDay11 = monthDay9.plus(readablePeriod10);
//        org.joda.time.MonthDay.Property property12 = monthDay9.monthOfYear();
//        org.joda.time.MonthDay monthDay13 = property12.getMonthDay();
//        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.MonthDay monthDay16 = monthDay14.plus(readablePeriod15);
//        org.joda.time.MonthDay.Property property17 = monthDay14.monthOfYear();
//        java.util.Locale locale18 = null;
//        java.lang.String str19 = property17.getAsText(locale18);
//        org.joda.time.MonthDay monthDay21 = property17.addWrapFieldToCopy((int) ' ');
//        java.lang.String str22 = monthDay21.toString();
//        int int23 = monthDay13.compareTo((org.joda.time.ReadablePartial) monthDay21);
//        org.joda.time.DateTimeField[] dateTimeFieldArray24 = monthDay13.getFields();
//        int int25 = monthDay7.compareTo((org.joda.time.ReadablePartial) monthDay13);
//        org.junit.Assert.assertNotNull(monthDay0);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June" + "'", str5.equals("June"));
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "--02-15" + "'", str8.equals("--02-15"));
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertNotNull(monthDay14);
//        org.junit.Assert.assertNotNull(monthDay16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June" + "'", str19.equals("June"));
//        org.junit.Assert.assertNotNull(monthDay21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "--02-15" + "'", str22.equals("--02-15"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test281");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
//        java.io.Writer writer2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withWeekOfWeekyear((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
//        org.joda.time.DateTime dateTime10 = dateTime8.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime12 = dateTime10.plusHours((int) 'a');
//        int int13 = dateTime10.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime10.plus(readablePeriod14);
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime18 = dateTime10.withPeriodAdded(readablePeriod16, (int) 'a');
//        boolean boolean19 = dateTime4.isBefore((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.MonthDay monthDay22 = monthDay20.plus(readablePeriod21);
//        org.joda.time.MonthDay monthDay24 = monthDay20.minusDays(1);
//        int int25 = monthDay20.getDayOfMonth();
//        org.joda.time.DateTime dateTime26 = dateTime10.withFields((org.joda.time.ReadablePartial) monthDay20);
//        try {
//            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadableInstant) dateTime10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(monthDay24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
//        org.junit.Assert.assertNotNull(dateTime26);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay0.getFieldType(0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.hours();
        org.joda.time.DurationField durationField9 = gJChronology6.millis();
        java.lang.Object obj10 = null;
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField9, obj10);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField12 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField9);
        boolean boolean13 = unsupportedDateTimeField12.isLenient();
        try {
            int int14 = unsupportedDateTimeField12.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        try {
            long long8 = copticChronology0.getDateTimeMillis(75662, 75706, (int) (byte) 1, (int) (short) 0, 75693, 4, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 75693 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone2.getShortName((long) 0, locale4);
        java.lang.String str6 = dateTimeZone2.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone2);
        org.joda.time.Instant instant8 = gJChronology0.getGregorianCutover();
        long long9 = instant8.getMillis();
        org.joda.time.DateTime dateTime10 = instant8.toDateTimeISO();
        int int11 = dateTime10.getYear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-00:00:00.001" + "'", str5.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.001" + "'", str6.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-12219292800000L) + "'", long9 == (-12219292800000L));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1582 + "'", int11 == 1582);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        int int0 = org.joda.time.MonthDay.MONTH_OF_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '4');
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "", (int) (short) 100, (int) (short) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.lang.String str7 = gregorianChronology6.toString();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology9);
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology9.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField12);
        boolean boolean14 = copticChronology0.equals((java.lang.Object) dateTimeField12);
        org.joda.time.DateTimeZone dateTimeZone15 = copticChronology0.getZone();
        org.joda.time.Chronology chronology16 = copticChronology0.withUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str7.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendWeekyear(24, 3);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology10);
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology10.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology15);
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology15.getZone();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology15.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField18, (int) ' ');
        int int22 = skipDateTimeField20.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
        java.util.Locale locale27 = null;
        java.lang.String str28 = dateTimeZone25.getShortName((long) 0, locale27);
        java.lang.String str29 = dateTimeZone25.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology30 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology23, dateTimeZone25);
        org.joda.time.MonthDay monthDay31 = new org.joda.time.MonthDay(dateTimeZone25);
        org.joda.time.MonthDay monthDay33 = monthDay31.plusMonths(82919);
        java.util.Locale locale35 = null;
        java.lang.String str36 = skipDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) monthDay33, (int) (byte) -1, locale35);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = skipDateTimeField20.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder3.appendShortText(dateTimeFieldType37);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder38.appendFractionOfDay(0, 69);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 59 + "'", int22 == 59);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-00:00:00.001" + "'", str28.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "-00:00:00.001" + "'", str29.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology30);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "-1" + "'", str36.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay4 = monthDay2.plus(readablePeriod3);
        org.joda.time.MonthDay monthDay6 = monthDay2.minusDays(1);
        try {
            java.lang.String str7 = dateTimeFormatter1.print((org.joda.time.ReadablePartial) monthDay2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay6);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay4 = monthDay2.plus(readablePeriod3);
        org.joda.time.MonthDay.Property property5 = monthDay2.monthOfYear();
        int[] intArray11 = new int[] { 75661, 20, 25, (byte) 10, '#' };
        try {
            gJChronology0.validate((org.joda.time.ReadablePartial) monthDay2, intArray11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 75661 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(intArray11);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withWeekOfWeekyear((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
//        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) 'a');
//        int int10 = dateTime7.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime7.plus(readablePeriod11);
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime7.withPeriodAdded(readablePeriod13, (int) 'a');
//        boolean boolean16 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime18 = dateTime1.minusMonths(10);
//        int int19 = dateTime1.getWeekyear();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getShortName((long) 0, locale18);
        java.lang.String str20 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology14, dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.MonthDay monthDay24 = monthDay22.plusMonths(82919);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay24, (int) (byte) -1, locale26);
        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay30 = monthDay28.plus(readablePeriod29);
        org.joda.time.MonthDay.Property property31 = monthDay28.monthOfYear();
        org.joda.time.MonthDay monthDay32 = property31.getMonthDay();
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.MonthDay monthDay35 = monthDay33.plus(readablePeriod34);
        org.joda.time.MonthDay.Property property36 = monthDay33.monthOfYear();
        java.util.Locale locale37 = null;
        java.lang.String str38 = property36.getAsText(locale37);
        org.joda.time.MonthDay monthDay40 = property36.setCopy((int) (byte) 10);
        java.util.Locale locale41 = null;
        int int42 = property36.getMaximumTextLength(locale41);
        java.util.Locale locale43 = null;
        java.lang.String str44 = property36.getAsText(locale43);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property36.getFieldType();
        org.joda.time.MonthDay.Property property46 = monthDay32.property(dateTimeFieldType45);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType45, (int) (byte) 1);
        org.joda.time.MonthDay monthDay49 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod50 = null;
        org.joda.time.MonthDay monthDay51 = monthDay49.plus(readablePeriod50);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = monthDay49.getFieldType(0);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField54 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField48, dateTimeFieldType53);
        int int55 = delegatedDateTimeField54.getMinimumValue();
        java.util.Locale locale56 = null;
        int int57 = delegatedDateTimeField54.getMaximumTextLength(locale56);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-00:00:00.001" + "'", str20.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-1" + "'", str27.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June" + "'", str38.equals("June"));
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June" + "'", str44.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(monthDay51);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2 + "'", int57 == 2);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (byte) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.append(dateTimeFormatter4);
        try {
            long long7 = dateTimeFormatter4.parseMillis("Property[centuryOfEra]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[centuryOfEra]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay monthDay4 = monthDay0.plusDays(0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.Chronology chronology8 = monthDay7.getChronology();
        org.joda.time.MonthDay monthDay10 = monthDay7.minusMonths(3);
        boolean boolean11 = monthDay4.isEqual((org.joda.time.ReadablePartial) monthDay7);
        org.joda.time.MonthDay.Property property12 = monthDay7.dayOfMonth();
        java.util.Locale locale14 = null;
        try {
            java.lang.String str15 = monthDay7.toString("AD", locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: A");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant6 = null;
        long long7 = property5.getDifferenceAsLong(readableInstant6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property5.getFieldType();
        org.joda.time.DateTime dateTime10 = property5.addToCopy((long) 1969);
        org.joda.time.DateTime dateTime11 = property5.roundHalfCeilingCopy();
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.year();
        org.joda.time.MutableDateTime mutableDateTime14 = dateTime11.toMutableDateTime((org.joda.time.Chronology) gJChronology12);
        org.joda.time.DateMidnight dateMidnight15 = dateTime11.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(dateMidnight15);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
        long long16 = skipDateTimeField11.getDifferenceAsLong(1560633160155L, (long) 3480);
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.MonthDay monthDay19 = monthDay17.plus(readablePeriod18);
        org.joda.time.MonthDay monthDay21 = monthDay17.plusDays(0);
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology23);
        org.joda.time.Chronology chronology25 = monthDay24.getChronology();
        org.joda.time.MonthDay monthDay27 = monthDay24.minusMonths(3);
        boolean boolean28 = monthDay21.isEqual((org.joda.time.ReadablePartial) monthDay24);
        org.joda.time.MonthDay monthDay29 = org.joda.time.MonthDay.now();
        boolean boolean30 = monthDay24.isEqual((org.joda.time.ReadablePartial) monthDay29);
        int[] intArray32 = null;
        try {
            int[] intArray34 = skipDateTimeField11.set((org.joda.time.ReadablePartial) monthDay24, 87, intArray32, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560633156L + "'", long16 == 1560633156L);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        try {
            org.joda.time.DateTime dateTime7 = dateTime3.withEra(75671436);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 75671436 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField3 = gJChronology1.hours();
        org.joda.time.DurationField durationField4 = gJChronology1.millis();
        org.joda.time.DurationField durationField5 = gJChronology1.years();
        org.joda.time.DurationField durationField6 = gJChronology1.halfdays();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay0.getFieldType(0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.hours();
        org.joda.time.DurationField durationField9 = gJChronology6.millis();
        java.lang.Object obj10 = null;
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField9, obj10);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField12 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField9);
        try {
            long long14 = unsupportedDateTimeField12.roundFloor(3L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField12);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getShortName((long) 0, locale18);
        java.lang.String str20 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology14, dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.MonthDay monthDay24 = monthDay22.plusMonths(82919);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay24, (int) (byte) -1, locale26);
        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay30 = monthDay28.plus(readablePeriod29);
        org.joda.time.MonthDay.Property property31 = monthDay28.monthOfYear();
        org.joda.time.MonthDay monthDay32 = property31.getMonthDay();
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.MonthDay monthDay35 = monthDay33.plus(readablePeriod34);
        org.joda.time.MonthDay.Property property36 = monthDay33.monthOfYear();
        java.util.Locale locale37 = null;
        java.lang.String str38 = property36.getAsText(locale37);
        org.joda.time.MonthDay monthDay40 = property36.setCopy((int) (byte) 10);
        java.util.Locale locale41 = null;
        int int42 = property36.getMaximumTextLength(locale41);
        java.util.Locale locale43 = null;
        java.lang.String str44 = property36.getAsText(locale43);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property36.getFieldType();
        org.joda.time.MonthDay.Property property46 = monthDay32.property(dateTimeFieldType45);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType45, (int) (byte) 1);
        org.joda.time.MonthDay monthDay49 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod50 = null;
        org.joda.time.MonthDay monthDay51 = monthDay49.plus(readablePeriod50);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = monthDay49.getFieldType(0);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField54 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField48, dateTimeFieldType53);
        org.joda.time.IllegalFieldValueException illegalFieldValueException58 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, (java.lang.Number) 31100L, (java.lang.Number) 6, (java.lang.Number) 75715L);
        org.joda.time.chrono.GJChronology gJChronology60 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay61 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology60);
        org.joda.time.DurationField durationField62 = gJChronology60.hours();
        org.joda.time.DurationField durationField63 = gJChronology60.millis();
        org.joda.time.DurationField durationField64 = gJChronology60.hours();
        long long67 = durationField64.subtract(1L, (int) (short) -1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField68 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType53, durationField64);
        org.joda.time.MonthDay monthDay69 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod70 = null;
        org.joda.time.MonthDay monthDay71 = monthDay69.plus(readablePeriod70);
        try {
            int int72 = unsupportedDateTimeField68.getMinimumValue((org.joda.time.ReadablePartial) monthDay69);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-00:00:00.001" + "'", str20.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-1" + "'", str27.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June" + "'", str38.equals("June"));
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June" + "'", str44.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(monthDay51);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertNotNull(gJChronology60);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(durationField63);
        org.junit.Assert.assertNotNull(durationField64);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 3600001L + "'", long67 == 3600001L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField68);
        org.junit.Assert.assertNotNull(monthDay69);
        org.junit.Assert.assertNotNull(monthDay71);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology3.getZone();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology3.secondOfMinute();
        try {
            org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(15, 15, (org.joda.time.Chronology) gJChronology3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 15 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (-75), (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 22L + "'", long2 == 22L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("T210124.112-0000");
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (byte) 0);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology5);
        org.joda.time.DateTimeZone dateTimeZone7 = gJChronology5.getZone();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology5.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology10);
        org.joda.time.DateTimeZone dateTimeZone12 = gJChronology10.getZone();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology10.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology5, dateTimeField13, (int) ' ');
        int int17 = skipDateTimeField15.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
        java.util.Locale locale22 = null;
        java.lang.String str23 = dateTimeZone20.getShortName((long) 0, locale22);
        java.lang.String str24 = dateTimeZone20.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology18, dateTimeZone20);
        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay(dateTimeZone20);
        org.joda.time.MonthDay monthDay28 = monthDay26.plusMonths(82919);
        java.util.Locale locale30 = null;
        java.lang.String str31 = skipDateTimeField15.getAsShortText((org.joda.time.ReadablePartial) monthDay28, (int) (byte) -1, locale30);
        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.MonthDay monthDay34 = monthDay32.plus(readablePeriod33);
        org.joda.time.MonthDay.Property property35 = monthDay32.monthOfYear();
        org.joda.time.MonthDay monthDay36 = property35.getMonthDay();
        org.joda.time.MonthDay monthDay37 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.MonthDay monthDay39 = monthDay37.plus(readablePeriod38);
        org.joda.time.MonthDay.Property property40 = monthDay37.monthOfYear();
        java.util.Locale locale41 = null;
        java.lang.String str42 = property40.getAsText(locale41);
        org.joda.time.MonthDay monthDay44 = property40.setCopy((int) (byte) 10);
        java.util.Locale locale45 = null;
        int int46 = property40.getMaximumTextLength(locale45);
        java.util.Locale locale47 = null;
        java.lang.String str48 = property40.getAsText(locale47);
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = property40.getFieldType();
        org.joda.time.MonthDay.Property property50 = monthDay36.property(dateTimeFieldType49);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField15, dateTimeFieldType49, (int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder1.appendFixedSignedDecimal(dateTimeFieldType49, 59);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder1.appendTimeZoneOffset("", false, 58, (-292275054));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 59 + "'", int17 == 59);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "-00:00:00.001" + "'", str23.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "-00:00:00.001" + "'", str24.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "-1" + "'", str31.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(monthDay36);
        org.junit.Assert.assertNotNull(monthDay37);
        org.junit.Assert.assertNotNull(monthDay39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "June" + "'", str42.equals("June"));
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 9 + "'", int46 == 9);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "June" + "'", str48.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay0.getFieldType(0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.hours();
        org.joda.time.DurationField durationField9 = gJChronology6.millis();
        java.lang.Object obj10 = null;
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField9, obj10);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField12 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField9);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = unsupportedDateTimeField12.getType();
        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.MonthDay monthDay16 = monthDay14.plus(readablePeriod15);
        org.joda.time.MonthDay monthDay18 = monthDay14.plusDays(0);
        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.MonthDay monthDay21 = monthDay19.plus(readablePeriod20);
        org.joda.time.MonthDay.Property property22 = monthDay19.monthOfYear();
        boolean boolean23 = monthDay14.isBefore((org.joda.time.ReadablePartial) monthDay19);
        org.joda.time.DateTimeField[] dateTimeFieldArray24 = monthDay19.getFields();
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay27 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology26);
        boolean boolean28 = monthDay19.isAfter((org.joda.time.ReadablePartial) monthDay27);
        int[] intArray30 = null;
        java.util.Locale locale32 = null;
        try {
            int[] intArray33 = unsupportedDateTimeField12.set((org.joda.time.ReadablePartial) monthDay19, (int) (byte) 0, intArray30, "January", locale32);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldArray24);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 'a', dateTimeZone1);
        java.util.Date date3 = dateTime2.toDate();
        java.lang.String str4 = dateTime2.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970-01-01T00:00:00.096-00:00:00.001" + "'", str4.equals("1970-01-01T00:00:00.096-00:00:00.001"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        boolean boolean5 = dateTime3.equals((java.lang.Object) 1.0f);
        org.joda.time.DateTime.Property property6 = dateTime3.weekyear();
        java.lang.String str7 = property6.getAsString();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField3 = gJChronology1.hours();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour((int) (byte) 1);
        boolean boolean8 = dateTime7.isEqualNow();
        org.joda.time.DateTime.Property property9 = dateTime7.centuryOfEra();
        org.joda.time.DateTime dateTime10 = property9.withMaximumValue();
        org.joda.time.DateTime dateTime12 = dateTime10.plusWeeks((int) (short) 10);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime15 = dateTime10.withDurationAdded(readableDuration13, (int) (short) -1);
        boolean boolean16 = gJChronology1.equals((java.lang.Object) (short) -1);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology1.yearOfCentury();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay0.getFieldType(0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.hours();
        org.joda.time.DurationField durationField9 = gJChronology6.millis();
        java.lang.Object obj10 = null;
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField9, obj10);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField12 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField9);
        try {
            java.lang.String str14 = unsupportedDateTimeField12.getAsText((-12219292800000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField12);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 31100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
        dateTimeFormatterBuilder0.clear();
        boolean boolean4 = dateTimeFormatterBuilder0.canBuildFormatter();
        dateTimeFormatterBuilder0.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        org.joda.time.MonthDay monthDay7 = property3.addToCopy((int) (short) 10);
        int int8 = property3.get();
        org.joda.time.DurationField durationField9 = property3.getRangeDurationField();
        java.lang.String str10 = property3.getAsText();
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June" + "'", str5.equals("June"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June" + "'", str10.equals("June"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        org.joda.time.MonthDay monthDay7 = property3.setCopy((int) (byte) 10);
        java.util.Locale locale8 = null;
        int int9 = property3.getMaximumTextLength(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property3.getAsText(locale10);
        int int12 = property3.getMinimumValueOverall();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone14);
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now(dateTimeZone14);
        boolean boolean17 = property3.equals((java.lang.Object) dateTimeZone14);
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now(dateTimeZone14);
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "", (int) (short) 100, (int) (short) -1);
        java.util.TimeZone timeZone25 = fixedDateTimeZone24.toTimeZone();
        long long28 = fixedDateTimeZone24.convertLocalToUTC((long) 75718, false);
        org.joda.time.Chronology chronology29 = copticChronology19.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        try {
            org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone24, (long) 66, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 9");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June" + "'", str5.equals("June"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June" + "'", str11.equals("June"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 75618L + "'", long28 == 75618L);
        org.junit.Assert.assertNotNull(chronology29);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        long long14 = skipDateTimeField11.add((long) '4', (int) (short) 1);
        boolean boolean15 = skipDateTimeField11.isSupported();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = skipDateTimeField11.getType();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1052L + "'", long14 == 1052L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-75L), (java.lang.Number) 4, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
        try {
            org.joda.time.DateTimeField dateTimeField2 = monthDay0.getField((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 10");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology2, dateTimeZone4);
        java.lang.String str6 = zonedChronology5.toString();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology8.getZone();
        org.joda.time.Chronology chronology11 = gJChronology8.withUTC();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology8.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) zonedChronology5, dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ZonedChronology[BuddhistChronology[UTC], -00:00:00.001]" + "'", str6.equals("ZonedChronology[BuddhistChronology[UTC], -00:00:00.001]"));
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay0.getFieldType(0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.hours();
        org.joda.time.DurationField durationField9 = gJChronology6.millis();
        java.lang.Object obj10 = null;
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField9, obj10);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField12 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField9);
        org.joda.time.DurationField durationField13 = unsupportedDateTimeField12.getLeapDurationField();
        try {
            long long15 = unsupportedDateTimeField12.roundHalfEven((long) 75714);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField12);
        org.junit.Assert.assertNull(durationField13);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getShortName((long) 0, locale18);
        java.lang.String str20 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology14, dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.MonthDay monthDay24 = monthDay22.plusMonths(82919);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay24, (int) (byte) -1, locale26);
        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay30 = monthDay28.plus(readablePeriod29);
        org.joda.time.MonthDay.Property property31 = monthDay28.monthOfYear();
        org.joda.time.MonthDay monthDay32 = property31.getMonthDay();
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.MonthDay monthDay35 = monthDay33.plus(readablePeriod34);
        org.joda.time.MonthDay.Property property36 = monthDay33.monthOfYear();
        java.util.Locale locale37 = null;
        java.lang.String str38 = property36.getAsText(locale37);
        org.joda.time.MonthDay monthDay40 = property36.setCopy((int) (byte) 10);
        java.util.Locale locale41 = null;
        int int42 = property36.getMaximumTextLength(locale41);
        java.util.Locale locale43 = null;
        java.lang.String str44 = property36.getAsText(locale43);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property36.getFieldType();
        org.joda.time.MonthDay.Property property46 = monthDay32.property(dateTimeFieldType45);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType45, (int) (byte) 1);
        long long51 = offsetDateTimeField48.getDifferenceAsLong((long) (short) 100, 0L);
        int int52 = offsetDateTimeField48.getOffset();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-00:00:00.001" + "'", str20.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-1" + "'", str27.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June" + "'", str38.equals("June"));
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June" + "'", str44.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long3 = durationField0.subtract((long) 0, (int) 'a');
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField5 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-97L) + "'", long3 == (-97L));
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
//        boolean boolean5 = dateTime3.equals((java.lang.Object) 1.0f);
//        int int6 = dateTime3.getCenturyOfEra();
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
//        try {
//            org.joda.time.DateTime dateTime9 = dateTime3.withHourOfDay(69);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 20 + "'", int6 == 20);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560632497473L + "'", long7 == 1560632497473L);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipDateTimeField11.getAsText(52000L, locale15);
        java.lang.String str18 = skipDateTimeField11.getAsShortText(63696229261266L);
        java.util.Locale locale19 = null;
        int int20 = skipDateTimeField11.getMaximumTextLength(locale19);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1" + "'", str18.equals("1"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "3");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 21);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendMillisOfSecond(31);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendShortText(dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
//        boolean boolean2 = dateTimeFormatter0.isParser();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime4.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime8 = dateTime6.plusHours((int) 'a');
//        org.joda.time.DateTime dateTime10 = dateTime6.withMillisOfSecond((int) (byte) 100);
//        java.lang.String str11 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getShortName((long) 0, locale15);
//        java.lang.String str17 = dateTimeZone13.getID();
//        org.joda.time.DateTime dateTime18 = dateTime10.withZoneRetainFields(dateTimeZone13);
//        int int19 = dateTime18.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019-06-15T21:01" + "'", str11.equals("2019-06-15T21:01"));
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-00:00:00.001" + "'", str16.equals("-00:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-00:00:00.001" + "'", str17.equals("-00:00:00.001"));
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 24 + "'", int19 == 24);
//    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "", (int) (short) 100, (int) (short) -1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        java.lang.String str6 = gregorianChronology5.toString();
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology8);
//        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology8.getZone();
//        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.secondOfMinute();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField11);
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        org.joda.time.DateTime dateTime16 = dateTime14.withWeekOfWeekyear((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime18.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime22 = dateTime20.plusHours((int) 'a');
//        int int23 = dateTime20.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime20.plus(readablePeriod24);
//        org.joda.time.ReadablePeriod readablePeriod26 = null;
//        org.joda.time.DateTime dateTime28 = dateTime20.withPeriodAdded(readablePeriod26, (int) 'a');
//        boolean boolean29 = dateTime14.isBefore((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone34 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "", (int) (short) 100, (int) (short) -1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone34);
//        org.joda.time.DateTime dateTime36 = dateTime14.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone34);
//        boolean boolean37 = gregorianChronology5.equals((java.lang.Object) dateTime14);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str6.equals("GregorianChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 24 + "'", int23 == 24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("monthOfYear", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"monthOfYear\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        java.util.Locale locale6 = null;
        java.lang.String str7 = property3.getAsShortText(locale6);
        java.util.Locale locale8 = null;
        int int9 = property3.getMaximumShortTextLength(locale8);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June" + "'", str5.equals("June"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Jun" + "'", str7.equals("Jun"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getShortName((long) 0, locale18);
        java.lang.String str20 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology14, dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.MonthDay monthDay24 = monthDay22.plusMonths(82919);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay24, (int) (byte) -1, locale26);
        java.lang.String str29 = skipDateTimeField11.getAsText(0L);
        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.MonthDay monthDay32 = monthDay30.plus(readablePeriod31);
        java.util.Locale locale34 = null;
        java.lang.String str35 = skipDateTimeField11.getAsText((org.joda.time.ReadablePartial) monthDay30, (int) (byte) 10, locale34);
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale37 = null;
        try {
            java.lang.String str38 = skipDateTimeField11.getAsText(readablePartial36, locale37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-00:00:00.001" + "'", str20.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-1" + "'", str27.equals("-1"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "10" + "'", str35.equals("10"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant6 = null;
        long long7 = property5.getDifferenceAsLong(readableInstant6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        int int9 = property5.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime dateTime11 = dateTime8.plusWeeks((int) 'a');
        org.joda.time.DateTime.Property property12 = dateTime8.year();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(6, 87);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 522 + "'", int2 == 522);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) 'a');
//        int int6 = dateTime3.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime8 = dateTime3.minus(0L);
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        org.joda.time.DateTime dateTime12 = dateTime10.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime14 = dateTime12.plusHours((int) 'a');
//        int int15 = dateTime12.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime12.plus(readablePeriod16);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime20 = dateTime12.withPeriodAdded(readablePeriod18, (int) 'a');
//        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology22);
//        org.joda.time.DurationField durationField24 = gJChronology22.hours();
//        org.joda.time.DurationField durationField25 = gJChronology22.millis();
//        org.joda.time.DateTime dateTime26 = dateTime20.withChronology((org.joda.time.Chronology) gJChronology22);
//        boolean boolean27 = dateTime3.isEqual((org.joda.time.ReadableInstant) dateTime26);
//        org.joda.time.MutableDateTime mutableDateTime28 = dateTime26.toMutableDateTime();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(gJChronology22);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(durationField25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime28);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "", (int) (short) 100, (int) (short) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str6 = gregorianChronology5.toString();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology8.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField11);
        try {
            long long15 = skipUndoDateTimeField12.set(1000L, 75693);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 75693 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[-00:00:00.001]" + "'", str6.equals("GregorianChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getShortName((long) 0, locale18);
        java.lang.String str20 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology14, dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.MonthDay monthDay24 = monthDay22.plusMonths(82919);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay24, (int) (byte) -1, locale26);
        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay30 = monthDay28.plus(readablePeriod29);
        org.joda.time.MonthDay.Property property31 = monthDay28.monthOfYear();
        org.joda.time.MonthDay monthDay32 = property31.getMonthDay();
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.MonthDay monthDay35 = monthDay33.plus(readablePeriod34);
        org.joda.time.MonthDay.Property property36 = monthDay33.monthOfYear();
        java.util.Locale locale37 = null;
        java.lang.String str38 = property36.getAsText(locale37);
        org.joda.time.MonthDay monthDay40 = property36.setCopy((int) (byte) 10);
        java.util.Locale locale41 = null;
        int int42 = property36.getMaximumTextLength(locale41);
        java.util.Locale locale43 = null;
        java.lang.String str44 = property36.getAsText(locale43);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property36.getFieldType();
        org.joda.time.MonthDay.Property property46 = monthDay32.property(dateTimeFieldType45);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType45, (int) (byte) 1);
        java.lang.String str50 = offsetDateTimeField48.getAsText(101L);
        long long53 = offsetDateTimeField48.add(1L, (long) (byte) 10);
        long long56 = offsetDateTimeField48.add(52000L, 31);
        long long58 = offsetDateTimeField48.roundHalfCeiling((long) 75671436);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-00:00:00.001" + "'", str20.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-1" + "'", str27.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June" + "'", str38.equals("June"));
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June" + "'", str44.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "0" + "'", str50.equals("0"));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 10001L + "'", long53 == 10001L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 83000L + "'", long56 == 83000L);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 75671000L + "'", long58 == 75671000L);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        org.joda.time.MonthDay monthDay7 = property3.setCopy((int) (byte) 10);
        java.util.Locale locale8 = null;
        int int9 = property3.getMaximumTextLength(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property3.getAsText(locale10);
        int int12 = property3.getMinimumValueOverall();
        org.joda.time.MonthDay monthDay13 = property3.getMonthDay();
        try {
            int int15 = monthDay13.getValue(25);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 25");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June" + "'", str5.equals("June"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June" + "'", str11.equals("June"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(monthDay13);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("GregorianChronology[-00:00:00.001]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[-00:00:00.001]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("52", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"52/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "", (int) (short) 100, (int) (short) -1);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        long long7 = fixedDateTimeZone4.nextTransition(1560632466320L);
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        long long10 = fixedDateTimeZone4.nextTransition((long) 75671436);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560632466320L + "'", long7 == 1560632466320L);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 75671436L + "'", long10 == 75671436L);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendYear((int) '4', 7);
        boolean boolean7 = dateTimeFormatterBuilder3.canBuildParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("10");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"10\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(75661, 100, 6, (int) (short) 0, 75693, 75687, 75718, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 75693 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology2, dateTimeZone4);
        java.lang.String str6 = buddhistChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = dateTimeZone8.getShortName((long) 0, locale10);
        java.lang.String str12 = dateTimeZone8.getID();
        org.joda.time.LocalDateTime localDateTime13 = null;
        boolean boolean14 = dateTimeZone8.isLocalDateTimeGap(localDateTime13);
        org.joda.time.Chronology chronology15 = buddhistChronology2.withZone(dateTimeZone8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        boolean boolean17 = cachedDateTimeZone16.isFixed();
        boolean boolean19 = cachedDateTimeZone16.equals((java.lang.Object) 100L);
        java.lang.String str21 = cachedDateTimeZone16.getNameKey(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "BuddhistChronology[-00:00:00.001]" + "'", str6.equals("BuddhistChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-00:00:00.001" + "'", str11.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-00:00:00.001" + "'", str12.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(str21);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withWeekOfWeekyear((int) '4');
//        org.joda.time.DateTime.Property property4 = dateTime1.minuteOfHour();
//        long long5 = dateTime1.getMillis();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560633221283L + "'", long5 == 1560633221283L);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.DurationField durationField4 = gJChronology2.hours();
        org.joda.time.DurationField durationField5 = gJChronology2.millis();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology2.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology2.monthOfYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) 'a');
//        int int6 = dateTime3.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime3.plus(readablePeriod7);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime11 = dateTime3.withPeriodAdded(readablePeriod9, (int) 'a');
//        org.joda.time.DateTime.Property property12 = dateTime3.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        org.joda.time.DateTime dateTime16 = dateTime14.withMinuteOfHour((int) (byte) 1);
//        boolean boolean17 = dateTime16.isEqualNow();
//        org.joda.time.DateTime.Property property18 = dateTime16.centuryOfEra();
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        long long20 = property18.getDifferenceAsLong(readableInstant19);
//        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property18.getFieldType();
//        boolean boolean22 = dateTime3.isSupported(dateTimeFieldType21);
//        int int23 = dateTime3.getYearOfEra();
//        try {
//            org.joda.time.DateTime dateTime27 = dateTime3.withDate(109, 75706, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 75706 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology2, dateTimeZone4);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DurationField durationField7 = buddhistChronology2.centuries();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        org.joda.time.MonthDay monthDay7 = property3.setCopy((int) (byte) 10);
        java.util.Locale locale8 = null;
        int int9 = property3.getMaximumTextLength(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property3.getAsText(locale10);
        int int12 = property3.getMinimumValueOverall();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone14);
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now(dateTimeZone14);
        boolean boolean17 = property3.equals((java.lang.Object) dateTimeZone14);
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now(dateTimeZone14);
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone14);
        try {
            long long24 = copticChronology19.getDateTimeMillis(75671, 0, 87, 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June" + "'", str5.equals("June"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "June" + "'", str11.equals("June"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(copticChronology19);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendYear((int) '4', 7);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder3.appendYearOfCentury(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone2.getShortName((long) 0, locale4);
        java.lang.String str6 = dateTimeZone2.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology9);
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology9.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology14);
        org.joda.time.DateTimeZone dateTimeZone16 = gJChronology14.getZone();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology14.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField17, (int) ' ');
        int int21 = skipDateTimeField19.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        java.util.Locale locale26 = null;
        java.lang.String str27 = dateTimeZone24.getShortName((long) 0, locale26);
        java.lang.String str28 = dateTimeZone24.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology22, dateTimeZone24);
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay(dateTimeZone24);
        org.joda.time.MonthDay monthDay32 = monthDay30.plusMonths(82919);
        java.util.Locale locale34 = null;
        java.lang.String str35 = skipDateTimeField19.getAsShortText((org.joda.time.ReadablePartial) monthDay32, (int) (byte) -1, locale34);
        org.joda.time.MonthDay monthDay36 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.MonthDay monthDay38 = monthDay36.plus(readablePeriod37);
        org.joda.time.MonthDay.Property property39 = monthDay36.monthOfYear();
        org.joda.time.MonthDay monthDay40 = property39.getMonthDay();
        org.joda.time.MonthDay monthDay41 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod42 = null;
        org.joda.time.MonthDay monthDay43 = monthDay41.plus(readablePeriod42);
        org.joda.time.MonthDay.Property property44 = monthDay41.monthOfYear();
        java.util.Locale locale45 = null;
        java.lang.String str46 = property44.getAsText(locale45);
        org.joda.time.MonthDay monthDay48 = property44.setCopy((int) (byte) 10);
        java.util.Locale locale49 = null;
        int int50 = property44.getMaximumTextLength(locale49);
        java.util.Locale locale51 = null;
        java.lang.String str52 = property44.getAsText(locale51);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property44.getFieldType();
        org.joda.time.MonthDay.Property property54 = monthDay40.property(dateTimeFieldType53);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField19, dateTimeFieldType53, (int) (byte) 1);
        long long59 = offsetDateTimeField56.add((long) 4, 59);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField60 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) offsetDateTimeField56);
        org.joda.time.DurationField durationField61 = offsetDateTimeField56.getLeapDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-00:00:00.001" + "'", str5.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.001" + "'", str6.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-00:00:00.001" + "'", str27.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-00:00:00.001" + "'", str28.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "-1" + "'", str35.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay36);
        org.junit.Assert.assertNotNull(monthDay38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertNotNull(monthDay43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "June" + "'", str46.equals("June"));
        org.junit.Assert.assertNotNull(monthDay48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 9 + "'", int50 == 9);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "June" + "'", str52.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 59004L + "'", long59 == 59004L);
        org.junit.Assert.assertNull(durationField61);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission8 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean9 = jodaTimePermission6.implies((java.security.Permission) jodaTimePermission8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = dateTimeZone11.getShortName((long) 0, locale13);
        java.lang.String str15 = dateTimeZone11.getID();
        jodaTimePermission6.checkGuard((java.lang.Object) dateTimeZone11);
        java.lang.String str17 = jodaTimePermission6.getName();
        boolean boolean18 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission6);
        java.lang.String str19 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-00:00:00.001" + "'", str14.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-00:00:00.001" + "'", str15.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) 'a');
        org.joda.time.DateTime dateTime7 = dateTime3.withMillisOfSecond((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime7.toMutableDateTime();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime6 = dateTime3.withSecondOfMinute(0);
        org.joda.time.DateTime dateTime8 = dateTime3.plusMillis(15);
        org.joda.time.DateTime dateTime10 = dateTime3.plusMinutes(66);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
        int int8 = dateTimeZone5.getOffsetFromLocal(100L);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology10 = gJChronology1.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology1.dayOfYear();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay0.getFieldType(0);
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
//        org.joda.time.DurationField durationField8 = gJChronology6.hours();
//        org.joda.time.DurationField durationField9 = gJChronology6.millis();
//        java.lang.Object obj10 = null;
//        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField9, obj10);
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField12 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField9);
//        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.MonthDay monthDay15 = monthDay13.plus(readablePeriod14);
//        org.joda.time.MonthDay.Property property16 = monthDay13.monthOfYear();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = property16.getAsText(locale17);
//        org.joda.time.MonthDay monthDay20 = property16.addWrapFieldToCopy((int) ' ');
//        java.lang.String str21 = monthDay20.toString();
//        int int22 = monthDay20.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone25);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeUtils.getZone(dateTimeZone27);
//        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology26, dateTimeZone28);
//        java.lang.String str30 = buddhistChronology26.toString();
//        java.lang.String str31 = buddhistChronology26.toString();
//        org.joda.time.DurationField durationField32 = buddhistChronology26.years();
//        org.joda.time.Chronology chronology33 = buddhistChronology26.withUTC();
//        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay36 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology35);
//        org.joda.time.DateTimeZone dateTimeZone37 = gJChronology35.getZone();
//        org.joda.time.DateTimeField dateTimeField38 = gJChronology35.secondOfMinute();
//        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.MonthDay monthDay41 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology40);
//        org.joda.time.DateTimeZone dateTimeZone42 = gJChronology40.getZone();
//        org.joda.time.DateTimeField dateTimeField43 = gJChronology40.secondOfMinute();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField45 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology35, dateTimeField43, (int) ' ');
//        long long48 = skipDateTimeField45.add((long) '4', (int) (short) 1);
//        boolean boolean49 = skipDateTimeField45.isSupported();
//        int int52 = skipDateTimeField45.getDifference((long) (byte) 1, (-3480001L));
//        org.joda.time.MonthDay monthDay53 = org.joda.time.MonthDay.now();
//        org.joda.time.ReadablePeriod readablePeriod54 = null;
//        org.joda.time.MonthDay monthDay55 = monthDay53.plus(readablePeriod54);
//        org.joda.time.MonthDay monthDay57 = monthDay53.plusDays(0);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = skipDateTimeField45.getAsShortText((org.joda.time.ReadablePartial) monthDay57, (int) (byte) 10, locale59);
//        int[] intArray62 = buddhistChronology26.get((org.joda.time.ReadablePartial) monthDay57, 4L);
//        try {
//            int[] intArray64 = unsupportedDateTimeField12.addWrapField((org.joda.time.ReadablePartial) monthDay20, 0, intArray62, 1582);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(monthDay0);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertNotNull(dateTimeFieldType4);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField12);
//        org.junit.Assert.assertNotNull(monthDay13);
//        org.junit.Assert.assertNotNull(monthDay15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "June" + "'", str18.equals("June"));
//        org.junit.Assert.assertNotNull(monthDay20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "--02-15" + "'", str21.equals("--02-15"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(zonedChronology29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "BuddhistChronology[-00:00:00.001]" + "'", str30.equals("BuddhistChronology[-00:00:00.001]"));
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "BuddhistChronology[-00:00:00.001]" + "'", str31.equals("BuddhistChronology[-00:00:00.001]"));
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(chronology33);
//        org.junit.Assert.assertNotNull(gJChronology35);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(gJChronology40);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1052L + "'", long48 == 1052L);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3480 + "'", int52 == 3480);
//        org.junit.Assert.assertNotNull(monthDay53);
//        org.junit.Assert.assertNotNull(monthDay55);
//        org.junit.Assert.assertNotNull(monthDay57);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "10" + "'", str60.equals("10"));
//        org.junit.Assert.assertNotNull(intArray62);
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay monthDay4 = monthDay0.withDayOfMonth((int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay6 = monthDay4.minus(readablePeriod5);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.DateTime dateTime8 = monthDay6.toDateTime(readableInstant7);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) 'a');
//        int int6 = dateTime3.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime3.plus(readablePeriod7);
//        org.joda.time.LocalDateTime localDateTime9 = dateTime3.toLocalDateTime();
//        try {
//            java.lang.String str11 = dateTime3.toString("AD");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: A");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDateTime9);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone2.getShortName((long) 0, locale4);
        java.lang.String str6 = dateTimeZone2.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology9);
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology9.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology14);
        org.joda.time.DateTimeZone dateTimeZone16 = gJChronology14.getZone();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology14.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField17, (int) ' ');
        int int21 = skipDateTimeField19.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        java.util.Locale locale26 = null;
        java.lang.String str27 = dateTimeZone24.getShortName((long) 0, locale26);
        java.lang.String str28 = dateTimeZone24.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology22, dateTimeZone24);
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay(dateTimeZone24);
        org.joda.time.MonthDay monthDay32 = monthDay30.plusMonths(82919);
        java.util.Locale locale34 = null;
        java.lang.String str35 = skipDateTimeField19.getAsShortText((org.joda.time.ReadablePartial) monthDay32, (int) (byte) -1, locale34);
        org.joda.time.MonthDay monthDay36 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.MonthDay monthDay38 = monthDay36.plus(readablePeriod37);
        org.joda.time.MonthDay.Property property39 = monthDay36.monthOfYear();
        org.joda.time.MonthDay monthDay40 = property39.getMonthDay();
        org.joda.time.MonthDay monthDay41 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod42 = null;
        org.joda.time.MonthDay monthDay43 = monthDay41.plus(readablePeriod42);
        org.joda.time.MonthDay.Property property44 = monthDay41.monthOfYear();
        java.util.Locale locale45 = null;
        java.lang.String str46 = property44.getAsText(locale45);
        org.joda.time.MonthDay monthDay48 = property44.setCopy((int) (byte) 10);
        java.util.Locale locale49 = null;
        int int50 = property44.getMaximumTextLength(locale49);
        java.util.Locale locale51 = null;
        java.lang.String str52 = property44.getAsText(locale51);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property44.getFieldType();
        org.joda.time.MonthDay.Property property54 = monthDay40.property(dateTimeFieldType53);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField19, dateTimeFieldType53, (int) (byte) 1);
        long long59 = offsetDateTimeField56.add((long) 4, 59);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField60 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) offsetDateTimeField56);
        java.lang.String str61 = offsetDateTimeField56.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-00:00:00.001" + "'", str5.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.001" + "'", str6.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 59 + "'", int21 == 59);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-00:00:00.001" + "'", str27.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-00:00:00.001" + "'", str28.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "-1" + "'", str35.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay36);
        org.junit.Assert.assertNotNull(monthDay38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertNotNull(monthDay43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "June" + "'", str46.equals("June"));
        org.junit.Assert.assertNotNull(monthDay48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 9 + "'", int50 == 9);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "June" + "'", str52.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 59004L + "'", long59 == 59004L);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "DateTimeField[monthOfYear]" + "'", str61.equals("DateTimeField[monthOfYear]"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        org.joda.time.MonthDay monthDay7 = property3.addWrapFieldToCopy((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = dateTime9.withMinuteOfHour((int) (byte) 1);
        boolean boolean12 = dateTime11.isEqualNow();
        org.joda.time.DateTime.Property property13 = dateTime11.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant14 = null;
        long long15 = property13.getDifferenceAsLong(readableInstant14);
        int int16 = property13.getMaximumValueOverall();
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.MonthDay monthDay19 = monthDay17.plus(readablePeriod18);
        org.joda.time.MonthDay.Property property20 = monthDay17.monthOfYear();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay17.withChronologyRetainFields(chronology21);
        boolean boolean23 = property13.equals((java.lang.Object) monthDay22);
        int int24 = property3.compareTo((org.joda.time.ReadablePartial) monthDay22);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June" + "'", str5.equals("June"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2922789 + "'", int16 == 2922789);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField3 = gJChronology1.hours();
        org.joda.time.DurationField durationField4 = gJChronology1.millis();
        org.joda.time.DurationField durationField5 = gJChronology1.weekyears();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField7 = new org.joda.time.field.DecoratedDurationField(durationField5, durationFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getShortName((long) 0, locale18);
        java.lang.String str20 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology14, dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.MonthDay monthDay24 = monthDay22.plusMonths(82919);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay24, (int) (byte) -1, locale26);
        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay30 = monthDay28.plus(readablePeriod29);
        org.joda.time.MonthDay.Property property31 = monthDay28.monthOfYear();
        org.joda.time.MonthDay monthDay32 = property31.getMonthDay();
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.MonthDay monthDay35 = monthDay33.plus(readablePeriod34);
        org.joda.time.MonthDay.Property property36 = monthDay33.monthOfYear();
        java.util.Locale locale37 = null;
        java.lang.String str38 = property36.getAsText(locale37);
        org.joda.time.MonthDay monthDay40 = property36.setCopy((int) (byte) 10);
        java.util.Locale locale41 = null;
        int int42 = property36.getMaximumTextLength(locale41);
        java.util.Locale locale43 = null;
        java.lang.String str44 = property36.getAsText(locale43);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property36.getFieldType();
        org.joda.time.MonthDay.Property property46 = monthDay32.property(dateTimeFieldType45);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType45, (int) (byte) 1);
        java.lang.String str50 = offsetDateTimeField48.getAsText(101L);
        long long53 = offsetDateTimeField48.add(1L, (long) (byte) 10);
        java.util.Locale locale55 = null;
        java.lang.String str56 = offsetDateTimeField48.getAsShortText((int) (byte) 10, locale55);
        java.lang.String str58 = offsetDateTimeField48.getAsShortText((long) ' ');
        try {
            long long61 = offsetDateTimeField48.set((long) (-292275054), "0.0");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"0.0\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-00:00:00.001" + "'", str20.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-1" + "'", str27.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June" + "'", str38.equals("June"));
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June" + "'", str44.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "0" + "'", str50.equals("0"));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 10001L + "'", long53 == 10001L);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10" + "'", str56.equals("10"));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "0" + "'", str58.equals("0"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
        dateTimeFormatterBuilder0.clear();
        boolean boolean4 = dateTimeFormatterBuilder0.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) 'a', false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        org.joda.time.MonthDay monthDay4 = property3.getMonthDay();
        int int5 = property3.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTimeZone dateTimeZone4 = gJChronology2.getZone();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology7);
        org.joda.time.DateTimeZone dateTimeZone9 = gJChronology7.getZone();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology7.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField10, (int) ' ');
        long long15 = skipDateTimeField12.add((long) '4', (int) (short) 1);
        boolean boolean16 = skipDateTimeField12.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipDateTimeField12, 2922789);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 'a', dateTimeZone20);
        java.util.Date date22 = dateTime21.toDate();
        org.joda.time.MonthDay monthDay23 = org.joda.time.MonthDay.fromDateFields(date22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology25);
        org.joda.time.DateTimeZone dateTimeZone27 = gJChronology25.getZone();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology25.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay31 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology30);
        org.joda.time.DateTimeZone dateTimeZone32 = gJChronology30.getZone();
        org.joda.time.DateTimeField dateTimeField33 = gJChronology30.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField35 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology25, dateTimeField33, (int) ' ');
        int int37 = skipDateTimeField35.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeUtils.getZone(dateTimeZone39);
        java.util.Locale locale42 = null;
        java.lang.String str43 = dateTimeZone40.getShortName((long) 0, locale42);
        java.lang.String str44 = dateTimeZone40.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology45 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology38, dateTimeZone40);
        org.joda.time.MonthDay monthDay46 = new org.joda.time.MonthDay(dateTimeZone40);
        org.joda.time.MonthDay monthDay48 = monthDay46.plusMonths(82919);
        java.util.Locale locale50 = null;
        java.lang.String str51 = skipDateTimeField35.getAsShortText((org.joda.time.ReadablePartial) monthDay48, (int) (byte) -1, locale50);
        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod53 = null;
        org.joda.time.MonthDay monthDay54 = monthDay52.plus(readablePeriod53);
        org.joda.time.MonthDay.Property property55 = monthDay52.monthOfYear();
        org.joda.time.MonthDay monthDay56 = property55.getMonthDay();
        org.joda.time.MonthDay monthDay57 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod58 = null;
        org.joda.time.MonthDay monthDay59 = monthDay57.plus(readablePeriod58);
        org.joda.time.MonthDay.Property property60 = monthDay57.monthOfYear();
        java.util.Locale locale61 = null;
        java.lang.String str62 = property60.getAsText(locale61);
        org.joda.time.MonthDay monthDay64 = property60.setCopy((int) (byte) 10);
        java.util.Locale locale65 = null;
        int int66 = property60.getMaximumTextLength(locale65);
        java.util.Locale locale67 = null;
        java.lang.String str68 = property60.getAsText(locale67);
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = property60.getFieldType();
        org.joda.time.MonthDay.Property property70 = monthDay56.property(dateTimeFieldType69);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField72 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField35, dateTimeFieldType69, (int) (byte) 1);
        org.joda.time.MonthDay monthDay73 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod74 = null;
        org.joda.time.MonthDay monthDay75 = monthDay73.plus(readablePeriod74);
        org.joda.time.DateTimeFieldType dateTimeFieldType77 = monthDay73.getFieldType(0);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField78 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField72, dateTimeFieldType77);
        boolean boolean79 = monthDay23.isSupported(dateTimeFieldType77);
        java.util.Locale locale80 = null;
        try {
            java.lang.String str81 = skipDateTimeField18.getAsShortText((org.joda.time.ReadablePartial) monthDay23, locale80);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfMinute' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1052L + "'", long15 == 1052L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 59 + "'", int37 == 59);
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "-00:00:00.001" + "'", str43.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "-00:00:00.001" + "'", str44.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology45);
        org.junit.Assert.assertNotNull(monthDay48);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "-1" + "'", str51.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay52);
        org.junit.Assert.assertNotNull(monthDay54);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertNotNull(monthDay56);
        org.junit.Assert.assertNotNull(monthDay57);
        org.junit.Assert.assertNotNull(monthDay59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "June" + "'", str62.equals("June"));
        org.junit.Assert.assertNotNull(monthDay64);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 9 + "'", int66 == 9);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "June" + "'", str68.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType69);
        org.junit.Assert.assertNotNull(property70);
        org.junit.Assert.assertNotNull(monthDay73);
        org.junit.Assert.assertNotNull(monthDay75);
        org.junit.Assert.assertNotNull(dateTimeFieldType77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.Chronology chronology4 = gJChronology1.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology1.secondOfMinute();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        try {
            int[] intArray8 = gJChronology1.get(readablePeriod6, (long) 24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendYear((int) '4', 7);
        try {
            org.joda.time.Instant instant7 = new org.joda.time.Instant((java.lang.Object) dateTimeFormatterBuilder6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatterBuilder");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant3 = instant0.withDurationAdded(readableDuration1, 1582);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        int int5 = dateTimeZone2.getOffsetFromLocal(100L);
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone8);
        org.joda.time.Chronology chronology10 = julianChronology6.withZone(dateTimeZone8);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        java.lang.String str13 = dateTimeZone8.getName((long) 12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter0.withZone(dateTimeZone8);
        boolean boolean15 = dateTimeFormatter14.isOffsetParsed();
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter14.withLocale(locale16);
        java.io.Writer writer18 = null;
        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.MonthDay monthDay21 = monthDay19.plus(readablePeriod20);
        org.joda.time.MonthDay.Property property22 = monthDay19.monthOfYear();
        java.util.Locale locale23 = null;
        java.lang.String str24 = property22.getAsText(locale23);
        org.joda.time.MonthDay monthDay26 = property22.setCopy((int) (byte) 10);
        try {
            dateTimeFormatter14.printTo(writer18, (org.joda.time.ReadablePartial) monthDay26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-00:00:00.001" + "'", str13.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June" + "'", str24.equals("June"));
        org.junit.Assert.assertNotNull(monthDay26);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.io.Writer writer2 = null;
        try {
            dateTimeFormatter0.printTo(writer2, 1560632479267L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("27", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style character: 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        try {
            org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("monthOfYear", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"monthOfYear\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        try {
            org.joda.time.Instant instant2 = new org.joda.time.Instant((java.lang.Object) dateTimeFormatter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(101L, 32L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 69L + "'", long2 == 69L);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone2.getShortName((long) 0, locale4);
        java.lang.String str6 = dateTimeZone2.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone2);
        org.joda.time.Instant instant8 = gJChronology0.getGregorianCutover();
        long long9 = instant8.getMillis();
        org.joda.time.DateTime dateTime10 = instant8.toDateTimeISO();
        org.joda.time.MutableDateTime mutableDateTime11 = instant8.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-00:00:00.001" + "'", str5.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.001" + "'", str6.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-12219292800000L) + "'", long9 == (-12219292800000L));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        org.joda.time.MonthDay monthDay7 = property3.addWrapFieldToCopy((int) ' ');
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) 'a', dateTimeZone9);
        java.util.Date date11 = dateTime10.toDate();
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.fromDateFields(date11);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology14);
        org.joda.time.DateTimeZone dateTimeZone16 = gJChronology14.getZone();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology14.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology19);
        org.joda.time.DateTimeZone dateTimeZone21 = gJChronology19.getZone();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology19.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology14, dateTimeField22, (int) ' ');
        int int26 = skipDateTimeField24.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        java.util.Locale locale31 = null;
        java.lang.String str32 = dateTimeZone29.getShortName((long) 0, locale31);
        java.lang.String str33 = dateTimeZone29.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology34 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology27, dateTimeZone29);
        org.joda.time.MonthDay monthDay35 = new org.joda.time.MonthDay(dateTimeZone29);
        org.joda.time.MonthDay monthDay37 = monthDay35.plusMonths(82919);
        java.util.Locale locale39 = null;
        java.lang.String str40 = skipDateTimeField24.getAsShortText((org.joda.time.ReadablePartial) monthDay37, (int) (byte) -1, locale39);
        org.joda.time.MonthDay monthDay41 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod42 = null;
        org.joda.time.MonthDay monthDay43 = monthDay41.plus(readablePeriod42);
        org.joda.time.MonthDay.Property property44 = monthDay41.monthOfYear();
        org.joda.time.MonthDay monthDay45 = property44.getMonthDay();
        org.joda.time.MonthDay monthDay46 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod47 = null;
        org.joda.time.MonthDay monthDay48 = monthDay46.plus(readablePeriod47);
        org.joda.time.MonthDay.Property property49 = monthDay46.monthOfYear();
        java.util.Locale locale50 = null;
        java.lang.String str51 = property49.getAsText(locale50);
        org.joda.time.MonthDay monthDay53 = property49.setCopy((int) (byte) 10);
        java.util.Locale locale54 = null;
        int int55 = property49.getMaximumTextLength(locale54);
        java.util.Locale locale56 = null;
        java.lang.String str57 = property49.getAsText(locale56);
        org.joda.time.DateTimeFieldType dateTimeFieldType58 = property49.getFieldType();
        org.joda.time.MonthDay.Property property59 = monthDay45.property(dateTimeFieldType58);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField61 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField24, dateTimeFieldType58, (int) (byte) 1);
        org.joda.time.MonthDay monthDay62 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod63 = null;
        org.joda.time.MonthDay monthDay64 = monthDay62.plus(readablePeriod63);
        org.joda.time.DateTimeFieldType dateTimeFieldType66 = monthDay62.getFieldType(0);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField67 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField61, dateTimeFieldType66);
        boolean boolean68 = monthDay12.isSupported(dateTimeFieldType66);
        boolean boolean69 = monthDay7.isSupported(dateTimeFieldType66);
        try {
            int int71 = monthDay7.getValue((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June" + "'", str5.equals("June"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 59 + "'", int26 == 59);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "-00:00:00.001" + "'", str32.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "-00:00:00.001" + "'", str33.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology34);
        org.junit.Assert.assertNotNull(monthDay37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "-1" + "'", str40.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertNotNull(monthDay43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(monthDay45);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertNotNull(monthDay48);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "June" + "'", str51.equals("June"));
        org.junit.Assert.assertNotNull(monthDay53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 9 + "'", int55 == 9);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "June" + "'", str57.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType58);
        org.junit.Assert.assertNotNull(property59);
        org.junit.Assert.assertNotNull(monthDay62);
        org.junit.Assert.assertNotNull(monthDay64);
        org.junit.Assert.assertNotNull(dateTimeFieldType66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
//        boolean boolean4 = dateTime3.isEqualNow();
//        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
//        org.joda.time.ReadableInstant readableInstant6 = null;
//        long long7 = property5.getDifferenceAsLong(readableInstant6);
//        int int8 = property5.getMaximumValueOverall();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
//        org.joda.time.DateTime dateTime12 = dateTime10.withWeekOfWeekyear((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone13 = null;
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
//        org.joda.time.DateTime dateTime16 = dateTime14.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime18 = dateTime16.plusHours((int) 'a');
//        int int19 = dateTime16.getWeekOfWeekyear();
//        org.joda.time.ReadablePeriod readablePeriod20 = null;
//        org.joda.time.DateTime dateTime21 = dateTime16.plus(readablePeriod20);
//        org.joda.time.ReadablePeriod readablePeriod22 = null;
//        org.joda.time.DateTime dateTime24 = dateTime16.withPeriodAdded(readablePeriod22, (int) 'a');
//        boolean boolean25 = dateTime10.isBefore((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime dateTime27 = dateTime16.minus(0L);
//        int int28 = property5.getDifference((org.joda.time.ReadableInstant) dateTime16);
//        boolean boolean29 = property5.isLeap();
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2922789 + "'", int8 == 2922789);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 24 + "'", int19 == 24);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getShortName((long) 0, locale18);
        java.lang.String str20 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology14, dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.MonthDay monthDay24 = monthDay22.plusMonths(82919);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay24, (int) (byte) -1, locale26);
        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay30 = monthDay28.plus(readablePeriod29);
        org.joda.time.MonthDay.Property property31 = monthDay28.monthOfYear();
        org.joda.time.MonthDay monthDay32 = property31.getMonthDay();
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.MonthDay monthDay35 = monthDay33.plus(readablePeriod34);
        org.joda.time.MonthDay.Property property36 = monthDay33.monthOfYear();
        java.util.Locale locale37 = null;
        java.lang.String str38 = property36.getAsText(locale37);
        org.joda.time.MonthDay monthDay40 = property36.setCopy((int) (byte) 10);
        java.util.Locale locale41 = null;
        int int42 = property36.getMaximumTextLength(locale41);
        java.util.Locale locale43 = null;
        java.lang.String str44 = property36.getAsText(locale43);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property36.getFieldType();
        org.joda.time.MonthDay.Property property46 = monthDay32.property(dateTimeFieldType45);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType45, (int) (byte) 1);
        org.joda.time.MonthDay monthDay49 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod50 = null;
        org.joda.time.MonthDay monthDay51 = monthDay49.plus(readablePeriod50);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = monthDay49.getFieldType(0);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField54 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField48, dateTimeFieldType53);
        org.joda.time.IllegalFieldValueException illegalFieldValueException58 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, (java.lang.Number) 31100L, (java.lang.Number) 6, (java.lang.Number) 75715L);
        org.joda.time.chrono.GJChronology gJChronology60 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay61 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology60);
        org.joda.time.DurationField durationField62 = gJChronology60.hours();
        org.joda.time.DurationField durationField63 = gJChronology60.millis();
        org.joda.time.DurationField durationField64 = gJChronology60.hours();
        long long67 = durationField64.subtract(1L, (int) (short) -1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField68 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType53, durationField64);
        try {
            java.lang.String str70 = unsupportedDateTimeField68.getAsShortText((long) 75700);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-00:00:00.001" + "'", str20.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-1" + "'", str27.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June" + "'", str38.equals("June"));
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "June" + "'", str44.equals("June"));
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(monthDay51);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertNotNull(gJChronology60);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(durationField63);
        org.junit.Assert.assertNotNull(durationField64);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 3600001L + "'", long67 == 3600001L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField68);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 75678);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) 'a');
        int int6 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.plus(readablePeriod7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime3.withPeriodAdded(readablePeriod9, (int) 'a');
        org.joda.time.DateTime.Property property12 = dateTime3.dayOfMonth();
        java.util.Locale locale13 = null;
        java.lang.String str14 = property12.getAsShortText(locale13);
        org.joda.time.DateTime dateTime15 = property12.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1" + "'", str14.equals("1"));
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder5.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendHourOfHalfday((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendDayOfYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendWeekyear(24, 3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter15 = dateTimeFormatter14.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.append(dateTimePrinter15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder17.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendHourOfHalfday((int) (byte) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder18.append(dateTimeFormatter21);
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter21.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder0.append(dateTimePrinter15, dateTimeParser23);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay27 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology26);
        org.joda.time.DateTimeZone dateTimeZone28 = gJChronology26.getZone();
        org.joda.time.DateTimeField dateTimeField29 = gJChronology26.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology31);
        org.joda.time.DateTimeZone dateTimeZone33 = gJChronology31.getZone();
        org.joda.time.DateTimeField dateTimeField34 = gJChronology31.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology26, dateTimeField34, (int) ' ');
        int int38 = skipDateTimeField36.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeUtils.getZone(dateTimeZone40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = dateTimeZone41.getShortName((long) 0, locale43);
        java.lang.String str45 = dateTimeZone41.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology46 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology39, dateTimeZone41);
        org.joda.time.MonthDay monthDay47 = new org.joda.time.MonthDay(dateTimeZone41);
        org.joda.time.MonthDay monthDay49 = monthDay47.plusMonths(82919);
        java.util.Locale locale51 = null;
        java.lang.String str52 = skipDateTimeField36.getAsShortText((org.joda.time.ReadablePartial) monthDay49, (int) (byte) -1, locale51);
        org.joda.time.MonthDay monthDay53 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.MonthDay monthDay55 = monthDay53.plus(readablePeriod54);
        org.joda.time.MonthDay.Property property56 = monthDay53.monthOfYear();
        org.joda.time.MonthDay monthDay57 = property56.getMonthDay();
        org.joda.time.MonthDay monthDay58 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod59 = null;
        org.joda.time.MonthDay monthDay60 = monthDay58.plus(readablePeriod59);
        org.joda.time.MonthDay.Property property61 = monthDay58.monthOfYear();
        java.util.Locale locale62 = null;
        java.lang.String str63 = property61.getAsText(locale62);
        org.joda.time.MonthDay monthDay65 = property61.setCopy((int) (byte) 10);
        java.util.Locale locale66 = null;
        int int67 = property61.getMaximumTextLength(locale66);
        java.util.Locale locale68 = null;
        java.lang.String str69 = property61.getAsText(locale68);
        org.joda.time.DateTimeFieldType dateTimeFieldType70 = property61.getFieldType();
        org.joda.time.MonthDay.Property property71 = monthDay57.property(dateTimeFieldType70);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField73 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField36, dateTimeFieldType70, (int) (byte) 1);
        org.joda.time.MonthDay monthDay74 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod75 = null;
        org.joda.time.MonthDay monthDay76 = monthDay74.plus(readablePeriod75);
        org.joda.time.DateTimeFieldType dateTimeFieldType78 = monthDay74.getFieldType(0);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField79 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField73, dateTimeFieldType78);
        org.joda.time.IllegalFieldValueException illegalFieldValueException83 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType78, (java.lang.Number) 31100L, (java.lang.Number) 6, (java.lang.Number) 75715L);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder86 = dateTimeFormatterBuilder24.appendDecimal(dateTimeFieldType78, (-292275054), 75702);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimePrinter15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 59 + "'", int38 == 59);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "-00:00:00.001" + "'", str44.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "-00:00:00.001" + "'", str45.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology46);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "-1" + "'", str52.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay53);
        org.junit.Assert.assertNotNull(monthDay55);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(monthDay57);
        org.junit.Assert.assertNotNull(monthDay58);
        org.junit.Assert.assertNotNull(monthDay60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "January" + "'", str63.equals("January"));
        org.junit.Assert.assertNotNull(monthDay65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 9 + "'", int67 == 9);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "January" + "'", str69.equals("January"));
        org.junit.Assert.assertNotNull(dateTimeFieldType70);
        org.junit.Assert.assertNotNull(property71);
        org.junit.Assert.assertNotNull(monthDay74);
        org.junit.Assert.assertNotNull(monthDay76);
        org.junit.Assert.assertNotNull(dateTimeFieldType78);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        int int7 = property4.getMinimumValueOverall();
        java.lang.String str8 = property4.getAsString();
        int int9 = property4.getMinimumValueOverall();
        java.lang.String str10 = property4.getAsString();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "AD" + "'", str6.equals("AD"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.Chronology chronology4 = gJChronology1.withUTC();
        try {
            long long12 = gJChronology1.getDateTimeMillis(109, 58, 29, 75703, (int) (short) 10, 24, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 75703 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology2, dateTimeZone4);
        org.joda.time.Chronology chronology6 = zonedChronology5.withUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        long long12 = dateTimeZone8.convertLocalToUTC((long) (byte) 100, false, (long) 'a');
        org.joda.time.Chronology chronology13 = zonedChronology5.withZone(dateTimeZone8);
        java.lang.String str14 = zonedChronology5.toString();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        java.lang.String str17 = dateTimeZone15.getName((long) (short) -1);
        org.joda.time.Chronology chronology18 = zonedChronology5.withZone(dateTimeZone15);
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology20);
        org.joda.time.DateTimeZone dateTimeZone22 = gJChronology20.getZone();
        org.joda.time.Chronology chronology23 = gJChronology20.withUTC();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology20.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField25 = gJChronology20.secondOfMinute();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField(chronology18, dateTimeField25, 75671);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 101L + "'", long12 == 101L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[BuddhistChronology[UTC], -00:00:00.001]" + "'", str14.equals("ZonedChronology[BuddhistChronology[UTC], -00:00:00.001]"));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-00:00:00.001" + "'", str17.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant6 = null;
        long long7 = property5.getDifferenceAsLong(readableInstant6);
        int int8 = property5.getMaximumValueOverall();
        java.util.Locale locale9 = null;
        java.lang.String str10 = property5.getAsText(locale9);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2922789 + "'", int8 == 2922789);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "19" + "'", str10.equals("19"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendMinuteOfHour((int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendHourOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendPattern("");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("T210124.112-0000", 3480, 75678, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3480 for T210124.112-0000 must be in the range [75678,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(31, 'a', (int) (short) 100, 6, 21, true, 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder8.setFixedSavings("ZonedChronology[BuddhistChronology[UTC], -00:00:00.001]", 75661);
        java.io.DataOutput dataOutput13 = null;
        try {
            dateTimeZoneBuilder8.writeTo("3", dataOutput13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay0.getFieldType(0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.hours();
        org.joda.time.DurationField durationField9 = gJChronology6.millis();
        java.lang.Object obj10 = null;
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField9, obj10);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField12 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField9);
        boolean boolean13 = unsupportedDateTimeField12.isLenient();
        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.MonthDay monthDay16 = monthDay14.plus(readablePeriod15);
        org.joda.time.MonthDay monthDay18 = monthDay14.plusDays(0);
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology20);
        org.joda.time.Chronology chronology22 = monthDay21.getChronology();
        org.joda.time.MonthDay monthDay24 = monthDay21.minusMonths(3);
        boolean boolean25 = monthDay18.isEqual((org.joda.time.ReadablePartial) monthDay21);
        org.joda.time.MonthDay monthDay26 = org.joda.time.MonthDay.now();
        boolean boolean27 = monthDay21.isEqual((org.joda.time.ReadablePartial) monthDay26);
        int[] intArray32 = new int[] { 60, 13, (-75) };
        java.util.Locale locale34 = null;
        try {
            int[] intArray35 = unsupportedDateTimeField12.set((org.joda.time.ReadablePartial) monthDay26, (int) (byte) 1, intArray32, "-00:00:00.001", locale34);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(intArray32);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant6 = null;
        long long7 = property5.getDifferenceAsLong(readableInstant6);
        org.joda.time.DateTime dateTime9 = property5.addToCopy((long) 6);
        org.joda.time.DateTime dateTime11 = dateTime9.minusDays(100);
        boolean boolean12 = dateTime11.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay monthDay4 = monthDay0.withDayOfMonth((int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay6 = monthDay4.minus(readablePeriod5);
        try {
            int int8 = monthDay4.getValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay6);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime6 = dateTime3.withSecondOfMinute(0);
        org.joda.time.DateTime dateTime8 = dateTime3.plus(32L);
        org.joda.time.DateTime dateTime10 = dateTime8.withEra(0);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.dayOfYear();
        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay15 = monthDay13.plus(readablePeriod14);
        org.joda.time.MonthDay.Property property16 = monthDay13.monthOfYear();
        java.util.Locale locale17 = null;
        java.lang.String str18 = property16.getAsText(locale17);
        org.joda.time.MonthDay monthDay20 = property16.addToCopy((int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property16.getFieldType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField23 = new org.joda.time.field.RemainderDateTimeField(dateTimeField12, dateTimeFieldType21, 75703);
        int int24 = dateTime10.get(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "January" + "'", str18.equals("January"));
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) 'a');
        int int6 = dateTime3.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime8 = dateTime3.minus(0L);
        java.util.Locale locale9 = null;
        java.util.Calendar calendar10 = dateTime8.toCalendar(locale9);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(calendar10);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay0.getFieldType(0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.hours();
        org.joda.time.DurationField durationField9 = gJChronology6.millis();
        java.lang.Object obj10 = null;
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField9, obj10);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField12 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField9);
        boolean boolean13 = unsupportedDateTimeField12.isLenient();
        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.MonthDay monthDay16 = monthDay14.plus(readablePeriod15);
        org.joda.time.MonthDay.Property property17 = monthDay14.monthOfYear();
        java.util.Locale locale18 = null;
        java.lang.String str19 = property17.getAsText(locale18);
        org.joda.time.MonthDay monthDay21 = property17.addWrapFieldToCopy((int) ' ');
        java.lang.String str22 = monthDay21.toString();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeUtils.getZone(dateTimeZone26);
        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology25, dateTimeZone27);
        java.lang.String str29 = buddhistChronology25.toString();
        java.lang.String str30 = buddhistChronology25.toString();
        org.joda.time.DurationField durationField31 = buddhistChronology25.years();
        org.joda.time.Chronology chronology32 = buddhistChronology25.withUTC();
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay35 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology34);
        org.joda.time.DateTimeZone dateTimeZone36 = gJChronology34.getZone();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology34.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology39);
        org.joda.time.DateTimeZone dateTimeZone41 = gJChronology39.getZone();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology34, dateTimeField42, (int) ' ');
        long long47 = skipDateTimeField44.add((long) '4', (int) (short) 1);
        boolean boolean48 = skipDateTimeField44.isSupported();
        int int51 = skipDateTimeField44.getDifference((long) (byte) 1, (-3480001L));
        org.joda.time.MonthDay monthDay52 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod53 = null;
        org.joda.time.MonthDay monthDay54 = monthDay52.plus(readablePeriod53);
        org.joda.time.MonthDay monthDay56 = monthDay52.plusDays(0);
        java.util.Locale locale58 = null;
        java.lang.String str59 = skipDateTimeField44.getAsShortText((org.joda.time.ReadablePartial) monthDay56, (int) (byte) 10, locale58);
        int[] intArray61 = buddhistChronology25.get((org.joda.time.ReadablePartial) monthDay56, 4L);
        try {
            int int62 = unsupportedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) monthDay21, intArray61);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "January" + "'", str19.equals("January"));
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "--09-01" + "'", str22.equals("--09-01"));
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(buddhistChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(zonedChronology28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "BuddhistChronology[-00:00:00.001]" + "'", str29.equals("BuddhistChronology[-00:00:00.001]"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "BuddhistChronology[-00:00:00.001]" + "'", str30.equals("BuddhistChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1052L + "'", long47 == 1052L);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 3480 + "'", int51 == 3480);
        org.junit.Assert.assertNotNull(monthDay52);
        org.junit.Assert.assertNotNull(monthDay54);
        org.junit.Assert.assertNotNull(monthDay56);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "10" + "'", str59.equals("10"));
        org.junit.Assert.assertNotNull(intArray61);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        int int4 = dateTime3.getDayOfYear();
        org.joda.time.DateTime dateTime6 = dateTime3.withCenturyOfEra(75662);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        int int4 = dateTimeZone1.getOffsetFromLocal(100L);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology6 = julianChronology5.withUTC();
        try {
            long long11 = julianChronology5.getDateTimeMillis(0, 69, 75671436, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay monthDay4 = monthDay0.minusDays(1);
        org.joda.time.MonthDay monthDay5 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay7 = monthDay5.plus(readablePeriod6);
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        java.util.Locale locale9 = null;
        java.lang.String str10 = property8.getAsText(locale9);
        org.joda.time.MonthDay monthDay12 = property8.addToCopy((int) (short) 10);
        boolean boolean13 = monthDay4.isAfter((org.joda.time.ReadablePartial) monthDay12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay15 = monthDay4.minus(readablePeriod14);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "January" + "'", str10.equals("January"));
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(monthDay15);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) 'a');
        int int6 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.plus(readablePeriod7);
        org.joda.time.DateTime.Property property9 = dateTime3.era();
        boolean boolean11 = dateTime3.isEqual((long) 2922789);
        org.joda.time.DateTime.Property property12 = dateTime3.dayOfWeek();
        try {
            org.joda.time.DateTime dateTime17 = dateTime3.withTime(75700, 75686, 7, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 75700 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(1000L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.MonthDay monthDay5 = monthDay3.plus(readablePeriod4);
        org.joda.time.MonthDay.Property property6 = monthDay3.monthOfYear();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property6.getAsText(locale7);
        org.joda.time.MonthDay monthDay10 = property6.addToCopy((int) (short) 10);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.MonthDay monthDay13 = monthDay10.withPeriodAdded(readablePeriod11, (int) (short) 0);
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology15);
        org.joda.time.DateTimeZone dateTimeZone17 = gJChronology15.getZone();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology15.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology20);
        org.joda.time.DateTimeZone dateTimeZone22 = gJChronology20.getZone();
        org.joda.time.DateTimeField dateTimeField23 = gJChronology20.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology15, dateTimeField23, (int) ' ');
        int int27 = skipDateTimeField25.getMaximumValue((long) 0);
        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay30 = monthDay28.plus(readablePeriod29);
        org.joda.time.MonthDay.Property property31 = monthDay28.monthOfYear();
        int[] intArray38 = new int[] { 66, 20, 10, 'a', 75662, 75666 };
        int int39 = skipDateTimeField25.getMinimumValue((org.joda.time.ReadablePartial) monthDay28, intArray38);
        try {
            iSOChronology1.validate((org.joda.time.ReadablePartial) monthDay10, intArray38);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 66 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "January" + "'", str8.equals("January"));
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 59 + "'", int27 == 59);
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        org.joda.time.DateTime dateTime8 = dateTime6.plusWeeks((int) (short) 10);
        int int9 = dateTime6.getSecondOfDay();
        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks(15);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.minus(readablePeriod12);
        org.joda.time.DateTime dateTime15 = dateTime13.plusMonths(75693);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 75 + "'", int9 == 75);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        try {
            org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((java.lang.Object) strSet0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.util.TreeSet");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay monthDay4 = monthDay0.withDayOfMonth((int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay6 = monthDay4.minus(readablePeriod5);
        java.lang.Number number10 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException("ZonedChronology[BuddhistChronology[UTC], -00:00:00.001]", (java.lang.Number) 0.0d, (java.lang.Number) 82919, number10);
        boolean boolean12 = monthDay6.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.minus(readableDuration2);
        org.joda.time.DateTime dateTime5 = dateTime3.withDayOfYear(9);
        int int6 = dateTime5.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField3 = gJChronology1.hours();
        org.joda.time.DurationField durationField4 = gJChronology1.millis();
        org.joda.time.DurationField durationField5 = org.joda.time.field.MillisDurationField.INSTANCE;
        java.lang.Class<?> wildcardClass6 = durationField5.getClass();
        boolean boolean7 = gJChronology1.equals((java.lang.Object) wildcardClass6);
        org.joda.time.DateTimeField dateTimeField8 = gJChronology1.yearOfEra();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) ' ', (int) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1024L + "'", long2 == 1024L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology2, dateTimeZone4);
        java.lang.String str6 = buddhistChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = dateTimeZone8.getShortName((long) 0, locale10);
        java.lang.String str12 = dateTimeZone8.getID();
        org.joda.time.LocalDateTime localDateTime13 = null;
        boolean boolean14 = dateTimeZone8.isLocalDateTimeGap(localDateTime13);
        org.joda.time.Chronology chronology15 = buddhistChronology2.withZone(dateTimeZone8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        boolean boolean17 = cachedDateTimeZone16.isFixed();
        boolean boolean19 = cachedDateTimeZone16.equals((java.lang.Object) 100L);
        long long21 = cachedDateTimeZone16.previousTransition(103L);
        org.joda.time.DateTimeZone dateTimeZone22 = cachedDateTimeZone16.getUncachedZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "BuddhistChronology[-00:00:00.001]" + "'", str6.equals("BuddhistChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-00:00:00.001" + "'", str11.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-00:00:00.001" + "'", str12.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 103L + "'", long21 == 103L);
        org.junit.Assert.assertNotNull(dateTimeZone22);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay0.getFieldType(0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.hours();
        org.joda.time.DurationField durationField9 = gJChronology6.millis();
        java.lang.Object obj10 = null;
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField9, obj10);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField12 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField9);
        boolean boolean13 = unsupportedDateTimeField12.isLenient();
        java.util.Locale locale14 = null;
        try {
            int int15 = unsupportedDateTimeField12.getMaximumTextLength(locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) 'a');
        int int6 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.plus(readablePeriod7);
        int int9 = dateTime8.getSecondOfDay();
        org.joda.time.DateTime dateTime11 = dateTime8.withCenturyOfEra((int) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusMillis(3);
        int int14 = dateTime11.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 75 + "'", int9 == 75);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay4 = monthDay2.plus(readablePeriod3);
        org.joda.time.MonthDay.Property property5 = monthDay2.monthOfYear();
        java.util.Locale locale6 = null;
        java.lang.String str7 = property5.getAsText(locale6);
        org.joda.time.MonthDay monthDay9 = property5.addToCopy((int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property5.getFieldType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField12 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType10, 75703);
        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay15 = monthDay13.plus(readablePeriod14);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = monthDay13.getFieldType(0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField18 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField12, dateTimeFieldType17);
        int int20 = remainderDateTimeField12.get(13L);
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology22);
        org.joda.time.Chronology chronology24 = monthDay23.getChronology();
        org.joda.time.MonthDay monthDay26 = monthDay23.minusMonths(3);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology30, dateTimeZone32);
        java.lang.String str34 = buddhistChronology30.toString();
        java.lang.String str35 = buddhistChronology30.toString();
        org.joda.time.DurationField durationField36 = buddhistChronology30.years();
        org.joda.time.Chronology chronology37 = buddhistChronology30.withUTC();
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology39);
        org.joda.time.DateTimeZone dateTimeZone41 = gJChronology39.getZone();
        org.joda.time.DateTimeField dateTimeField42 = gJChronology39.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay45 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology44);
        org.joda.time.DateTimeZone dateTimeZone46 = gJChronology44.getZone();
        org.joda.time.DateTimeField dateTimeField47 = gJChronology44.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField49 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology39, dateTimeField47, (int) ' ');
        long long52 = skipDateTimeField49.add((long) '4', (int) (short) 1);
        boolean boolean53 = skipDateTimeField49.isSupported();
        int int56 = skipDateTimeField49.getDifference((long) (byte) 1, (-3480001L));
        org.joda.time.MonthDay monthDay57 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod58 = null;
        org.joda.time.MonthDay monthDay59 = monthDay57.plus(readablePeriod58);
        org.joda.time.MonthDay monthDay61 = monthDay57.plusDays(0);
        java.util.Locale locale63 = null;
        java.lang.String str64 = skipDateTimeField49.getAsShortText((org.joda.time.ReadablePartial) monthDay61, (int) (byte) 10, locale63);
        int[] intArray66 = buddhistChronology30.get((org.joda.time.ReadablePartial) monthDay61, 4L);
        try {
            int[] intArray68 = remainderDateTimeField12.addWrapPartial((org.joda.time.ReadablePartial) monthDay26, 1, intArray66, (-75));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Fields invalid for add");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January" + "'", str7.equals("January"));
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "BuddhistChronology[-00:00:00.001]" + "'", str34.equals("BuddhistChronology[-00:00:00.001]"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "BuddhistChronology[-00:00:00.001]" + "'", str35.equals("BuddhistChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1052L + "'", long52 == 1052L);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 3480 + "'", int56 == 3480);
        org.junit.Assert.assertNotNull(monthDay57);
        org.junit.Assert.assertNotNull(monthDay59);
        org.junit.Assert.assertNotNull(monthDay61);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "10" + "'", str64.equals("10"));
        org.junit.Assert.assertNotNull(intArray66);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission8 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean9 = jodaTimePermission6.implies((java.security.Permission) jodaTimePermission8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        java.util.Locale locale13 = null;
        java.lang.String str14 = dateTimeZone11.getShortName((long) 0, locale13);
        java.lang.String str15 = dateTimeZone11.getID();
        jodaTimePermission6.checkGuard((java.lang.Object) dateTimeZone11);
        java.lang.String str17 = jodaTimePermission6.getName();
        boolean boolean18 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission6);
        java.lang.String str19 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-00:00:00.001" + "'", str14.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-00:00:00.001" + "'", str15.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str19.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone6);
        int int9 = dateTimeZone6.getOffsetFromLocal(100L);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology11 = julianChronology10.withUTC();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.DateTime dateTime15 = dateTime13.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime17 = dateTime15.plusHours((int) 'a');
        int int18 = dateTime15.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime15.plus(readablePeriod19);
        int int21 = dateTime20.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone22 = dateTime20.getZone();
        long long26 = dateTimeZone22.convertLocalToUTC((long) 75714, true, (-1000L));
        org.joda.time.Chronology chronology27 = julianChronology10.withZone(dateTimeZone22);
        try {
            org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((int) (byte) -1, (int) '#', (int) (byte) 10, (int) (short) 100, (int) (byte) 100, (org.joda.time.Chronology) julianChronology10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 75 + "'", int21 == 75);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 75715L + "'", long26 == 75715L);
        org.junit.Assert.assertNotNull(chronology27);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder1.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendHourOfHalfday((int) (byte) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.append(dateTimeFormatter5);
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatter5.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter5.withPivotYear((int) (short) 1);
        try {
            org.joda.time.Instant instant10 = org.joda.time.Instant.parse("December", dateTimeFormatter9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"December\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendEraText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendTimeZoneShortName(strMap5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        org.joda.time.MonthDay monthDay7 = property3.setCopy((int) (byte) 10);
        java.util.Locale locale8 = null;
        int int9 = property3.getMaximumTextLength(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property3.getAsText(locale10);
        int int12 = property3.getMinimumValueOverall();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone14);
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now(dateTimeZone14);
        boolean boolean17 = property3.equals((java.lang.Object) dateTimeZone14);
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now(dateTimeZone14);
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "", (int) (short) 100, (int) (short) -1);
        java.util.TimeZone timeZone25 = fixedDateTimeZone24.toTimeZone();
        long long28 = fixedDateTimeZone24.convertLocalToUTC((long) 75718, false);
        org.joda.time.Chronology chronology29 = copticChronology19.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
        org.joda.time.DateTime dateTime33 = dateTime31.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime35 = dateTime33.plusHours((int) 'a');
        org.joda.time.DateTime.Property property36 = dateTime33.hourOfDay();
        int int37 = dateTime33.getEra();
        int int38 = dateTime33.getHourOfDay();
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone24, (org.joda.time.ReadableInstant) dateTime33);
        boolean boolean41 = fixedDateTimeZone24.equals((java.lang.Object) "0.0");
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "January" + "'", str5.equals("January"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "January" + "'", str11.equals("January"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 75618L + "'", long28 == 75618L);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(iSOChronology42);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(4, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendHourOfDay(2019);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        org.joda.time.MonthDay monthDay7 = property3.addWrapFieldToCopy((int) ' ');
        int int8 = property3.getMaximumValue();
        java.lang.String str9 = property3.toString();
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "January" + "'", str5.equals("January"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Property[monthOfYear]" + "'", str9.equals("Property[monthOfYear]"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("Jun");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Jun\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMinuteOfHour((int) (byte) 1);
        boolean boolean5 = dateTime4.isEqualNow();
        org.joda.time.DateTime dateTime6 = monthDay0.toDateTime((org.joda.time.ReadableInstant) dateTime4);
        boolean boolean8 = dateTime6.isBefore((long) 59);
        try {
            org.joda.time.DateTime dateTime10 = dateTime6.withDayOfMonth(75671436);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 75671436 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) 'a');
        int int6 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.plus(readablePeriod7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime3.withPeriodAdded(readablePeriod9, (int) 'a');
        org.joda.time.DateTime.Property property12 = dateTime3.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime14.withMinuteOfHour((int) (byte) 1);
        boolean boolean17 = dateTime16.isEqualNow();
        org.joda.time.DateTime.Property property18 = dateTime16.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant19 = null;
        long long20 = property18.getDifferenceAsLong(readableInstant19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property18.getFieldType();
        boolean boolean22 = dateTime3.isSupported(dateTimeFieldType21);
        long long23 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property24 = dateTime3.weekOfWeekyear();
        org.joda.time.MonthDay monthDay25 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.MonthDay monthDay27 = monthDay25.plus(readablePeriod26);
        org.joda.time.MonthDay monthDay29 = monthDay25.withDayOfMonth((int) (short) 1);
        org.joda.time.MonthDay monthDay31 = monthDay25.minusMonths(100);
        try {
            int int32 = property24.compareTo((org.joda.time.ReadablePartial) monthDay25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekOfWeekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 75678L + "'", long23 == 75678L);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(monthDay31);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology2, dateTimeZone4);
        org.joda.time.Chronology chronology6 = zonedChronology5.withUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        long long12 = dateTimeZone8.convertLocalToUTC((long) (byte) 100, false, (long) 'a');
        org.joda.time.Chronology chronology13 = zonedChronology5.withZone(dateTimeZone8);
        java.lang.String str14 = dateTimeZone8.getID();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 101L + "'", long12 == 101L);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-00:00:00.001" + "'", str14.equals("-00:00:00.001"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) 'a');
        int int6 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.plus(readablePeriod7);
        int int9 = dateTime8.getSecondOfDay();
        org.joda.time.DateTime dateTime11 = dateTime8.withCenturyOfEra((int) (short) 10);
        org.joda.time.LocalTime localTime12 = dateTime11.toLocalTime();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 75 + "'", int9 == 75);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localTime12);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) 'a');
        org.joda.time.DateTime.Property property6 = dateTime3.hourOfDay();
        org.joda.time.DateTime dateTime8 = dateTime3.withMillis((long) 'a');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone11);
        int int14 = dateTimeZone11.getOffsetFromLocal(100L);
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter9.withZone(dateTimeZone11);
        java.lang.String str17 = dateTime8.toString(dateTimeFormatter16);
        java.lang.Appendable appendable18 = null;
        org.joda.time.ReadablePartial readablePartial19 = null;
        try {
            dateTimeFormatter16.printTo(appendable18, readablePartial19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "T000000.096-0000" + "'", str17.equals("T000000.096-0000"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfMinute(75693, 522);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology9, dateTimeZone11);
        org.joda.time.Chronology chronology13 = zonedChronology12.withUTC();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
        long long19 = dateTimeZone15.convertLocalToUTC((long) (byte) 100, false, (long) 'a');
        org.joda.time.Chronology chronology20 = zonedChronology12.withZone(dateTimeZone15);
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField22 = julianChronology21.dayOfMonth();
        try {
            org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(0, 12, (int) (byte) 10, (int) (short) 0, 75678, 75693, 15, (org.joda.time.Chronology) julianChronology21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 75678 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 101L + "'", long19 == 101L);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(1000L, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        long long8 = dateTimeZone4.convertLocalToUTC((long) (byte) 100, false, (long) 'a');
        org.joda.time.Chronology chronology9 = iSOChronology1.withZone(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology1.monthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 101L + "'", long8 == 101L);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) 'a');
        int int10 = dateTime7.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime7.plus(readablePeriod11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime15 = dateTime7.withPeriodAdded(readablePeriod13, (int) 'a');
        boolean boolean16 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.MonthDay monthDay19 = monthDay17.plus(readablePeriod18);
        org.joda.time.MonthDay monthDay21 = monthDay17.minusDays(1);
        int int22 = monthDay17.getDayOfMonth();
        org.joda.time.DateTime dateTime23 = dateTime7.withFields((org.joda.time.ReadablePartial) monthDay17);
        org.joda.time.DateTime dateTime25 = dateTime23.withWeekyear(10);
        org.joda.time.DateTime dateTime26 = dateTime23.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay0.getFieldType(0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.hours();
        org.joda.time.DurationField durationField9 = gJChronology6.millis();
        java.lang.Object obj10 = null;
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField9, obj10);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField12 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField9);
        boolean boolean13 = unsupportedDateTimeField12.isLenient();
        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.MonthDay monthDay16 = monthDay14.plus(readablePeriod15);
        org.joda.time.MonthDay.Property property17 = monthDay14.monthOfYear();
        java.util.Locale locale18 = null;
        java.lang.String str19 = property17.getAsText(locale18);
        org.joda.time.MonthDay monthDay21 = property17.addWrapFieldToCopy((int) ' ');
        java.lang.String str22 = monthDay21.toString();
        int int23 = monthDay21.getMonthOfYear();
        try {
            int int24 = unsupportedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) monthDay21);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "January" + "'", str19.equals("January"));
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "--09-01" + "'", str22.equals("--09-01"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        int int13 = skipDateTimeField11.getMaximumValue((long) 0);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone16.getShortName((long) 0, locale18);
        java.lang.String str20 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology14, dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.MonthDay monthDay24 = monthDay22.plusMonths(82919);
        java.util.Locale locale26 = null;
        java.lang.String str27 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay24, (int) (byte) -1, locale26);
        org.joda.time.MonthDay monthDay28 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay30 = monthDay28.plus(readablePeriod29);
        org.joda.time.MonthDay.Property property31 = monthDay28.monthOfYear();
        org.joda.time.MonthDay monthDay32 = property31.getMonthDay();
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.MonthDay monthDay35 = monthDay33.plus(readablePeriod34);
        org.joda.time.MonthDay.Property property36 = monthDay33.monthOfYear();
        java.util.Locale locale37 = null;
        java.lang.String str38 = property36.getAsText(locale37);
        org.joda.time.MonthDay monthDay40 = property36.setCopy((int) (byte) 10);
        java.util.Locale locale41 = null;
        int int42 = property36.getMaximumTextLength(locale41);
        java.util.Locale locale43 = null;
        java.lang.String str44 = property36.getAsText(locale43);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property36.getFieldType();
        org.joda.time.MonthDay.Property property46 = monthDay32.property(dateTimeFieldType45);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField11, dateTimeFieldType45, (int) (byte) 1);
        org.joda.time.MonthDay monthDay49 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod50 = null;
        org.joda.time.MonthDay monthDay51 = monthDay49.plus(readablePeriod50);
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = monthDay49.getFieldType(0);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField54 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField48, dateTimeFieldType53);
        org.joda.time.IllegalFieldValueException illegalFieldValueException58 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, (java.lang.Number) 31100L, (java.lang.Number) 6, (java.lang.Number) 75715L);
        org.joda.time.chrono.GJChronology gJChronology60 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay61 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology60);
        org.joda.time.DurationField durationField62 = gJChronology60.hours();
        org.joda.time.DurationField durationField63 = gJChronology60.millis();
        org.joda.time.DurationField durationField64 = gJChronology60.hours();
        long long67 = durationField64.subtract(1L, (int) (short) -1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField68 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType53, durationField64);
        try {
            boolean boolean70 = unsupportedDateTimeField68.isLeap(3600001L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-00:00:00.001" + "'", str19.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-00:00:00.001" + "'", str20.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "-1" + "'", str27.equals("-1"));
        org.junit.Assert.assertNotNull(monthDay28);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "January" + "'", str38.equals("January"));
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "January" + "'", str44.equals("January"));
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(monthDay51);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertNotNull(gJChronology60);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(durationField63);
        org.junit.Assert.assertNotNull(durationField64);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 3600001L + "'", long67 == 3600001L);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField68);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        long long14 = skipDateTimeField11.add((long) '4', (int) (short) 1);
        boolean boolean15 = skipDateTimeField11.isSupported();
        int int17 = skipDateTimeField11.get((long) 1);
        boolean boolean18 = skipDateTimeField11.isLenient();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1052L + "'", long14 == 1052L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) 'a');
        org.joda.time.DateTime.Property property6 = dateTime3.hourOfDay();
        org.joda.time.DateTime dateTime8 = dateTime3.withMillis((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime10.withMinuteOfHour((int) (byte) 1);
        boolean boolean13 = dateTime12.isEqualNow();
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime3, (org.joda.time.ReadableInstant) dateTime12);
        try {
            org.joda.time.DateTime dateTime16 = dateTime3.withDayOfWeek(29);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 29 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 'a', dateTimeZone1);
        int int3 = dateTime2.getEra();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
        int int8 = dateTimeZone5.getOffsetFromLocal(100L);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology10 = gJChronology1.withZone(dateTimeZone5);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology1);
        try {
            long long16 = gJChronology1.getDateTimeMillis(75693, 0, 109, 59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone2.getShortName((long) 0, locale4);
        java.lang.String str6 = dateTimeZone2.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone2);
        org.joda.time.Instant instant8 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTime dateTime9 = instant8.toDateTimeISO();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-00:00:00.001" + "'", str5.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.001" + "'", str6.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime6 = dateTime3.withSecondOfMinute(0);
        org.joda.time.DateTime dateTime8 = dateTime3.plusMillis(15);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = null;
        java.lang.String str10 = dateTime8.toString(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970-01-01T00:01:15.692-00:00:00.001" + "'", str10.equals("1970-01-01T00:01:15.692-00:00:00.001"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay0.getFieldType(0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.hours();
        org.joda.time.DurationField durationField9 = gJChronology6.millis();
        java.lang.Object obj10 = null;
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField9, obj10);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField12 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField9);
        boolean boolean13 = unsupportedDateTimeField12.isLenient();
        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.MonthDay monthDay16 = monthDay14.plus(readablePeriod15);
        org.joda.time.MonthDay monthDay18 = monthDay14.plusDays(0);
        int[] intArray25 = new int[] { (-1), 160, 75671, 75703, 75700, 75687 };
        try {
            int int26 = unsupportedDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) monthDay14, intArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DurationField durationField3 = gJChronology1.hours();
        org.joda.time.DurationField durationField4 = gJChronology1.months();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology11);
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology11.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology11.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology6, dateTimeField14, (int) ' ');
        long long18 = skipDateTimeField16.roundHalfCeiling((long) (-1));
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipDateTimeField16);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime11 = dateTime9.plusHours((int) 'a');
        int int12 = dateTime9.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime9.plus(readablePeriod13);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime9.withPeriodAdded(readablePeriod15, (int) 'a');
        boolean boolean18 = dateTime3.isBefore((org.joda.time.ReadableInstant) dateTime9);
        java.lang.String str19 = dateTimeFormatter1.print((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTimeZone dateTimeZone20 = dateTimeFormatter1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter1.withPivotYear((java.lang.Integer) 0);
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
        java.util.Locale locale27 = null;
        java.lang.String str28 = dateTimeZone25.getShortName((long) 0, locale27);
        java.lang.String str29 = dateTimeZone25.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology30 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology23, dateTimeZone25);
        org.joda.time.Instant instant31 = gJChronology23.getGregorianCutover();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gJChronology23);
        try {
            org.joda.time.MutableDateTime mutableDateTime34 = dateTimeFormatter1.parseMutableDateTime("0010-06-19");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"0010-06-19\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1970-01-01T00:01" + "'", str19.equals("1970-01-01T00:01"));
        org.junit.Assert.assertNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-00:00:00.001" + "'", str28.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "-00:00:00.001" + "'", str29.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology30);
        org.junit.Assert.assertNotNull(instant31);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.Chronology chronology3 = gJChronology1.withUTC();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) 'a');
        int int10 = dateTime7.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime7.plus(readablePeriod11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime15 = dateTime7.withPeriodAdded(readablePeriod13, (int) 'a');
        boolean boolean16 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime18 = dateTime7.minus(0L);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime20.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime24 = dateTime22.plusHours((int) 'a');
        int int25 = dateTime22.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime27 = dateTime22.plus(readablePeriod26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime30 = dateTime22.withPeriodAdded(readablePeriod28, (int) 'a');
        org.joda.time.DateTime.Property property31 = dateTime22.dayOfMonth();
        boolean boolean32 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime dateTime34 = dateTime22.withDayOfMonth(10);
        org.joda.time.DateTimeZone dateTimeZone35 = dateTime22.getZone();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.ReadableInstant readableInstant6 = null;
        long long7 = property5.getDifferenceAsLong(readableInstant6);
        int int8 = property5.getMaximumValueOverall();
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.MonthDay monthDay11 = monthDay9.plus(readablePeriod10);
        org.joda.time.MonthDay.Property property12 = monthDay9.monthOfYear();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.MonthDay monthDay14 = monthDay9.withChronologyRetainFields(chronology13);
        boolean boolean15 = property5.equals((java.lang.Object) monthDay14);
        try {
            org.joda.time.DateTime dateTime17 = property5.setCopy("Dec");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Dec\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2922789 + "'", int8 == 2922789);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) ' ', 3480);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendMillisOfDay(12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.lang.String str2 = dateTimeZone0.getName((long) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
        long long7 = dateTimeZone0.getMillisKeepLocal(dateTimeZone4, 0L);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-00:00:00.001" + "'", str2.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(copticChronology8);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime5 = dateTime3.plusHours((int) 'a');
        int int6 = dateTime3.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime3.plus(readablePeriod7);
        int int9 = dateTime8.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        org.joda.time.DateTime dateTime12 = dateTime8.withWeekyear((int) (short) 1);
        org.joda.time.DateTime dateTime14 = dateTime8.withYear((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 75 + "'", int9 == 75);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay0.getFieldType(0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.hours();
        org.joda.time.DurationField durationField9 = gJChronology6.millis();
        java.lang.Object obj10 = null;
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField9, obj10);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField12 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField9);
        try {
            java.lang.String str14 = unsupportedDateTimeField12.getAsShortText((long) 2922789);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField12);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 2, 75678);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 151356L + "'", long2 == 151356L);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        long long14 = skipDateTimeField11.add((long) '4', (int) (short) 1);
        boolean boolean15 = skipDateTimeField11.isSupported();
        int int18 = skipDateTimeField11.getDifference((long) (byte) 1, (-3480001L));
        org.joda.time.MonthDay monthDay19 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.MonthDay monthDay21 = monthDay19.plus(readablePeriod20);
        org.joda.time.MonthDay monthDay23 = monthDay19.plusDays(0);
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay23, (int) (byte) 10, locale25);
        long long29 = skipDateTimeField11.addWrapField(75715L, 75714);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
        java.util.Locale locale34 = null;
        java.lang.String str35 = dateTimeZone32.getShortName((long) 0, locale34);
        java.lang.String str36 = dateTimeZone32.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology37 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology30, dateTimeZone32);
        org.joda.time.MonthDay monthDay38 = new org.joda.time.MonthDay(dateTimeZone32);
        java.util.Locale locale39 = null;
        try {
            java.lang.String str40 = skipDateTimeField11.getAsText((org.joda.time.ReadablePartial) monthDay38, locale39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfMinute' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1052L + "'", long14 == 1052L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3480 + "'", int18 == 3480);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "10" + "'", str26.equals("10"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 69715L + "'", long29 == 69715L);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "-00:00:00.001" + "'", str35.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "-00:00:00.001" + "'", str36.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology37);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone2.getShortName((long) 0, locale4);
        java.lang.String str6 = dateTimeZone2.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone2);
        org.joda.time.Instant instant8 = gJChronology0.getGregorianCutover();
        try {
            long long16 = gJChronology0.getDateTimeMillis(12, (int) (byte) 1, 0, 75671436, 66, (int) (short) 0, 60);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 75671436 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-00:00:00.001" + "'", str5.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.001" + "'", str6.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        long long13 = skipDateTimeField11.roundHalfFloor(0L);
        java.util.Locale locale16 = null;
        try {
            long long17 = skipDateTimeField11.set(1560632519004L, "BuddhistChronology[-00:00:00.001]", locale16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"BuddhistChronology[-00:00:00.001]\" for secondOfMinute is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay monthDay4 = monthDay0.minusDays(1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay6 = monthDay4.minus(readablePeriod5);
        int int7 = monthDay6.getDayOfMonth();
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-52) + "'", int1 == (-52));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        java.util.Locale locale6 = null;
        java.lang.String str7 = property3.getAsText(locale6);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "January" + "'", str5.equals("January"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January" + "'", str7.equals("January"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay0.getFieldType(0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.hours();
        org.joda.time.DurationField durationField9 = gJChronology6.millis();
        java.lang.Object obj10 = null;
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField9, obj10);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField12 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField9);
        boolean boolean13 = unsupportedDateTimeField12.isLenient();
        try {
            long long15 = unsupportedDateTimeField12.roundHalfFloor(1560632466320L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay4 = monthDay2.plus(readablePeriod3);
        org.joda.time.MonthDay.Property property5 = monthDay2.monthOfYear();
        java.util.Locale locale6 = null;
        java.lang.String str7 = property5.getAsText(locale6);
        org.joda.time.MonthDay monthDay9 = property5.addToCopy((int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property5.getFieldType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField12 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType10, 75703);
        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay15 = monthDay13.plus(readablePeriod14);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = monthDay13.getFieldType(0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField18 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField12, dateTimeFieldType17);
        long long21 = remainderDateTimeField12.addWrapField((long) 3480, 2);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "January" + "'", str7.equals("January"));
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 172803480L + "'", long21 == 172803480L);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.JodaTimePermission jodaTimePermission2 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission4 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean5 = jodaTimePermission2.implies((java.security.Permission) jodaTimePermission4);
        org.joda.time.JodaTimePermission jodaTimePermission7 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission9 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean10 = jodaTimePermission7.implies((java.security.Permission) jodaTimePermission9);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        java.util.Locale locale14 = null;
        java.lang.String str15 = dateTimeZone12.getShortName((long) 0, locale14);
        java.lang.String str16 = dateTimeZone12.getID();
        jodaTimePermission7.checkGuard((java.lang.Object) dateTimeZone12);
        java.lang.String str18 = jodaTimePermission7.getName();
        boolean boolean19 = jodaTimePermission2.implies((java.security.Permission) jodaTimePermission7);
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime21.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime25 = dateTime23.plusHours((int) 'a');
        org.joda.time.DateTime.Property property26 = dateTime23.hourOfDay();
        org.joda.time.DateTime dateTime28 = dateTime23.withMillis((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone29);
        org.joda.time.DateTime dateTime32 = dateTime30.withMinuteOfHour((int) (byte) 1);
        boolean boolean33 = dateTime32.isEqualNow();
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime23, (org.joda.time.ReadableInstant) dateTime32);
        boolean boolean35 = jodaTimePermission2.equals((java.lang.Object) chronology34);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter0.withChronology(chronology34);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-00:00:00.001" + "'", str15.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-00:00:00.001" + "'", str16.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        boolean boolean4 = dateTime3.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime7 = dateTime3.plusMinutes((int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology2, dateTimeZone4);
        org.joda.time.Chronology chronology6 = zonedChronology5.withUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = zonedChronology5.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay0.getFieldType(0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.hours();
        org.joda.time.DurationField durationField9 = gJChronology6.millis();
        java.lang.Object obj10 = null;
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField9, obj10);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField12 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField9);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = unsupportedDateTimeField12.getType();
        try {
            boolean boolean15 = unsupportedDateTimeField12.isLeap((long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone2.getShortName((long) 0, locale4);
        java.lang.String str6 = dateTimeZone2.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone2);
        org.joda.time.Instant instant8 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-00:00:00.001" + "'", str5.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.001" + "'", str6.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone2.getShortName((long) 0, locale4);
        java.lang.String str6 = dateTimeZone2.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone2);
        org.joda.time.Instant instant8 = gJChronology0.getGregorianCutover();
        long long9 = instant8.getMillis();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Instant instant11 = instant8.plus(readableDuration10);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-00:00:00.001" + "'", str5.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.001" + "'", str6.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-12219292800000L) + "'", long9 == (-12219292800000L));
        org.junit.Assert.assertNotNull(instant11);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = dateTime5.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime7.plusHours((int) 'a');
        int int10 = dateTime7.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime7.plus(readablePeriod11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime15 = dateTime7.withPeriodAdded(readablePeriod13, (int) 'a');
        boolean boolean16 = dateTime1.isBefore((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.MonthDay monthDay19 = monthDay17.plus(readablePeriod18);
        org.joda.time.MonthDay monthDay21 = monthDay17.minusDays(1);
        int int22 = monthDay17.getDayOfMonth();
        org.joda.time.DateTime dateTime23 = dateTime7.withFields((org.joda.time.ReadablePartial) monthDay17);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime25.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(dateTimeZone28);
        org.joda.time.DateTime dateTime31 = dateTime29.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime33 = dateTime31.plusHours((int) 'a');
        int int34 = dateTime31.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime31.plus(readablePeriod35);
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.DateTime dateTime39 = dateTime31.withPeriodAdded(readablePeriod37, (int) 'a');
        boolean boolean40 = dateTime25.isBefore((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.MonthDay monthDay41 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod42 = null;
        org.joda.time.MonthDay monthDay43 = monthDay41.plus(readablePeriod42);
        org.joda.time.MonthDay monthDay45 = monthDay41.minusDays(1);
        int int46 = monthDay41.getDayOfMonth();
        org.joda.time.DateTime dateTime47 = dateTime31.withFields((org.joda.time.ReadablePartial) monthDay41);
        org.joda.time.DateTime dateTime49 = dateTime47.withWeekyear(10);
        boolean boolean50 = dateTime7.isBefore((org.joda.time.ReadableInstant) dateTime49);
        int int51 = dateTime49.getHourOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertNotNull(monthDay43);
        org.junit.Assert.assertNotNull(monthDay45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime6 = dateTime3.withSecondOfMinute(0);
        org.joda.time.DateTime dateTime8 = dateTime3.plus(32L);
        org.joda.time.DateTime dateTime10 = dateTime3.minusYears((int) (byte) 0);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.minus(readableDuration11);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology1.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology6.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField9, (int) ' ');
        boolean boolean12 = skipDateTimeField11.isSupported();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("--09-01", (int) (short) -1, 82919, (int) '#', ' ', 31, 1, 0, true, (int) (byte) 10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder11.setFixedSavings("GregorianChronology[-00:00:00.001]", 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder14.setStandardOffset(7);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder16.setFixedSavings("0", 522);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder14);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder16);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay0.getFieldType(0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.hours();
        org.joda.time.DurationField durationField9 = gJChronology6.millis();
        java.lang.Object obj10 = null;
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField9, obj10);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField12 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField9);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = unsupportedDateTimeField12.getType();
        org.joda.time.ReadablePartial readablePartial14 = null;
        java.util.Locale locale16 = null;
        try {
            java.lang.String str17 = unsupportedDateTimeField12.getAsShortText(readablePartial14, 60, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withWeekOfWeekyear((int) '4');
        int int4 = dateTime3.getMinuteOfHour();
        long long5 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime3);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 30844875678L + "'", long5 == 30844875678L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        int int7 = property4.getMinimumValueOverall();
        org.joda.time.DurationField durationField8 = property4.getDurationField();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "AD" + "'", str6.equals("AD"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        java.util.Locale locale6 = null;
        java.lang.String str7 = property3.getAsShortText(locale6);
        java.util.Locale locale8 = null;
        java.lang.String str9 = property3.getAsShortText(locale8);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "January" + "'", str5.equals("January"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Jan" + "'", str7.equals("Jan"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Jan" + "'", str9.equals("Jan"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.year();
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime6 = dateTime4.plusHours((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime4.hourOfDay();
        org.joda.time.DateTime dateTime9 = dateTime4.plusYears((int) (short) 0);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology11);
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone15);
        int int18 = dateTimeZone15.getOffsetFromLocal(100L);
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.Chronology chronology20 = gJChronology11.withZone(dateTimeZone15);
        org.joda.time.DateTime dateTime21 = dateTime4.withZone(dateTimeZone15);
        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone15);
        java.util.Locale locale24 = null;
        java.lang.String str25 = dateTimeZone15.getName(0L, locale24);
        try {
            org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((java.lang.Object) 0.0d, dateTimeZone15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Double");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(buddhistChronology22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "-00:00:00.001" + "'", str25.equals("-00:00:00.001"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTime dateTime3 = dateTime1.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTimeField dateTimeField5 = null;
        try {
            int int6 = dateTime3.get(dateTimeField5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeField must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendHourOfHalfday((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfYear((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendWeekyear(24, 3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter10 = dateTimeFormatter9.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.append(dateTimePrinter10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendWeekyear(60, 1582);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimePrinter10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("ZonedChronology[BuddhistChronology[UTC], -00:00:00.001]", (java.lang.Number) 0.0d, (java.lang.Number) 82919, number3);
        java.lang.String str5 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number6 = illegalFieldValueException4.getLowerBound();
        illegalFieldValueException4.prependMessage("ISOChronology[-00:00:00.001]");
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0.0" + "'", str5.equals("0.0"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 82919 + "'", number6.equals(82919));
        org.junit.Assert.assertNull(dateTimeFieldType9);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        long long5 = dateTimeZone1.convertLocalToUTC((long) (byte) 100, false, (long) 'a');
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime11 = dateTime9.plusHours((int) 'a');
        int int12 = dateTime9.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime9.plus(readablePeriod13);
        org.joda.time.LocalDate localDate15 = dateTime14.toLocalDate();
        int int16 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime14);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 75661);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 75661");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 101L + "'", long5 == 101L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfHour((-52));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, 0, 4, 31, 100, 75, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        long long5 = gJChronology1.add((-1L), (long) (byte) 0, 7);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        int int4 = dateTimeZone1.getOffsetFromLocal(100L);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology6 = julianChronology5.withUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime12 = dateTime10.plusHours((int) 'a');
        int int13 = dateTime10.getWeekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime10.plus(readablePeriod14);
        int int16 = dateTime15.getSecondOfDay();
        org.joda.time.DateTimeZone dateTimeZone17 = dateTime15.getZone();
        long long21 = dateTimeZone17.convertLocalToUTC((long) 75714, true, (-1000L));
        org.joda.time.Chronology chronology22 = julianChronology5.withZone(dateTimeZone17);
        int int23 = julianChronology5.getMinimumDaysInFirstWeek();
        int int24 = julianChronology5.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 75 + "'", int16 == 75);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 75715L + "'", long21 == 75715L);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) buddhistChronology2, dateTimeZone4);
        java.lang.String str6 = buddhistChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = dateTimeZone8.getShortName((long) 0, locale10);
        java.lang.String str12 = dateTimeZone8.getID();
        org.joda.time.LocalDateTime localDateTime13 = null;
        boolean boolean14 = dateTimeZone8.isLocalDateTimeGap(localDateTime13);
        org.joda.time.Chronology chronology15 = buddhistChronology2.withZone(dateTimeZone8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        java.lang.String str18 = cachedDateTimeZone16.getNameKey(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "BuddhistChronology[-00:00:00.001]" + "'", str6.equals("BuddhistChronology[-00:00:00.001]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-00:00:00.001" + "'", str11.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-00:00:00.001" + "'", str12.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone2.getShortName((long) 0, locale4);
        java.lang.String str6 = dateTimeZone2.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology7 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology0, dateTimeZone2);
        org.joda.time.Instant instant8 = gJChronology0.getGregorianCutover();
        long long9 = instant8.getMillis();
        org.joda.time.Chronology chronology10 = instant8.getChronology();
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Instant instant12 = instant8.plus(readableDuration11);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-00:00:00.001" + "'", str5.equals("-00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-00:00:00.001" + "'", str6.equals("-00:00:00.001"));
        org.junit.Assert.assertNotNull(zonedChronology7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-12219292800000L) + "'", long9 == (-12219292800000L));
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(instant12);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay0.getFieldType(0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.hours();
        org.joda.time.DurationField durationField9 = gJChronology6.millis();
        java.lang.Object obj10 = null;
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField9, obj10);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField12 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField9);
        org.joda.time.DurationField durationField13 = unsupportedDateTimeField12.getLeapDurationField();
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField12.getDurationField();
        org.joda.time.MonthDay monthDay15 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.MonthDay monthDay17 = monthDay15.plus(readablePeriod16);
        org.joda.time.MonthDay.Property property18 = monthDay15.monthOfYear();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property18.getAsText(locale19);
        org.joda.time.MonthDay monthDay22 = property18.addWrapFieldToCopy((int) (byte) 1);
        int[] intArray24 = null;
        try {
            int[] intArray26 = unsupportedDateTimeField12.add((org.joda.time.ReadablePartial) monthDay22, 75, intArray24, 75693);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField12);
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "January" + "'", str20.equals("January"));
        org.junit.Assert.assertNotNull(monthDay22);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.MonthDay.Property property3 = monthDay0.monthOfYear();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property3.getAsText(locale4);
        org.joda.time.MonthDay monthDay7 = property3.setCopy((int) (byte) 10);
        java.util.Locale locale8 = null;
        int int9 = property3.getMaximumTextLength(locale8);
        java.util.Locale locale10 = null;
        java.lang.String str11 = property3.getAsText(locale10);
        int int12 = property3.getMinimumValueOverall();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone14);
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now(dateTimeZone14);
        boolean boolean17 = property3.equals((java.lang.Object) dateTimeZone14);
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now(dateTimeZone14);
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("-00:00:00.001", "", (int) (short) 100, (int) (short) -1);
        java.util.TimeZone timeZone25 = fixedDateTimeZone24.toTimeZone();
        long long28 = fixedDateTimeZone24.convertLocalToUTC((long) 75718, false);
        org.joda.time.Chronology chronology29 = copticChronology19.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
        org.joda.time.DateTime dateTime33 = dateTime31.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime35 = dateTime33.plusHours((int) 'a');
        org.joda.time.DateTime.Property property36 = dateTime33.hourOfDay();
        int int37 = dateTime33.getEra();
        int int38 = dateTime33.getHourOfDay();
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone24, (org.joda.time.ReadableInstant) dateTime33);
        java.util.TimeZone timeZone40 = fixedDateTimeZone24.toTimeZone();
        long long42 = fixedDateTimeZone24.nextTransition((long) 75700);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "January" + "'", str5.equals("January"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "January" + "'", str11.equals("January"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 75618L + "'", long28 == 75618L);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 75700L + "'", long42 == 75700L);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.MonthDay monthDay2 = monthDay0.plus(readablePeriod1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay0.getFieldType(0);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology6);
        org.joda.time.DurationField durationField8 = gJChronology6.hours();
        org.joda.time.DurationField durationField9 = gJChronology6.millis();
        java.lang.Object obj10 = null;
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationField9, obj10);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField12 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType4, durationField9);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = unsupportedDateTimeField12.getType();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) -1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone15);
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now(dateTimeZone15);
        java.util.Locale locale18 = null;
        try {
            java.lang.String str19 = unsupportedDateTimeField12.getAsText((org.joda.time.ReadablePartial) monthDay17, locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: monthOfYear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(monthDay17);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(75674, 75693, (int) '#', 7, 75686, 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 75686 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology2);
        org.joda.time.DateTimeZone dateTimeZone4 = gJChronology2.getZone();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology2.secondOfMinute();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((java.lang.Object) 100L, (org.joda.time.Chronology) gJChronology7);
        org.joda.time.DateTimeZone dateTimeZone9 = gJChronology7.getZone();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology7.secondOfMinute();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField10, (int) ' ');
        long long15 = skipDateTimeField12.add((long) '4', (int) (short) 1);
        boolean boolean16 = skipDateTimeField12.isSupported();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField(chronology0, (org.joda.time.DateTimeField) skipDateTimeField12, 2922789);
        org.joda.time.DurationField durationField19 = skipDateTimeField18.getRangeDurationField();
        boolean boolean21 = skipDateTimeField18.isLeap((long) 75690);
        java.util.Locale locale23 = null;
        java.lang.String str24 = skipDateTimeField18.getAsShortText((long) 25, locale23);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1052L + "'", long15 == 1052L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "0" + "'", str24.equals("0"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 'a', dateTimeZone1);
        int int3 = dateTime2.getEra();
        int int4 = dateTime2.getDayOfMonth();
        int int5 = dateTime2.getMillisOfDay();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 96 + "'", int5 == 96);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        try {
            org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }
}

