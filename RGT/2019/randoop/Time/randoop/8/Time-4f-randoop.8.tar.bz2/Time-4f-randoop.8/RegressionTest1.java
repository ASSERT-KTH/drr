import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        long long5 = delegatedDateTimeField2.remainder((long) 4);
        java.lang.String str7 = delegatedDateTimeField2.getAsText((long) 0);
        long long10 = delegatedDateTimeField2.add((long) 3, (long) 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 4L + "'", long5 == 4L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "20" + "'", str7.equals("20"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3L + "'", long10 == 3L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTime dateTime8 = dateTime2.toDateTime((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology10);
        java.lang.String str12 = dateTime11.toString();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.plus(readablePeriod13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16);
        org.joda.time.DurationField durationField18 = delegatedDateTimeField17.getLeapDurationField();
        int int21 = delegatedDateTimeField17.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = delegatedDateTimeField17.getType();
        int int23 = dateTime14.get(dateTimeFieldType22);
        boolean boolean24 = dateTime8.isAfter((org.joda.time.ReadableInstant) dateTime14);
        int int25 = dateTime14.getEra();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1970 + "'", int3 == 1970);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str12.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 20 + "'", int23 == 20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.millisOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.hourOfDay();
        try {
            org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((java.lang.Object) gregorianChronology0, (org.joda.time.Chronology) gregorianChronology5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.chrono.GregorianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        boolean boolean10 = localDate3.equals((java.lang.Object) 100.0f);
        int int11 = localDate3.getYear();
        int int12 = localDate3.getDayOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("ISOChronology[UTC]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendMillisOfDay((int) 'a');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder2.appendTimeZoneOffset("1970-01-01T00:00:00.010Z", "1970-01-01", false, (int) (short) -1, 99);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfDay(2, (-520));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendMillisOfSecond((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(19, true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long12 = dateTimeZone8.getMillisKeepLocal(dateTimeZone10, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter6.withZone(dateTimeZone10);
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10, 4);
        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now(dateTimeZone10);
        java.util.Locale locale18 = null;
        java.lang.String str19 = dateTimeZone10.getName((long) (byte) 0, locale18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long25 = dateTimeZone21.getMillisKeepLocal(dateTimeZone23, (long) (short) 0);
        org.joda.time.LocalDateTime localDateTime26 = null;
        boolean boolean27 = dateTimeZone23.isLocalDateTimeGap(localDateTime26);
        long long29 = dateTimeZone10.getMillisKeepLocal(dateTimeZone23, 978307194800L);
        try {
            org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((int) (byte) 1, 24, 2, (int) (short) -1, (int) (short) -1, (int) (short) 100, dateTimeZone23);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+00:00:00.100" + "'", str19.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 978307194800L + "'", long29 == 978307194800L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(10L, dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(10L, dateTimeZone15);
        boolean boolean17 = localDate12.isAfter((org.joda.time.ReadablePartial) localDate16);
        boolean boolean18 = localDate7.isBefore((org.joda.time.ReadablePartial) localDate12);
        org.joda.time.Partial partial19 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = partial19.getFormatter();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22);
        org.joda.time.DurationField durationField24 = delegatedDateTimeField23.getLeapDurationField();
        int int27 = delegatedDateTimeField23.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField23.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, "Property[monthOfYear]");
        try {
            org.joda.time.Partial.Property property31 = partial19.property(dateTimeFieldType28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'centuryOfEra' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNull(durationField24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("ISOChronology[UTC]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendDayOfYear((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        boolean boolean10 = localDate3.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        int int17 = delegatedDateTimeField13.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = delegatedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property21 = localDate3.property(dateTimeFieldType18);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.LocalDate localDate23 = localDate3.plus(readablePeriod22);
        int int24 = localDate23.getDayOfYear();
        int int25 = localDate23.getEra();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology3.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology1, dateTimeField4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField5, 4);
        int int9 = offsetDateTimeField7.getLeapAmount(100L);
        boolean boolean10 = offsetDateTimeField7.isSupported();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(10L, dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(10L, dateTimeZone17);
        boolean boolean19 = localDate14.isAfter((org.joda.time.ReadablePartial) localDate18);
        boolean boolean21 = localDate14.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField23);
        org.joda.time.DurationField durationField25 = delegatedDateTimeField24.getLeapDurationField();
        int int28 = delegatedDateTimeField24.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = delegatedDateTimeField24.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property32 = localDate14.property(dateTimeFieldType29);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate(10L, dateTimeZone35);
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate40 = new org.joda.time.LocalDate(10L, dateTimeZone39);
        boolean boolean41 = localDate36.isAfter((org.joda.time.ReadablePartial) localDate40);
        boolean boolean43 = localDate36.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology44.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField46 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField45);
        org.joda.time.DurationField durationField47 = delegatedDateTimeField46.getLeapDurationField();
        int int50 = delegatedDateTimeField46.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = delegatedDateTimeField46.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException53 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType51, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property54 = localDate36.property(dateTimeFieldType51);
        boolean boolean55 = localDate14.isSupported(dateTimeFieldType51);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType51, 19);
        org.joda.time.ReadablePartial readablePartial58 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology59 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology59.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField62 = gJChronology61.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField63 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology59, dateTimeField62);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField63, 4);
        int int67 = offsetDateTimeField65.getLeapAmount(100L);
        java.util.Locale locale69 = null;
        java.lang.String str70 = offsetDateTimeField65.getAsShortText((long) 1, locale69);
        boolean boolean72 = offsetDateTimeField65.isLeap(0L);
        java.util.Locale locale74 = null;
        java.lang.String str75 = offsetDateTimeField65.getAsShortText((int) (byte) -1, locale74);
        org.joda.time.DateTimeZone dateTimeZone78 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate79 = new org.joda.time.LocalDate(10L, dateTimeZone78);
        org.joda.time.chrono.GregorianChronology gregorianChronology80 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField81 = gregorianChronology80.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField82 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField81);
        org.joda.time.DurationField durationField83 = delegatedDateTimeField82.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType84 = delegatedDateTimeField82.getType();
        int int85 = localDate79.get(dateTimeFieldType84);
        org.joda.time.ReadablePeriod readablePeriod86 = null;
        org.joda.time.LocalDate localDate87 = localDate79.plus(readablePeriod86);
        int[] intArray94 = new int[] { 2922790, (short) 10, 24, (short) 100, 2019, 20 };
        int int95 = offsetDateTimeField65.getMaximumValue((org.joda.time.ReadablePartial) localDate79, intArray94);
        int int96 = offsetDateTimeField57.getMinimumValue(readablePartial58, intArray94);
        try {
            org.joda.time.Partial partial97 = new org.joda.time.Partial(dateTimeFieldTypeArray0, intArray94);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNull(durationField25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(gregorianChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNull(durationField47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(gregorianChronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(gJChronology61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "5" + "'", str70.equals("5"));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "-1" + "'", str75.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeZone78);
        org.junit.Assert.assertNotNull(gregorianChronology80);
        org.junit.Assert.assertNotNull(dateTimeField81);
        org.junit.Assert.assertNull(durationField83);
        org.junit.Assert.assertNotNull(dateTimeFieldType84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 19 + "'", int85 == 19);
        org.junit.Assert.assertNotNull(localDate87);
        org.junit.Assert.assertNotNull(intArray94);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 57 + "'", int95 == 57);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 24 + "'", int96 == 24);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        java.lang.String str3 = dateTime2.toString();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        int int6 = dateTime5.getMillisOfSecond();
        int int7 = dateTime5.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str3.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (int) (byte) 100, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        int int6 = delegatedDateTimeField2.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = delegatedDateTimeField2.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Property[monthOfYear]");
        java.lang.Number number10 = illegalFieldValueException9.getUpperBound();
        org.joda.time.IllegalInstantException illegalInstantException12 = new org.joda.time.IllegalInstantException("1970-01-01T00:00:00.010Z");
        org.joda.time.IllegalInstantException illegalInstantException14 = new org.joda.time.IllegalInstantException("1970-01-01T00:00:00.010Z");
        illegalInstantException12.addSuppressed((java.lang.Throwable) illegalInstantException14);
        java.lang.String str16 = illegalInstantException12.toString();
        illegalFieldValueException9.addSuppressed((java.lang.Throwable) illegalInstantException12);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = illegalFieldValueException9.getDateTimeFieldType();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.joda.time.IllegalInstantException: 1970-01-01T00:00:00.010Z" + "'", str16.equals("org.joda.time.IllegalInstantException: 1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 3213215999999L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        boolean boolean10 = localDate3.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        int int17 = delegatedDateTimeField13.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = delegatedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property21 = localDate3.property(dateTimeFieldType18);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.centuryOfEra();
        org.joda.time.DurationField durationField24 = gregorianChronology22.weekyears();
        org.joda.time.DurationField durationField25 = gregorianChronology22.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField25);
        try {
            int int28 = unsupportedDateTimeField26.getMaximumValue(31556995200100L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        java.lang.String str3 = dateTime2.toString();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.minus(0L);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillisOfSecond((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime7.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str3.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField3);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4);
        int int6 = delegatedDateTimeField5.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(24);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTimeZoneId();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneShortName(strMap6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(10L, dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField8.getType();
        int int11 = localDate5.get(dateTimeFieldType10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType10, 5);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        org.joda.time.DurationField durationField17 = delegatedDateTimeField16.getLeapDurationField();
        int int19 = delegatedDateTimeField16.getLeapAmount((long) (-1));
        long long21 = delegatedDateTimeField16.roundFloor((long) 3);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(10L, dateTimeZone24);
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField27);
        org.joda.time.DurationField durationField29 = delegatedDateTimeField28.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = delegatedDateTimeField28.getType();
        int int31 = localDate25.get(dateTimeFieldType30);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField16, dateTimeFieldType30, 100);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField34 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField13, dateTimeFieldType30);
        long long37 = dividedDateTimeField34.add((long) (byte) -1, (int) (byte) 10);
        org.joda.time.DurationField durationField38 = dividedDateTimeField34.getRangeDurationField();
        int int39 = dividedDateTimeField34.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-2177452800000L) + "'", long21 == (-2177452800000L));
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 19 + "'", int31 == 19);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 30239999999L + "'", long37 == 30239999999L);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        boolean boolean10 = localDate3.equals((java.lang.Object) 100.0f);
        int int11 = localDate3.getYear();
        boolean boolean13 = localDate3.equals((java.lang.Object) 1L);
        org.joda.time.LocalDate.Property property14 = localDate3.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long20 = dateTimeZone16.getMillisKeepLocal(dateTimeZone18, (long) (short) 0);
        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now(dateTimeZone16);
        org.joda.time.DateTime dateTime22 = localDate3.toDateTimeAtStartOfDay(dateTimeZone16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendClockhourOfHalfday(24);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap26 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder25.appendTimeZoneName(strMap26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.appendTimeZoneId();
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField30);
        org.joda.time.DurationField durationField32 = delegatedDateTimeField31.getLeapDurationField();
        int int35 = delegatedDateTimeField31.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = delegatedDateTimeField31.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder25.appendFixedSignedDecimal(dateTimeFieldType36, 2019);
        int int39 = localDate3.get(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 19 + "'", int39 == 19);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        int int9 = localDate3.getEra();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.LocalDate localDate11 = localDate3.minus(readablePeriod10);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = gJChronology12.getZone();
        org.joda.time.Interval interval14 = localDate3.toInterval(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(interval14);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(10L, dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(10L, dateTimeZone15);
        boolean boolean17 = localDate12.isAfter((org.joda.time.ReadablePartial) localDate16);
        boolean boolean18 = localDate7.isBefore((org.joda.time.ReadablePartial) localDate12);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology20);
        java.lang.String str22 = dateTime21.toString();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime24 = dateTime21.plus(readablePeriod23);
        org.joda.time.DateTime dateTime25 = localDate12.toDateTime((org.joda.time.ReadableInstant) dateTime21);
        int int27 = localDate12.getValue(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.appendClockhourOfHalfday(24);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap31 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder30.appendTimeZoneName(strMap31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder30.appendTimeZoneId();
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField35);
        org.joda.time.DurationField durationField37 = delegatedDateTimeField36.getLeapDurationField();
        int int40 = delegatedDateTimeField36.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = delegatedDateTimeField36.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder30.appendFixedSignedDecimal(dateTimeFieldType41, 2019);
        int int44 = localDate12.get(dateTimeFieldType41);
        org.joda.time.DateMidnight dateMidnight45 = localDate12.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str22.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNull(durationField37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 19 + "'", int44 == 19);
        org.junit.Assert.assertNotNull(dateMidnight45);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((-210863995200000L));
        org.joda.time.LocalDate.Property property2 = localDate1.dayOfWeek();
        org.joda.time.LocalDate localDate4 = localDate1.withWeekyear((-520));
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        boolean boolean10 = localDate3.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        int int17 = delegatedDateTimeField13.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = delegatedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property21 = localDate3.property(dateTimeFieldType18);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.centuryOfEra();
        org.joda.time.DurationField durationField24 = gregorianChronology22.weekyears();
        org.joda.time.DurationField durationField25 = gregorianChronology22.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField25);
        org.joda.time.ReadablePartial readablePartial27 = null;
        java.util.Locale locale28 = null;
        try {
            java.lang.String str29 = unsupportedDateTimeField26.getAsShortText(readablePartial27, locale28);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long6 = dateTimeZone2.getMillisKeepLocal(dateTimeZone4, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone4);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4, 4);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long19 = dateTimeZone15.getMillisKeepLocal(dateTimeZone17, (long) (short) 0);
        long long21 = dateTimeZone12.getMillisKeepLocal(dateTimeZone17, (long) 100);
        org.joda.time.Chronology chronology22 = julianChronology9.withZone(dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology9.getZone();
        int int24 = julianChronology9.getMinimumDaysInFirstWeek();
        try {
            long long32 = julianChronology9.getDateTimeMillis(292279000, 99, 4, 18, (int) (short) 10, (int) 'a', 2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        java.lang.String str3 = dateTimeZone1.getShortName(0L);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.100" + "'", str3.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(24);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-24) + "'", int1 == (-24));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        java.lang.String str3 = dateTime2.toString();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getLeapDurationField();
        int int12 = delegatedDateTimeField8.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField8.getType();
        int int14 = dateTime5.get(dateTimeFieldType13);
        org.joda.time.DateTime dateTime16 = dateTime5.plusMonths((int) (short) 1);
        org.joda.time.DateTime dateTime18 = dateTime16.withYearOfCentury(10);
        boolean boolean20 = dateTime18.isBefore((long) (byte) 1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str3.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 20 + "'", int14 == 20);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField3);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, 4);
        int int8 = offsetDateTimeField6.getLeapAmount(100L);
        boolean boolean9 = offsetDateTimeField6.isSupported();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(10L, dateTimeZone16);
        boolean boolean18 = localDate13.isAfter((org.joda.time.ReadablePartial) localDate17);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray19 = localDate13.getFieldTypes();
        int[] intArray20 = new int[] {};
        int int21 = offsetDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) localDate13, intArray20);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField6.getAsText((int) (byte) 1, locale23);
        long long26 = offsetDateTimeField6.roundHalfCeiling((long) 1);
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField6.getAsText((int) (byte) 1, locale28);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1" + "'", str24.equals("1"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-259200000L) + "'", long26 == (-259200000L));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1" + "'", str29.equals("1"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(24);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder2.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendTimeZoneShortName(strMap8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(strMap8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        boolean boolean10 = localDate3.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        int int17 = delegatedDateTimeField13.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = delegatedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property21 = localDate3.property(dateTimeFieldType18);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.LocalDate localDate23 = localDate3.plus(readablePeriod22);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long30 = dateTimeZone26.getMillisKeepLocal(dateTimeZone28, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter24.withZone(dateTimeZone28);
        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone28, 4);
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate(10L, dateTimeZone36);
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long43 = dateTimeZone39.getMillisKeepLocal(dateTimeZone41, (long) (short) 0);
        long long45 = dateTimeZone36.getMillisKeepLocal(dateTimeZone41, (long) 100);
        org.joda.time.Chronology chronology46 = julianChronology33.withZone(dateTimeZone41);
        org.joda.time.DateTimeZone dateTimeZone47 = julianChronology33.getZone();
        org.joda.time.DateMidnight dateMidnight48 = localDate23.toDateMidnight(dateTimeZone47);
        org.joda.time.DateTime dateTime49 = localDate23.toDateTimeAtMidnight();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(julianChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
        org.junit.Assert.assertNotNull(chronology46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(dateMidnight48);
        org.junit.Assert.assertNotNull(dateTime49);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        int int6 = delegatedDateTimeField2.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = delegatedDateTimeField2.getType();
        java.util.Locale locale9 = null;
        java.lang.String str10 = delegatedDateTimeField2.getAsShortText(1, locale9);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.DurationField durationField13 = gregorianChronology11.weekyears();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(10L, dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(10L, dateTimeZone20);
        boolean boolean22 = localDate17.isAfter((org.joda.time.ReadablePartial) localDate21);
        boolean boolean24 = localDate17.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26);
        org.joda.time.DurationField durationField28 = delegatedDateTimeField27.getLeapDurationField();
        int int31 = delegatedDateTimeField27.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = delegatedDateTimeField27.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType32, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property35 = localDate17.property(dateTimeFieldType32);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.LocalDate localDate37 = localDate17.plus(readablePeriod36);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate41 = new org.joda.time.LocalDate(10L, dateTimeZone40);
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate45 = new org.joda.time.LocalDate(10L, dateTimeZone44);
        boolean boolean46 = localDate41.isAfter((org.joda.time.ReadablePartial) localDate45);
        boolean boolean48 = localDate41.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology49.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField51 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField50);
        org.joda.time.DurationField durationField52 = delegatedDateTimeField51.getLeapDurationField();
        int int55 = delegatedDateTimeField51.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType56 = delegatedDateTimeField51.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException58 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType56, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property59 = localDate41.property(dateTimeFieldType56);
        int int60 = localDate17.get(dateTimeFieldType56);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField61 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, durationField13, dateTimeFieldType56);
        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology62.weekOfWeekyear();
        org.joda.time.LocalDate localDate64 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gregorianChronology62);
        org.joda.time.DurationField durationField65 = gregorianChronology62.weekyears();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter66 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long72 = dateTimeZone68.getMillisKeepLocal(dateTimeZone70, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter73 = dateTimeFormatter66.withZone(dateTimeZone70);
        org.joda.time.chrono.JulianChronology julianChronology75 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone70, 4);
        org.joda.time.DurationField durationField76 = julianChronology75.minutes();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField77 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType56, durationField65, durationField76);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNull(durationField28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNull(durationField52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType56);
        org.junit.Assert.assertNotNull(property59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 19 + "'", int60 == 19);
        org.junit.Assert.assertNotNull(gregorianChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertNotNull(dateTimeFormatter66);
        org.junit.Assert.assertNotNull(dateTimeZone68);
        org.junit.Assert.assertNotNull(dateTimeZone70);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter73);
        org.junit.Assert.assertNotNull(julianChronology75);
        org.junit.Assert.assertNotNull(durationField76);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        boolean boolean10 = localDate3.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        int int17 = delegatedDateTimeField13.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = delegatedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property21 = localDate3.property(dateTimeFieldType18);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.centuryOfEra();
        org.joda.time.DurationField durationField24 = gregorianChronology22.weekyears();
        org.joda.time.DurationField durationField25 = gregorianChronology22.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField25);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate(10L, dateTimeZone29);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate(10L, dateTimeZone33);
        boolean boolean35 = localDate30.isAfter((org.joda.time.ReadablePartial) localDate34);
        boolean boolean37 = localDate30.equals((java.lang.Object) 100.0f);
        int int38 = localDate30.getYear();
        boolean boolean40 = localDate30.equals((java.lang.Object) 1L);
        org.joda.time.LocalDate.Property property41 = localDate30.dayOfWeek();
        boolean boolean42 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate30);
        try {
            int int43 = unsupportedDateTimeField26.getMinimumValue((org.joda.time.ReadablePartial) localDate30);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1970 + "'", int38 == 1970);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(24);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTimeZoneId();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getLeapDurationField();
        int int12 = delegatedDateTimeField8.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField8.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder2.appendFixedSignedDecimal(dateTimeFieldType13, 2019);
        org.joda.time.format.DateTimePrinter dateTimePrinter16 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendLiteral("ISOChronology[UTC]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendMillisOfDay((int) 'a');
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatterBuilder22.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter16, dateTimeParser23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder15.append(dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "19");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(10L, dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField8.getType();
        int int11 = localDate5.get(dateTimeFieldType10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType10, 5);
        int int16 = remainderDateTimeField13.getDifference(4L, 97L);
        int int18 = remainderDateTimeField13.getMinimumValue((-210863995200000L));
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        int int6 = delegatedDateTimeField2.getDifference((long) 1, 1L);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology8, dateTimeField11);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField12, 4);
        int int16 = offsetDateTimeField14.getLeapAmount(100L);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField14.getAsShortText((long) 1, locale18);
        int int21 = offsetDateTimeField14.getLeapAmount(1L);
        org.joda.time.DurationField durationField22 = offsetDateTimeField14.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, durationField22, dateTimeFieldType23);
        java.util.Locale locale26 = null;
        java.lang.String str27 = delegatedDateTimeField2.getAsShortText(57, locale26);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "5" + "'", str19.equals("5"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "57" + "'", str27.equals("57"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField3);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, 4);
        int int8 = offsetDateTimeField6.getLeapAmount(100L);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsShortText((long) 1, locale10);
        boolean boolean13 = offsetDateTimeField6.isLeap(0L);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField6.getAsShortText((int) (byte) -1, locale15);
        int int17 = offsetDateTimeField6.getOffset();
        long long19 = offsetDateTimeField6.roundFloor(100L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1" + "'", str16.equals("-1"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200000L) + "'", long19 == (-259200000L));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("ISOChronology[UTC]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology7);
        int int9 = dateTime8.getYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.Partial partial13 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.DateTime dateTime14 = dateTime8.toDateTime((org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16);
        org.joda.time.DurationField durationField18 = delegatedDateTimeField17.getLeapDurationField();
        int int21 = delegatedDateTimeField17.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = delegatedDateTimeField17.getType();
        org.joda.time.DateTime dateTime24 = dateTime14.withField(dateTimeFieldType22, 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder5.appendLiteral("T������");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1970 + "'", int9 == 1970);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        java.lang.String str3 = dateTime2.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology5);
        java.lang.String str7 = dateTime6.toString();
        boolean boolean8 = dateTime2.isAfter((org.joda.time.ReadableInstant) dateTime6);
        int int9 = dateTime2.getHourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology11);
        java.lang.String str13 = dateTime12.toString();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.plus(readablePeriod14);
        boolean boolean16 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime12);
        try {
            org.joda.time.DateTime dateTime18 = dateTime2.withSecondOfMinute((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str3.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str7.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str13.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        java.lang.String str3 = dateTime2.toString();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime2.toMutableDateTime((org.joda.time.Chronology) gregorianChronology7);
        int int10 = dateTime2.getMinuteOfHour();
        org.joda.time.DateTime dateTime11 = dateTime2.toDateTime();
        java.util.GregorianCalendar gregorianCalendar12 = dateTime11.toGregorianCalendar();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str3.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianCalendar12);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8);
        org.joda.time.DurationField durationField10 = delegatedDateTimeField9.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField9.getType();
        int int12 = localDate6.get(dateTimeFieldType11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.LocalDate localDate14 = localDate6.plus(readablePeriod13);
        int[] intArray16 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDate6, (long) 18);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology19);
        java.lang.String str21 = dateTime20.toString();
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.plus(readablePeriod22);
        org.joda.time.LocalTime localTime24 = dateTime23.toLocalTime();
        java.lang.String str25 = dateTimeFormatter17.print((org.joda.time.ReadablePartial) localTime24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long32 = dateTimeZone28.getMillisKeepLocal(dateTimeZone30, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = dateTimeFormatter26.withZone(dateTimeZone30);
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone30, 4);
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate(10L, dateTimeZone38);
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long45 = dateTimeZone41.getMillisKeepLocal(dateTimeZone43, (long) (short) 0);
        long long47 = dateTimeZone38.getMillisKeepLocal(dateTimeZone43, (long) 100);
        org.joda.time.Chronology chronology48 = julianChronology35.withZone(dateTimeZone43);
        org.joda.time.DateTimeZone dateTimeZone49 = julianChronology35.getZone();
        java.util.TimeZone timeZone50 = dateTimeZone49.toTimeZone();
        try {
            org.joda.time.DateTime dateTime51 = localDate6.toDateTime(localTime24, dateTimeZone49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The chronology of the time does not match");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str21.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(localTime24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "����-W��-�T00:00:00.010" + "'", str25.equals("����-W��-�T00:00:00.010"));
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter33);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 100L + "'", long47 == 100L);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(timeZone50);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        boolean boolean10 = localDate3.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        int int17 = delegatedDateTimeField13.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = delegatedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property21 = localDate3.property(dateTimeFieldType18);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.centuryOfEra();
        org.joda.time.DurationField durationField24 = gregorianChronology22.weekyears();
        org.joda.time.DurationField durationField25 = gregorianChronology22.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField25);
        try {
            long long29 = unsupportedDateTimeField26.set((long) 70, "35");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        boolean boolean10 = localDate3.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        int int17 = delegatedDateTimeField13.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = delegatedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property21 = localDate3.property(dateTimeFieldType18);
        org.joda.time.LocalDate localDate23 = property21.setCopy(100);
        org.joda.time.LocalDate localDate24 = property21.roundHalfCeilingCopy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long31 = dateTimeZone27.getMillisKeepLocal(dateTimeZone29, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter25.withZone(dateTimeZone29);
        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone29, 4);
        org.joda.time.LocalDate localDate35 = org.joda.time.LocalDate.now(dateTimeZone29);
        java.util.Locale locale37 = null;
        java.lang.String str38 = dateTimeZone29.getName((long) (byte) 0, locale37);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long44 = dateTimeZone40.getMillisKeepLocal(dateTimeZone42, (long) (short) 0);
        org.joda.time.LocalDateTime localDateTime45 = null;
        boolean boolean46 = dateTimeZone42.isLocalDateTimeGap(localDateTime45);
        long long48 = dateTimeZone29.getMillisKeepLocal(dateTimeZone42, 978307194800L);
        boolean boolean49 = property21.equals((java.lang.Object) long48);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(julianChronology34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "+00:00:00.100" + "'", str38.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 978307194800L + "'", long48 == 978307194800L);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        boolean boolean10 = localDate3.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        int int17 = delegatedDateTimeField13.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = delegatedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property21 = localDate3.property(dateTimeFieldType18);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(10L, dateTimeZone24);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate(10L, dateTimeZone28);
        boolean boolean30 = localDate25.isAfter((org.joda.time.ReadablePartial) localDate29);
        boolean boolean32 = localDate25.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField34);
        org.joda.time.DurationField durationField36 = delegatedDateTimeField35.getLeapDurationField();
        int int39 = delegatedDateTimeField35.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = delegatedDateTimeField35.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property43 = localDate25.property(dateTimeFieldType40);
        boolean boolean44 = localDate3.isSupported(dateTimeFieldType40);
        org.joda.time.LocalDate localDate46 = localDate3.plusMonths(2019);
        int int47 = localDate3.getWeekyear();
        org.joda.time.LocalDate.Property property48 = localDate3.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNull(durationField36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1970 + "'", int47 == 1970);
        org.junit.Assert.assertNotNull(property48);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        int int6 = delegatedDateTimeField2.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = delegatedDateTimeField2.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Property[monthOfYear]");
        java.lang.Number number10 = illegalFieldValueException9.getUpperBound();
        java.lang.String str11 = illegalFieldValueException9.toString();
        illegalFieldValueException9.prependMessage("centuryOfEra");
        org.joda.time.DurationFieldType durationFieldType14 = illegalFieldValueException9.getDurationFieldType();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"Property[monthOfYear]\" for centuryOfEra is not supported" + "'", str11.equals("org.joda.time.IllegalFieldValueException: Value \"Property[monthOfYear]\" for centuryOfEra is not supported"));
        org.junit.Assert.assertNull(durationFieldType14);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField3);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, 4);
        int int8 = offsetDateTimeField6.getLeapAmount(100L);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsShortText((long) 1, locale10);
        int int13 = offsetDateTimeField6.getLeapAmount(1L);
        long long16 = offsetDateTimeField6.addWrapField(259200018L, 1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 864000018L + "'", long16 == 864000018L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(10L, dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField8.getType();
        int int11 = localDate5.get(dateTimeFieldType10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType10, 5);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = localDate14.getFieldType((int) (byte) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField13, dateTimeFieldType16);
        int int20 = dividedDateTimeField17.getDifference((long) 1, (long) (-1));
        long long22 = dividedDateTimeField17.remainder(0L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 26);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        java.lang.String str3 = dateTime2.toString();
        java.lang.String str4 = dateTime2.toString();
        int int5 = dateTime2.getMinuteOfHour();
        boolean boolean7 = dateTime2.isEqual(0L);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime2.minus(readablePeriod8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime12 = dateTime2.withPeriodAdded(readablePeriod10, 292279000);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str3.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str4.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.Chronology chronology1 = copticChronology0.withUTC();
        int int2 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology3, dateTimeField6);
        int int8 = skipDateTimeField7.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(10L, dateTimeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        org.joda.time.DurationField durationField16 = delegatedDateTimeField15.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = delegatedDateTimeField15.getType();
        int int18 = localDate12.get(dateTimeFieldType17);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, dateTimeFieldType17, 10);
        boolean boolean21 = skipDateTimeField7.isLenient();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) skipDateTimeField7);
        int int24 = skipUndoDateTimeField22.get((long) 20);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 19 + "'", int18 == 19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(24);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder2.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendFractionOfHour((int) 'a', 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean11 = dateTimeFormatterBuilder10.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendMinuteOfDay(100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long20 = dateTimeZone16.getMillisKeepLocal(dateTimeZone18, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter14.withZone(dateTimeZone18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder13.append(dateTimeFormatter21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendLiteral("ISOChronology[UTC]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder25.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.appendMillisOfDay((int) 'a');
        org.joda.time.format.DateTimeParser dateTimeParser29 = dateTimeFormatterBuilder28.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder22.append(dateTimeParser29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder2.append(dateTimeParser29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeParser29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField4 = null;
        try {
            org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField4, 99);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(24);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTimeZoneId();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneShortName(strMap6);
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatter9.getParser();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.append(dateTimePrinter8, dateTimeParser10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfHalfday(2019);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendTimeZoneOffset("JulianChronology[+00:00:00.100]", true, 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField3);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, 4);
        int int8 = offsetDateTimeField6.getLeapAmount(100L);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsShortText((long) 1, locale10);
        boolean boolean13 = offsetDateTimeField6.isLeap(0L);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField6.getAsShortText((int) (byte) -1, locale15);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(10L, dateTimeZone19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22);
        org.joda.time.DurationField durationField24 = delegatedDateTimeField23.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField23.getType();
        int int26 = localDate20.get(dateTimeFieldType25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.LocalDate localDate28 = localDate20.plus(readablePeriod27);
        int[] intArray35 = new int[] { 2922790, (short) 10, 24, (short) 100, 2019, 20 };
        int int36 = offsetDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDate20, intArray35);
        org.joda.time.Partial partial37 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate20);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = partial37.getFormatter();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1" + "'", str16.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 19 + "'", int26 == 19);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 57 + "'", int36 == 57);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(10L, dateTimeZone9);
        boolean boolean11 = localDate6.isAfter((org.joda.time.ReadablePartial) localDate10);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray12 = localDate6.getFieldTypes();
        int int13 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(10L, dateTimeZone19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22);
        org.joda.time.DurationField durationField24 = delegatedDateTimeField23.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField23.getType();
        int int26 = localDate20.get(dateTimeFieldType25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.LocalDate localDate28 = localDate20.plus(readablePeriod27);
        int[] intArray30 = gregorianChronology14.get((org.joda.time.ReadablePartial) localDate20, (long) 18);
        org.joda.time.LocalDate.Property property31 = localDate20.era();
        org.joda.time.DateTime dateTime32 = localDate20.toDateTimeAtStartOfDay();
        int int33 = localDate20.getYearOfCentury();
        java.util.Locale locale35 = null;
        java.lang.String str36 = delegatedDateTimeField2.getAsShortText((org.joda.time.ReadablePartial) localDate20, (int) '#', locale35);
        long long39 = delegatedDateTimeField2.set(0L, "1");
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2922790 + "'", int13 == 2922790);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 19 + "'", int26 == 19);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 70 + "'", int33 == 70);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "35" + "'", str36.equals("35"));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-59958144000000L) + "'", long39 == (-59958144000000L));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(10L, dateTimeZone10);
        boolean boolean12 = localDate7.isAfter((org.joda.time.ReadablePartial) localDate11);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(10L, dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(10L, dateTimeZone19);
        boolean boolean21 = localDate16.isAfter((org.joda.time.ReadablePartial) localDate20);
        boolean boolean22 = localDate11.isBefore((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology24);
        java.lang.String str26 = dateTime25.toString();
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.plus(readablePeriod27);
        org.joda.time.DateTime dateTime29 = localDate16.toDateTime((org.joda.time.ReadableInstant) dateTime25);
        java.lang.String str30 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology31);
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        java.lang.String str36 = dateTimeZone34.getShortName(0L);
        java.lang.String str38 = dateTimeZone34.getName(0L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = dateTimeFormatter0.withZone(dateTimeZone34);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str26.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "T������" + "'", str30.equals("T������"));
        org.junit.Assert.assertNotNull(buddhistChronology31);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "+00:00:00.100" + "'", str36.equals("+00:00:00.100"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "+00:00:00.100" + "'", str38.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField5);
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5, (int) (byte) -1);
        long long10 = skipDateTimeField8.roundHalfCeiling(60100L);
        long long13 = skipDateTimeField8.add((long) 100, 97L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-259200000L) + "'", long10 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 58665600100L + "'", long13 == 58665600100L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 2922790, (int) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 102297650L + "'", long2 == 102297650L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(24);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendTwoDigitYear((int) 'a', false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMonthOfYear(7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(2922790, 5, 1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        java.lang.String str3 = dateTimeZone1.getShortName(0L);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        boolean boolean6 = dateTimeZone1.isStandardOffset(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.100" + "'", str3.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long6 = dateTimeZone2.getMillisKeepLocal(dateTimeZone4, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone4);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4, 4);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long19 = dateTimeZone15.getMillisKeepLocal(dateTimeZone17, (long) (short) 0);
        long long21 = dateTimeZone12.getMillisKeepLocal(dateTimeZone17, (long) 100);
        org.joda.time.Chronology chronology22 = julianChronology9.withZone(dateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone23 = julianChronology9.getZone();
        java.util.TimeZone timeZone24 = dateTimeZone23.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forTimeZone(timeZone24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '+00:00:00.100' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(timeZone24);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology5);
        java.lang.String str7 = dateTime6.toString();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.plus(readablePeriod8);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime6.toMutableDateTime((org.joda.time.Chronology) gregorianChronology11);
        int int14 = dateTime6.getMinuteOfHour();
        org.joda.time.DateTime dateTime16 = dateTime6.withSecondOfMinute(1);
        org.joda.time.DateTime.Property property17 = dateTime6.centuryOfEra();
        org.joda.time.DateTime dateTime19 = property17.setCopy("1");
        boolean boolean20 = gregorianChronology0.equals((java.lang.Object) property17);
        org.joda.time.DateTime dateTime21 = property17.roundHalfEvenCopy();
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate(10L, dateTimeZone27);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField30);
        org.joda.time.DurationField durationField32 = delegatedDateTimeField31.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = delegatedDateTimeField31.getType();
        int int34 = localDate28.get(dateTimeFieldType33);
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.LocalDate localDate36 = localDate28.plus(readablePeriod35);
        int[] intArray38 = gregorianChronology22.get((org.joda.time.ReadablePartial) localDate28, (long) 18);
        org.joda.time.LocalDate.Property property39 = localDate28.era();
        org.joda.time.LocalDate localDate40 = property39.roundHalfEvenCopy();
        org.joda.time.LocalDate.Property property41 = localDate40.weekyear();
        boolean boolean42 = dateTime21.equals((java.lang.Object) localDate40);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str7.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 19 + "'", int34 == 19);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(localDate40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        boolean boolean10 = localDate3.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        int int17 = delegatedDateTimeField13.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = delegatedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property21 = localDate3.property(dateTimeFieldType18);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.centuryOfEra();
        org.joda.time.DurationField durationField24 = gregorianChronology22.weekyears();
        org.joda.time.DurationField durationField25 = gregorianChronology22.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField25);
        try {
            int int28 = unsupportedDateTimeField26.getMinimumValue((long) 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(10L, dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(10L, dateTimeZone15);
        boolean boolean17 = localDate12.isAfter((org.joda.time.ReadablePartial) localDate16);
        boolean boolean18 = localDate7.isBefore((org.joda.time.ReadablePartial) localDate12);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology20);
        java.lang.String str22 = dateTime21.toString();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime24 = dateTime21.plus(readablePeriod23);
        org.joda.time.DateTime dateTime25 = localDate12.toDateTime((org.joda.time.ReadableInstant) dateTime21);
        int int26 = dateTime21.getMillisOfSecond();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str22.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 0L, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        int[] intArray1 = partial0.getValues();
        org.junit.Assert.assertNotNull(intArray1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        boolean boolean10 = localDate3.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        int int17 = delegatedDateTimeField13.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = delegatedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property21 = localDate3.property(dateTimeFieldType18);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(10L, dateTimeZone24);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate(10L, dateTimeZone28);
        boolean boolean30 = localDate25.isAfter((org.joda.time.ReadablePartial) localDate29);
        boolean boolean32 = localDate25.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField34);
        org.joda.time.DurationField durationField36 = delegatedDateTimeField35.getLeapDurationField();
        int int39 = delegatedDateTimeField35.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = delegatedDateTimeField35.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property43 = localDate25.property(dateTimeFieldType40);
        boolean boolean44 = localDate3.isSupported(dateTimeFieldType40);
        org.joda.time.LocalDate localDate46 = localDate3.plusMonths(2019);
        int int47 = localDate3.getWeekyear();
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate(10L, dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate55 = new org.joda.time.LocalDate(10L, dateTimeZone54);
        boolean boolean56 = localDate51.isAfter((org.joda.time.ReadablePartial) localDate55);
        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate60 = new org.joda.time.LocalDate(10L, dateTimeZone59);
        org.joda.time.DateTimeZone dateTimeZone63 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate64 = new org.joda.time.LocalDate(10L, dateTimeZone63);
        boolean boolean65 = localDate60.isAfter((org.joda.time.ReadablePartial) localDate64);
        boolean boolean66 = localDate55.isBefore((org.joda.time.ReadablePartial) localDate60);
        int int67 = localDate55.getCenturyOfEra();
        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate71 = new org.joda.time.LocalDate(10L, dateTimeZone70);
        org.joda.time.chrono.GregorianChronology gregorianChronology72 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField73 = gregorianChronology72.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField74 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField73);
        org.joda.time.DurationField durationField75 = delegatedDateTimeField74.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType76 = delegatedDateTimeField74.getType();
        int int77 = localDate71.get(dateTimeFieldType76);
        int int78 = localDate55.get(dateTimeFieldType76);
        org.joda.time.LocalDate localDate80 = localDate3.withField(dateTimeFieldType76, 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNull(durationField36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1970 + "'", int47 == 1970);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(dateTimeZone63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 19 + "'", int67 == 19);
        org.junit.Assert.assertNotNull(dateTimeZone70);
        org.junit.Assert.assertNotNull(gregorianChronology72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertNull(durationField75);
        org.junit.Assert.assertNotNull(dateTimeFieldType76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 19 + "'", int77 == 19);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 19 + "'", int78 == 19);
        org.junit.Assert.assertNotNull(localDate80);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        int int6 = delegatedDateTimeField2.getDifference((long) 1, 1L);
        long long8 = delegatedDateTimeField2.roundHalfEven((long) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField2.getAsText(60100L, locale10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 978307200000L + "'", long8 == 978307200000L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(chronology2);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[UTC]" + "'", str1.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        java.lang.String str3 = dateTime2.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology5);
        java.lang.String str7 = dateTime6.toString();
        boolean boolean8 = dateTime2.isAfter((org.joda.time.ReadableInstant) dateTime6);
        int int9 = dateTime2.getHourOfDay();
        org.joda.time.DateTime.Property property10 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime12 = property10.addWrapFieldToCopy(0);
        java.util.Locale locale14 = null;
        try {
            org.joda.time.DateTime dateTime15 = property10.setCopy("org.joda.time.IllegalFieldValueException: Value \"Property[monthOfYear]\" for centuryOfEra is not supported", locale14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalFieldValueException: Value \"Property[monthOfYear]\" for centuryOfEra is not supported\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str3.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str7.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneId();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendTimeZoneOffset("1970-01-01", "19", false, 3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.joda.time.Chronology chronology2 = gJChronology0.withUTC();
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(chronology2);
        org.joda.time.LocalDate.Property property4 = localDate3.era();
        org.joda.time.LocalDate localDate5 = property4.withMaximumValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate5);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        java.lang.String str3 = dateTime2.toString();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime2.toMutableDateTime((org.joda.time.Chronology) gregorianChronology7);
        int int10 = dateTime2.getMinuteOfHour();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology12);
        java.lang.String str14 = dateTime13.toString();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.plus(readablePeriod15);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.MutableDateTime mutableDateTime20 = dateTime13.toMutableDateTime((org.joda.time.Chronology) gregorianChronology18);
        int int21 = dateTime13.getMinuteOfHour();
        org.joda.time.DateTime dateTime23 = dateTime13.withSecondOfMinute(1);
        boolean boolean24 = dateTime2.isBefore((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long31 = dateTimeZone27.getMillisKeepLocal(dateTimeZone29, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter25.withZone(dateTimeZone29);
        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone29, 4);
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate38 = new org.joda.time.LocalDate(10L, dateTimeZone37);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long44 = dateTimeZone40.getMillisKeepLocal(dateTimeZone42, (long) (short) 0);
        long long46 = dateTimeZone37.getMillisKeepLocal(dateTimeZone42, (long) 100);
        org.joda.time.Chronology chronology47 = julianChronology34.withZone(dateTimeZone42);
        org.joda.time.DateTimeZone dateTimeZone48 = julianChronology34.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology50);
        java.lang.String str52 = dateTime51.toString();
        java.lang.String str53 = dateTime51.toString();
        int int54 = dateTime51.getMinuteOfHour();
        org.joda.time.chrono.GJChronology gJChronology55 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone48, (org.joda.time.ReadableInstant) dateTime51);
        org.joda.time.DateTime dateTime56 = dateTime23.toDateTime(dateTimeZone48);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str3.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str14.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(julianChronology34);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 100L + "'", long46 == 100L);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(gregorianChronology50);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str52.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str53.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(gJChronology55);
        org.junit.Assert.assertNotNull(dateTime56);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        java.lang.String str3 = dateTime2.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology5);
        java.lang.String str7 = dateTime6.toString();
        boolean boolean8 = dateTime2.isAfter((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property9 = dateTime6.weekyear();
        java.util.Locale locale11 = null;
        try {
            org.joda.time.DateTime dateTime12 = property9.setCopy("", locale11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for weekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str3.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str7.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(0L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gJChronology0.centuries();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology2);
        int int4 = dateTime3.getYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime9 = dateTime3.toDateTime((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11);
        org.joda.time.DurationField durationField13 = delegatedDateTimeField12.getLeapDurationField();
        int int16 = delegatedDateTimeField12.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = delegatedDateTimeField12.getType();
        org.joda.time.DateTime dateTime19 = dateTime9.withField(dateTimeFieldType17, 4);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime22 = dateTime9.withDurationAdded(readableDuration20, (int) '#');
        org.joda.time.DateTime dateTime24 = dateTime9.minusMonths(20);
        boolean boolean25 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZoneBuilder0, (java.lang.Object) 20);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder33 = dateTimeZoneBuilder0.addCutover(0, '4', (int) (short) 1, 1, 0, true, 1970);
        org.joda.time.DateTimeZone dateTimeZone36 = dateTimeZoneBuilder0.toDateTimeZone("+00:00:00.100", false);
        java.io.OutputStream outputStream38 = null;
        try {
            dateTimeZoneBuilder0.writeTo("org.joda.time.IllegalFieldValueException: Value null for hi! must be in the range [100,978307200000]", outputStream38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder33);
        org.junit.Assert.assertNotNull(dateTimeZone36);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendMinuteOfDay(10);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology8, dateTimeField11);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField12, 4);
        int int16 = offsetDateTimeField14.getLeapAmount(100L);
        boolean boolean17 = offsetDateTimeField14.isSupported();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(10L, dateTimeZone20);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(10L, dateTimeZone24);
        boolean boolean26 = localDate21.isAfter((org.joda.time.ReadablePartial) localDate25);
        boolean boolean28 = localDate21.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField30);
        org.joda.time.DurationField durationField32 = delegatedDateTimeField31.getLeapDurationField();
        int int35 = delegatedDateTimeField31.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = delegatedDateTimeField31.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException38 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property39 = localDate21.property(dateTimeFieldType36);
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate(10L, dateTimeZone42);
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate(10L, dateTimeZone46);
        boolean boolean48 = localDate43.isAfter((org.joda.time.ReadablePartial) localDate47);
        boolean boolean50 = localDate43.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology51.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField53 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField52);
        org.joda.time.DurationField durationField54 = delegatedDateTimeField53.getLeapDurationField();
        int int57 = delegatedDateTimeField53.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType58 = delegatedDateTimeField53.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException60 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType58, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property61 = localDate43.property(dateTimeFieldType58);
        boolean boolean62 = localDate21.isSupported(dateTimeFieldType58);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField64 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField14, dateTimeFieldType58, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder7.appendFixedDecimal(dateTimeFieldType58, 292279000);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder7.appendDayOfMonth((-24));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNull(durationField54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType58);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTime dateTime8 = dateTime2.toDateTime((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime2.minus(readableDuration9);
        int int11 = dateTime10.getYear();
        int int12 = dateTime10.getHourOfDay();
        org.joda.time.DateTime.Property property13 = dateTime10.secondOfMinute();
        int int14 = property13.get();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1970 + "'", int3 == 1970);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology0.getZone();
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(copticChronology7);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DurationField durationField7 = delegatedDateTimeField6.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = delegatedDateTimeField6.getType();
        int int9 = localDate3.get(dateTimeFieldType8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.LocalDate localDate11 = localDate3.plus(readablePeriod10);
        org.joda.time.LocalDate.Property property12 = localDate11.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 19 + "'", int9 == 19);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 10);
        org.joda.time.Instant instant4 = instant1.withDurationAdded(3155759999999L, (int) (byte) 10);
        org.joda.time.DateTime dateTime5 = instant1.toDateTime();
        org.joda.time.MutableDateTime mutableDateTime6 = instant1.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        boolean boolean10 = localDate3.equals((java.lang.Object) 100.0f);
        int int11 = localDate3.getYear();
        boolean boolean13 = localDate3.equals((java.lang.Object) 1L);
        org.joda.time.LocalDate localDate15 = localDate3.withWeekyear((int) (short) -1);
        try {
            org.joda.time.LocalDate localDate17 = localDate3.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(localDate15);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(10L, dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField8.getType();
        int int11 = localDate5.get(dateTimeFieldType10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType10, 5);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        org.joda.time.DurationField durationField17 = delegatedDateTimeField16.getLeapDurationField();
        int int19 = delegatedDateTimeField16.getLeapAmount((long) (-1));
        long long21 = delegatedDateTimeField16.roundFloor((long) 3);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(10L, dateTimeZone24);
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField27);
        org.joda.time.DurationField durationField29 = delegatedDateTimeField28.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = delegatedDateTimeField28.getType();
        int int31 = localDate25.get(dateTimeFieldType30);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField16, dateTimeFieldType30, 100);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField34 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField13, dateTimeFieldType30);
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology36);
        org.joda.time.DateTime.Property property38 = dateTime37.monthOfYear();
        org.joda.time.DateTimeField dateTimeField39 = property38.getField();
        long long40 = property38.remainder();
        java.lang.String str41 = property38.getAsShortText();
        org.joda.time.DurationField durationField42 = property38.getRangeDurationField();
        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = localDate43.getFieldType((int) (byte) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField46 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField13, durationField42, dateTimeFieldType45);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-2177452800000L) + "'", long21 == (-2177452800000L));
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 19 + "'", int31 == 19);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Jan" + "'", str41.equals("Jan"));
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        java.lang.String str3 = dateTime2.toString();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology7);
        java.lang.String str9 = dateTime8.toString();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.plus(readablePeriod10);
        boolean boolean12 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime dateTime13 = dateTime2.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property14 = dateTime13.year();
        try {
            org.joda.time.DateTime dateTime16 = property14.addToCopy(978307200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 978307200000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str3.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str9.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        boolean boolean10 = localDate3.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        int int17 = delegatedDateTimeField13.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = delegatedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property21 = localDate3.property(dateTimeFieldType18);
        org.joda.time.LocalDate localDate22 = property21.roundFloorCopy();
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((-210863995200000L));
        org.joda.time.LocalDate.Property property25 = localDate24.dayOfWeek();
        int int26 = localDate24.getDayOfMonth();
        int int27 = property21.compareTo((org.joda.time.ReadablePartial) localDate24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser29 = dateTimeFormatter28.getParser();
        org.joda.time.DateTimeZone dateTimeZone30 = dateTimeFormatter28.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter28.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate(10L, dateTimeZone34);
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate(10L, dateTimeZone38);
        boolean boolean40 = localDate35.isAfter((org.joda.time.ReadablePartial) localDate39);
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate(10L, dateTimeZone43);
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(10L, dateTimeZone47);
        boolean boolean49 = localDate44.isAfter((org.joda.time.ReadablePartial) localDate48);
        boolean boolean50 = localDate39.isBefore((org.joda.time.ReadablePartial) localDate44);
        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology52);
        java.lang.String str54 = dateTime53.toString();
        org.joda.time.ReadablePeriod readablePeriod55 = null;
        org.joda.time.DateTime dateTime56 = dateTime53.plus(readablePeriod55);
        org.joda.time.DateTime dateTime57 = localDate44.toDateTime((org.joda.time.ReadableInstant) dateTime53);
        java.lang.String str58 = dateTimeFormatter28.print((org.joda.time.ReadablePartial) localDate44);
        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        java.lang.String str62 = dateTimeZone60.getShortName(0L);
        org.joda.time.chrono.GJChronology gJChronology63 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone60);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter64 = dateTimeFormatter28.withZone(dateTimeZone60);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter65 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone67 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone69 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long71 = dateTimeZone67.getMillisKeepLocal(dateTimeZone69, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter72 = dateTimeFormatter65.withZone(dateTimeZone69);
        org.joda.time.chrono.JulianChronology julianChronology74 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone69, 4);
        org.joda.time.LocalDate localDate75 = org.joda.time.LocalDate.now(dateTimeZone69);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter76 = dateTimeFormatter28.withZone(dateTimeZone69);
        org.joda.time.DateTime dateTime77 = localDate24.toDateTimeAtStartOfDay(dateTimeZone69);
        org.joda.time.chrono.GJChronology gJChronology78 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant79 = gJChronology78.getGregorianCutover();
        org.joda.time.chrono.GregorianChronology gregorianChronology80 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField81 = gregorianChronology80.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology82 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField83 = gJChronology82.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField84 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology80, dateTimeField83);
        org.joda.time.field.SkipDateTimeField skipDateTimeField86 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology78, dateTimeField83, (int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone87 = gJChronology78.getZone();
        org.joda.time.DateTime dateTime88 = localDate24.toDateTimeAtCurrentTime(dateTimeZone87);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 26 + "'", int26 == 26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTimeParser29);
        org.junit.Assert.assertNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(gregorianChronology52);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str54.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "T������" + "'", str58.equals("T������"));
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "+00:00:00.100" + "'", str62.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(gJChronology63);
        org.junit.Assert.assertNotNull(dateTimeFormatter64);
        org.junit.Assert.assertNotNull(dateTimeFormatter65);
        org.junit.Assert.assertNotNull(dateTimeZone67);
        org.junit.Assert.assertNotNull(dateTimeZone69);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 0L + "'", long71 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter72);
        org.junit.Assert.assertNotNull(julianChronology74);
        org.junit.Assert.assertNotNull(localDate75);
        org.junit.Assert.assertNotNull(dateTimeFormatter76);
        org.junit.Assert.assertNotNull(dateTime77);
        org.junit.Assert.assertNotNull(gJChronology78);
        org.junit.Assert.assertNotNull(instant79);
        org.junit.Assert.assertNotNull(gregorianChronology80);
        org.junit.Assert.assertNotNull(dateTimeField81);
        org.junit.Assert.assertNotNull(gJChronology82);
        org.junit.Assert.assertNotNull(dateTimeField83);
        org.junit.Assert.assertNotNull(dateTimeZone87);
        org.junit.Assert.assertNotNull(dateTime88);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (short) 0, 18, 70, (int) (byte) 100, 20, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        boolean boolean10 = localDate3.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        int int17 = delegatedDateTimeField13.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = delegatedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property21 = localDate3.property(dateTimeFieldType18);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.centuryOfEra();
        org.joda.time.DurationField durationField24 = gregorianChronology22.weekyears();
        org.joda.time.DurationField durationField25 = gregorianChronology22.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField25);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology28);
        org.joda.time.Partial partial30 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology28);
        java.util.Locale locale31 = null;
        try {
            java.lang.String str32 = unsupportedDateTimeField26.getAsText((org.joda.time.ReadablePartial) partial30, locale31);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
        org.junit.Assert.assertNotNull(gregorianChronology28);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        boolean boolean10 = localDate3.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        int int17 = delegatedDateTimeField13.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = delegatedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property21 = localDate3.property(dateTimeFieldType18);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.LocalDate localDate23 = localDate3.plus(readablePeriod22);
        org.joda.time.LocalDate.Property property24 = localDate3.dayOfYear();
        org.joda.time.LocalDate localDate25 = property24.withMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(localDate25);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        boolean boolean10 = localDate3.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        int int17 = delegatedDateTimeField13.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = delegatedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property21 = localDate3.property(dateTimeFieldType18);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.centuryOfEra();
        org.joda.time.DurationField durationField24 = gregorianChronology22.weekyears();
        org.joda.time.DurationField durationField25 = gregorianChronology22.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField25);
        org.joda.time.ReadablePartial readablePartial27 = null;
        java.util.Locale locale29 = null;
        try {
            java.lang.String str30 = unsupportedDateTimeField26.getAsShortText(readablePartial27, 0, locale29);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        boolean boolean10 = localDate3.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        int int17 = delegatedDateTimeField13.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = delegatedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property21 = localDate3.property(dateTimeFieldType18);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.LocalDate localDate23 = localDate3.plus(readablePeriod22);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology26);
        java.lang.String str28 = dateTime27.toString();
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.DateTime dateTime30 = dateTime27.plus(readablePeriod29);
        org.joda.time.LocalTime localTime31 = dateTime30.toLocalTime();
        java.lang.String str32 = dateTimeFormatter24.print((org.joda.time.ReadablePartial) localTime31);
        try {
            org.joda.time.DateTime dateTime33 = localDate3.toDateTime(localTime31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The chronology of the time does not match");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str28.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(localTime31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "����-W��-�T00:00:00.010" + "'", str32.equals("����-W��-�T00:00:00.010"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(24);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendTwoDigitYear((int) 'a', false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder2.appendLiteral('#');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(24);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMillisOfDay(4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("ISOChronology[UTC]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendMillisOfDay((int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology7);
        int int9 = dateTime8.getYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.Partial partial13 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.DateTime dateTime14 = dateTime8.toDateTime((org.joda.time.Chronology) gregorianChronology11);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16);
        org.joda.time.DurationField durationField18 = delegatedDateTimeField17.getLeapDurationField();
        int int21 = delegatedDateTimeField17.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = delegatedDateTimeField17.getType();
        org.joda.time.DateTime dateTime24 = dateTime14.withField(dateTimeFieldType22, 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder5.appendShortText(dateTimeFieldType22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder5.appendFractionOfSecond(7, 2922790);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder5.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder29.appendYearOfCentury(3, 10);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder32.appendDayOfYear((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1970 + "'", int9 == 1970);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(10L, dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(10L, dateTimeZone15);
        boolean boolean17 = localDate12.isAfter((org.joda.time.ReadablePartial) localDate16);
        boolean boolean18 = localDate7.isBefore((org.joda.time.ReadablePartial) localDate12);
        org.joda.time.LocalDate.Property property19 = localDate7.yearOfCentury();
        org.joda.time.LocalDate localDate20 = property19.roundHalfCeilingCopy();
        org.joda.time.LocalDate localDate21 = property19.getLocalDate();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(localDate21);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology2);
        java.lang.String str4 = dateTime3.toString();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readablePeriod5);
        org.joda.time.LocalTime localTime7 = dateTime6.toLocalTime();
        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localTime7);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology10);
        java.lang.String str12 = dateTime11.toString();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.plus(readablePeriod13);
        org.joda.time.DateTime dateTime16 = dateTime11.minus(0L);
        org.joda.time.DateTime.Property property17 = dateTime16.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = property17.getDateTime();
        org.joda.time.DateTime dateTime20 = property17.addToCopy(20);
        java.lang.String str21 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime dateTime23 = dateTime20.plusSeconds((int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str4.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����-W��-�T00:00:00.010" + "'", str8.equals("����-W��-�T00:00:00.010"));
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str12.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970-W21-4T00:00:00.010Z" + "'", str21.equals("1970-W21-4T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField3);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, 4);
        int int8 = offsetDateTimeField6.getLeapAmount(100L);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsShortText((long) 1, locale10);
        int int13 = offsetDateTimeField6.getLeapAmount(1L);
        long long15 = offsetDateTimeField6.roundHalfFloor((long) (byte) -1);
        int int17 = offsetDateTimeField6.get((long) 1970);
        long long19 = offsetDateTimeField6.roundCeiling((long) (-24));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200000L) + "'", long15 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 5 + "'", int17 == 5);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 345600000L + "'", long19 == 345600000L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(26, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 126 + "'", int2 == 126);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(10L, dateTimeZone10);
        boolean boolean12 = localDate7.isAfter((org.joda.time.ReadablePartial) localDate11);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(10L, dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(10L, dateTimeZone19);
        boolean boolean21 = localDate16.isAfter((org.joda.time.ReadablePartial) localDate20);
        boolean boolean22 = localDate11.isBefore((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology24);
        java.lang.String str26 = dateTime25.toString();
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.plus(readablePeriod27);
        org.joda.time.DateTime dateTime29 = localDate16.toDateTime((org.joda.time.ReadableInstant) dateTime25);
        java.lang.String str30 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        java.lang.String str34 = dateTimeZone32.getShortName(0L);
        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone32);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter0.withZone(dateTimeZone32);
        org.joda.time.Chronology chronology37 = dateTimeFormatter36.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str26.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "T������" + "'", str30.equals("T������"));
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "+00:00:00.100" + "'", str34.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(gJChronology35);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNull(chronology37);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTime dateTime8 = dateTime2.toDateTime((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime2.minus(readableDuration9);
        org.joda.time.DateTime dateTime12 = dateTime2.withMillisOfSecond(70);
        java.util.GregorianCalendar gregorianCalendar13 = dateTime2.toGregorianCalendar();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1970 + "'", int3 == 1970);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gregorianCalendar13);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long6 = dateTimeZone2.getMillisKeepLocal(dateTimeZone4, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone4);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4, 4);
        long long11 = dateTimeZone4.convertUTCToLocal(345600000L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 345600100L + "'", long11 == 345600100L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        boolean boolean10 = localDate3.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        int int17 = delegatedDateTimeField13.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = delegatedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property21 = localDate3.property(dateTimeFieldType18);
        org.joda.time.LocalDate localDate23 = property21.setCopy(100);
        org.joda.time.Interval interval24 = property21.toInterval();
        org.joda.time.ReadableInterval readableInterval25 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval24);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(interval24);
        org.junit.Assert.assertNotNull(readableInterval25);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(10L, dateTimeZone10);
        boolean boolean12 = localDate7.isAfter((org.joda.time.ReadablePartial) localDate11);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(10L, dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(10L, dateTimeZone19);
        boolean boolean21 = localDate16.isAfter((org.joda.time.ReadablePartial) localDate20);
        boolean boolean22 = localDate11.isBefore((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology24);
        java.lang.String str26 = dateTime25.toString();
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.plus(readablePeriod27);
        org.joda.time.DateTime dateTime29 = localDate16.toDateTime((org.joda.time.ReadableInstant) dateTime25);
        java.lang.String str30 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        java.lang.String str34 = dateTimeZone32.getShortName(0L);
        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone32);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter0.withZone(dateTimeZone32);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology37.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology37.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate(10L, dateTimeZone42);
        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology44.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField46 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField45);
        org.joda.time.DurationField durationField47 = delegatedDateTimeField46.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = delegatedDateTimeField46.getType();
        int int49 = localDate43.get(dateTimeFieldType48);
        org.joda.time.ReadablePeriod readablePeriod50 = null;
        org.joda.time.LocalDate localDate51 = localDate43.plus(readablePeriod50);
        int[] intArray53 = gregorianChronology37.get((org.joda.time.ReadablePartial) localDate43, (long) 18);
        org.joda.time.LocalDate.Property property54 = localDate43.era();
        org.joda.time.DateTime dateTime55 = localDate43.toDateTimeAtStartOfDay();
        java.lang.String str56 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime55);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter58 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str26.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "T������" + "'", str30.equals("T������"));
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "+00:00:00.100" + "'", str34.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(gJChronology35);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(gregorianChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNull(durationField47);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 19 + "'", int49 == 19);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "T000000-0800" + "'", str56.equals("T000000-0800"));
        org.junit.Assert.assertNotNull(dateTimeFormatter58);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.Chronology chronology2 = instant1.getChronology();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendHourOfHalfday(2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendTwoDigitWeekyear(1, true);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatter9.getParser();
        org.joda.time.DateTimeZone dateTimeZone11 = dateTimeFormatter9.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter9.withZoneUTC();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.append(dateTimeFormatter12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
        org.junit.Assert.assertNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        java.lang.String str2 = dateTimeFormatter0.print(readableInstant1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "15:39:01.523-07:00" + "'", str2.equals("15:39:01.523-07:00"));
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        java.lang.String str3 = dateTime2.toString();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology8 = iSOChronology7.withUTC();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant10 = gJChronology9.getGregorianCutover();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology11, dateTimeField14);
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology9, dateTimeField14, (int) (byte) -1);
        boolean boolean18 = iSOChronology7.equals((java.lang.Object) gJChronology9);
        org.joda.time.DateTime dateTime19 = dateTime5.toDateTime((org.joda.time.Chronology) gJChronology9);
        int int20 = dateTime19.getHourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str3.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localTime6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        java.lang.String str3 = dateTime2.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology5);
        java.lang.String str7 = dateTime6.toString();
        boolean boolean8 = dateTime2.isAfter((org.joda.time.ReadableInstant) dateTime6);
        int int9 = dateTime2.getHourOfDay();
        int int10 = dateTime2.getMonthOfYear();
        try {
            org.joda.time.DateTime dateTime15 = dateTime2.withTime((int) (byte) 0, (int) (byte) 10, 1970, (-24));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str3.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str7.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        int int5 = delegatedDateTimeField2.getLeapAmount((long) (-1));
        long long7 = delegatedDateTimeField2.roundFloor((long) 3);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(10L, dateTimeZone10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13);
        org.joda.time.DurationField durationField15 = delegatedDateTimeField14.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = delegatedDateTimeField14.getType();
        int int17 = localDate11.get(dateTimeFieldType16);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType16, 100);
        org.joda.time.ReadablePartial readablePartial20 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.weekOfWeekyear();
        org.joda.time.LocalDate localDate24 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate(10L, dateTimeZone29);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate(10L, dateTimeZone33);
        boolean boolean35 = localDate30.isAfter((org.joda.time.ReadablePartial) localDate34);
        boolean boolean37 = localDate30.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField40 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField39);
        org.joda.time.DurationField durationField41 = delegatedDateTimeField40.getLeapDurationField();
        int int44 = delegatedDateTimeField40.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = delegatedDateTimeField40.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException47 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType45, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property48 = localDate30.property(dateTimeFieldType45);
        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate52 = new org.joda.time.LocalDate(10L, dateTimeZone51);
        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate56 = new org.joda.time.LocalDate(10L, dateTimeZone55);
        boolean boolean57 = localDate52.isAfter((org.joda.time.ReadablePartial) localDate56);
        boolean boolean59 = localDate52.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField61 = gregorianChronology60.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField62 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField61);
        org.joda.time.DurationField durationField63 = delegatedDateTimeField62.getLeapDurationField();
        int int66 = delegatedDateTimeField62.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType67 = delegatedDateTimeField62.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException69 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType67, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property70 = localDate52.property(dateTimeFieldType67);
        boolean boolean71 = localDate30.isSupported(dateTimeFieldType67);
        org.joda.time.LocalDate localDate73 = localDate30.plusMonths(2019);
        int int74 = localDate30.getWeekyear();
        int[] intArray76 = gregorianChronology22.get((org.joda.time.ReadablePartial) localDate30, (long) 19);
        try {
            int[] intArray78 = offsetDateTimeField19.addWrapPartial(readablePartial20, 53, intArray76, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 53");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2177452800000L) + "'", long7 == (-2177452800000L));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 19 + "'", int17 == 19);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNull(durationField41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(gregorianChronology60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNull(durationField63);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType67);
        org.junit.Assert.assertNotNull(property70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(localDate73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1970 + "'", int74 == 1970);
        org.junit.Assert.assertNotNull(intArray76);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = iSOChronology1.withUTC();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gJChronology7.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology5, dateTimeField8);
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField8, (int) (byte) -1);
        boolean boolean12 = iSOChronology1.equals((java.lang.Object) gJChronology3);
        org.joda.time.Partial partial13 = partial0.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology1);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology16.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology14, dateTimeField17);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField18, 4);
        int int22 = offsetDateTimeField20.getLeapAmount(100L);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField20.getAsShortText((long) 1, locale24);
        boolean boolean27 = offsetDateTimeField20.isLeap(0L);
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField20.getAsShortText((int) (byte) -1, locale29);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate(10L, dateTimeZone33);
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36);
        org.joda.time.DurationField durationField38 = delegatedDateTimeField37.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = delegatedDateTimeField37.getType();
        int int40 = localDate34.get(dateTimeFieldType39);
        org.joda.time.ReadablePeriod readablePeriod41 = null;
        org.joda.time.LocalDate localDate42 = localDate34.plus(readablePeriod41);
        int[] intArray49 = new int[] { 2922790, (short) 10, 24, (short) 100, 2019, 20 };
        int int50 = offsetDateTimeField20.getMaximumValue((org.joda.time.ReadablePartial) localDate34, intArray49);
        org.joda.time.LocalDate localDate52 = localDate34.plusMonths(10);
        try {
            boolean boolean53 = partial13.isAfter((org.joda.time.ReadablePartial) localDate52);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(partial13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "5" + "'", str25.equals("5"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "-1" + "'", str30.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 19 + "'", int40 == 19);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 57 + "'", int50 == 57);
        org.junit.Assert.assertNotNull(localDate52);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        java.lang.String str3 = dateTimeFormatter0.print(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.hourOfDay();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withPivotYear((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969-365" + "'", str3.equals("1969-365"));
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
//        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.LocalDate localDate4 = localDate2.minus(readablePeriod3);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
//        long long11 = dateTimeZone7.getMillisKeepLocal(dateTimeZone9, (long) (short) 0);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(0L, dateTimeZone7);
//        java.lang.String str13 = dateTimeZone7.toString();
//        org.joda.time.DateTime dateTime14 = localDate2.toDateTimeAtCurrentTime(dateTimeZone7);
//        org.joda.time.DateTime dateTime16 = dateTime14.plus((long) 0);
//        int int17 = dateTime14.getDayOfYear();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00:00.100" + "'", str13.equals("+00:00:00.100"));
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 166 + "'", int17 == 166);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long6 = dateTimeZone2.getMillisKeepLocal(dateTimeZone4, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone4);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4, 4);
        org.joda.time.Chronology chronology10 = julianChronology9.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(10L, dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(10L, dateTimeZone20);
        boolean boolean22 = localDate17.isAfter((org.joda.time.ReadablePartial) localDate21);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray23 = localDate17.getFieldTypes();
        int int24 = delegatedDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) localDate17);
        int[] intArray26 = julianChronology9.get((org.joda.time.ReadablePartial) localDate17, (long) (byte) 100);
        org.joda.time.LocalDate.Property property27 = localDate17.yearOfCentury();
        org.joda.time.LocalDate.Property property28 = localDate17.dayOfYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2922790 + "'", int24 == 2922790);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(property28);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(10L, dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField8.getType();
        int int11 = localDate5.get(dateTimeFieldType10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType10, 5);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = localDate14.getFieldType((int) (byte) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField13, dateTimeFieldType16);
        int int18 = remainderDateTimeField13.getMaximumValue();
        org.joda.time.DurationField durationField19 = remainderDateTimeField13.getRangeDurationField();
        org.joda.time.DurationField durationField20 = remainderDateTimeField13.getLeapDurationField();
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology21.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate(10L, dateTimeZone25);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28);
        org.joda.time.DurationField durationField30 = delegatedDateTimeField29.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = delegatedDateTimeField29.getType();
        int int32 = localDate26.get(dateTimeFieldType31);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField(dateTimeField22, dateTimeFieldType31, 5);
        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = localDate35.getFieldType((int) (byte) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField34, dateTimeFieldType37);
        org.joda.time.DurationField durationField39 = remainderDateTimeField34.getDurationField();
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate(10L, dateTimeZone42);
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate(10L, dateTimeZone46);
        boolean boolean48 = localDate43.isAfter((org.joda.time.ReadablePartial) localDate47);
        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate52 = new org.joda.time.LocalDate(10L, dateTimeZone51);
        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate56 = new org.joda.time.LocalDate(10L, dateTimeZone55);
        boolean boolean57 = localDate52.isAfter((org.joda.time.ReadablePartial) localDate56);
        boolean boolean58 = localDate47.isBefore((org.joda.time.ReadablePartial) localDate52);
        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology60);
        java.lang.String str62 = dateTime61.toString();
        org.joda.time.ReadablePeriod readablePeriod63 = null;
        org.joda.time.DateTime dateTime64 = dateTime61.plus(readablePeriod63);
        org.joda.time.DateTime dateTime65 = localDate52.toDateTime((org.joda.time.ReadableInstant) dateTime61);
        int int67 = localDate52.getValue(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder70 = dateTimeFormatterBuilder68.appendClockhourOfHalfday(24);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap71 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder72 = dateTimeFormatterBuilder70.appendTimeZoneName(strMap71);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder70.appendTimeZoneId();
        org.joda.time.chrono.GregorianChronology gregorianChronology74 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField75 = gregorianChronology74.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField76 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField75);
        org.joda.time.DurationField durationField77 = delegatedDateTimeField76.getLeapDurationField();
        int int80 = delegatedDateTimeField76.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType81 = delegatedDateTimeField76.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder83 = dateTimeFormatterBuilder70.appendFixedSignedDecimal(dateTimeFieldType81, 2019);
        int int84 = localDate52.get(dateTimeFieldType81);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField85 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField13, durationField39, dateTimeFieldType81);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNull(durationField20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 19 + "'", int32 == 19);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(gregorianChronology60);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str62.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder70);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder72);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
        org.junit.Assert.assertNotNull(gregorianChronology74);
        org.junit.Assert.assertNotNull(dateTimeField75);
        org.junit.Assert.assertNull(durationField77);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType81);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 19 + "'", int84 == 19);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        boolean boolean10 = localDate3.equals((java.lang.Object) 100.0f);
        org.joda.time.LocalDate.Property property11 = localDate3.monthOfYear();
        int int12 = property11.getMinimumValueOverall();
        org.joda.time.LocalDate localDate13 = property11.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate15 = localDate13.withCenturyOfEra((int) '4');
        int int16 = localDate15.getDayOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTime dateTime8 = dateTime2.toDateTime((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
        org.joda.time.DateTime dateTime11 = property9.addToCopy(10);
        org.joda.time.DateTime dateTime13 = property9.setCopy(5);
        java.lang.String str14 = property9.getName();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1970 + "'", int3 == 1970);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "minuteOfDay" + "'", str14.equals("minuteOfDay"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology2);
        int int4 = dateTime3.getYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime9 = dateTime3.toDateTime((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11);
        org.joda.time.DurationField durationField13 = delegatedDateTimeField12.getLeapDurationField();
        int int16 = delegatedDateTimeField12.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = delegatedDateTimeField12.getType();
        org.joda.time.DateTime dateTime19 = dateTime9.withField(dateTimeFieldType17, 4);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime22 = dateTime9.withDurationAdded(readableDuration20, (int) '#');
        org.joda.time.DateTime dateTime24 = dateTime9.minusMonths(20);
        boolean boolean25 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZoneBuilder0, (java.lang.Object) 20);
        java.io.OutputStream outputStream27 = null;
        try {
            dateTimeZoneBuilder0.writeTo("weekOfWeekyear", outputStream27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        boolean boolean10 = localDate3.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        int int17 = delegatedDateTimeField13.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = delegatedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property21 = localDate3.property(dateTimeFieldType18);
        java.util.Date date22 = localDate3.toDate();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(10L, dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField8.getType();
        int int11 = localDate5.get(dateTimeFieldType10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType10, 5);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = localDate14.getFieldType((int) (byte) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField13, dateTimeFieldType16);
        int int20 = dividedDateTimeField17.getDifference((long) 1, (long) (-1));
        int int21 = dividedDateTimeField17.getMaximumValue();
        java.util.Locale locale23 = null;
        java.lang.String str24 = dividedDateTimeField17.getAsText(292279000, locale23);
        int int25 = dividedDateTimeField17.getMinimumValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "292279000" + "'", str24.equals("292279000"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        java.lang.String str3 = dateTime2.toString();
        java.lang.String str4 = dateTime2.toString();
        org.joda.time.DateTime dateTime6 = dateTime2.minusMinutes(3);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str3.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str4.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DurationField durationField4 = gregorianChronology1.days();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField6 = new org.joda.time.field.DecoratedDurationField(durationField4, durationFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long6 = dateTimeZone2.getMillisKeepLocal(dateTimeZone4, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeFormatter7.getZone();
        try {
            org.joda.time.MutableDateTime mutableDateTime10 = dateTimeFormatter7.parseMutableDateTime("1969-365");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-365\" is malformed at \"69-365\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        int int6 = delegatedDateTimeField2.getDifference((long) 1, 1L);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2);
        long long10 = delegatedDateTimeField7.getDifferenceAsLong(102297650L, (long) (byte) 1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(10L, dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField8.getType();
        int int11 = localDate5.get(dateTimeFieldType10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType10, 5);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = localDate14.getFieldType((int) (byte) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField13, dateTimeFieldType16);
        int int20 = dividedDateTimeField17.getDifference((long) 1, (long) (-1));
        int int21 = dividedDateTimeField17.getMaximumValue();
        int int22 = dividedDateTimeField17.getMaximumValue();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        boolean boolean10 = localDate3.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        int int17 = delegatedDateTimeField13.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = delegatedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property21 = localDate3.property(dateTimeFieldType18);
        org.joda.time.LocalDate localDate22 = property21.roundFloorCopy();
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((-210863995200000L));
        org.joda.time.LocalDate.Property property25 = localDate24.dayOfWeek();
        int int26 = localDate24.getDayOfMonth();
        int int27 = property21.compareTo((org.joda.time.ReadablePartial) localDate24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser29 = dateTimeFormatter28.getParser();
        org.joda.time.DateTimeZone dateTimeZone30 = dateTimeFormatter28.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter28.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate(10L, dateTimeZone34);
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate(10L, dateTimeZone38);
        boolean boolean40 = localDate35.isAfter((org.joda.time.ReadablePartial) localDate39);
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate(10L, dateTimeZone43);
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate(10L, dateTimeZone47);
        boolean boolean49 = localDate44.isAfter((org.joda.time.ReadablePartial) localDate48);
        boolean boolean50 = localDate39.isBefore((org.joda.time.ReadablePartial) localDate44);
        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology52);
        java.lang.String str54 = dateTime53.toString();
        org.joda.time.ReadablePeriod readablePeriod55 = null;
        org.joda.time.DateTime dateTime56 = dateTime53.plus(readablePeriod55);
        org.joda.time.DateTime dateTime57 = localDate44.toDateTime((org.joda.time.ReadableInstant) dateTime53);
        java.lang.String str58 = dateTimeFormatter28.print((org.joda.time.ReadablePartial) localDate44);
        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        java.lang.String str62 = dateTimeZone60.getShortName(0L);
        org.joda.time.chrono.GJChronology gJChronology63 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone60);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter64 = dateTimeFormatter28.withZone(dateTimeZone60);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter65 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone67 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone69 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long71 = dateTimeZone67.getMillisKeepLocal(dateTimeZone69, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter72 = dateTimeFormatter65.withZone(dateTimeZone69);
        org.joda.time.chrono.JulianChronology julianChronology74 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone69, 4);
        org.joda.time.LocalDate localDate75 = org.joda.time.LocalDate.now(dateTimeZone69);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter76 = dateTimeFormatter28.withZone(dateTimeZone69);
        org.joda.time.DateTime dateTime77 = localDate24.toDateTimeAtStartOfDay(dateTimeZone69);
        org.joda.time.chrono.GregorianChronology gregorianChronology79 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone69, 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 26 + "'", int26 == 26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTimeParser29);
        org.junit.Assert.assertNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(gregorianChronology52);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str54.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "T������" + "'", str58.equals("T������"));
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "+00:00:00.100" + "'", str62.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(gJChronology63);
        org.junit.Assert.assertNotNull(dateTimeFormatter64);
        org.junit.Assert.assertNotNull(dateTimeFormatter65);
        org.junit.Assert.assertNotNull(dateTimeZone67);
        org.junit.Assert.assertNotNull(dateTimeZone69);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 0L + "'", long71 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter72);
        org.junit.Assert.assertNotNull(julianChronology74);
        org.junit.Assert.assertNotNull(localDate75);
        org.junit.Assert.assertNotNull(dateTimeFormatter76);
        org.junit.Assert.assertNotNull(dateTime77);
        org.junit.Assert.assertNotNull(gregorianChronology79);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long8 = dateTimeZone4.getMillisKeepLocal(dateTimeZone6, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter2.withZone(dateTimeZone6);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6, 4);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate(10L, dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long21 = dateTimeZone17.getMillisKeepLocal(dateTimeZone19, (long) (short) 0);
        long long23 = dateTimeZone14.getMillisKeepLocal(dateTimeZone19, (long) 100);
        org.joda.time.Chronology chronology24 = julianChronology11.withZone(dateTimeZone19);
        org.joda.time.LocalDate localDate25 = org.joda.time.LocalDate.now(dateTimeZone19);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) 292279000, dateTimeZone19);
        org.joda.time.DateTime dateTime28 = dateTime26.plusYears((int) (short) -1);
        org.joda.time.MutableDateTime mutableDateTime29 = dateTime28.toMutableDateTime();
        java.util.GregorianCalendar gregorianCalendar30 = dateTime28.toGregorianCalendar();
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime28);
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime34 = dateTime28.withPeriodAdded(readablePeriod32, 5);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(mutableDateTime29);
        org.junit.Assert.assertNotNull(gregorianCalendar30);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(dateTime34);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Instant instant2 = new org.joda.time.Instant(978307200000L);
        boolean boolean3 = iSOChronology0.equals((java.lang.Object) 978307200000L);
        org.joda.time.DurationField durationField4 = iSOChronology0.seconds();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        java.lang.String str3 = dateTime2.toString();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime2.toMutableDateTime((org.joda.time.Chronology) gregorianChronology7);
        int int10 = dateTime2.getMinuteOfHour();
        org.joda.time.DateTime dateTime12 = dateTime2.withSecondOfMinute(1);
        org.joda.time.DateTime.Property property13 = dateTime2.centuryOfEra();
        java.util.Locale locale14 = null;
        int int15 = property13.getMaximumTextLength(locale14);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str3.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 7 + "'", int15 == 7);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        java.io.Writer writer2 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(10L, dateTimeZone9);
        boolean boolean11 = localDate6.isAfter((org.joda.time.ReadablePartial) localDate10);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate(10L, dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate(10L, dateTimeZone18);
        boolean boolean20 = localDate15.isAfter((org.joda.time.ReadablePartial) localDate19);
        boolean boolean21 = localDate10.isBefore((org.joda.time.ReadablePartial) localDate15);
        org.joda.time.Partial partial22 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate15);
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadablePartial) partial22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate(10L, dateTimeZone10);
        boolean boolean12 = localDate7.isAfter((org.joda.time.ReadablePartial) localDate11);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(10L, dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(10L, dateTimeZone19);
        boolean boolean21 = localDate16.isAfter((org.joda.time.ReadablePartial) localDate20);
        boolean boolean22 = localDate11.isBefore((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology24);
        java.lang.String str26 = dateTime25.toString();
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.plus(readablePeriod27);
        org.joda.time.DateTime dateTime29 = localDate16.toDateTime((org.joda.time.ReadableInstant) dateTime25);
        java.lang.String str30 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        java.lang.String str34 = dateTimeZone32.getShortName(0L);
        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone32);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter0.withZone(dateTimeZone32);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long43 = dateTimeZone39.getMillisKeepLocal(dateTimeZone41, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = dateTimeFormatter37.withZone(dateTimeZone41);
        org.joda.time.chrono.JulianChronology julianChronology46 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone41, 4);
        org.joda.time.LocalDate localDate47 = org.joda.time.LocalDate.now(dateTimeZone41);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter48 = dateTimeFormatter0.withZone(dateTimeZone41);
        java.lang.String str50 = dateTimeZone41.getShortName(60100L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str26.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "T������" + "'", str30.equals("T������"));
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "+00:00:00.100" + "'", str34.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(gJChronology35);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertNotNull(julianChronology46);
        org.junit.Assert.assertNotNull(localDate47);
        org.junit.Assert.assertNotNull(dateTimeFormatter48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "+00:00:00.100" + "'", str50.equals("+00:00:00.100"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField3);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, 4);
        int int8 = offsetDateTimeField6.getLeapAmount(100L);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsShortText((long) 1, locale10);
        int int13 = offsetDateTimeField6.getLeapAmount(1L);
        long long15 = offsetDateTimeField6.roundHalfFloor((long) (byte) -1);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate(10L, dateTimeZone21);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24);
        org.joda.time.DurationField durationField26 = delegatedDateTimeField25.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = delegatedDateTimeField25.getType();
        int int28 = localDate22.get(dateTimeFieldType27);
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.LocalDate localDate30 = localDate22.plus(readablePeriod29);
        int[] intArray32 = gregorianChronology16.get((org.joda.time.ReadablePartial) localDate22, (long) 18);
        org.joda.time.LocalDate localDate34 = localDate22.withYear((int) '4');
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField39 = gJChronology38.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField40 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology36, dateTimeField39);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField40, 4);
        int int44 = offsetDateTimeField42.getLeapAmount(100L);
        java.util.Locale locale46 = null;
        java.lang.String str47 = offsetDateTimeField42.getAsShortText((long) 1, locale46);
        boolean boolean49 = offsetDateTimeField42.isLeap(0L);
        java.util.Locale locale51 = null;
        java.lang.String str52 = offsetDateTimeField42.getAsShortText((int) (byte) -1, locale51);
        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate56 = new org.joda.time.LocalDate(10L, dateTimeZone55);
        org.joda.time.chrono.GregorianChronology gregorianChronology57 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField58 = gregorianChronology57.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField59 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField58);
        org.joda.time.DurationField durationField60 = delegatedDateTimeField59.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = delegatedDateTimeField59.getType();
        int int62 = localDate56.get(dateTimeFieldType61);
        org.joda.time.ReadablePeriod readablePeriod63 = null;
        org.joda.time.LocalDate localDate64 = localDate56.plus(readablePeriod63);
        int[] intArray71 = new int[] { 2922790, (short) 10, 24, (short) 100, 2019, 20 };
        int int72 = offsetDateTimeField42.getMaximumValue((org.joda.time.ReadablePartial) localDate56, intArray71);
        try {
            int[] intArray74 = offsetDateTimeField6.addWrapField((org.joda.time.ReadablePartial) localDate22, (int) (byte) 100, intArray71, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200000L) + "'", long15 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 19 + "'", int28 == 19);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "5" + "'", str47.equals("5"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "-1" + "'", str52.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertNotNull(gregorianChronology57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNull(durationField60);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 19 + "'", int62 == 19);
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 57 + "'", int72 == 57);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField3);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, 4);
        int int8 = offsetDateTimeField6.getLeapAmount(100L);
        boolean boolean9 = offsetDateTimeField6.isSupported();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(10L, dateTimeZone16);
        boolean boolean18 = localDate13.isAfter((org.joda.time.ReadablePartial) localDate17);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray19 = localDate13.getFieldTypes();
        int[] intArray20 = new int[] {};
        int int21 = offsetDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) localDate13, intArray20);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField6.getAsText((int) (byte) 1, locale23);
        long long26 = offsetDateTimeField6.roundFloor((long) 53);
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField6.getAsShortText(4L, locale28);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1" + "'", str24.equals("1"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-259200000L) + "'", long26 == (-259200000L));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "5" + "'", str29.equals("5"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        java.lang.String str3 = dateTime2.toString();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.minus(0L);
        org.joda.time.DateTime dateTime9 = dateTime2.withDayOfMonth((int) (byte) 10);
        org.joda.time.DateTime dateTime11 = dateTime9.minusWeeks(24);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str3.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField3);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, 4);
        int int8 = offsetDateTimeField6.getLeapAmount(100L);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsShortText((long) 1, locale10);
        boolean boolean13 = offsetDateTimeField6.isLeap(0L);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField6.getAsShortText((int) (byte) -1, locale15);
        int int17 = offsetDateTimeField6.getOffset();
        org.joda.time.DurationField durationField18 = offsetDateTimeField6.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1" + "'", str16.equals("-1"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNull(durationField18);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(24);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTimeZoneId();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getLeapDurationField();
        int int12 = delegatedDateTimeField8.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField8.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder2.appendFixedSignedDecimal(dateTimeFieldType13, 2019);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder2.appendTimeZoneOffset("Property[minuteOfDay]", "Jan", false, 53, 26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField3);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, 4);
        boolean boolean7 = skipDateTimeField4.isSupported();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        org.joda.time.DurationField durationField11 = delegatedDateTimeField10.getLeapDurationField();
        int int14 = delegatedDateTimeField10.getDifference((long) 1, 1L);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField10);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology18.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology16, dateTimeField19);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField20, 4);
        int int24 = offsetDateTimeField22.getLeapAmount(100L);
        java.util.Locale locale26 = null;
        java.lang.String str27 = offsetDateTimeField22.getAsShortText((long) 1, locale26);
        int int29 = offsetDateTimeField22.getLeapAmount(1L);
        org.joda.time.DurationField durationField30 = offsetDateTimeField22.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField10, durationField30, dateTimeFieldType31);
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology33.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField34);
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate(10L, dateTimeZone38);
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate(10L, dateTimeZone42);
        boolean boolean44 = localDate39.isAfter((org.joda.time.ReadablePartial) localDate43);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray45 = localDate39.getFieldTypes();
        int int46 = delegatedDateTimeField35.getMaximumValue((org.joda.time.ReadablePartial) localDate39);
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField49 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField48);
        org.joda.time.DurationField durationField50 = delegatedDateTimeField49.getLeapDurationField();
        int int52 = delegatedDateTimeField49.getLeapAmount((long) (-1));
        long long54 = delegatedDateTimeField49.roundFloor((long) 3);
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate(10L, dateTimeZone57);
        org.joda.time.chrono.GregorianChronology gregorianChronology59 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField60 = gregorianChronology59.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField61 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField60);
        org.joda.time.DurationField durationField62 = delegatedDateTimeField61.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType63 = delegatedDateTimeField61.getType();
        int int64 = localDate58.get(dateTimeFieldType63);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField66 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField49, dateTimeFieldType63, 100);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField70 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField35, dateTimeFieldType63, (int) (short) 100, (int) (short) 10, 292279000);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField72 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, durationField30, dateTimeFieldType63, 100);
        long long75 = durationField30.subtract(3155759999999L, (long) 18);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "5" + "'", str27.equals("5"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2922790 + "'", int46 == 2922790);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNull(durationField50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-2177452800000L) + "'", long54 == (-2177452800000L));
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(gregorianChronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNull(durationField62);
        org.junit.Assert.assertNotNull(dateTimeFieldType63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 19 + "'", int64 == 19);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 2587852799999L + "'", long75 == 2587852799999L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1970-01-01");
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField3);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, 4);
        int int8 = offsetDateTimeField6.getLeapAmount(100L);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsShortText((long) 1, locale10);
        boolean boolean13 = offsetDateTimeField6.isLeap(0L);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField6.getAsShortText((int) (byte) -1, locale15);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(10L, dateTimeZone19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22);
        org.joda.time.DurationField durationField24 = delegatedDateTimeField23.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField23.getType();
        int int26 = localDate20.get(dateTimeFieldType25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.LocalDate localDate28 = localDate20.plus(readablePeriod27);
        int[] intArray35 = new int[] { 2922790, (short) 10, 24, (short) 100, 2019, 20 };
        int int36 = offsetDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDate20, intArray35);
        long long38 = offsetDateTimeField6.remainder((-100L));
        org.joda.time.DurationField durationField39 = offsetDateTimeField6.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1" + "'", str16.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 19 + "'", int26 == 19);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 57 + "'", int36 == 57);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 259199900L + "'", long38 == 259199900L);
        org.junit.Assert.assertNotNull(durationField39);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(10L, dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField8.getType();
        int int11 = localDate5.get(dateTimeFieldType10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType10, 5);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = localDate14.getFieldType((int) (byte) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField13, dateTimeFieldType16);
        int int20 = dividedDateTimeField17.getDifference((long) 1, (long) (-1));
        int int22 = dividedDateTimeField17.get((long) (-1));
        int int23 = dividedDateTimeField17.getDivisor();
        int int24 = dividedDateTimeField17.getDivisor();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 5 + "'", int24 == 5);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear(10);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(24);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder2.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendLiteral('#');
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(10L, dateTimeZone13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16);
        org.joda.time.DurationField durationField18 = delegatedDateTimeField17.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = delegatedDateTimeField17.getType();
        int int20 = localDate14.get(dateTimeFieldType19);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField22 = new org.joda.time.field.RemainderDateTimeField(dateTimeField10, dateTimeFieldType19, 5);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = localDate23.getFieldType((int) (byte) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType25);
        int int27 = remainderDateTimeField22.getMaximumValue();
        org.joda.time.DurationField durationField28 = remainderDateTimeField22.getRangeDurationField();
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate(10L, dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate(10L, dateTimeZone35);
        boolean boolean37 = localDate32.isAfter((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate41 = new org.joda.time.LocalDate(10L, dateTimeZone40);
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate45 = new org.joda.time.LocalDate(10L, dateTimeZone44);
        boolean boolean46 = localDate41.isAfter((org.joda.time.ReadablePartial) localDate45);
        boolean boolean47 = localDate36.isBefore((org.joda.time.ReadablePartial) localDate41);
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology49);
        java.lang.String str51 = dateTime50.toString();
        org.joda.time.ReadablePeriod readablePeriod52 = null;
        org.joda.time.DateTime dateTime53 = dateTime50.plus(readablePeriod52);
        org.joda.time.DateTime dateTime54 = localDate41.toDateTime((org.joda.time.ReadableInstant) dateTime50);
        int int56 = localDate41.getValue(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder57.appendClockhourOfHalfday(24);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap60 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder59.appendTimeZoneName(strMap60);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder59.appendTimeZoneId();
        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology63.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField65 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField64);
        org.joda.time.DurationField durationField66 = delegatedDateTimeField65.getLeapDurationField();
        int int69 = delegatedDateTimeField65.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType70 = delegatedDateTimeField65.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder72 = dateTimeFormatterBuilder59.appendFixedSignedDecimal(dateTimeFieldType70, 2019);
        int int73 = localDate41.get(dateTimeFieldType70);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField74 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType70);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder75 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder77 = dateTimeFormatterBuilder75.appendClockhourOfHalfday(24);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap78 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder79 = dateTimeFormatterBuilder77.appendTimeZoneName(strMap78);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder80 = dateTimeFormatterBuilder77.appendTimeZoneId();
        org.joda.time.chrono.GregorianChronology gregorianChronology81 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField82 = gregorianChronology81.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField83 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField82);
        org.joda.time.DurationField durationField84 = delegatedDateTimeField83.getLeapDurationField();
        int int87 = delegatedDateTimeField83.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType88 = delegatedDateTimeField83.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder90 = dateTimeFormatterBuilder77.appendFixedSignedDecimal(dateTimeFieldType88, 2019);
        org.joda.time.IllegalFieldValueException illegalFieldValueException92 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType88, "19");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField93 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField22, dateTimeFieldType88);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder96 = dateTimeFormatterBuilder8.appendFraction(dateTimeFieldType88, 26, (int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 19 + "'", int20 == 19);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str51.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertNotNull(gregorianChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNull(durationField66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType70);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 19 + "'", int73 == 19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder77);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder79);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder80);
        org.junit.Assert.assertNotNull(gregorianChronology81);
        org.junit.Assert.assertNotNull(dateTimeField82);
        org.junit.Assert.assertNull(durationField84);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType88);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder90);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder96);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(24);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder4.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendYearOfEra(2019, 99);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.DateTime.Property property2 = dateTime1.monthOfYear();
        org.joda.time.DateTime dateTime4 = dateTime1.minusMonths(10);
        int int5 = dateTime4.getMonthOfYear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology4);
        java.lang.String str6 = dateTime5.toString();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.plus(readablePeriod7);
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str6.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology2);
        int int4 = dateTime3.getYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.Partial partial8 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTime dateTime9 = dateTime3.toDateTime((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11);
        org.joda.time.DurationField durationField13 = delegatedDateTimeField12.getLeapDurationField();
        int int16 = delegatedDateTimeField12.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = delegatedDateTimeField12.getType();
        org.joda.time.DateTime dateTime19 = dateTime9.withField(dateTimeFieldType17, 4);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime22 = dateTime9.withDurationAdded(readableDuration20, (int) '#');
        org.joda.time.DateTime dateTime24 = dateTime9.minusMonths(20);
        boolean boolean25 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZoneBuilder0, (java.lang.Object) 20);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder27 = dateTimeZoneBuilder0.setStandardOffset(19);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder35 = dateTimeZoneBuilder0.addCutover((int) (byte) 10, ' ', (-10), (-10), 19, true, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder27);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long6 = dateTimeZone2.getMillisKeepLocal(dateTimeZone4, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone4);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4, 4);
        org.joda.time.Chronology chronology10 = julianChronology9.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(10L, dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(10L, dateTimeZone20);
        boolean boolean22 = localDate17.isAfter((org.joda.time.ReadablePartial) localDate21);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray23 = localDate17.getFieldTypes();
        int int24 = delegatedDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) localDate17);
        int[] intArray26 = julianChronology9.get((org.joda.time.ReadablePartial) localDate17, (long) (byte) 100);
        org.joda.time.DurationFieldType durationFieldType27 = null;
        boolean boolean28 = localDate17.isSupported(durationFieldType27);
        int int29 = localDate17.getDayOfYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2922790 + "'", int24 == 2922790);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        int int6 = delegatedDateTimeField2.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = delegatedDateTimeField2.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, "Property[monthOfYear]");
        java.lang.Number number10 = illegalFieldValueException9.getUpperBound();
        java.lang.String str11 = illegalFieldValueException9.toString();
        illegalFieldValueException9.prependMessage("T������");
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"Property[monthOfYear]\" for centuryOfEra is not supported" + "'", str11.equals("org.joda.time.IllegalFieldValueException: Value \"Property[monthOfYear]\" for centuryOfEra is not supported"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(10L, dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField8.getType();
        int int11 = localDate5.get(dateTimeFieldType10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType10, 5);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = localDate14.getFieldType((int) (byte) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField13, dateTimeFieldType16);
        int int18 = remainderDateTimeField13.getMaximumValue();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        org.joda.time.DurationField durationField22 = delegatedDateTimeField21.getLeapDurationField();
        int int25 = delegatedDateTimeField21.getDifference((long) 1, 1L);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField21);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField31 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology27, dateTimeField30);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField31, 4);
        int int35 = offsetDateTimeField33.getLeapAmount(100L);
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField33.getAsShortText((long) 1, locale37);
        int int40 = offsetDateTimeField33.getLeapAmount(1L);
        org.joda.time.DurationField durationField41 = offsetDateTimeField33.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField43 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField21, durationField41, dateTimeFieldType42);
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = gJChronology44.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate49 = new org.joda.time.LocalDate(10L, dateTimeZone48);
        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology50.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField52 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField51);
        org.joda.time.DurationField durationField53 = delegatedDateTimeField52.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = delegatedDateTimeField52.getType();
        int int55 = localDate49.get(dateTimeFieldType54);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField45, dateTimeFieldType54, 5);
        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType60 = localDate58.getFieldType((int) (byte) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField61 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField57, dateTimeFieldType60);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField62 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField13, durationField41, dateTimeFieldType60);
        java.util.Locale locale63 = null;
        int int64 = remainderDateTimeField13.getMaximumShortTextLength(locale63);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNull(durationField22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "5" + "'", str38.equals("5"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(gregorianChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNull(durationField53);
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 19 + "'", int55 == 19);
        org.junit.Assert.assertNotNull(dateTimeFieldType60);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTime dateTime8 = dateTime2.toDateTime((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
        org.joda.time.DateTime dateTime11 = property9.addToCopy(10);
        org.joda.time.DateTime dateTime13 = property9.setCopy(5);
        java.lang.String str14 = property9.toString();
        java.util.Locale locale15 = null;
        java.lang.String str16 = property9.getAsShortText(locale15);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1970 + "'", int3 == 1970);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Property[minuteOfDay]" + "'", str14.equals("Property[minuteOfDay]"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withOffsetParsed();
        java.io.Writer writer3 = null;
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            dateTimeFormatter2.printTo(writer3, readablePartial4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology2);
        java.lang.String str4 = dateTime3.toString();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readablePeriod5);
        org.joda.time.DateTime dateTime8 = dateTime3.minus(0L);
        org.joda.time.DateTime dateTime10 = dateTime3.withDayOfMonth((int) (byte) 10);
        boolean boolean11 = iSOChronology0.equals((java.lang.Object) dateTime10);
        int int12 = dateTime10.getYearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str4.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 70 + "'", int12 == 70);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfDay(2, (-520));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendDayOfYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendFractionOfHour(70, (int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long6 = dateTimeZone2.getMillisKeepLocal(dateTimeZone4, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeFormatter7.getZone();
        long long11 = dateTimeZone8.adjustOffset(4L, false);
        long long15 = dateTimeZone8.convertLocalToUTC((long) 18, true, (long) '#');
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 4L + "'", long11 == 4L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-82L) + "'", long15 == (-82L));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology3, dateTimeField6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, 4);
        int int11 = offsetDateTimeField9.getLeapAmount(100L);
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField9, 0);
        int int14 = offsetDateTimeField9.getMinimumValue();
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField9.getAsText((long) (short) -1, locale16);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "5" + "'", str17.equals("5"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long6 = dateTimeZone2.getMillisKeepLocal(dateTimeZone4, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone4);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4, 4);
        org.joda.time.DurationField durationField10 = julianChronology9.minutes();
        org.joda.time.Chronology chronology11 = julianChronology9.withUTC();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate(10L, dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate(10L, dateTimeZone18);
        boolean boolean20 = localDate15.isAfter((org.joda.time.ReadablePartial) localDate19);
        boolean boolean22 = localDate15.equals((java.lang.Object) 100.0f);
        int int23 = localDate15.getYear();
        boolean boolean25 = localDate15.equals((java.lang.Object) 1L);
        org.joda.time.LocalDate.Property property26 = localDate15.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long32 = dateTimeZone28.getMillisKeepLocal(dateTimeZone30, (long) (short) 0);
        org.joda.time.LocalDate localDate33 = org.joda.time.LocalDate.now(dateTimeZone28);
        org.joda.time.DateTime dateTime34 = localDate15.toDateTimeAtStartOfDay(dateTimeZone28);
        org.joda.time.Chronology chronology35 = julianChronology9.withZone(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1970 + "'", int23 == 1970);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(chronology35);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField3);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, 4);
        int int8 = offsetDateTimeField6.getLeapAmount(100L);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsShortText((long) 1, locale10);
        boolean boolean13 = offsetDateTimeField6.isLeap(0L);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField6.getAsShortText((int) (byte) -1, locale15);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(10L, dateTimeZone19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22);
        org.joda.time.DurationField durationField24 = delegatedDateTimeField23.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField23.getType();
        int int26 = localDate20.get(dateTimeFieldType25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.LocalDate localDate28 = localDate20.plus(readablePeriod27);
        int[] intArray35 = new int[] { 2922790, (short) 10, 24, (short) 100, 2019, 20 };
        int int36 = offsetDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDate20, intArray35);
        org.joda.time.LocalDate localDate38 = localDate20.withDayOfMonth(24);
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField40 = gJChronology39.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate(10L, dateTimeZone43);
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField47 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField46);
        org.joda.time.DurationField durationField48 = delegatedDateTimeField47.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = delegatedDateTimeField47.getType();
        int int50 = localDate44.get(dateTimeFieldType49);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField52 = new org.joda.time.field.RemainderDateTimeField(dateTimeField40, dateTimeFieldType49, 5);
        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology53.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField55 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField54);
        org.joda.time.DurationField durationField56 = delegatedDateTimeField55.getLeapDurationField();
        int int58 = delegatedDateTimeField55.getLeapAmount((long) (-1));
        long long60 = delegatedDateTimeField55.roundFloor((long) 3);
        org.joda.time.DateTimeZone dateTimeZone63 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate64 = new org.joda.time.LocalDate(10L, dateTimeZone63);
        org.joda.time.chrono.GregorianChronology gregorianChronology65 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField66 = gregorianChronology65.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField67 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField66);
        org.joda.time.DurationField durationField68 = delegatedDateTimeField67.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = delegatedDateTimeField67.getType();
        int int70 = localDate64.get(dateTimeFieldType69);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField72 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField55, dateTimeFieldType69, 100);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField73 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField52, dateTimeFieldType69);
        boolean boolean74 = localDate20.isSupported(dateTimeFieldType69);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1" + "'", str16.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 19 + "'", int26 == 19);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 57 + "'", int36 == 57);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNull(durationField48);
        org.junit.Assert.assertNotNull(dateTimeFieldType49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 19 + "'", int50 == 19);
        org.junit.Assert.assertNotNull(gregorianChronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNull(durationField56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-2177452800000L) + "'", long60 == (-2177452800000L));
        org.junit.Assert.assertNotNull(dateTimeZone63);
        org.junit.Assert.assertNotNull(gregorianChronology65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNull(durationField68);
        org.junit.Assert.assertNotNull(dateTimeFieldType69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 19 + "'", int70 == 19);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 0, (int) (byte) -1);
        boolean boolean4 = dateTimeZone2.isStandardOffset((long) 1);
        java.lang.String str5 = dateTimeZone2.getID();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-00:01" + "'", str5.equals("-00:01"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        int int9 = localDate3.getEra();
        org.joda.time.LocalDate.Property property10 = localDate3.era();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology12);
        java.lang.String str14 = dateTime13.toString();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.plus(readablePeriod15);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology18);
        org.joda.time.MutableDateTime mutableDateTime20 = dateTime13.toMutableDateTime((org.joda.time.Chronology) gregorianChronology18);
        int int21 = dateTime13.getMinuteOfHour();
        org.joda.time.DateTime dateTime23 = dateTime13.withDayOfMonth((int) (short) 1);
        org.joda.time.DateTime.Property property24 = dateTime23.centuryOfEra();
        boolean boolean26 = dateTime23.isEqual((-2177452800000L));
        org.joda.time.DateTime dateTime27 = dateTime23.toDateTime();
        try {
            long long28 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime27);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str14.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = localDate3.getFieldTypes();
        int[] intArray10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField15 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology11, dateTimeField14);
        try {
            org.joda.time.Partial partial16 = new org.joda.time.Partial(dateTimeFieldTypeArray9, intArray10, (org.joda.time.Chronology) gregorianChronology11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long6 = dateTimeZone2.getMillisKeepLocal(dateTimeZone4, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone4);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4, 4);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long19 = dateTimeZone15.getMillisKeepLocal(dateTimeZone17, (long) (short) 0);
        long long21 = dateTimeZone12.getMillisKeepLocal(dateTimeZone17, (long) 100);
        org.joda.time.Chronology chronology22 = julianChronology9.withZone(dateTimeZone17);
        org.joda.time.LocalDate localDate23 = org.joda.time.LocalDate.now(dateTimeZone17);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology24, dateTimeField27);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField28, 4);
        int int32 = offsetDateTimeField30.getLeapAmount(100L);
        boolean boolean33 = offsetDateTimeField30.isSupported();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate(10L, dateTimeZone36);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate41 = new org.joda.time.LocalDate(10L, dateTimeZone40);
        boolean boolean42 = localDate37.isAfter((org.joda.time.ReadablePartial) localDate41);
        boolean boolean44 = localDate37.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField47 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField46);
        org.joda.time.DurationField durationField48 = delegatedDateTimeField47.getLeapDurationField();
        int int51 = delegatedDateTimeField47.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = delegatedDateTimeField47.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException54 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType52, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property55 = localDate37.property(dateTimeFieldType52);
        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate59 = new org.joda.time.LocalDate(10L, dateTimeZone58);
        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate63 = new org.joda.time.LocalDate(10L, dateTimeZone62);
        boolean boolean64 = localDate59.isAfter((org.joda.time.ReadablePartial) localDate63);
        boolean boolean66 = localDate59.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology67 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField68 = gregorianChronology67.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField69 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField68);
        org.joda.time.DurationField durationField70 = delegatedDateTimeField69.getLeapDurationField();
        int int73 = delegatedDateTimeField69.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType74 = delegatedDateTimeField69.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException76 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType74, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property77 = localDate59.property(dateTimeFieldType74);
        boolean boolean78 = localDate37.isSupported(dateTimeFieldType74);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField80 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField30, dateTimeFieldType74, 19);
        boolean boolean81 = localDate23.isSupported(dateTimeFieldType74);
        org.joda.time.DateTimeField[] dateTimeFieldArray82 = localDate23.getFields();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNull(durationField48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(dateTimeZone62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(gregorianChronology67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNull(durationField70);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType74);
        org.junit.Assert.assertNotNull(property77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertNotNull(dateTimeFieldArray82);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.hourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.hourOfDay();
        org.joda.time.DateTime dateTime11 = dateTime6.withChronology((org.joda.time.Chronology) gregorianChronology7);
        boolean boolean12 = partial3.isMatch((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        try {
            org.joda.time.DateTime.Property property14 = dateTime11.property(dateTimeFieldType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866760000000L) + "'", long1 == (-210866760000000L));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(0, 0, 24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        java.util.Locale locale4 = null;
        int int5 = delegatedDateTimeField2.getMaximumShortTextLength(locale4);
        int int6 = delegatedDateTimeField2.getMaximumValue();
        long long8 = delegatedDateTimeField2.roundHalfFloor((long) 26);
        long long11 = delegatedDateTimeField2.set(4L, (int) '#');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2922790 + "'", int6 == 2922790);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 978307200000L + "'", long8 == 978307200000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 47335449600004L + "'", long11 == 47335449600004L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology2);
        java.lang.String str4 = dateTime3.toString();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readablePeriod5);
        org.joda.time.DateTime dateTime8 = dateTime3.minus(0L);
        org.joda.time.DateTime dateTime10 = dateTime3.withDayOfMonth((int) (byte) 10);
        boolean boolean11 = iSOChronology0.equals((java.lang.Object) dateTime10);
        org.joda.time.DateTime dateTime13 = dateTime10.plusMillis(18);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str4.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        java.lang.String str3 = dateTimeZone1.getShortName(0L);
        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.100" + "'", str3.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(localDate4);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("Property[monthOfYear]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[monthOfYear]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (-59958144000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField3);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, 4);
        int int8 = offsetDateTimeField6.getLeapAmount(100L);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsShortText((long) 1, locale10);
        boolean boolean13 = offsetDateTimeField6.isLeap(0L);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField6.getAsShortText((int) (byte) -1, locale15);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(10L, dateTimeZone22);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        org.joda.time.DurationField durationField27 = delegatedDateTimeField26.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField26.getType();
        int int29 = localDate23.get(dateTimeFieldType28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.LocalDate localDate31 = localDate23.plus(readablePeriod30);
        int[] intArray33 = gregorianChronology17.get((org.joda.time.ReadablePartial) localDate23, (long) 18);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long40 = dateTimeZone36.getMillisKeepLocal(dateTimeZone38, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter34.withZone(dateTimeZone38);
        org.joda.time.chrono.JulianChronology julianChronology43 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone38, 4);
        org.joda.time.Chronology chronology44 = julianChronology43.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField47 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField46);
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate(10L, dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate55 = new org.joda.time.LocalDate(10L, dateTimeZone54);
        boolean boolean56 = localDate51.isAfter((org.joda.time.ReadablePartial) localDate55);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray57 = localDate51.getFieldTypes();
        int int58 = delegatedDateTimeField47.getMaximumValue((org.joda.time.ReadablePartial) localDate51);
        int[] intArray60 = julianChronology43.get((org.joda.time.ReadablePartial) localDate51, (long) (byte) 100);
        int int61 = offsetDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) localDate23, intArray60);
        long long63 = offsetDateTimeField6.roundFloor(0L);
        long long65 = offsetDateTimeField6.roundCeiling((-259200000L));
        java.util.Locale locale67 = null;
        java.lang.String str68 = offsetDateTimeField6.getAsShortText((int) '#', locale67);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1" + "'", str16.equals("-1"));
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 19 + "'", int29 == 19);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(julianChronology43);
        org.junit.Assert.assertNotNull(chronology44);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2922790 + "'", int58 == 2922790);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 5 + "'", int61 == 5);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-259200000L) + "'", long63 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-259200000L) + "'", long65 == (-259200000L));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "35" + "'", str68.equals("35"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField3);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, 4);
        int int8 = offsetDateTimeField6.getLeapAmount(100L);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsShortText((long) 1, locale10);
        boolean boolean13 = offsetDateTimeField6.isLeap(0L);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField6.getAsShortText((int) (byte) -1, locale15);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(10L, dateTimeZone22);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        org.joda.time.DurationField durationField27 = delegatedDateTimeField26.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField26.getType();
        int int29 = localDate23.get(dateTimeFieldType28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.LocalDate localDate31 = localDate23.plus(readablePeriod30);
        int[] intArray33 = gregorianChronology17.get((org.joda.time.ReadablePartial) localDate23, (long) 18);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long40 = dateTimeZone36.getMillisKeepLocal(dateTimeZone38, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter34.withZone(dateTimeZone38);
        org.joda.time.chrono.JulianChronology julianChronology43 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone38, 4);
        org.joda.time.Chronology chronology44 = julianChronology43.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField47 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField46);
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate(10L, dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate55 = new org.joda.time.LocalDate(10L, dateTimeZone54);
        boolean boolean56 = localDate51.isAfter((org.joda.time.ReadablePartial) localDate55);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray57 = localDate51.getFieldTypes();
        int int58 = delegatedDateTimeField47.getMaximumValue((org.joda.time.ReadablePartial) localDate51);
        int[] intArray60 = julianChronology43.get((org.joda.time.ReadablePartial) localDate51, (long) (byte) 100);
        int int61 = offsetDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) localDate23, intArray60);
        org.joda.time.DateTime dateTime62 = localDate23.toDateTimeAtCurrentTime();
        org.joda.time.DateTime dateTime67 = dateTime62.withTime((int) (short) 1, (int) ' ', 0, (int) (byte) 100);
        org.joda.time.DateTime dateTime69 = dateTime67.plusSeconds(99);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1" + "'", str16.equals("-1"));
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 19 + "'", int29 == 19);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(julianChronology43);
        org.junit.Assert.assertNotNull(chronology44);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2922790 + "'", int58 == 2922790);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 5 + "'", int61 == 5);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(dateTime69);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        boolean boolean10 = localDate3.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        int int17 = delegatedDateTimeField13.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = delegatedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property21 = localDate3.property(dateTimeFieldType18);
        org.joda.time.LocalDate localDate23 = property21.setCopy(100);
        org.joda.time.LocalDate localDate24 = property21.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(localDate24);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = delegatedDateTimeField2.getType();
        long long7 = delegatedDateTimeField2.add((long) (short) -1, (long) (short) 1);
        long long10 = delegatedDateTimeField2.add((long) 2019, (int) (byte) 0);
        long long13 = delegatedDateTimeField2.add(1L, 0);
        int int15 = delegatedDateTimeField2.getMinimumValue(3155759999999L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = delegatedDateTimeField2.getAsText(7, locale17);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155759999999L + "'", long7 == 3155759999999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "7" + "'", str18.equals("7"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.joda.time.Chronology chronology2 = gJChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.centuryOfEra();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long6 = dateTimeZone2.getMillisKeepLocal(dateTimeZone4, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone4);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4, 4);
        org.joda.time.Chronology chronology10 = julianChronology9.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(10L, dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(10L, dateTimeZone20);
        boolean boolean22 = localDate17.isAfter((org.joda.time.ReadablePartial) localDate21);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray23 = localDate17.getFieldTypes();
        int int24 = delegatedDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) localDate17);
        int[] intArray26 = julianChronology9.get((org.joda.time.ReadablePartial) localDate17, (long) (byte) 100);
        org.joda.time.DurationFieldType durationFieldType27 = null;
        boolean boolean28 = localDate17.isSupported(durationFieldType27);
        int int29 = localDate17.getYearOfEra();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2922790 + "'", int24 == 2922790);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1970 + "'", int29 == 1970);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = delegatedDateTimeField2.getType();
        int int7 = delegatedDateTimeField2.getDifference((long) (byte) 1, 1560638273285L);
        org.joda.time.DateTimeField dateTimeField8 = delegatedDateTimeField2.getWrappedField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long5 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, (long) (short) 0);
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone3.isLocalDateTimeGap(localDateTime6);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, 3);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.dayOfMonth();
        try {
            long long18 = gregorianChronology9.getDateTimeMillis(19, 99, (int) (short) 10, 1, 10, 8, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 99 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField5);
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5, (int) (byte) -1);
        long long10 = skipDateTimeField8.roundHalfCeiling(60100L);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField8);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-259200000L) + "'", long10 == (-259200000L));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfDay(2, (-520));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfDay(0, 1970);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField3);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, 4);
        int int7 = skipDateTimeField4.getMinimumValue();
        long long10 = skipDateTimeField4.add((long) 166, (long) 166);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100396800166L + "'", long10 == 100396800166L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(24);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMinuteOfDay(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = delegatedDateTimeField2.getType();
        long long7 = delegatedDateTimeField2.add((long) (short) -1, (long) (short) 1);
        long long10 = delegatedDateTimeField2.add((long) 2019, (int) (byte) 0);
        org.joda.time.DateTimeField dateTimeField11 = delegatedDateTimeField2.getWrappedField();
        try {
            long long14 = delegatedDateTimeField2.set(31449593950L, "org.joda.time.IllegalFieldValueException: Value null for hi! must be in the range [100,978307200000]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalFieldValueException: Value null for hi! must be in the range [100,978307200000]\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155759999999L + "'", long7 == 3155759999999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(10L, dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField8.getType();
        int int11 = localDate5.get(dateTimeFieldType10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType10, 5);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = localDate14.getFieldType((int) (byte) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField13, dateTimeFieldType16);
        int int20 = dividedDateTimeField17.getDifference((long) 1, (long) (-1));
        int int22 = dividedDateTimeField17.get((long) (-1));
        int int25 = dividedDateTimeField17.getDifference((long) (byte) -1, (-1L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField26 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.hourOfDay();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology27.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology32);
        java.lang.String str34 = dateTime33.toString();
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime33.plus(readablePeriod35);
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology38);
        org.joda.time.MutableDateTime mutableDateTime40 = dateTime33.toMutableDateTime((org.joda.time.Chronology) gregorianChronology38);
        int int41 = dateTime33.getMinuteOfHour();
        org.joda.time.DateTime dateTime43 = dateTime33.withSecondOfMinute(1);
        org.joda.time.DateTime.Property property44 = dateTime33.centuryOfEra();
        org.joda.time.DateTime dateTime46 = property44.setCopy("1");
        boolean boolean47 = gregorianChronology27.equals((java.lang.Object) property44);
        org.joda.time.DurationField durationField48 = gregorianChronology27.days();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder49.appendClockhourOfHalfday(24);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap52 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder51.appendTimeZoneName(strMap52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder51.appendTimeZoneId();
        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology55.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField57 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField56);
        org.joda.time.DurationField durationField58 = delegatedDateTimeField57.getLeapDurationField();
        int int61 = delegatedDateTimeField57.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = delegatedDateTimeField57.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder51.appendFixedSignedDecimal(dateTimeFieldType62, 2019);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField65 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17, durationField48, dateTimeFieldType62);
        org.joda.time.chrono.GJChronology gJChronology66 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField67 = gJChronology66.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate71 = new org.joda.time.LocalDate(10L, dateTimeZone70);
        org.joda.time.chrono.GregorianChronology gregorianChronology72 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField73 = gregorianChronology72.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField74 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField73);
        org.joda.time.DurationField durationField75 = delegatedDateTimeField74.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType76 = delegatedDateTimeField74.getType();
        int int77 = localDate71.get(dateTimeFieldType76);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField79 = new org.joda.time.field.RemainderDateTimeField(dateTimeField67, dateTimeFieldType76, 5);
        org.joda.time.LocalDate localDate80 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType82 = localDate80.getFieldType((int) (byte) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField79, dateTimeFieldType82);
        org.joda.time.DurationField durationField84 = remainderDateTimeField79.getDurationField();
        org.joda.time.DurationField durationField85 = remainderDateTimeField79.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField86 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType62, durationField85);
        org.joda.time.ReadablePartial readablePartial87 = null;
        int[] intArray93 = new int[] { 8, (byte) 10, 26, 100 };
        try {
            int[] intArray95 = unsupportedDateTimeField86.addWrapField(readablePartial87, (-520), intArray93, (-24));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str34.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(mutableDateTime40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(gregorianChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNull(durationField58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(gJChronology66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(dateTimeZone70);
        org.junit.Assert.assertNotNull(gregorianChronology72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertNull(durationField75);
        org.junit.Assert.assertNotNull(dateTimeFieldType76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 19 + "'", int77 == 19);
        org.junit.Assert.assertNotNull(dateTimeFieldType82);
        org.junit.Assert.assertNotNull(durationField84);
        org.junit.Assert.assertNotNull(durationField85);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField86);
        org.junit.Assert.assertNotNull(intArray93);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long6 = dateTimeZone2.getMillisKeepLocal(dateTimeZone4, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone4);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4, 4);
        org.joda.time.Chronology chronology10 = julianChronology9.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(10L, dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(10L, dateTimeZone20);
        boolean boolean22 = localDate17.isAfter((org.joda.time.ReadablePartial) localDate21);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray23 = localDate17.getFieldTypes();
        int int24 = delegatedDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) localDate17);
        int[] intArray26 = julianChronology9.get((org.joda.time.ReadablePartial) localDate17, (long) (byte) 100);
        java.lang.String str27 = julianChronology9.toString();
        java.lang.String str28 = julianChronology9.toString();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2922790 + "'", int24 == 2922790);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "JulianChronology[+00:00:00.100]" + "'", str27.equals("JulianChronology[+00:00:00.100]"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "JulianChronology[+00:00:00.100]" + "'", str28.equals("JulianChronology[+00:00:00.100]"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(10L, dateTimeZone9);
        boolean boolean11 = localDate6.isAfter((org.joda.time.ReadablePartial) localDate10);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray12 = localDate6.getFieldTypes();
        int int13 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate6);
        int int15 = delegatedDateTimeField2.getMinimumValue((long) 0);
        org.joda.time.ReadablePartial readablePartial16 = null;
        int[] intArray23 = new int[] { 100, (-520), (byte) -1, 10, 1970, 19 };
        int int24 = delegatedDateTimeField2.getMaximumValue(readablePartial16, intArray23);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate(10L, dateTimeZone27);
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate(10L, dateTimeZone31);
        boolean boolean33 = localDate28.isAfter((org.joda.time.ReadablePartial) localDate32);
        boolean boolean35 = localDate28.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField37);
        org.joda.time.DurationField durationField39 = delegatedDateTimeField38.getLeapDurationField();
        int int42 = delegatedDateTimeField38.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = delegatedDateTimeField38.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException45 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property46 = localDate28.property(dateTimeFieldType43);
        java.util.Locale locale47 = null;
        java.lang.String str48 = delegatedDateTimeField2.getAsShortText((org.joda.time.ReadablePartial) localDate28, locale47);
        java.util.Locale locale49 = null;
        int int50 = delegatedDateTimeField2.getMaximumTextLength(locale49);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2922790 + "'", int13 == 2922790);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2922790 + "'", int24 == 2922790);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNull(durationField39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "19" + "'", str48.equals("19"));
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 7 + "'", int50 == 7);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale2 = null;
        java.lang.String str5 = defaultNameProvider0.getShortName(locale2, "7", "minuteOfDay");
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        java.lang.String str3 = dateTime2.toString();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology7);
        java.lang.String str9 = dateTime8.toString();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime8.plus(readablePeriod10);
        boolean boolean12 = dateTime2.isEqual((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(10L, dateTimeZone17);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        org.joda.time.DurationField durationField22 = delegatedDateTimeField21.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = delegatedDateTimeField21.getType();
        int int24 = localDate18.get(dateTimeFieldType23);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField26 = new org.joda.time.field.RemainderDateTimeField(dateTimeField14, dateTimeFieldType23, 5);
        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = localDate27.getFieldType((int) (byte) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField30 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField26, dateTimeFieldType29);
        org.joda.time.DurationField durationField31 = remainderDateTimeField26.getDurationField();
        org.joda.time.DurationField durationField32 = remainderDateTimeField26.getRangeDurationField();
        org.joda.time.DurationField durationField33 = remainderDateTimeField26.getDurationField();
        int int34 = dateTime8.get((org.joda.time.DateTimeField) remainderDateTimeField26);
        long long36 = remainderDateTimeField26.roundHalfCeiling(60100L);
        long long39 = remainderDateTimeField26.getDifferenceAsLong(259200018L, (long) 166);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str3.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str9.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 19 + "'", int24 == 19);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-259200000L) + "'", long36 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        java.util.Locale locale4 = null;
        int int5 = delegatedDateTimeField2.getMaximumShortTextLength(locale4);
        try {
            long long8 = delegatedDateTimeField2.set(3213215999999L, "GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[UTC]\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(10L, dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField8.getType();
        int int11 = localDate5.get(dateTimeFieldType10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType10, 5);
        long long15 = remainderDateTimeField13.roundHalfEven((long) 292279000);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 345600000L + "'", long15 == 345600000L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("Jan");
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("ISOChronology[UTC]");
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.joda.time.LocalTime localTime3 = dateTimeFormatter0.parseLocalTime("1970-01-01");
        java.lang.Integer int4 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(localTime3);
        org.junit.Assert.assertNull(int4);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        int int6 = delegatedDateTimeField2.getDifference((long) 1, 1L);
        long long8 = delegatedDateTimeField2.roundHalfEven((long) 100);
        java.util.Locale locale10 = null;
        java.lang.String str11 = delegatedDateTimeField2.getAsShortText((-259200000L), locale10);
        long long13 = delegatedDateTimeField2.roundHalfFloor((-5217L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 978307200000L + "'", long8 == 978307200000L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "20" + "'", str11.equals("20"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 978307200000L + "'", long13 == 978307200000L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 20, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime.Property property3 = dateTime2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = property3.getField();
        try {
            org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((java.lang.Object) property3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.DateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate(10L, dateTimeZone9);
        boolean boolean11 = localDate6.isAfter((org.joda.time.ReadablePartial) localDate10);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray12 = localDate6.getFieldTypes();
        int int13 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate6);
        int int15 = delegatedDateTimeField2.getMinimumValue((long) 0);
        org.joda.time.ReadablePartial readablePartial16 = null;
        int[] intArray23 = new int[] { 100, (-520), (byte) -1, 10, 1970, 19 };
        int int24 = delegatedDateTimeField2.getMaximumValue(readablePartial16, intArray23);
        java.lang.String str26 = delegatedDateTimeField2.getAsText((long) (byte) 0);
        long long28 = delegatedDateTimeField2.roundCeiling((-6050L));
        java.util.Locale locale30 = null;
        java.lang.String str31 = delegatedDateTimeField2.getAsShortText(0, locale30);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2922790 + "'", int13 == 2922790);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2922790 + "'", int24 == 2922790);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "20" + "'", str26.equals("20"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 978307200000L + "'", long28 == 978307200000L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(24);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTimeZoneId();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getLeapDurationField();
        int int12 = delegatedDateTimeField8.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = delegatedDateTimeField8.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder2.appendFixedSignedDecimal(dateTimeFieldType13, 2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder2.appendMinuteOfHour((int) ' ');
        org.joda.time.format.DateTimePrinter dateTimePrinter18 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendLiteral("ISOChronology[UTC]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder21.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder21.appendMillisOfDay((int) 'a');
        org.joda.time.format.DateTimeParser dateTimeParser25 = dateTimeFormatterBuilder24.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter18, dateTimeParser25);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder2.appendOptional(dateTimeParser25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeParser25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", number1, (java.lang.Number) 100L, (java.lang.Number) 978307200000L);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.Number number6 = illegalFieldValueException4.getUpperBound();
        java.lang.Number number7 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 978307200000L + "'", number6.equals(978307200000L));
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(10L, dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField8.getType();
        int int11 = localDate5.get(dateTimeFieldType10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType10, 5);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = localDate14.getFieldType((int) (byte) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField13, dateTimeFieldType16);
        int int20 = dividedDateTimeField17.getDifference((long) 1, (long) (-1));
        int int22 = dividedDateTimeField17.get((long) (-1));
        try {
            long long24 = dividedDateTimeField17.roundHalfCeiling((long) 166);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        java.lang.String str3 = dateTime2.toString();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime2.toMutableDateTime((org.joda.time.Chronology) gregorianChronology7);
        int int10 = dateTime2.getMinuteOfHour();
        org.joda.time.DateTime dateTime12 = dateTime2.withSecondOfMinute(1);
        org.joda.time.DateTime.Property property13 = dateTime2.centuryOfEra();
        org.joda.time.DateTime dateTime15 = property13.setCopy("1");
        org.joda.time.DateTime dateTime16 = property13.getDateTime();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str3.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        boolean boolean10 = localDate3.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        int int17 = delegatedDateTimeField13.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = delegatedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property21 = localDate3.property(dateTimeFieldType18);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.LocalDate localDate23 = localDate3.plus(readablePeriod22);
        org.joda.time.LocalDate.Property property24 = localDate3.dayOfYear();
        java.util.Locale locale25 = null;
        int int26 = property24.getMaximumTextLength(locale25);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3 + "'", int26 == 3);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        java.lang.String str3 = dateTime2.toString();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime2.minus(0L);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = property8.getDateTime();
        org.joda.time.DateTime dateTime10 = property8.roundHalfEvenCopy();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology12);
        int int14 = dateTime13.getYear();
        org.joda.time.DateTime dateTime16 = dateTime13.minus(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology18);
        java.lang.String str20 = dateTime19.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology22);
        java.lang.String str24 = dateTime23.toString();
        boolean boolean25 = dateTime19.isAfter((org.joda.time.ReadableInstant) dateTime23);
        int int26 = dateTime19.getHourOfDay();
        int int27 = dateTime19.getMonthOfYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.centuryOfEra();
        int int30 = gregorianChronology28.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology28.weekyear();
        int int32 = gregorianChronology28.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology28.secondOfMinute();
        org.joda.time.DateTime dateTime34 = dateTime19.toDateTime((org.joda.time.Chronology) gregorianChronology28);
        boolean boolean35 = dateTime13.isEqual((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTime dateTime36 = dateTime34.withEarlierOffsetAtOverlap();
        int int37 = dateTime10.compareTo((org.joda.time.ReadableInstant) dateTime36);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str3.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1970 + "'", int14 == 1970);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str20.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str24.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTime dateTime8 = dateTime2.toDateTime((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
        org.joda.time.DateTime dateTime11 = property9.addToCopy(10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology12, dateTimeField15);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField16, 4);
        int int20 = offsetDateTimeField18.getLeapAmount(100L);
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField18.getAsShortText((long) 1, locale22);
        int int25 = offsetDateTimeField18.getLeapAmount(1L);
        int int26 = dateTime11.get((org.joda.time.DateTimeField) offsetDateTimeField18);
        org.joda.time.DateTime dateTime28 = dateTime11.minusMonths((int) (byte) 100);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1970 + "'", int3 == 1970);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "5" + "'", str23.equals("5"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 5 + "'", int26 == 5);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        boolean boolean10 = localDate3.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        int int17 = delegatedDateTimeField13.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = delegatedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property21 = localDate3.property(dateTimeFieldType18);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.centuryOfEra();
        org.joda.time.DurationField durationField24 = gregorianChronology22.weekyears();
        org.joda.time.DurationField durationField25 = gregorianChronology22.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField25);
        try {
            long long28 = unsupportedDateTimeField26.roundHalfFloor(3213215999999L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long6 = dateTimeZone2.getMillisKeepLocal(dateTimeZone4, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone4);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4, 4);
        org.joda.time.Chronology chronology10 = julianChronology9.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(10L, dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(10L, dateTimeZone20);
        boolean boolean22 = localDate17.isAfter((org.joda.time.ReadablePartial) localDate21);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray23 = localDate17.getFieldTypes();
        int int24 = delegatedDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) localDate17);
        int[] intArray26 = julianChronology9.get((org.joda.time.ReadablePartial) localDate17, (long) (byte) 100);
        int int27 = julianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate((org.joda.time.Chronology) julianChronology9);
        java.util.Date date29 = localDate28.toDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2922790 + "'", int24 == 2922790);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(date29);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long6 = dateTimeZone2.getMillisKeepLocal(dateTimeZone4, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone4);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4, 4);
        org.joda.time.Chronology chronology10 = julianChronology9.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(10L, dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(10L, dateTimeZone20);
        boolean boolean22 = localDate17.isAfter((org.joda.time.ReadablePartial) localDate21);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray23 = localDate17.getFieldTypes();
        int int24 = delegatedDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) localDate17);
        int[] intArray26 = julianChronology9.get((org.joda.time.ReadablePartial) localDate17, (long) (byte) 100);
        org.joda.time.LocalDate.Property property27 = localDate17.yearOfCentury();
        int int28 = property27.getMaximumValue();
        org.joda.time.DurationField durationField29 = property27.getRangeDurationField();
        try {
            org.joda.time.LocalDate localDate31 = property27.setCopy("��:��:��");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"��:��:��\" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2922790 + "'", int24 == 2922790);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 99 + "'", int28 == 99);
        org.junit.Assert.assertNotNull(durationField29);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        java.lang.String str3 = dateTime2.toString();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.minus(readablePeriod6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime9 = dateTime7.withZoneRetainFields(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str3.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gJChronology4.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField5);
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField5, (int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone9 = gJChronology0.getZone();
        org.joda.time.Instant instant10 = gJChronology0.getGregorianCutover();
        int int11 = gJChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(instant10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology2);
        java.lang.String str4 = dateTime3.toString();
        org.joda.time.DateTime dateTime6 = dateTime3.minus((long) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime3.getZone();
        org.joda.time.Chronology chronology8 = buddhistChronology0.withZone(dateTimeZone7);
        java.lang.Object obj9 = null;
        boolean boolean10 = buddhistChronology0.equals(obj9);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str4.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField3);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, 4);
        int int8 = offsetDateTimeField6.getLeapAmount(100L);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsShortText((long) 1, locale10);
        boolean boolean13 = offsetDateTimeField6.isLeap(0L);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField6.getAsShortText((int) (byte) -1, locale15);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(10L, dateTimeZone22);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        org.joda.time.DurationField durationField27 = delegatedDateTimeField26.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField26.getType();
        int int29 = localDate23.get(dateTimeFieldType28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.LocalDate localDate31 = localDate23.plus(readablePeriod30);
        int[] intArray33 = gregorianChronology17.get((org.joda.time.ReadablePartial) localDate23, (long) 18);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long40 = dateTimeZone36.getMillisKeepLocal(dateTimeZone38, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter34.withZone(dateTimeZone38);
        org.joda.time.chrono.JulianChronology julianChronology43 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone38, 4);
        org.joda.time.Chronology chronology44 = julianChronology43.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField47 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField46);
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate(10L, dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate55 = new org.joda.time.LocalDate(10L, dateTimeZone54);
        boolean boolean56 = localDate51.isAfter((org.joda.time.ReadablePartial) localDate55);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray57 = localDate51.getFieldTypes();
        int int58 = delegatedDateTimeField47.getMaximumValue((org.joda.time.ReadablePartial) localDate51);
        int[] intArray60 = julianChronology43.get((org.joda.time.ReadablePartial) localDate51, (long) (byte) 100);
        int int61 = offsetDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) localDate23, intArray60);
        org.joda.time.LocalDate.Property property62 = localDate23.dayOfWeek();
        org.joda.time.DateTime dateTime63 = localDate23.toDateTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1" + "'", str16.equals("-1"));
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 19 + "'", int29 == 19);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(julianChronology43);
        org.junit.Assert.assertNotNull(chronology44);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2922790 + "'", int58 == 2922790);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 5 + "'", int61 == 5);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertNotNull(dateTime63);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = buddhistChronology0.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        boolean boolean3 = cachedDateTimeZone2.isFixed();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 10);
        org.joda.time.Instant instant4 = instant1.withDurationAdded(3155759999999L, (int) (byte) 10);
        org.joda.time.Instant instant6 = instant1.plus((long) (-1));
        org.joda.time.MutableDateTime mutableDateTime7 = instant1.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("-00:01");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-00:01\" is malformed at \":01\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField3);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4);
        long long8 = skipDateTimeField4.set((-59958144000000L), (int) '4');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-59927299200000L) + "'", long8 == (-59927299200000L));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DurationField durationField1 = julianChronology0.weeks();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = buddhistChronology0.getZone();
        long long5 = buddhistChronology0.add((long) 1, (long) (-520), 19);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-9879L) + "'", long5 == (-9879L));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = delegatedDateTimeField2.getType();
        long long7 = delegatedDateTimeField2.add((long) (short) -1, (long) (short) 1);
        long long10 = delegatedDateTimeField2.add((long) 2019, (int) (byte) 0);
        java.lang.String str11 = delegatedDateTimeField2.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155759999999L + "'", long7 == 3155759999999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "DateTimeField[centuryOfEra]" + "'", str11.equals("DateTimeField[centuryOfEra]"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long7 = dateTimeZone3.getMillisKeepLocal(dateTimeZone5, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone5);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5, 4);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(10L, dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long20 = dateTimeZone16.getMillisKeepLocal(dateTimeZone18, (long) (short) 0);
        long long22 = dateTimeZone13.getMillisKeepLocal(dateTimeZone18, (long) 100);
        org.joda.time.Chronology chronology23 = julianChronology10.withZone(dateTimeZone18);
        org.joda.time.LocalDate localDate24 = org.joda.time.LocalDate.now(dateTimeZone18);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) 292279000, dateTimeZone18);
        org.joda.time.DateTime dateTime27 = dateTime25.plusYears((int) (short) -1);
        int int28 = dateTime27.getDayOfYear();
        org.joda.time.DateTime dateTime30 = dateTime27.minusMonths((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(dateTime30);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8);
        org.joda.time.DurationField durationField10 = delegatedDateTimeField9.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField9.getType();
        int int12 = localDate6.get(dateTimeFieldType11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.LocalDate localDate14 = localDate6.plus(readablePeriod13);
        int[] intArray16 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDate6, (long) 18);
        org.joda.time.LocalDate.Property property17 = localDate6.era();
        org.joda.time.LocalDate localDate18 = property17.roundHalfEvenCopy();
        org.joda.time.LocalDate.Property property19 = localDate18.weekyear();
        org.joda.time.LocalDate localDate21 = localDate18.plusMonths(2);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(localDate21);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendMinuteOfDay(10);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTimeZoneName(strMap8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(strMap8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = null;
        java.lang.String str5 = dateTime2.toString(dateTimeFormatter4);
        org.joda.time.DateTime.Property property6 = dateTime2.dayOfWeek();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1970 + "'", int3 == 1970);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str5.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) 'a', 19);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 116 + "'", int2 == 116);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(10L, dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField8.getType();
        int int11 = localDate5.get(dateTimeFieldType10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType10, 5);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = localDate14.getFieldType((int) (byte) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField13, dateTimeFieldType16);
        int int20 = dividedDateTimeField17.getDifference((long) 1, (long) (-1));
        int int22 = dividedDateTimeField17.get((long) (-1));
        int int24 = dividedDateTimeField17.get((long) 7);
        long long27 = dividedDateTimeField17.getDifferenceAsLong((-210866673600000L), (long) 4);
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate(10L, dateTimeZone30);
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate(10L, dateTimeZone34);
        boolean boolean36 = localDate31.isAfter((org.joda.time.ReadablePartial) localDate35);
        boolean boolean38 = localDate31.equals((java.lang.Object) 100.0f);
        int int39 = localDate31.getYear();
        boolean boolean41 = localDate31.equals((java.lang.Object) 1L);
        org.joda.time.LocalDate.Property property42 = localDate31.dayOfWeek();
        boolean boolean43 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDate31);
        int[] intArray45 = null;
        try {
            int[] intArray47 = dividedDateTimeField17.set((org.joda.time.ReadablePartial) localDate31, 126, intArray45, 2922790);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2922790 for year must be in the range [0,10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-69731L) + "'", long27 == (-69731L));
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1970 + "'", int39 == 1970);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.hourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.hourOfDay();
        org.joda.time.DateTime dateTime11 = dateTime6.withChronology((org.joda.time.Chronology) gregorianChronology7);
        boolean boolean12 = partial3.isMatch((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.Partial partial15 = partial3.withPeriodAdded(readablePeriod13, 24);
        org.joda.time.Chronology chronology16 = partial15.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = partial15.getFormatter();
        org.joda.time.DurationFieldType durationFieldType18 = null;
        try {
            org.joda.time.Partial partial20 = partial15.withFieldAddWrapped(durationFieldType18, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(partial15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNull(dateTimeFormatter17);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.hourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.hourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime2.withChronology((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology3.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(10L, dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(10L, dateTimeZone15);
        boolean boolean17 = localDate12.isAfter((org.joda.time.ReadablePartial) localDate16);
        boolean boolean18 = localDate7.isBefore((org.joda.time.ReadablePartial) localDate12);
        org.joda.time.Partial partial19 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate12);
        java.lang.String str20 = partial19.toString();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.Partial partial22 = partial19.plus(readablePeriod21);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology24);
        java.lang.String str26 = dateTime25.toString();
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.plus(readablePeriod27);
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology30);
        java.lang.String str32 = dateTime31.toString();
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.DateTime dateTime34 = dateTime31.plus(readablePeriod33);
        boolean boolean35 = dateTime25.isEqual((org.joda.time.ReadableInstant) dateTime31);
        boolean boolean36 = partial19.isMatch((org.joda.time.ReadableInstant) dateTime25);
        java.lang.String str37 = partial19.toString();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1970-01-01" + "'", str20.equals("1970-01-01"));
        org.junit.Assert.assertNotNull(partial22);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str26.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str32.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1970-01-01" + "'", str37.equals("1970-01-01"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(19, 0, 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        int int6 = delegatedDateTimeField2.getDifference((long) 1, 1L);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology8, dateTimeField11);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField12, 4);
        int int16 = offsetDateTimeField14.getLeapAmount(100L);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField14.getAsShortText((long) 1, locale18);
        int int21 = offsetDateTimeField14.getLeapAmount(1L);
        org.joda.time.DurationField durationField22 = offsetDateTimeField14.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, durationField22, dateTimeFieldType23);
        long long27 = delegatedDateTimeField2.add(4L, (int) (short) 1);
        java.lang.String str28 = delegatedDateTimeField2.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "5" + "'", str19.equals("5"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 3155760000004L + "'", long27 == 3155760000004L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "DateTimeField[centuryOfEra]" + "'", str28.equals("DateTimeField[centuryOfEra]"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTime dateTime8 = dateTime2.toDateTime((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTime.Property property9 = dateTime8.minuteOfDay();
        org.joda.time.DateTime dateTime11 = property9.addToCopy(10);
        org.joda.time.DateTime dateTime13 = property9.addToCopy((long) 10);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1970 + "'", int3 == 1970);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology2);
        java.lang.String str4 = dateTime3.toString();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readablePeriod5);
        org.joda.time.LocalTime localTime7 = dateTime6.toLocalTime();
        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localTime7);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology10);
        java.lang.String str12 = dateTime11.toString();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.plus(readablePeriod13);
        org.joda.time.DateTime dateTime16 = dateTime11.minus(0L);
        org.joda.time.DateTime.Property property17 = dateTime16.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = property17.getDateTime();
        org.joda.time.DateTime dateTime20 = property17.addToCopy(20);
        java.lang.String str21 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime20);
        try {
            org.joda.time.DateTime dateTime23 = dateTime20.withMinuteOfHour((-24));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -24 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str4.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����-W��-�T00:00:00.010" + "'", str8.equals("����-W��-�T00:00:00.010"));
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str12.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970-W21-4T00:00:00.010Z" + "'", str21.equals("1970-W21-4T00:00:00.010Z"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant2 = gJChronology1.getGregorianCutover();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology3, dateTimeField6);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, dateTimeField6, (int) (byte) -1);
        org.joda.time.DateTimeZone dateTimeZone10 = gJChronology1.getZone();
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (short) -1, (org.joda.time.Chronology) gJChronology1);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(10L, dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField8.getType();
        int int11 = localDate5.get(dateTimeFieldType10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType10, 5);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = localDate14.getFieldType((int) (byte) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField13, dateTimeFieldType16);
        int int18 = remainderDateTimeField13.getMaximumValue();
        org.joda.time.DurationField durationField19 = remainderDateTimeField13.getRangeDurationField();
        org.joda.time.DurationField durationField20 = remainderDateTimeField13.getDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getYear();
        org.joda.time.DateTime dateTime5 = dateTime2.minus(0L);
        org.joda.time.DateTime dateTime7 = dateTime5.minusMinutes(53);
        int int8 = dateTime7.getYear();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1970 + "'", int3 == 1970);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(10L, dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField8.getType();
        int int11 = localDate5.get(dateTimeFieldType10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType10, 5);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = localDate14.getFieldType((int) (byte) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField13, dateTimeFieldType16);
        int int20 = dividedDateTimeField17.getDifference((long) 1, (long) (-1));
        int int22 = dividedDateTimeField17.get((long) (-1));
        int int23 = dividedDateTimeField17.getMaximumValue();
        long long26 = dividedDateTimeField17.add(0L, 0);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField3);
        int int5 = skipDateTimeField4.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate(10L, dateTimeZone8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11);
        org.joda.time.DurationField durationField13 = delegatedDateTimeField12.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField12.getType();
        int int15 = localDate9.get(dateTimeFieldType14);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, dateTimeFieldType14, 10);
        boolean boolean18 = skipDateTimeField4.isLenient();
        org.joda.time.LocalDate localDate20 = org.joda.time.LocalDate.parse("1969-365");
        int int21 = skipDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate20);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 19 + "'", int15 == 19);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 53 + "'", int21 == 53);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate(10L, dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate16 = new org.joda.time.LocalDate(10L, dateTimeZone15);
        boolean boolean17 = localDate12.isAfter((org.joda.time.ReadablePartial) localDate16);
        boolean boolean18 = localDate7.isBefore((org.joda.time.ReadablePartial) localDate12);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology20);
        java.lang.String str22 = dateTime21.toString();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime24 = dateTime21.plus(readablePeriod23);
        org.joda.time.DateTime dateTime25 = localDate12.toDateTime((org.joda.time.ReadableInstant) dateTime21);
        int int27 = localDate12.getValue(2);
        int int28 = localDate12.getCenturyOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str22.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 19 + "'", int28 == 19);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField3);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, 4);
        int int8 = offsetDateTimeField6.getLeapAmount(100L);
        boolean boolean9 = offsetDateTimeField6.isSupported();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate(10L, dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(10L, dateTimeZone16);
        boolean boolean18 = localDate13.isAfter((org.joda.time.ReadablePartial) localDate17);
        boolean boolean20 = localDate13.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22);
        org.joda.time.DurationField durationField24 = delegatedDateTimeField23.getLeapDurationField();
        int int27 = delegatedDateTimeField23.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField23.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property31 = localDate13.property(dateTimeFieldType28);
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate(10L, dateTimeZone34);
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate39 = new org.joda.time.LocalDate(10L, dateTimeZone38);
        boolean boolean40 = localDate35.isAfter((org.joda.time.ReadablePartial) localDate39);
        boolean boolean42 = localDate35.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology43.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField44);
        org.joda.time.DurationField durationField46 = delegatedDateTimeField45.getLeapDurationField();
        int int49 = delegatedDateTimeField45.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = delegatedDateTimeField45.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException52 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType50, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property53 = localDate35.property(dateTimeFieldType50);
        boolean boolean54 = localDate13.isSupported(dateTimeFieldType50);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType50, 19);
        org.joda.time.ReadablePartial readablePartial57 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology58 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField59 = gregorianChronology58.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology60 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField61 = gJChronology60.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField62 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology58, dateTimeField61);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField64 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField62, 4);
        int int66 = offsetDateTimeField64.getLeapAmount(100L);
        java.util.Locale locale68 = null;
        java.lang.String str69 = offsetDateTimeField64.getAsShortText((long) 1, locale68);
        boolean boolean71 = offsetDateTimeField64.isLeap(0L);
        java.util.Locale locale73 = null;
        java.lang.String str74 = offsetDateTimeField64.getAsShortText((int) (byte) -1, locale73);
        org.joda.time.DateTimeZone dateTimeZone77 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate78 = new org.joda.time.LocalDate(10L, dateTimeZone77);
        org.joda.time.chrono.GregorianChronology gregorianChronology79 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField80 = gregorianChronology79.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField81 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField80);
        org.joda.time.DurationField durationField82 = delegatedDateTimeField81.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType83 = delegatedDateTimeField81.getType();
        int int84 = localDate78.get(dateTimeFieldType83);
        org.joda.time.ReadablePeriod readablePeriod85 = null;
        org.joda.time.LocalDate localDate86 = localDate78.plus(readablePeriod85);
        int[] intArray93 = new int[] { 2922790, (short) 10, 24, (short) 100, 2019, 20 };
        int int94 = offsetDateTimeField64.getMaximumValue((org.joda.time.ReadablePartial) localDate78, intArray93);
        int int95 = offsetDateTimeField56.getMinimumValue(readablePartial57, intArray93);
        org.joda.time.DateTimeField dateTimeField96 = offsetDateTimeField56.getWrappedField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNull(durationField24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(gregorianChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNull(durationField46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(gregorianChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(gJChronology60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "5" + "'", str69.equals("5"));
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "-1" + "'", str74.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeZone77);
        org.junit.Assert.assertNotNull(gregorianChronology79);
        org.junit.Assert.assertNotNull(dateTimeField80);
        org.junit.Assert.assertNull(durationField82);
        org.junit.Assert.assertNotNull(dateTimeFieldType83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 19 + "'", int84 == 19);
        org.junit.Assert.assertNotNull(localDate86);
        org.junit.Assert.assertNotNull(intArray93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 57 + "'", int94 == 57);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 24 + "'", int95 == 24);
        org.junit.Assert.assertNotNull(dateTimeField96);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[UTC]" + "'", str1.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(10L, dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField8.getType();
        int int11 = localDate5.get(dateTimeFieldType10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType10, 5);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = localDate14.getFieldType((int) (byte) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField13, dateTimeFieldType16);
        int int20 = dividedDateTimeField17.getDifference((long) 1, (long) (-1));
        int int22 = dividedDateTimeField17.get((long) (-1));
        int int25 = dividedDateTimeField17.getDifference((long) (byte) -1, (-1L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField26 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.hourOfDay();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology27.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology32);
        java.lang.String str34 = dateTime33.toString();
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime33.plus(readablePeriod35);
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology38);
        org.joda.time.MutableDateTime mutableDateTime40 = dateTime33.toMutableDateTime((org.joda.time.Chronology) gregorianChronology38);
        int int41 = dateTime33.getMinuteOfHour();
        org.joda.time.DateTime dateTime43 = dateTime33.withSecondOfMinute(1);
        org.joda.time.DateTime.Property property44 = dateTime33.centuryOfEra();
        org.joda.time.DateTime dateTime46 = property44.setCopy("1");
        boolean boolean47 = gregorianChronology27.equals((java.lang.Object) property44);
        org.joda.time.DurationField durationField48 = gregorianChronology27.days();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder49.appendClockhourOfHalfday(24);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap52 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder51.appendTimeZoneName(strMap52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder51.appendTimeZoneId();
        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology55.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField57 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField56);
        org.joda.time.DurationField durationField58 = delegatedDateTimeField57.getLeapDurationField();
        int int61 = delegatedDateTimeField57.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = delegatedDateTimeField57.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder51.appendFixedSignedDecimal(dateTimeFieldType62, 2019);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField65 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17, durationField48, dateTimeFieldType62);
        org.joda.time.chrono.GJChronology gJChronology66 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField67 = gJChronology66.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate71 = new org.joda.time.LocalDate(10L, dateTimeZone70);
        org.joda.time.chrono.GregorianChronology gregorianChronology72 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField73 = gregorianChronology72.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField74 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField73);
        org.joda.time.DurationField durationField75 = delegatedDateTimeField74.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType76 = delegatedDateTimeField74.getType();
        int int77 = localDate71.get(dateTimeFieldType76);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField79 = new org.joda.time.field.RemainderDateTimeField(dateTimeField67, dateTimeFieldType76, 5);
        org.joda.time.LocalDate localDate80 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType82 = localDate80.getFieldType((int) (byte) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField79, dateTimeFieldType82);
        org.joda.time.DurationField durationField84 = remainderDateTimeField79.getDurationField();
        org.joda.time.DurationField durationField85 = remainderDateTimeField79.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField86 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType62, durationField85);
        org.joda.time.DurationField durationField87 = unsupportedDateTimeField86.getDurationField();
        java.util.Locale locale89 = null;
        try {
            java.lang.String str90 = unsupportedDateTimeField86.getAsShortText((-259200000L), locale89);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str34.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(mutableDateTime40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(gregorianChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNull(durationField58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(gJChronology66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(dateTimeZone70);
        org.junit.Assert.assertNotNull(gregorianChronology72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertNull(durationField75);
        org.junit.Assert.assertNotNull(dateTimeFieldType76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 19 + "'", int77 == 19);
        org.junit.Assert.assertNotNull(dateTimeFieldType82);
        org.junit.Assert.assertNotNull(durationField84);
        org.junit.Assert.assertNotNull(durationField85);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField86);
        org.junit.Assert.assertNotNull(durationField87);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(10L, dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField8.getType();
        int int11 = localDate5.get(dateTimeFieldType10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType10, 5);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = localDate14.getFieldType((int) (byte) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField13, dateTimeFieldType16);
        int int20 = dividedDateTimeField17.getDifference((long) 1, (long) (-1));
        int int22 = dividedDateTimeField17.get((long) (-1));
        int int25 = dividedDateTimeField17.getDifference((long) (byte) -1, (-1L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField26 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.hourOfDay();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology27.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology32);
        java.lang.String str34 = dateTime33.toString();
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime33.plus(readablePeriod35);
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology38);
        org.joda.time.MutableDateTime mutableDateTime40 = dateTime33.toMutableDateTime((org.joda.time.Chronology) gregorianChronology38);
        int int41 = dateTime33.getMinuteOfHour();
        org.joda.time.DateTime dateTime43 = dateTime33.withSecondOfMinute(1);
        org.joda.time.DateTime.Property property44 = dateTime33.centuryOfEra();
        org.joda.time.DateTime dateTime46 = property44.setCopy("1");
        boolean boolean47 = gregorianChronology27.equals((java.lang.Object) property44);
        org.joda.time.DurationField durationField48 = gregorianChronology27.days();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder49.appendClockhourOfHalfday(24);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap52 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder51.appendTimeZoneName(strMap52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder51.appendTimeZoneId();
        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology55.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField57 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField56);
        org.joda.time.DurationField durationField58 = delegatedDateTimeField57.getLeapDurationField();
        int int61 = delegatedDateTimeField57.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = delegatedDateTimeField57.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder51.appendFixedSignedDecimal(dateTimeFieldType62, 2019);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField65 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17, durationField48, dateTimeFieldType62);
        java.util.Locale locale66 = null;
        int int67 = remainderDateTimeField65.getMaximumShortTextLength(locale66);
        boolean boolean68 = remainderDateTimeField65.isSupported();
        org.joda.time.DurationField durationField69 = remainderDateTimeField65.getRangeDurationField();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str34.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(mutableDateTime40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(gregorianChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNull(durationField58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(durationField69);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(10L, dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField8.getType();
        int int11 = localDate5.get(dateTimeFieldType10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType10, 5);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = localDate14.getFieldType((int) (byte) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField13, dateTimeFieldType16);
        int int20 = dividedDateTimeField17.getDifference((long) 1, (long) (-1));
        int int22 = dividedDateTimeField17.get((long) (-1));
        int int25 = dividedDateTimeField17.getDifference((long) (byte) -1, (-1L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField26 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.hourOfDay();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology27.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology32);
        java.lang.String str34 = dateTime33.toString();
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime33.plus(readablePeriod35);
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology38);
        org.joda.time.MutableDateTime mutableDateTime40 = dateTime33.toMutableDateTime((org.joda.time.Chronology) gregorianChronology38);
        int int41 = dateTime33.getMinuteOfHour();
        org.joda.time.DateTime dateTime43 = dateTime33.withSecondOfMinute(1);
        org.joda.time.DateTime.Property property44 = dateTime33.centuryOfEra();
        org.joda.time.DateTime dateTime46 = property44.setCopy("1");
        boolean boolean47 = gregorianChronology27.equals((java.lang.Object) property44);
        org.joda.time.DurationField durationField48 = gregorianChronology27.days();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder49.appendClockhourOfHalfday(24);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap52 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder51.appendTimeZoneName(strMap52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder51.appendTimeZoneId();
        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology55.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField57 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField56);
        org.joda.time.DurationField durationField58 = delegatedDateTimeField57.getLeapDurationField();
        int int61 = delegatedDateTimeField57.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = delegatedDateTimeField57.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder51.appendFixedSignedDecimal(dateTimeFieldType62, 2019);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField65 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17, durationField48, dateTimeFieldType62);
        org.joda.time.chrono.GJChronology gJChronology66 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField67 = gJChronology66.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate71 = new org.joda.time.LocalDate(10L, dateTimeZone70);
        org.joda.time.chrono.GregorianChronology gregorianChronology72 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField73 = gregorianChronology72.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField74 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField73);
        org.joda.time.DurationField durationField75 = delegatedDateTimeField74.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType76 = delegatedDateTimeField74.getType();
        int int77 = localDate71.get(dateTimeFieldType76);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField79 = new org.joda.time.field.RemainderDateTimeField(dateTimeField67, dateTimeFieldType76, 5);
        org.joda.time.LocalDate localDate80 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType82 = localDate80.getFieldType((int) (byte) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField79, dateTimeFieldType82);
        org.joda.time.DurationField durationField84 = remainderDateTimeField79.getDurationField();
        org.joda.time.DurationField durationField85 = remainderDateTimeField79.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField86 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType62, durationField85);
        try {
            long long88 = unsupportedDateTimeField86.remainder(864000018L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str34.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(mutableDateTime40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(gregorianChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNull(durationField58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(gJChronology66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(dateTimeZone70);
        org.junit.Assert.assertNotNull(gregorianChronology72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertNull(durationField75);
        org.junit.Assert.assertNotNull(dateTimeFieldType76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 19 + "'", int77 == 19);
        org.junit.Assert.assertNotNull(dateTimeFieldType82);
        org.junit.Assert.assertNotNull(durationField84);
        org.junit.Assert.assertNotNull(durationField85);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField86);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        java.lang.String str1 = copticChronology0.toString();
        org.joda.time.Chronology chronology2 = copticChronology0.withUTC();
        int int3 = copticChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[UTC]" + "'", str1.equals("CopticChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant3 = gJChronology2.getGregorianCutover();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) instant3);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long5 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, (long) (short) 0);
        org.joda.time.LocalDate localDate6 = org.joda.time.LocalDate.now(dateTimeZone1);
        java.lang.String str8 = dateTimeZone1.getName(4L);
        java.lang.String str9 = dateTimeZone1.toString();
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.100" + "'", str8.equals("+00:00:00.100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.100" + "'", str9.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(julianChronology10);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate(10L, dateTimeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8);
        org.joda.time.DurationField durationField10 = delegatedDateTimeField9.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = delegatedDateTimeField9.getType();
        int int12 = localDate6.get(dateTimeFieldType11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.LocalDate localDate14 = localDate6.plus(readablePeriod13);
        int[] intArray16 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDate6, (long) 18);
        org.joda.time.Interval interval17 = localDate6.toInterval();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(interval17);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long5 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, (long) (short) 0);
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone3.isLocalDateTimeGap(localDateTime6);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, 3);
        try {
            long long14 = gregorianChronology9.getDateTimeMillis(292279000, (int) (short) -1, 1970, 53);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292279000 for year must be in the range [-292275054,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(gregorianChronology9);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long6 = dateTimeZone2.getMillisKeepLocal(dateTimeZone4, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone4);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4, 4);
        org.joda.time.Chronology chronology10 = julianChronology9.withUTC();
        int int11 = julianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField12 = julianChronology9.weekyears();
        org.joda.time.DurationFieldType durationFieldType13 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField15 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType13, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.hourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.hourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime2.withChronology((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology3.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendMinuteOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendClockhourOfHalfday((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendMinuteOfDay(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTwoDigitYear(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        java.lang.String str3 = dateTime2.toString();
        java.lang.String str4 = dateTime2.toString();
        int int5 = dateTime2.getMinuteOfHour();
        org.joda.time.DateTime dateTime6 = dateTime2.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfDay(10);
        org.joda.time.DateTime.Property property9 = dateTime6.secondOfMinute();
        org.joda.time.Interval interval10 = property9.toInterval();
        org.joda.time.DateTimeField dateTimeField11 = property9.getField();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str3.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str4.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(interval10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.Instant instant3 = gJChronology2.getGregorianCutover();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField8 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology4, dateTimeField7);
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology2, dateTimeField7, (int) (byte) -1);
        boolean boolean11 = iSOChronology0.equals((java.lang.Object) gJChronology2);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        long long15 = gJChronology2.add(readablePeriod12, 0L, 126);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(10L, dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField8.getType();
        int int11 = localDate5.get(dateTimeFieldType10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType10, 5);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = localDate14.getFieldType((int) (byte) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField13, dateTimeFieldType16);
        org.joda.time.DurationField durationField18 = remainderDateTimeField13.getDurationField();
        org.joda.time.DurationField durationField19 = remainderDateTimeField13.getRangeDurationField();
        org.joda.time.DurationField durationField20 = remainderDateTimeField13.getRangeDurationField();
        java.util.Locale locale23 = null;
        try {
            long long24 = remainderDateTimeField13.set((long) 99, "-00:01", locale23);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"-00:01\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.DurationField durationField2 = gregorianChronology0.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = gJChronology5.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField7 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology3, dateTimeField6);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField7, 4);
        int int11 = offsetDateTimeField9.getLeapAmount(100L);
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) offsetDateTimeField9, 0);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long12 = dateTimeZone8.getMillisKeepLocal(dateTimeZone10, (long) (short) 0);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(10, (int) (byte) 10, 19, (int) (byte) -1, 1970, 0, 24, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        java.lang.String str3 = dateTime2.toString();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.plus(readablePeriod4);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime2.toMutableDateTime((org.joda.time.Chronology) gregorianChronology7);
        int int10 = dateTime2.getMinuteOfHour();
        org.joda.time.DateTime dateTime12 = dateTime2.withSecondOfMinute(1);
        org.joda.time.DateTime.Property property13 = dateTime2.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(10L, dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(10L, dateTimeZone20);
        boolean boolean22 = localDate17.isAfter((org.joda.time.ReadablePartial) localDate21);
        boolean boolean24 = localDate17.equals((java.lang.Object) 100.0f);
        int int25 = localDate17.getYear();
        boolean boolean27 = localDate17.equals((java.lang.Object) 1L);
        int int28 = property13.compareTo((org.joda.time.ReadablePartial) localDate17);
        java.util.Locale locale29 = null;
        int int30 = property13.getMaximumTextLength(locale29);
        try {
            org.joda.time.DateTime dateTime32 = property13.setCopy("GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[UTC]\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str3.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1970 + "'", int25 == 1970);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 7 + "'", int30 == 7);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendLiteral("ISOChronology[UTC]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.append(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.hourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.hourOfDay();
        org.joda.time.DateTime dateTime7 = dateTime2.withChronology((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.withChronology(chronology8);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField3);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, 4);
        int int8 = offsetDateTimeField6.getLeapAmount(100L);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsShortText((long) 1, locale10);
        boolean boolean13 = offsetDateTimeField6.isLeap(0L);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField6.getAsShortText((int) (byte) -1, locale15);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(10L, dateTimeZone22);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        org.joda.time.DurationField durationField27 = delegatedDateTimeField26.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField26.getType();
        int int29 = localDate23.get(dateTimeFieldType28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.LocalDate localDate31 = localDate23.plus(readablePeriod30);
        int[] intArray33 = gregorianChronology17.get((org.joda.time.ReadablePartial) localDate23, (long) 18);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long40 = dateTimeZone36.getMillisKeepLocal(dateTimeZone38, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter34.withZone(dateTimeZone38);
        org.joda.time.chrono.JulianChronology julianChronology43 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone38, 4);
        org.joda.time.Chronology chronology44 = julianChronology43.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField47 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField46);
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate(10L, dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate55 = new org.joda.time.LocalDate(10L, dateTimeZone54);
        boolean boolean56 = localDate51.isAfter((org.joda.time.ReadablePartial) localDate55);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray57 = localDate51.getFieldTypes();
        int int58 = delegatedDateTimeField47.getMaximumValue((org.joda.time.ReadablePartial) localDate51);
        int[] intArray60 = julianChronology43.get((org.joda.time.ReadablePartial) localDate51, (long) (byte) 100);
        int int61 = offsetDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) localDate23, intArray60);
        org.joda.time.LocalDate localDate63 = localDate23.plusYears(0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1" + "'", str16.equals("-1"));
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 19 + "'", int29 == 19);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(julianChronology43);
        org.junit.Assert.assertNotNull(chronology44);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2922790 + "'", int58 == 2922790);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 5 + "'", int61 == 5);
        org.junit.Assert.assertNotNull(localDate63);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(10L, dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate(10L, dateTimeZone6);
        boolean boolean8 = localDate3.isAfter((org.joda.time.ReadablePartial) localDate7);
        boolean boolean10 = localDate3.equals((java.lang.Object) 100.0f);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField13.getLeapDurationField();
        int int17 = delegatedDateTimeField13.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = delegatedDateTimeField13.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "Property[monthOfYear]");
        org.joda.time.LocalDate.Property property21 = localDate3.property(dateTimeFieldType18);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.centuryOfEra();
        org.joda.time.DurationField durationField24 = gregorianChronology22.weekyears();
        org.joda.time.DurationField durationField25 = gregorianChronology22.eras();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField26 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType18, durationField25);
        try {
            boolean boolean28 = unsupportedDateTimeField26.isLeap(30239999999L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField26);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long7 = dateTimeZone3.getMillisKeepLocal(dateTimeZone5, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone(dateTimeZone5);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5, 4);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate(10L, dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long20 = dateTimeZone16.getMillisKeepLocal(dateTimeZone18, (long) (short) 0);
        long long22 = dateTimeZone13.getMillisKeepLocal(dateTimeZone18, (long) 100);
        org.joda.time.Chronology chronology23 = julianChronology10.withZone(dateTimeZone18);
        org.joda.time.LocalDate localDate24 = org.joda.time.LocalDate.now(dateTimeZone18);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) 292279000, dateTimeZone18);
        org.joda.time.DateTime dateTime27 = dateTime25.plusYears((int) (short) -1);
        org.joda.time.DateTime dateTime29 = dateTime27.withMillisOfDay((int) (short) 100);
        org.joda.time.DateTime dateTime31 = dateTime27.withWeekyear(26);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField3);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, 4);
        int int8 = offsetDateTimeField6.getLeapAmount(100L);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsShortText((long) 1, locale10);
        int int13 = offsetDateTimeField6.getLeapAmount(1L);
        long long15 = offsetDateTimeField6.roundHalfFloor((long) (byte) -1);
        int int17 = offsetDateTimeField6.get((long) 1970);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate(10L, dateTimeZone23);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26);
        org.joda.time.DurationField durationField28 = delegatedDateTimeField27.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = delegatedDateTimeField27.getType();
        int int30 = localDate24.get(dateTimeFieldType29);
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.LocalDate localDate32 = localDate24.plus(readablePeriod31);
        int[] intArray34 = gregorianChronology18.get((org.joda.time.ReadablePartial) localDate24, (long) 18);
        org.joda.time.LocalDate localDate36 = localDate24.withYear((int) '4');
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localDate36, 0, locale38);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200000L) + "'", long15 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 5 + "'", int17 == 5);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 19 + "'", int30 == 19);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField3);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, 4);
        int int8 = offsetDateTimeField6.getLeapAmount(100L);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsShortText((long) 1, locale10);
        int int13 = offsetDateTimeField6.getLeapAmount(1L);
        org.joda.time.DurationField durationField14 = offsetDateTimeField6.getRangeDurationField();
        long long16 = offsetDateTimeField6.roundHalfEven((long) (byte) 10);
        int int17 = offsetDateTimeField6.getMinimumValue();
        java.util.Locale locale18 = null;
        int int19 = offsetDateTimeField6.getMaximumTextLength(locale18);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-259200000L) + "'", long16 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 5 + "'", int17 == 5);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        java.lang.String str3 = dateTimeZone1.getShortName(0L);
        org.joda.time.ReadableInstant readableInstant4 = null;
        int int5 = dateTimeZone1.getOffset(readableInstant4);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+00:00:00.100" + "'", str3.equals("+00:00:00.100"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertNotNull(gJChronology6);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(24);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatterBuilder2.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendFractionOfDay((int) '4', 26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long6 = dateTimeZone2.getMillisKeepLocal(dateTimeZone4, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone(dateTimeZone4);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4, 4);
        org.joda.time.DurationField durationField10 = julianChronology9.minutes();
        org.joda.time.Chronology chronology11 = julianChronology9.withUTC();
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology12.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(10L, dateTimeZone16);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19);
        org.joda.time.DurationField durationField21 = delegatedDateTimeField20.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = delegatedDateTimeField20.getType();
        int int23 = localDate17.get(dateTimeFieldType22);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField25 = new org.joda.time.field.RemainderDateTimeField(dateTimeField13, dateTimeFieldType22, 5);
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = localDate26.getFieldType((int) (byte) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField29 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField25, dateTimeFieldType28);
        int int32 = dividedDateTimeField29.getDifference((long) 1, (long) (-1));
        int int33 = dividedDateTimeField29.getMaximumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology9, (org.joda.time.DateTimeField) dividedDateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 19 + "'", int23 == 19);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 10 + "'", int33 == 10);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Instant instant1 = gJChronology0.getGregorianCutover();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.centuryOfEra();
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology2.weekOfWeekyear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField4 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField3);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField4, 4);
        int int8 = offsetDateTimeField6.getLeapAmount(100L);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField6.getAsShortText((long) 1, locale10);
        boolean boolean13 = offsetDateTimeField6.isLeap(0L);
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField6.getAsShortText((int) (byte) -1, locale15);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.hourOfDay();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(10L, dateTimeZone22);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        org.joda.time.DurationField durationField27 = delegatedDateTimeField26.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField26.getType();
        int int29 = localDate23.get(dateTimeFieldType28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.LocalDate localDate31 = localDate23.plus(readablePeriod30);
        int[] intArray33 = gregorianChronology17.get((org.joda.time.ReadablePartial) localDate23, (long) 18);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long40 = dateTimeZone36.getMillisKeepLocal(dateTimeZone38, (long) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter34.withZone(dateTimeZone38);
        org.joda.time.chrono.JulianChronology julianChronology43 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone38, 4);
        org.joda.time.Chronology chronology44 = julianChronology43.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology45.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField47 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField46);
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate(10L, dateTimeZone50);
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate55 = new org.joda.time.LocalDate(10L, dateTimeZone54);
        boolean boolean56 = localDate51.isAfter((org.joda.time.ReadablePartial) localDate55);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray57 = localDate51.getFieldTypes();
        int int58 = delegatedDateTimeField47.getMaximumValue((org.joda.time.ReadablePartial) localDate51);
        int[] intArray60 = julianChronology43.get((org.joda.time.ReadablePartial) localDate51, (long) (byte) 100);
        int int61 = offsetDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) localDate23, intArray60);
        org.joda.time.LocalDate.Property property62 = localDate23.dayOfWeek();
        org.joda.time.LocalDate localDate63 = property62.withMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "5" + "'", str11.equals("5"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1" + "'", str16.equals("-1"));
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 19 + "'", int29 == 19);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(julianChronology43);
        org.junit.Assert.assertNotNull(chronology44);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2922790 + "'", int58 == 2922790);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 5 + "'", int61 == 5);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertNotNull(localDate63);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology2);
        java.lang.String str4 = dateTime3.toString();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readablePeriod5);
        org.joda.time.LocalTime localTime7 = dateTime6.toLocalTime();
        java.lang.String str8 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localTime7);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology10);
        java.lang.String str12 = dateTime11.toString();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.plus(readablePeriod13);
        org.joda.time.DateTime dateTime16 = dateTime11.minus(0L);
        org.joda.time.DateTime.Property property17 = dateTime16.weekOfWeekyear();
        org.joda.time.DateTime dateTime18 = property17.getDateTime();
        org.joda.time.DateTime dateTime20 = property17.addToCopy(20);
        java.lang.String str21 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime dateTime23 = dateTime20.minus((long) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str4.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localTime7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "����-W��-�T00:00:00.010" + "'", str8.equals("����-W��-�T00:00:00.010"));
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str12.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1970-W21-4T00:00:00.010Z" + "'", str21.equals("1970-W21-4T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate(10L, dateTimeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DurationField durationField9 = delegatedDateTimeField8.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField8.getType();
        int int11 = localDate5.get(dateTimeFieldType10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType10, 5);
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = localDate14.getFieldType((int) (byte) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField17 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField13, dateTimeFieldType16);
        int int20 = dividedDateTimeField17.getDifference((long) 1, (long) (-1));
        int int22 = dividedDateTimeField17.get((long) (-1));
        int int25 = dividedDateTimeField17.getDifference((long) (byte) -1, (-1L));
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField26 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology27.hourOfDay();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology27.hourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology32);
        java.lang.String str34 = dateTime33.toString();
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime33.plus(readablePeriod35);
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology38);
        org.joda.time.MutableDateTime mutableDateTime40 = dateTime33.toMutableDateTime((org.joda.time.Chronology) gregorianChronology38);
        int int41 = dateTime33.getMinuteOfHour();
        org.joda.time.DateTime dateTime43 = dateTime33.withSecondOfMinute(1);
        org.joda.time.DateTime.Property property44 = dateTime33.centuryOfEra();
        org.joda.time.DateTime dateTime46 = property44.setCopy("1");
        boolean boolean47 = gregorianChronology27.equals((java.lang.Object) property44);
        org.joda.time.DurationField durationField48 = gregorianChronology27.days();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder49.appendClockhourOfHalfday(24);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap52 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder51.appendTimeZoneName(strMap52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder51.appendTimeZoneId();
        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology55.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField57 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField56);
        org.joda.time.DurationField durationField58 = delegatedDateTimeField57.getLeapDurationField();
        int int61 = delegatedDateTimeField57.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = delegatedDateTimeField57.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder51.appendFixedSignedDecimal(dateTimeFieldType62, 2019);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField65 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField17, durationField48, dateTimeFieldType62);
        org.joda.time.chrono.GJChronology gJChronology66 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField67 = gJChronology66.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.LocalDate localDate71 = new org.joda.time.LocalDate(10L, dateTimeZone70);
        org.joda.time.chrono.GregorianChronology gregorianChronology72 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField73 = gregorianChronology72.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField74 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField73);
        org.joda.time.DurationField durationField75 = delegatedDateTimeField74.getLeapDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType76 = delegatedDateTimeField74.getType();
        int int77 = localDate71.get(dateTimeFieldType76);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField79 = new org.joda.time.field.RemainderDateTimeField(dateTimeField67, dateTimeFieldType76, 5);
        org.joda.time.LocalDate localDate80 = new org.joda.time.LocalDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType82 = localDate80.getFieldType((int) (byte) 0);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField83 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField79, dateTimeFieldType82);
        org.joda.time.DurationField durationField84 = remainderDateTimeField79.getDurationField();
        org.joda.time.DurationField durationField85 = remainderDateTimeField79.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField86 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType62, durationField85);
        org.joda.time.DurationField durationField87 = unsupportedDateTimeField86.getDurationField();
        java.util.Locale locale89 = null;
        try {
            java.lang.String str90 = unsupportedDateTimeField86.getAsText(10, locale89);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: centuryOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1970-01-01T00:00:00.010Z" + "'", str34.equals("1970-01-01T00:00:00.010Z"));
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(mutableDateTime40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(gregorianChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNull(durationField58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(gJChronology66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertNotNull(dateTimeZone70);
        org.junit.Assert.assertNotNull(gregorianChronology72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertNull(durationField75);
        org.junit.Assert.assertNotNull(dateTimeFieldType76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 19 + "'", int77 == 19);
        org.junit.Assert.assertNotNull(dateTimeFieldType82);
        org.junit.Assert.assertNotNull(durationField84);
        org.junit.Assert.assertNotNull(durationField85);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField86);
        org.junit.Assert.assertNotNull(durationField87);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology1);
        int int3 = dateTime2.getYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTime dateTime8 = dateTime2.toDateTime((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.centuryOfEra();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField11 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField10);
        org.joda.time.DurationField durationField12 = delegatedDateTimeField11.getLeapDurationField();
        int int15 = delegatedDateTimeField11.getDifference((long) 1, 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = delegatedDateTimeField11.getType();
        org.joda.time.DateTime dateTime18 = dateTime8.withField(dateTimeFieldType16, 4);
        org.joda.time.DateTime dateTime20 = dateTime8.minusMinutes(1);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.Partial partial24 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) (short) 10, (org.joda.time.Chronology) gregorianChronology26);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.hourOfDay();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology28.hourOfDay();
        org.joda.time.DateTime dateTime32 = dateTime27.withChronology((org.joda.time.Chronology) gregorianChronology28);
        boolean boolean33 = partial24.isMatch((org.joda.time.ReadableInstant) dateTime32);
        int int34 = dateTime32.getSecondOfDay();
        org.joda.time.DateTime.Property property35 = dateTime32.millisOfSecond();
        org.joda.time.DateTime dateTime36 = property35.roundHalfCeilingCopy();
        boolean boolean37 = dateTime20.isAfter((org.joda.time.ReadableInstant) dateTime36);
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 100);
        long long44 = dateTimeZone40.getMillisKeepLocal(dateTimeZone42, (long) (short) 0);
        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(0L, dateTimeZone40);
        java.lang.String str46 = dateTimeZone40.toString();
        org.joda.time.DateTime dateTime47 = dateTime20.withZoneRetainFields(dateTimeZone40);
        org.joda.time.DateTimeZone dateTimeZone48 = dateTime47.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1970 + "'", int3 == 1970);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNull(durationField12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "+00:00:00.100" + "'", str46.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTimeZone48);
    }
}

