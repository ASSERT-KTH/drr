import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) ' ', (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-32L) + "'", long2 == (-32L));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 100.0d, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(chronology3);
        try {
            org.joda.time.chrono.LimitChronology limitChronology5 = org.joda.time.chrono.LimitChronology.getInstance(chronology0, (org.joda.time.ReadableDateTime) dateTime2, (org.joda.time.ReadableDateTime) dateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        try {
            org.joda.time.DateTime dateTime5 = dateTime2.withMonthOfYear((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField3 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (byte) 0, (int) (short) -1, 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(dateTimeZone1);
        java.util.Locale locale4 = null;
        try {
            java.lang.String str5 = monthDay2.toString("", locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 10.0f, (java.lang.Number) (short) -1, (java.lang.Number) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(0L);
        int[] intArray2 = monthDay1.getValues();
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant3);
        try {
            org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay((java.lang.Object) intArray2, chronology4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: [I");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) 100, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-100L) + "'", long2 == (-100L));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.dayOfWeek();
        java.util.Locale locale6 = null;
        try {
            org.joda.time.DateTime dateTime7 = property4.setCopy("", locale6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (short) 10, (-1L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-10) + "'", int2 == (-10));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (byte) 0, 816, (int) (byte) 10, (-10), (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(0L, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        try {
            long long11 = buddhistChronology3.getDateTimeMillis((int) 'a', (int) (short) -1, (-10), (int) ' ', (int) (byte) 10, (-10), 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (byte) 1, (-10), 1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (short) 0, 1, 100, (int) (short) 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(100L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        boolean boolean3 = dateTimeZone1.isStandardOffset(100L);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.DateTime dateTime7 = dateTime4.withField(dateTimeFieldType5, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(6, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.dayOfWeek();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.minus(readableDuration5);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant0, (org.joda.time.ReadableInstant) dateTime1);
        boolean boolean3 = dateTime1.isAfterNow();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        java.util.Locale locale14 = null;
        try {
            org.joda.time.DateTime dateTime15 = property4.setCopy("", locale14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        try {
            long long6 = julianChronology0.getDateTimeMillis((-1), 816, (int) '4', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 816 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(36, (-1), 6, (int) 'a', 100, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        boolean boolean3 = dateTimeZone1.isStandardOffset(100L);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        try {
            long long13 = gregorianChronology5.getDateTimeMillis((int) 'a', 816, (int) (byte) 100, (int) (short) 10, 6, (int) (short) 1, 36);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 816 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(gregorianChronology5);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test041");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
//        long long4 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560630982581L + "'", long4 == 1560630982581L);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("JulianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"JulianChronology[UTC]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test043");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(chronology3);
//        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, (org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime.Property property6 = dateTime4.dayOfWeek();
//        int int7 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        boolean boolean9 = dateTime1.isEqual(readableInstant8);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "", "hi!");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "JulianChronology[UTC]", "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test045");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTime dateTime5 = dateTime2.plusMonths((int) (byte) 100);
//        int int6 = dateTime2.getSecondOfDay();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 48983 + "'", int6 == 48983);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("+97:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+97:00\" is malformed at \"97:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        boolean boolean3 = dateTimeZone1.isStandardOffset(100L);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        int int7 = dateTimeZone1.getOffsetFromLocal((long) (-1));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("Sat");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Sat\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        boolean boolean5 = property4.isLeap();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test050");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        boolean boolean3 = dateTimeZone1.isStandardOffset(100L);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime.Property property9 = dateTime7.year();
//        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
//        boolean boolean12 = dateTime4.isAfter((org.joda.time.ReadableInstant) dateTime11);
//        int int13 = dateTime4.getMinuteOfHour();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
//        try {
//            int int15 = dateTime4.get(dateTimeFieldType14);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 36 + "'", int13 == 36);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getRangeDurationField();
        org.joda.time.DateTimeField dateTimeField6 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay(dateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.MonthDay monthDay12 = monthDay9.withPeriodAdded(readablePeriod10, (int) (byte) 100);
        int[] intArray16 = new int[] { (-10), '4' };
        try {
            int[] intArray18 = delegatedDateTimeField4.addWrapField((org.joda.time.ReadablePartial) monthDay12, 100, intArray16, 816);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(0L);
        int[] intArray2 = monthDay1.getValues();
        boolean boolean3 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay1);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.MonthDay monthDay6 = monthDay1.withFieldAdded(durationFieldType4, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(chronology14);
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, (org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime.Property property17 = dateTime15.year();
        org.joda.time.DateTime dateTime19 = dateTime15.withCenturyOfEra((int) 'a');
        int int20 = property4.getDifference((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime dateTime21 = property4.getDateTime();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-7700) + "'", int20 == (-7700));
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        java.lang.String str5 = dateTimeZone1.getShortName(10L);
        java.util.TimeZone timeZone6 = dateTimeZone1.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+97:00" + "'", str5.equals("+97:00"));
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType4, (int) (byte) 0, (int) ' ', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) (short) -1);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType3 = monthDay1.getFieldType(48983);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 48983");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 816);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 816 + "'", int1 == 816);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.yearOfCentury();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology2.getZone();
        boolean boolean5 = dateTimeZone3.isStandardOffset(100L);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime8 = dateTime6.withChronology((org.joda.time.Chronology) julianChronology7);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) dateTimeField1, (org.joda.time.Chronology) julianChronology7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.field.OffsetDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            int int3 = dateTime1.get(dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-7700), 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology3.getZone();
        boolean boolean6 = dateTimeZone4.isStandardOffset(100L);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.Chronology chronology8 = julianChronology2.withZone(dateTimeZone4);
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(0L);
        int[] intArray11 = monthDay10.getValues();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
        boolean boolean13 = monthDay10.isSupported(dateTimeFieldType12);
        long long15 = julianChronology2.set((org.joda.time.ReadablePartial) monthDay10, (long) (short) -1);
        boolean boolean16 = monthDay1.isEqual((org.joda.time.ReadablePartial) monthDay10);
        try {
            org.joda.time.MonthDay monthDay18 = monthDay1.withDayOfMonth(36);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 36 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1123199999L + "'", long15 == 1123199999L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        int int5 = delegatedDateTimeField3.getLeapAmount((long) 36);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(dateTimeZone7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay(dateTimeZone13);
        boolean boolean15 = monthDay11.isBefore((org.joda.time.ReadablePartial) monthDay14);
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(0L);
        int[] intArray19 = monthDay18.getValues();
        try {
            int[] intArray21 = delegatedDateTimeField3.add((org.joda.time.ReadablePartial) monthDay14, 4, intArray19, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.dayOfWeek();
        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) (short) -1);
        try {
            org.joda.time.DateTime dateTime8 = property4.setCopy((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: hi!");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType3, 1, (int) (short) 1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test075");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTime.Property property4 = dateTime2.dayOfWeek();
//        java.lang.String str5 = property4.getAsShortText();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
//        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(dateTimeZone7);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.MonthDay monthDay11 = monthDay8.withPeriodAdded(readablePeriod9, (int) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
//        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay(dateTimeZone13);
//        boolean boolean15 = monthDay11.isBefore((org.joda.time.ReadablePartial) monthDay14);
//        try {
//            int int16 = property4.compareTo((org.joda.time.ReadablePartial) monthDay11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfWeek' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Sat" + "'", str5.equals("Sat"));
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        boolean boolean3 = dateTimeZone1.isStandardOffset(100L);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = dateTime4.withChronology((org.joda.time.Chronology) julianChronology5);
        try {
            org.joda.time.DateTime dateTime8 = dateTime6.withCenturyOfEra((-7700));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -7700 for centuryOfEra must be in the range [1,2922730]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.DateTime.Property property7 = dateTime5.property(dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.util.Locale locale3 = dateTimeFormatter0.getLocale();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withLocale(locale4);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        int int10 = property7.getMinimumValue();
        org.joda.time.DateTime dateTime11 = property7.roundCeilingCopy();
        org.joda.time.Instant instant12 = dateTime11.toInstant();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(instant12);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.util.Locale locale3 = dateTimeFormatter0.getLocale();
        try {
            long long5 = dateTimeFormatter0.parseMillis("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(locale3);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test082");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTime.Property property4 = dateTime2.year();
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime.Property property9 = dateTime7.year();
//        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
//        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
//        int int13 = dateTime7.getDayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology14.getZone();
//        boolean boolean17 = dateTimeZone15.isStandardOffset(100L);
//        org.joda.time.DateTime dateTime18 = dateTime7.toDateTime(dateTimeZone15);
//        org.joda.time.DateTime dateTime20 = dateTime7.withMillisOfDay((int) (byte) 100);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(julianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property13 = dateTime7.millisOfDay();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime7.plus(readablePeriod14);
        int int16 = dateTime7.getEra();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology2.getZone();
        org.joda.time.Chronology chronology4 = julianChronology0.withZone(dateTimeZone3);
        try {
            long long12 = julianChronology0.getDateTimeMillis((int) (short) 0, (int) (byte) 10, (-1), (int) 'a', (int) 'a', (int) (byte) -1, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int0 = org.joda.time.MonthDay.MONTH_OF_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "9719");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("9719", "+97:00", (int) (byte) 10, 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (byte) 100);
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = julianChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology6.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8, dateTimeFieldType9);
        java.lang.String str12 = delegatedDateTimeField10.getAsShortText((long) (-10));
        long long14 = delegatedDateTimeField10.remainder((long) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = delegatedDateTimeField10.getType();
        try {
            org.joda.time.MonthDay.Property property16 = monthDay5.property(dateTimeFieldType15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfHour' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "59" + "'", str12.equals("59"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(816);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDecimal(dateTimeFieldType3, 1, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        try {
            long long2 = dateTimeFormatter0.parseMillis("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(10);
//        java.io.Writer writer3 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
//        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(dateTimeZone5);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.ReadableInstant readableInstant10 = null;
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, (org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime.Property property14 = dateTime12.dayOfWeek();
//        int int15 = dateTime9.compareTo((org.joda.time.ReadableInstant) dateTime12);
//        boolean boolean16 = dateTime9.isEqualNow();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) dateTime9);
//        try {
//            dateTimeFormatter2.printTo(writer3, (org.joda.time.ReadableInstant) dateTime9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(buddhistChronology7);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(gJChronology17);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        try {
            long long15 = unsupportedDateTimeField13.roundCeiling((long) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test095");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTime.Property property4 = dateTime2.year();
//        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
//        org.joda.time.ReadableInstant readableInstant7 = null;
//        org.joda.time.ReadableInstant readableInstant8 = null;
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(chronology9);
//        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant8, (org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime.Property property12 = dateTime10.year();
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        org.joda.time.Chronology chronology14 = null;
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(chronology14);
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, (org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime.Property property17 = dateTime15.year();
//        org.joda.time.DateTime dateTime19 = dateTime15.withCenturyOfEra((int) 'a');
//        long long20 = property12.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime.Property property21 = dateTime15.millisOfDay();
//        org.joda.time.DateTime dateTime23 = dateTime15.withYearOfCentury((int) (byte) 0);
//        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant7, (org.joda.time.ReadableInstant) dateTime23);
//        org.joda.time.DateTime dateTime25 = dateTime2.toDateTime(chronology24);
//        int int26 = dateTime25.getDayOfWeek();
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property13 = dateTime7.millisOfDay();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime7.plus(readablePeriod14);
        try {
            org.joda.time.DateTime dateTime20 = dateTime15.withTime((int) (short) 0, (int) '#', (-10), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        long long16 = unsupportedDateTimeField13.add((long) (-10), 36);
        java.util.Locale locale17 = null;
        try {
            int int18 = unsupportedDateTimeField13.getMaximumShortTextLength(locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35990L + "'", long16 == 35990L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("JulianChronology[UTC]", "Sat", 36, 816);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("DateTimeField[minuteOfHour]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[minuteOfHour]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        boolean boolean3 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        java.lang.StringBuffer stringBuffer4 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.MonthDay monthDay10 = monthDay7.withPeriodAdded(readablePeriod8, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone12);
        boolean boolean14 = monthDay10.isBefore((org.joda.time.ReadablePartial) monthDay13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.MonthDay monthDay20 = monthDay17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
        boolean boolean21 = monthDay13.isBefore((org.joda.time.ReadablePartial) monthDay17);
        try {
            dateTimeFormatter1.printTo(stringBuffer4, (org.joda.time.ReadablePartial) monthDay13);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTime.Property property4 = dateTime2.year();
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime.Property property9 = dateTime7.year();
//        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
//        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
//        int int13 = dateTime7.getDayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology14.getZone();
//        boolean boolean17 = dateTimeZone15.isStandardOffset(100L);
//        org.joda.time.DateTime dateTime18 = dateTime7.toDateTime(dateTimeZone15);
//        try {
//            org.joda.time.DateTime dateTime20 = dateTime7.withYearOfEra(0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(julianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        int int5 = delegatedDateTimeField3.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, 2019);
        long long9 = offsetDateTimeField7.roundHalfEven((long) (byte) 100);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        int int5 = dateTime2.getEra();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        int int5 = delegatedDateTimeField3.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, 2019);
        long long9 = offsetDateTimeField7.roundHalfFloor(0L);
        int int11 = offsetDateTimeField7.getMinimumValue((long) 'a');
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "100");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendWeekOfWeekyear((int) (byte) 10);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendTimeZoneOffset("Sat", "hi!", true, (int) (short) -1, 166);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTime.Property property4 = dateTime2.year();
//        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
//        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
//        java.lang.Object obj8 = null;
//        boolean boolean9 = property7.equals(obj8);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
//        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(dateTimeZone15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone15);
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(chronology18);
//        org.joda.time.ReadableInstant readableInstant20 = null;
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(chronology21);
//        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant20, (org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.DateTime.Property property24 = dateTime22.dayOfWeek();
//        int int25 = dateTime19.compareTo((org.joda.time.ReadableInstant) dateTime22);
//        boolean boolean26 = dateTime19.isEqualNow();
//        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15, (org.joda.time.ReadableInstant) dateTime19);
//        int int28 = gJChronology27.getMinimumDaysInFirstWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter29.withPivotYear((int) (short) 10);
//        boolean boolean32 = gJChronology27.equals((java.lang.Object) dateTimeFormatter29);
//        org.joda.time.MonthDay monthDay34 = new org.joda.time.MonthDay((long) (short) -1);
//        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.chrono.JulianChronology julianChronology36 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone37 = julianChronology36.getZone();
//        boolean boolean39 = dateTimeZone37.isStandardOffset(100L);
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(dateTimeZone37);
//        org.joda.time.Chronology chronology41 = julianChronology35.withZone(dateTimeZone37);
//        org.joda.time.MonthDay monthDay43 = new org.joda.time.MonthDay(0L);
//        int[] intArray44 = monthDay43.getValues();
//        org.joda.time.DateTimeFieldType dateTimeFieldType45 = null;
//        boolean boolean46 = monthDay43.isSupported(dateTimeFieldType45);
//        long long48 = julianChronology35.set((org.joda.time.ReadablePartial) monthDay43, (long) (short) -1);
//        boolean boolean49 = monthDay34.isEqual((org.joda.time.ReadablePartial) monthDay43);
//        boolean boolean50 = gJChronology27.equals((java.lang.Object) monthDay43);
//        int[] intArray57 = new int[] { (-1), (-10), 4, (byte) 1, 2000 };
//        try {
//            int[] intArray59 = unsupportedDateTimeField13.set((org.joda.time.ReadablePartial) monthDay43, 19, intArray57, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(buddhistChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(gJChronology27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(julianChronology35);
//        org.junit.Assert.assertNotNull(julianChronology36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertNotNull(chronology41);
//        org.junit.Assert.assertNotNull(intArray44);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1123199999L + "'", long48 == 1123199999L);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(intArray57);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology2.getZone();
        org.joda.time.Chronology chronology4 = julianChronology0.withZone(dateTimeZone3);
        try {
            long long9 = julianChronology0.getDateTimeMillis(1, 166, 48983, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 166 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property13 = dateTime7.millisOfDay();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime7.plus(readablePeriod14);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(dateTimeZone17);
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone17);
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, (org.joda.time.Chronology) buddhistChronology19);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray21 = monthDay20.getFieldTypes();
        try {
            int int23 = monthDay20.getValue(48983);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 48983");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray21);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 2078);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay9 = monthDay6.withPeriodAdded(readablePeriod7, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(dateTimeZone11);
        boolean boolean13 = monthDay9.isBefore((org.joda.time.ReadablePartial) monthDay12);
        int[] intArray18 = new int[] { (short) 100, 6, 0 };
        try {
            int[] intArray20 = delegatedDateTimeField3.set((org.joda.time.ReadablePartial) monthDay9, 2000, intArray18, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2000");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        try {
            org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0, (org.joda.time.Chronology) buddhistChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        long long16 = unsupportedDateTimeField13.add((long) (-10), 36);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay(dateTimeZone18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.MonthDay monthDay22 = monthDay19.withPeriodAdded(readablePeriod20, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay(dateTimeZone24);
        boolean boolean26 = monthDay22.isBefore((org.joda.time.ReadablePartial) monthDay25);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay29 = new org.joda.time.MonthDay(dateTimeZone28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.MonthDay monthDay32 = monthDay29.withPeriodAdded(readablePeriod30, (int) (byte) 100);
        boolean boolean33 = monthDay25.isBefore((org.joda.time.ReadablePartial) monthDay29);
        int[] intArray41 = new int[] { '4', 86399999, (-10), (byte) 100, '4', 36 };
        try {
            int[] intArray43 = unsupportedDateTimeField13.addWrapField((org.joda.time.ReadablePartial) monthDay25, 816, intArray41, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35990L + "'", long16 == 35990L);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(intArray41);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test116");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology2 = julianChronology1.withUTC();
//        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.minuteOfHour();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        int int6 = delegatedDateTimeField4.getLeapAmount((long) 36);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, 2019);
//        long long10 = offsetDateTimeField8.roundHalfFloor(0L);
//        long long13 = offsetDateTimeField8.add((long) '#', (int) (short) 1);
//        long long15 = offsetDateTimeField8.roundCeiling((-100L));
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
//        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(dateTimeZone17);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.MonthDay monthDay21 = monthDay18.withPeriodAdded(readablePeriod19, (int) (byte) 100);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
//        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay(dateTimeZone23);
//        boolean boolean25 = monthDay21.isBefore((org.joda.time.ReadablePartial) monthDay24);
//        int int26 = offsetDateTimeField8.getMaximumValue((org.joda.time.ReadablePartial) monthDay24);
//        java.lang.String str27 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay24);
//        try {
//            org.joda.time.MonthDay monthDay29 = monthDay24.withDayOfMonth((int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 60035L + "'", long13 == 60035L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(monthDay21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2078 + "'", int26 == 2078);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "6/19/�� �:�� �" + "'", str27.equals("6/19/�� �:�� �"));
//    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test117");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTime.Property property4 = dateTime2.dayOfWeek();
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology5.getZone();
//        java.util.TimeZone timeZone7 = dateTimeZone6.toTimeZone();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = dateTimeZone8.getShortName(0L, locale10);
//        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime(dateTimeZone8);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        java.lang.String str4 = delegatedDateTimeField3.toString();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology6 = julianChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        int int10 = delegatedDateTimeField8.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField8, 2019);
        long long14 = offsetDateTimeField12.roundHalfFloor(0L);
        long long17 = offsetDateTimeField12.add((long) '#', (int) (short) 1);
        long long19 = offsetDateTimeField12.roundCeiling((-100L));
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.MonthDay monthDay25 = monthDay22.withPeriodAdded(readablePeriod23, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay(dateTimeZone27);
        boolean boolean29 = monthDay25.isBefore((org.joda.time.ReadablePartial) monthDay28);
        int int30 = offsetDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) monthDay28);
        int[] intArray31 = new int[] {};
        int int32 = delegatedDateTimeField3.getMinimumValue((org.joda.time.ReadablePartial) monthDay28, intArray31);
        org.joda.time.MonthDay monthDay34 = new org.joda.time.MonthDay(0L);
        int[] intArray35 = monthDay34.getValues();
        org.joda.time.LocalDate localDate37 = monthDay34.toLocalDate(0);
        org.joda.time.chrono.JulianChronology julianChronology39 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology40 = julianChronology39.withUTC();
        org.joda.time.DateTimeField dateTimeField41 = julianChronology39.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField42 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField41);
        java.lang.String str43 = delegatedDateTimeField42.toString();
        org.joda.time.chrono.JulianChronology julianChronology44 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology45 = julianChronology44.withUTC();
        org.joda.time.DateTimeField dateTimeField46 = julianChronology44.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField47 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField46);
        int int49 = delegatedDateTimeField47.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField47, 2019);
        long long53 = offsetDateTimeField51.roundHalfFloor(0L);
        long long56 = offsetDateTimeField51.add((long) '#', (int) (short) 1);
        long long58 = offsetDateTimeField51.roundCeiling((-100L));
        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay61 = new org.joda.time.MonthDay(dateTimeZone60);
        org.joda.time.ReadablePeriod readablePeriod62 = null;
        org.joda.time.MonthDay monthDay64 = monthDay61.withPeriodAdded(readablePeriod62, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay67 = new org.joda.time.MonthDay(dateTimeZone66);
        boolean boolean68 = monthDay64.isBefore((org.joda.time.ReadablePartial) monthDay67);
        int int69 = offsetDateTimeField51.getMaximumValue((org.joda.time.ReadablePartial) monthDay67);
        int[] intArray70 = new int[] {};
        int int71 = delegatedDateTimeField42.getMinimumValue((org.joda.time.ReadablePartial) monthDay67, intArray70);
        try {
            int[] intArray73 = delegatedDateTimeField3.add((org.joda.time.ReadablePartial) monthDay34, (-1), intArray70, 292278993);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str4.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 60035L + "'", long17 == 60035L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2078 + "'", int30 == 2078);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertNotNull(julianChronology39);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str43.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertNotNull(julianChronology44);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 60035L + "'", long56 == 60035L);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(monthDay64);
        org.junit.Assert.assertNotNull(dateTimeZone66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 2078 + "'", int69 == 2078);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = copticChronology0.withUTC();
        int int2 = copticChronology0.getMinimumDaysInFirstWeek();
        try {
            org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((java.lang.Object) copticChronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.chrono.CopticChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay((long) (short) -1);
        try {
            dateTimeFormatter0.printTo(stringBuffer3, (org.joda.time.ReadablePartial) monthDay5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        try {
            org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 2000");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicDate();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("9719", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"9719\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) -1, (int) 'a', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(dateTimeZone1);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(chronology4);
//        org.joda.time.ReadableInstant readableInstant6 = null;
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(chronology7);
//        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant6, (org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime.Property property10 = dateTime8.dayOfWeek();
//        int int11 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime8);
//        boolean boolean12 = dateTime5.isEqualNow();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime5);
//        try {
//            long long18 = gJChronology13.getDateTimeMillis((int) (byte) 10, (-7700), (int) (short) 100, 2019);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -7700 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(buddhistChronology3);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(gJChronology13);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(dateTimeZone15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone21);
        boolean boolean23 = monthDay19.isBefore((org.joda.time.ReadablePartial) monthDay22);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay(dateTimeZone25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.MonthDay monthDay29 = monthDay26.withPeriodAdded(readablePeriod27, (int) (byte) 100);
        boolean boolean30 = monthDay22.isBefore((org.joda.time.ReadablePartial) monthDay26);
        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay(0L);
        int[] intArray33 = monthDay32.getValues();
        try {
            int int34 = unsupportedDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) monthDay26, intArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(intArray33);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(2078);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2078) + "'", int1 == (-2078));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        boolean boolean3 = dateTimeZone1.isStandardOffset(100L);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime7 = dateTime4.withPeriodAdded(readablePeriod5, 1);
        int int8 = dateTime4.getYearOfEra();
        org.joda.time.DateTime.Property property9 = dateTime4.year();
        java.util.Locale locale11 = null;
        try {
            org.joda.time.DateTime dateTime12 = property9.setCopy("DateTimeField[minuteOfHour]", locale11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"DateTimeField[minuteOfHour]\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology7.getZone();
        boolean boolean10 = dateTimeZone8.isStandardOffset(100L);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.Chronology chronology12 = julianChronology6.withZone(dateTimeZone8);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((int) (byte) 0, (int) '#', (int) (short) 1, 4, 36, (-2078), chronology12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2078 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        try {
            long long2 = dateTimeFormatter0.parseMillis("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(dateTimeZone15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay19 = monthDay16.withPeriodAdded(readablePeriod17, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone21);
        boolean boolean23 = monthDay19.isBefore((org.joda.time.ReadablePartial) monthDay22);
        java.util.Locale locale25 = null;
        try {
            java.lang.String str26 = unsupportedDateTimeField13.getAsShortText((org.joda.time.ReadablePartial) monthDay22, (int) (byte) 1, locale25);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendWeekOfWeekyear((int) (byte) 10);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(chronology4);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, (org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime.Property property7 = dateTime5.year();
        org.joda.time.DateTime dateTime9 = dateTime5.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        java.lang.Object obj11 = null;
        boolean boolean12 = property10.equals(obj11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, "UTC");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType13, 4, 10);
        org.joda.time.format.DateTimePrinter dateTimePrinter19 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder0.append(dateTimePrinter19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(dateTimeZone7);
        boolean boolean9 = monthDay5.isBefore((org.joda.time.ReadablePartial) monthDay8);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(dateTimeZone11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay15 = monthDay12.withPeriodAdded(readablePeriod13, (int) (byte) 100);
        boolean boolean16 = monthDay8.isBefore((org.joda.time.ReadablePartial) monthDay12);
        org.joda.time.DurationFieldType durationFieldType17 = null;
        try {
            org.joda.time.MonthDay monthDay19 = monthDay8.withFieldAdded(durationFieldType17, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        boolean boolean3 = dateTimeZone1.isStandardOffset(100L);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime6 = dateTime4.plusMillis(1);
        org.joda.time.DateTime dateTime8 = dateTime6.minusMonths(6);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(816);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMonthOfYear((-7700));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        long long16 = unsupportedDateTimeField13.add((long) (-10), 36);
        try {
            long long18 = unsupportedDateTimeField13.roundFloor(1L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35990L + "'", long16 == 35990L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology4 = julianChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        int int8 = delegatedDateTimeField6.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        org.joda.time.DurationField durationField10 = skipDateTimeField9.getLeapDurationField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(durationField10);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTime.Property property4 = dateTime2.dayOfWeek();
//        int int5 = dateTime2.getMinuteOfDay();
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
//        try {
//            int int7 = dateTime2.get(dateTimeFieldType6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 816 + "'", int5 == 816);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
//        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(dateTimeZone1);
//        int int3 = monthDay2.getDayOfMonth();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        java.util.TimeZone timeZone8 = dateTimeZone7.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        org.joda.time.DateTime dateTime10 = dateTime3.toDateTime(dateTimeZone9);
        try {
            java.lang.String str12 = dateTime10.toString("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendWeekOfWeekyear((int) (byte) 10);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(chronology4);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, (org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime.Property property7 = dateTime5.year();
        org.joda.time.DateTime dateTime9 = dateTime5.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        java.lang.Object obj11 = null;
        boolean boolean12 = property10.equals(obj11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, "UTC");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType13, 4, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendFractionOfSecond(0, 19);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder18.appendTimeZoneOffset("100", "100", true, 19, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        long long16 = unsupportedDateTimeField13.add((long) (-10), 36);
        boolean boolean17 = unsupportedDateTimeField13.isSupported();
        try {
            long long20 = unsupportedDateTimeField13.addWrapField(100L, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35990L + "'", long16 == 35990L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        long long16 = unsupportedDateTimeField13.add((long) (-10), 36);
        boolean boolean17 = unsupportedDateTimeField13.isSupported();
        org.joda.time.ReadablePartial readablePartial18 = null;
        try {
            int int19 = unsupportedDateTimeField13.getMinimumValue(readablePartial18);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35990L + "'", long16 == 35990L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        long long16 = unsupportedDateTimeField13.add((long) (-10), 36);
        boolean boolean17 = unsupportedDateTimeField13.isSupported();
        try {
            boolean boolean19 = unsupportedDateTimeField13.isLeap((long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35990L + "'", long16 == 35990L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendWeekOfWeekyear((int) (byte) 10);
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeParser dateTimeParser4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimeParser4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(600001L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        int int5 = delegatedDateTimeField3.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, 2019);
        long long9 = offsetDateTimeField7.roundHalfFloor(0L);
        long long12 = offsetDateTimeField7.add((long) '#', (int) (short) 1);
        long long14 = offsetDateTimeField7.roundCeiling((-100L));
        org.joda.time.DurationField durationField15 = offsetDateTimeField7.getDurationField();
        boolean boolean16 = offsetDateTimeField7.isSupported();
        long long18 = offsetDateTimeField7.roundHalfFloor((long) 10);
        java.util.Locale locale21 = null;
        try {
            long long22 = offsetDateTimeField7.set((long) 3, "JulianChronology[UTC]", locale21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"JulianChronology[UTC]\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 60035L + "'", long12 == 60035L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 13, 1123234999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1123234986L) + "'", long2 == (-1123234986L));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.MutableDateTime mutableDateTime2 = dateTime1.toMutableDateTime();
        int int3 = dateTime1.getWeekyear();
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        java.lang.String str6 = delegatedDateTimeField4.getAsShortText((long) (-10));
        long long8 = delegatedDateTimeField4.remainder((long) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField4.getType();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray10 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType9 };
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList11 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList11, dateTimeFieldTypeArray10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList11, false, true);
        org.joda.time.Chronology chronology16 = dateTimeFormatter15.getChronology();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "59" + "'", str6.equals("59"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNull(chronology16);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
//        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone2);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
//        org.joda.time.ReadableInstant readableInstant7 = null;
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
//        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant7, (org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime.Property property11 = dateTime9.dayOfWeek();
//        int int12 = dateTime6.compareTo((org.joda.time.ReadableInstant) dateTime9);
//        boolean boolean13 = dateTime6.isEqualNow();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime6);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gJChronology14);
//        org.joda.time.DateTimeField dateTimeField16 = gJChronology14.clockhourOfDay();
//        try {
//            long long21 = gJChronology14.getDateTimeMillis(86399999, 3, 36, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 36 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(buddhistChronology4);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(dateTimeZone7);
        boolean boolean9 = monthDay5.isBefore((org.joda.time.ReadablePartial) monthDay8);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.MonthDay monthDay12 = monthDay8.withFieldAdded(durationFieldType10, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        boolean boolean3 = dateTimeZone1.isStandardOffset(100L);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        java.util.TimeZone timeZone6 = dateTimeZone1.toTimeZone();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        boolean boolean3 = dateTimeZone1.isStandardOffset(100L);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.millisOfDay();
        int int7 = gregorianChronology5.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, (int) (byte) 100);
        try {
            long long7 = skipUndoDateTimeField4.set((-1L), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfCentury must be in the range [2,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        int int5 = delegatedDateTimeField3.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, 2019);
        long long9 = offsetDateTimeField7.roundHalfFloor(0L);
        long long12 = offsetDateTimeField7.add((long) '#', (int) (short) 1);
        long long14 = offsetDateTimeField7.roundCeiling((-100L));
        org.joda.time.DurationField durationField15 = offsetDateTimeField7.getDurationField();
        boolean boolean16 = offsetDateTimeField7.isSupported();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = julianChronology18.getZone();
        boolean boolean21 = dateTimeZone19.isStandardOffset(100L);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone19);
        org.joda.time.Chronology chronology23 = julianChronology17.withZone(dateTimeZone19);
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay(0L);
        int[] intArray26 = monthDay25.getValues();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        boolean boolean28 = monthDay25.isSupported(dateTimeFieldType27);
        long long30 = julianChronology17.set((org.joda.time.ReadablePartial) monthDay25, (long) (short) -1);
        java.util.Locale locale31 = null;
        try {
            java.lang.String str32 = offsetDateTimeField7.getAsText((org.joda.time.ReadablePartial) monthDay25, locale31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfHour' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 60035L + "'", long12 == 60035L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1123199999L + "'", long30 == 1123199999L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(chronology4);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, (org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime.Property property7 = dateTime5.year();
        org.joda.time.DateTime dateTime9 = dateTime5.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        java.lang.Object obj11 = null;
        boolean boolean12 = property10.equals(obj11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, "UTC");
        boolean boolean16 = iSOChronology0.equals((java.lang.Object) illegalFieldValueException15);
        java.lang.Number number17 = illegalFieldValueException15.getUpperBound();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(number17);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        long long16 = unsupportedDateTimeField13.add(1123199999L, (long) '#');
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay(dateTimeZone18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.MonthDay monthDay22 = monthDay19.withPeriodAdded(readablePeriod20, (int) (byte) 100);
        java.util.Locale locale24 = null;
        try {
            java.lang.String str25 = unsupportedDateTimeField13.getAsText((org.joda.time.ReadablePartial) monthDay22, (int) (short) 100, locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1123234999L + "'", long16 == 1123234999L);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(monthDay22);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.lang.Object obj7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(obj7, chronology9);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((int) 'a', 31, 2019, 100, 166, 0, (int) (byte) 100, chronology9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology9);
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        boolean boolean3 = dateTimeZone1.isStandardOffset(100L);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.ReadableInstant readableInstant5 = null;
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime.Property property9 = dateTime7.year();
//        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
//        boolean boolean12 = dateTime4.isAfter((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.YearMonthDay yearMonthDay13 = dateTime4.toYearMonthDay();
//        int int14 = dateTime4.getDayOfWeek();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(yearMonthDay13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 816);
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology7);
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.DateTime dateTime11 = dateTime8.withFields((org.joda.time.ReadablePartial) monthDay10);
        org.joda.time.MonthDay monthDay13 = monthDay10.minusMonths((-10));
        try {
            dateTimeFormatter0.printTo(stringBuffer3, (org.joda.time.ReadablePartial) monthDay13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(monthDay13);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = copticChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        try {
            long long10 = copticChronology0.getDateTimeMillis((-10), (int) (byte) 100, (int) (byte) 0, 3, (-2078), (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2078 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay8 = monthDay5.withPeriodAdded(readablePeriod6, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay(dateTimeZone10);
        boolean boolean12 = monthDay8.isBefore((org.joda.time.ReadablePartial) monthDay11);
        boolean boolean13 = monthDay2.isAfter((org.joda.time.ReadablePartial) monthDay11);
        try {
            int int15 = monthDay2.getValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.dayOfWeek();
        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) (short) -1);
        int int7 = property4.getLeapAmount();
        org.joda.time.DateTime dateTime8 = property4.withMinimumValue();
        try {
            org.joda.time.DateTime dateTime10 = dateTime8.withEra((-7700));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -7700 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology4 = julianChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        int int8 = delegatedDateTimeField6.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        int int10 = skipDateTimeField9.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay16 = monthDay13.withPeriodAdded(readablePeriod14, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay(dateTimeZone18);
        boolean boolean20 = monthDay16.isBefore((org.joda.time.ReadablePartial) monthDay19);
        int int21 = skipDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) monthDay16);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay(dateTimeZone23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.MonthDay monthDay27 = monthDay24.withPeriodAdded(readablePeriod25, (int) (byte) 100);
        int[] intArray32 = new int[] { 292278993, (-1), (short) 0 };
        try {
            int[] intArray34 = skipDateTimeField9.add((org.joda.time.ReadablePartial) monthDay27, (-2078), intArray32, 59);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -2078");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(intArray32);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.util.Date date0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.fromDateFields(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The date must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (-10));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("20", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"20/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        int int5 = delegatedDateTimeField3.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, 2019);
        long long9 = offsetDateTimeField7.roundHalfFloor(0L);
        long long12 = offsetDateTimeField7.add((long) '#', (int) (short) 1);
        long long14 = offsetDateTimeField7.roundCeiling((-100L));
        org.joda.time.DurationField durationField15 = offsetDateTimeField7.getDurationField();
        boolean boolean16 = offsetDateTimeField7.isSupported();
        java.util.Locale locale17 = null;
        int int18 = offsetDateTimeField7.getMaximumShortTextLength(locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField7.getType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType19, (-1), (int) (short) 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [100,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 60035L + "'", long12 == 60035L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, (int) '#', (int) 'a', 1236);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1175 + "'", int4 == 1175);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(4L, (long) 13);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-9L) + "'", long2 == (-9L));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = copticChronology0.withUTC();
        int int2 = copticChronology0.getMinimumDaysInFirstWeek();
        java.lang.String str3 = copticChronology0.toString();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CopticChronology[UTC]" + "'", str3.equals("CopticChronology[UTC]"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        java.lang.String str10 = property7.getAsString();
        org.joda.time.DateTime dateTime11 = property7.roundCeilingCopy();
        org.joda.time.MutableDateTime mutableDateTime12 = dateTime11.toMutableDateTime();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9769" + "'", str10.equals("9769"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("2078");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '2078' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getRangeDurationField();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone19 = julianChronology18.getZone();
        boolean boolean21 = dateTimeZone19.isStandardOffset(100L);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone19);
        org.joda.time.Chronology chronology23 = julianChronology17.withZone(dateTimeZone19);
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay(0L);
        int[] intArray26 = monthDay25.getValues();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        boolean boolean28 = monthDay25.isSupported(dateTimeFieldType27);
        long long30 = julianChronology17.set((org.joda.time.ReadablePartial) monthDay25, (long) (short) -1);
        boolean boolean31 = monthDay16.isEqual((org.joda.time.ReadablePartial) monthDay25);
        java.util.Locale locale33 = null;
        try {
            java.lang.String str34 = unsupportedDateTimeField13.getAsShortText((org.joda.time.ReadablePartial) monthDay25, (int) '#', locale33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1123199999L + "'", long30 == 1123199999L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(chronology3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, (org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime.Property property6 = dateTime4.dayOfWeek();
        int int7 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(2078, 19);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2097 + "'", int2 == 2097);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        boolean boolean3 = dateTimeZone1.isStandardOffset(100L);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.millisOfDay();
        try {
            long long14 = gregorianChronology5.getDateTimeMillis(59, 59, (-10), (int) (byte) 0, 0, 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getRangeDurationField();
        java.util.Locale locale15 = null;
        try {
            int int16 = unsupportedDateTimeField13.getMaximumTextLength(locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNull(durationField14);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        int int5 = delegatedDateTimeField3.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, 2019);
        long long9 = offsetDateTimeField7.roundHalfFloor(0L);
        long long12 = offsetDateTimeField7.add((long) '#', (int) (short) 1);
        long long14 = offsetDateTimeField7.roundCeiling((-100L));
        org.joda.time.DurationField durationField15 = offsetDateTimeField7.getDurationField();
        boolean boolean16 = offsetDateTimeField7.isSupported();
        java.util.Locale locale17 = null;
        int int18 = offsetDateTimeField7.getMaximumShortTextLength(locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField7.getType();
        java.util.Locale locale21 = null;
        java.lang.String str22 = offsetDateTimeField7.getAsText((long) (-1), locale21);
        long long24 = offsetDateTimeField7.roundHalfEven(1123199999L);
        java.lang.String str25 = offsetDateTimeField7.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology28 = julianChronology27.withUTC();
        org.joda.time.DateTimeField dateTimeField29 = julianChronology27.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
        int int32 = delegatedDateTimeField30.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField30, 2019);
        long long36 = offsetDateTimeField34.roundHalfFloor(0L);
        long long39 = offsetDateTimeField34.add((long) '#', (int) (short) 1);
        long long41 = offsetDateTimeField34.roundCeiling((-100L));
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay44 = new org.joda.time.MonthDay(dateTimeZone43);
        org.joda.time.ReadablePeriod readablePeriod45 = null;
        org.joda.time.MonthDay monthDay47 = monthDay44.withPeriodAdded(readablePeriod45, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay50 = new org.joda.time.MonthDay(dateTimeZone49);
        boolean boolean51 = monthDay47.isBefore((org.joda.time.ReadablePartial) monthDay50);
        int int52 = offsetDateTimeField34.getMaximumValue((org.joda.time.ReadablePartial) monthDay50);
        java.lang.String str53 = dateTimeFormatter26.print((org.joda.time.ReadablePartial) monthDay50);
        java.util.Locale locale54 = null;
        try {
            java.lang.String str55 = offsetDateTimeField7.getAsShortText((org.joda.time.ReadablePartial) monthDay50, locale54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfHour' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 60035L + "'", long12 == 60035L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2078" + "'", str22.equals("2078"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1123200000L + "'", long24 == 1123200000L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str25.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(julianChronology27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 60035L + "'", long39 == 60035L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(monthDay47);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2078 + "'", int52 == 2078);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "1/5/�� �:�� �" + "'", str53.equals("1/5/�� �:�� �"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.dayOfWeek();
        java.lang.String str5 = property4.getAsString();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "3" + "'", str5.equals("3"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        int int5 = delegatedDateTimeField3.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, 2019);
        long long9 = offsetDateTimeField7.roundHalfFloor(0L);
        long long12 = offsetDateTimeField7.add((long) '#', (int) (short) 1);
        long long14 = offsetDateTimeField7.roundCeiling((-100L));
        org.joda.time.DurationField durationField15 = offsetDateTimeField7.getDurationField();
        boolean boolean16 = offsetDateTimeField7.isSupported();
        java.util.Locale locale17 = null;
        int int18 = offsetDateTimeField7.getMaximumShortTextLength(locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField7.getType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType19, 2000, (int) (short) -1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for minuteOfHour must be in the range [-1,32]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 60035L + "'", long12 == 60035L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay(dateTimeZone3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, (int) (byte) 100);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) monthDay7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(monthDay7);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime4.withFields((org.joda.time.ReadablePartial) monthDay6);
        org.joda.time.MonthDay monthDay9 = monthDay6.minusMonths((-10));
        int int10 = monthDay6.getDayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay16 = monthDay13.withPeriodAdded(readablePeriod14, (int) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        int int18 = monthDay13.indexOf(dateTimeFieldType17);
        boolean boolean19 = monthDay6.isAfter((org.joda.time.ReadablePartial) monthDay13);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(1123200000L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) "1236");
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        java.lang.String str2 = julianChronology0.toString();
        long long6 = julianChronology0.add((long) 816, (long) 100, 2078);
        org.joda.time.DurationField durationField7 = julianChronology0.seconds();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[UTC]" + "'", str2.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 208616L + "'", long6 == 208616L);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        try {
            java.lang.String str15 = unsupportedDateTimeField13.getAsShortText((long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        try {
            org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Character");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime4.withFields((org.joda.time.ReadablePartial) monthDay6);
        try {
            org.joda.time.DateTime dateTime9 = dateTime4.withDayOfWeek((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.dayOfWeek();
        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) (short) -1);
        org.joda.time.DateTime dateTime8 = property4.addToCopy(0);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology10 = julianChronology9.withUTC();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology9.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology13 = julianChronology12.withUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology12.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int17 = delegatedDateTimeField15.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField18 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology9, (org.joda.time.DateTimeField) delegatedDateTimeField15);
        int int19 = skipDateTimeField18.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.MonthDay monthDay25 = monthDay22.withPeriodAdded(readablePeriod23, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay(dateTimeZone27);
        boolean boolean29 = monthDay25.isBefore((org.joda.time.ReadablePartial) monthDay28);
        int int30 = skipDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) monthDay25);
        try {
            int int31 = property4.compareTo((org.joda.time.ReadablePartial) monthDay25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfWeek' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        long long1 = instant0.getMillis();
        org.joda.time.Chronology chronology2 = instant0.getChronology();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1123200000L + "'", long1 == 1123200000L);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        boolean boolean3 = dateTimeZone1.isStandardOffset(100L);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        boolean boolean12 = dateTime4.isAfter((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        boolean boolean14 = dateTime4.isSupported(dateTimeFieldType13);
        org.joda.time.DateTime dateTime16 = dateTime4.minusSeconds(86399999);
        int int17 = dateTime4.getMinuteOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime6 = property4.roundHalfEvenCopy();
        java.lang.String str7 = property4.getAsString();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970" + "'", str7.equals("1970"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        int int13 = dateTime7.getDayOfWeek();
        boolean boolean14 = dateTime7.isEqualNow();
        org.joda.time.DateTime dateTime16 = dateTime7.withWeekOfWeekyear(12);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(chronology4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant6, (org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property10 = dateTime8.dayOfWeek();
        int int11 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime8);
        boolean boolean12 = dateTime5.isEqualNow();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime5);
        java.lang.String str15 = dateTimeZone1.getShortName(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+97:00" + "'", str15.equals("+97:00"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType10, "UTC");
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(chronology14);
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, (org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime.Property property17 = dateTime15.year();
        org.joda.time.DateTime dateTime19 = dateTime15.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
        java.lang.Object obj21 = null;
        boolean boolean22 = property20.equals(obj21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property20.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, "UTC");
        illegalFieldValueException12.addSuppressed((java.lang.Throwable) illegalFieldValueException25);
        java.lang.Number number27 = illegalFieldValueException12.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNull(number27);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property13 = dateTime7.millisOfDay();
        org.joda.time.DateTime dateTime15 = dateTime7.withYearOfCentury((int) (byte) 0);
        try {
            org.joda.time.DateTime dateTime20 = dateTime7.withTime(36, (int) (short) 100, 59, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 36 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("JulianChronology[UTC]", "Sat", 36, 816);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.hours();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        int int5 = delegatedDateTimeField3.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, 2019);
        long long9 = offsetDateTimeField7.roundHalfFloor(0L);
        long long12 = offsetDateTimeField7.add((long) '#', (int) (short) 1);
        long long14 = offsetDateTimeField7.roundCeiling((-100L));
        org.joda.time.DurationField durationField15 = offsetDateTimeField7.getDurationField();
        boolean boolean16 = offsetDateTimeField7.isSupported();
        java.util.Locale locale17 = null;
        int int18 = offsetDateTimeField7.getMaximumShortTextLength(locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField7.getType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType19, (-7700), (int) (byte) 10, 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -7700 for minuteOfHour must be in the range [10,6]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 60035L + "'", long12 == 60035L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("-01:00", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: -01:00");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        boolean boolean3 = dateTimeZone1.isStandardOffset(100L);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology5.getZone();
        org.joda.time.ReadableInstant readableInstant8 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, readableInstant8, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 2019");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        java.lang.String str6 = delegatedDateTimeField4.getAsShortText((long) (-10));
        long long8 = delegatedDateTimeField4.remainder((long) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField4.getType();
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField4.getAsText(readablePartial10, (int) (short) 100, locale12);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) delegatedDateTimeField4, 31, 48983, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for minuteOfHour must be in the range [48983,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "59" + "'", str6.equals("59"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        long long16 = unsupportedDateTimeField13.add((long) (-10), 36);
        boolean boolean17 = unsupportedDateTimeField13.isSupported();
        try {
            long long19 = unsupportedDateTimeField13.roundCeiling(74160000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35990L + "'", long16 == 35990L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        java.util.Locale locale14 = null;
        try {
            int int15 = unsupportedDateTimeField13.getMaximumShortTextLength(locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        boolean boolean3 = dateTimeZone1.isStandardOffset(100L);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        boolean boolean12 = dateTime4.isAfter((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        boolean boolean14 = dateTime4.isSupported(dateTimeFieldType13);
        org.joda.time.DateTime dateTime16 = dateTime4.minusSeconds(86399999);
        try {
            org.joda.time.DateTime dateTime18 = dateTime16.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        int int5 = delegatedDateTimeField3.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, 2019);
        long long9 = offsetDateTimeField7.roundHalfFloor(0L);
        long long12 = offsetDateTimeField7.add((long) '#', (int) (short) 1);
        long long14 = offsetDateTimeField7.roundCeiling((-100L));
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(dateTimeZone19);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.MonthDay monthDay23 = monthDay20.withPeriodAdded(readablePeriod21, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay(dateTimeZone25);
        boolean boolean27 = monthDay23.isBefore((org.joda.time.ReadablePartial) monthDay26);
        boolean boolean28 = monthDay17.isAfter((org.joda.time.ReadablePartial) monthDay26);
        int[] intArray34 = new int[] { 59, 166, 1236, 13 };
        try {
            int[] intArray36 = offsetDateTimeField7.addWrapField((org.joda.time.ReadablePartial) monthDay17, 0, intArray34, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2047");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 60035L + "'", long12 == 60035L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(intArray34);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.String str8 = property7.toString();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Property[yearOfEra]" + "'", str8.equals("Property[yearOfEra]"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        boolean boolean3 = dateTimeZone1.isStandardOffset(100L);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.TimeOfDay timeOfDay5 = dateTime4.toTimeOfDay();
        org.joda.time.DateTime.Property property6 = dateTime4.centuryOfEra();
        java.lang.String str7 = property6.toString();
        try {
            org.joda.time.DateTime dateTime9 = property6.setCopy("ISOChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ISOChronology[America/Los_Angeles]\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(timeOfDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[centuryOfEra]" + "'", str7.equals("Property[centuryOfEra]"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(chronology14);
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, (org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime.Property property17 = dateTime15.year();
        org.joda.time.DateTime dateTime19 = dateTime15.withCenturyOfEra((int) 'a');
        int int20 = property4.getDifference((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime dateTime22 = property4.addToCopy(0L);
        int int23 = property4.get();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-7800) + "'", int20 == (-7800));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1970 + "'", int23 == 1970);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendYearOfEra(13, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMillisOfSecond((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendWeekOfWeekyear((int) (byte) 10);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(chronology10);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant9, (org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime.Property property13 = dateTime11.year();
        org.joda.time.DateTime dateTime15 = dateTime11.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfEra();
        java.lang.Object obj17 = null;
        boolean boolean18 = property16.equals(obj17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property16.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, "UTC");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder6.appendFraction(dateTimeFieldType19, 4, 10);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder5.appendDecimal(dateTimeFieldType19, 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) -1, (int) (byte) 0, (int) '#', 10, 292278993, (int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology3 = iSOChronology1.withZone(dateTimeZone2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, (org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property8 = dateTime6.year();
        org.joda.time.DateTime dateTime10 = dateTime6.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property11 = dateTime10.yearOfEra();
        java.lang.Object obj12 = null;
        boolean boolean13 = property11.equals(obj12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, "UTC");
        boolean boolean17 = iSOChronology1.equals((java.lang.Object) illegalFieldValueException16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 1, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology1.year();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone2);
        org.joda.time.Chronology chronology4 = julianChronology0.withZone(dateTimeZone2);
        long long7 = dateTimeZone2.adjustOffset(10L, false);
        long long11 = dateTimeZone2.convertLocalToUTC((long) (short) 1, true, 0L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-349199999L) + "'", long11 == (-349199999L));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        boolean boolean3 = dateTimeZone1.isStandardOffset(100L);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.TimeOfDay timeOfDay5 = dateTime4.toTimeOfDay();
        org.joda.time.DateTime.Property property6 = dateTime4.centuryOfEra();
        java.lang.String str7 = property6.toString();
        java.lang.String str8 = property6.getAsText();
        org.joda.time.Interval interval9 = property6.toInterval();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(timeOfDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[centuryOfEra]" + "'", str7.equals("Property[centuryOfEra]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "19" + "'", str8.equals("19"));
        org.junit.Assert.assertNotNull(interval9);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        int int5 = delegatedDateTimeField3.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, 2019);
        long long9 = offsetDateTimeField7.roundHalfFloor(0L);
        long long11 = offsetDateTimeField7.roundHalfEven(0L);
        try {
            long long14 = offsetDateTimeField7.set((long) 31, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for minuteOfHour must be in the range [2019,2078]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property13 = dateTime7.millisOfDay();
        org.joda.time.DurationField durationField14 = property13.getLeapDurationField();
        org.joda.time.DateTime dateTime15 = property13.roundCeilingCopy();
        int int16 = property13.getMinimumValueOverall();
        int int17 = property13.getMaximumValue();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 86399999 + "'", int17 == 86399999);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = copticChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        try {
            long long7 = copticChronology0.getDateTimeMillis(1236, 816, (int) (byte) 10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 816 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(chronology3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, (org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime.Property property6 = dateTime4.dayOfWeek();
        int int7 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime4);
        boolean boolean8 = dateTime1.isEqualNow();
        boolean boolean10 = dateTime1.isEqual((long) 292278993);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        java.lang.String str5 = dateTimeZone1.getShortName(10L);
        java.util.TimeZone timeZone6 = dateTimeZone1.toTimeZone();
        long long10 = dateTimeZone1.convertLocalToUTC((long) (short) 10, true, (long) 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+97:00" + "'", str5.equals("+97:00"));
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-349199990L) + "'", long10 == (-349199990L));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology3 = iSOChronology1.withZone(dateTimeZone2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, (org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property8 = dateTime6.year();
        org.joda.time.DateTime dateTime10 = dateTime6.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property11 = dateTime10.yearOfEra();
        java.lang.Object obj12 = null;
        boolean boolean13 = property11.equals(obj12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, "UTC");
        boolean boolean17 = iSOChronology1.equals((java.lang.Object) illegalFieldValueException16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 1, (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property13 = dateTime7.millisOfDay();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime7.plus(readablePeriod14);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(dateTimeZone17);
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone17);
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, (org.joda.time.Chronology) buddhistChronology19);
        org.joda.time.MonthDay monthDay22 = monthDay20.plusDays((int) (short) 100);
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(chronology24);
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant23, (org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime.Property property27 = dateTime25.year();
        org.joda.time.DateTime dateTime29 = dateTime25.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property30 = dateTime29.yearOfEra();
        java.lang.Object obj31 = null;
        boolean boolean32 = property30.equals(obj31);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property30.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, "UTC");
        try {
            org.joda.time.MonthDay.Property property36 = monthDay20.property(dateTimeFieldType33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfEra' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        java.lang.String str6 = delegatedDateTimeField4.getAsShortText((long) (-10));
        long long8 = delegatedDateTimeField4.remainder((long) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField4.getType();
        long long12 = delegatedDateTimeField4.addWrapField(1123200000L, 57600000);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "59" + "'", str6.equals("59"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1123200000L + "'", long12 == 1123200000L);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = julianChronology1.withUTC();
        java.lang.String str3 = julianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withZone(dateTimeZone4);
        try {
            org.joda.time.LocalTime localTime7 = dateTimeFormatter5.parseLocalTime("2078");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2078\" is malformed at \"78\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        int int0 = org.joda.time.MonthDay.DAY_OF_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("Saturday");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Saturday/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.junit.Assert.assertNotNull(monthDay0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        try {
            org.joda.time.LocalDate localDate4 = dateTimeFormatter2.parseLocalDate("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology4 = julianChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        int int8 = delegatedDateTimeField6.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        int int10 = skipDateTimeField9.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay16 = monthDay13.withPeriodAdded(readablePeriod14, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay(dateTimeZone18);
        boolean boolean20 = monthDay16.isBefore((org.joda.time.ReadablePartial) monthDay19);
        int int21 = skipDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) monthDay16);
        org.joda.time.DurationField durationField22 = skipDateTimeField9.getLeapDurationField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(durationField22);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter2.withZone(dateTimeZone5);
        java.lang.Integer int8 = dateTimeFormatter7.getPivotYear();
        java.io.Writer writer9 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(dateTimeZone11);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay15 = monthDay12.withPeriodAdded(readablePeriod13, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(dateTimeZone17);
        boolean boolean19 = monthDay15.isBefore((org.joda.time.ReadablePartial) monthDay18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.MonthDay monthDay25 = monthDay22.withPeriodAdded(readablePeriod23, (int) (byte) 100);
        boolean boolean26 = monthDay18.isBefore((org.joda.time.ReadablePartial) monthDay22);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.MonthDay monthDay28 = monthDay18.minus(readablePeriod27);
        try {
            dateTimeFormatter7.printTo(writer9, (org.joda.time.ReadablePartial) monthDay28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8.equals(0));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(monthDay28);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property13 = dateTime7.millisOfDay();
        org.joda.time.DateTime dateTime15 = dateTime7.withYearOfCentury((int) (byte) 0);
        org.joda.time.DateTime dateTime18 = dateTime7.withDurationAdded((long) (byte) 100, 36);
        org.joda.time.DateTime dateTime20 = dateTime18.withSecondOfMinute(19);
        org.joda.time.DateTime.Property property21 = dateTime18.minuteOfHour();
        int int22 = dateTime18.getDayOfWeek();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.dayOfWeek();
        int int5 = dateTime2.getMinuteOfDay();
        java.util.GregorianCalendar gregorianCalendar6 = dateTime2.toGregorianCalendar();
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar6);
        try {
            org.joda.time.DateTimeField dateTimeField9 = monthDay7.getField(2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 2000");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 960 + "'", int5 == 960);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertNotNull(monthDay7);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getRangeDurationField();
        int int8 = delegatedDateTimeField4.getDifference(0L, (long) 1);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime.Property property5 = dateTime2.secondOfMinute();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        boolean boolean3 = dateTimeZone1.isStandardOffset(100L);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.TimeOfDay timeOfDay5 = dateTime4.toTimeOfDay();
        org.joda.time.DateTime.Property property6 = dateTime4.centuryOfEra();
        java.lang.String str7 = property6.toString();
        org.joda.time.DateTime dateTime8 = property6.withMaximumValue();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(timeOfDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[centuryOfEra]" + "'", str7.equals("Property[centuryOfEra]"));
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology3);
        java.lang.String str5 = buddhistChronology3.toString();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "BuddhistChronology[-01:00]" + "'", str5.equals("BuddhistChronology[-01:00]"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        int int5 = delegatedDateTimeField3.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, 2019);
        long long9 = offsetDateTimeField7.roundHalfFloor(0L);
        long long12 = offsetDateTimeField7.add((long) '#', (int) (short) 1);
        long long14 = offsetDateTimeField7.roundCeiling((-100L));
        org.joda.time.DurationField durationField15 = offsetDateTimeField7.getDurationField();
        boolean boolean16 = offsetDateTimeField7.isSupported();
        java.util.Locale locale17 = null;
        int int18 = offsetDateTimeField7.getMaximumShortTextLength(locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField7.getType();
        java.util.Locale locale21 = null;
        java.lang.String str22 = offsetDateTimeField7.getAsText((long) (-1), locale21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField7.getAsShortText(36, locale24);
        boolean boolean26 = offsetDateTimeField7.isSupported();
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology28 = julianChronology27.withUTC();
        org.joda.time.DateTimeField dateTimeField29 = julianChronology27.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology31 = julianChronology30.withUTC();
        org.joda.time.DateTimeField dateTimeField32 = julianChronology30.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField32);
        int int35 = delegatedDateTimeField33.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField36 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology27, (org.joda.time.DateTimeField) delegatedDateTimeField33);
        int int37 = skipDateTimeField36.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay(dateTimeZone39);
        org.joda.time.ReadablePeriod readablePeriod41 = null;
        org.joda.time.MonthDay monthDay43 = monthDay40.withPeriodAdded(readablePeriod41, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay46 = new org.joda.time.MonthDay(dateTimeZone45);
        boolean boolean47 = monthDay43.isBefore((org.joda.time.ReadablePartial) monthDay46);
        int int48 = skipDateTimeField36.getMinimumValue((org.joda.time.ReadablePartial) monthDay43);
        java.util.Locale locale49 = null;
        try {
            java.lang.String str50 = offsetDateTimeField7.getAsText((org.joda.time.ReadablePartial) monthDay43, locale49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfHour' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 60035L + "'", long12 == 60035L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2078" + "'", str22.equals("2078"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "36" + "'", str25.equals("36"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(julianChronology27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(monthDay43);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear(1);
        try {
            org.joda.time.LocalDate localDate6 = dateTimeFormatter2.parseLocalDate("Sat");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Sat\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfYear();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = julianChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology2.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology6 = julianChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        int int10 = delegatedDateTimeField8.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField8);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = julianChronology15.getZone();
        boolean boolean18 = dateTimeZone16.isStandardOffset(100L);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.Chronology chronology20 = julianChronology14.withZone(dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(0L);
        int[] intArray23 = monthDay22.getValues();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        boolean boolean25 = monthDay22.isSupported(dateTimeFieldType24);
        long long27 = julianChronology14.set((org.joda.time.ReadablePartial) monthDay22, (long) (short) -1);
        boolean boolean28 = monthDay13.isEqual((org.joda.time.ReadablePartial) monthDay22);
        java.util.Locale locale30 = null;
        java.lang.String str31 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay22, (-1), locale30);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipDateTimeField11, (int) '#');
        int int35 = skipDateTimeField11.get((-32L));
        org.joda.time.DurationField durationField36 = skipDateTimeField11.getLeapDurationField();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1123199999L + "'", long27 == 1123199999L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "-1" + "'", str31.equals("-1"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 59 + "'", int35 == 59);
        org.junit.Assert.assertNull(durationField36);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        long long16 = unsupportedDateTimeField13.add((long) (-10), 36);
        boolean boolean17 = unsupportedDateTimeField13.isSupported();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology21);
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.DateTime dateTime25 = dateTime22.withFields((org.joda.time.ReadablePartial) monthDay24);
        java.util.Locale locale26 = null;
        try {
            java.lang.String str27 = unsupportedDateTimeField13.getAsShortText((org.joda.time.ReadablePartial) monthDay24, locale26);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35990L + "'", long16 == 35990L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfYear();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = julianChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology2.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology6 = julianChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        int int10 = delegatedDateTimeField8.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField8);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = julianChronology15.getZone();
        boolean boolean18 = dateTimeZone16.isStandardOffset(100L);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.Chronology chronology20 = julianChronology14.withZone(dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(0L);
        int[] intArray23 = monthDay22.getValues();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        boolean boolean25 = monthDay22.isSupported(dateTimeFieldType24);
        long long27 = julianChronology14.set((org.joda.time.ReadablePartial) monthDay22, (long) (short) -1);
        boolean boolean28 = monthDay13.isEqual((org.joda.time.ReadablePartial) monthDay22);
        java.util.Locale locale30 = null;
        java.lang.String str31 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay22, (-1), locale30);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipDateTimeField11, (int) '#');
        long long36 = skipDateTimeField11.add((long) (byte) -1, 2000);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1123199999L + "'", long27 == 1123199999L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "-1" + "'", str31.equals("-1"));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 119999999L + "'", long36 == 119999999L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(119999999L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, (int) (byte) 100);
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipUndoDateTimeField4.getAsShortText(0L, locale6);
        long long9 = skipUndoDateTimeField4.roundHalfFloor((long) (-1));
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology11 = julianChronology10.withUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology10.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology14 = julianChronology13.withUTC();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology13.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int18 = delegatedDateTimeField16.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology10, (org.joda.time.DateTimeField) delegatedDateTimeField16);
        int int20 = skipDateTimeField19.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay(dateTimeZone22);
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.MonthDay monthDay26 = monthDay23.withPeriodAdded(readablePeriod24, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay29 = new org.joda.time.MonthDay(dateTimeZone28);
        boolean boolean30 = monthDay26.isBefore((org.joda.time.ReadablePartial) monthDay29);
        int int31 = skipDateTimeField19.getMinimumValue((org.joda.time.ReadablePartial) monthDay26);
        org.joda.time.MonthDay monthDay34 = new org.joda.time.MonthDay(0L);
        int[] intArray35 = monthDay34.getValues();
        try {
            int[] intArray37 = skipUndoDateTimeField4.set((org.joda.time.ReadablePartial) monthDay26, 0, intArray35, (-7800));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -7800 for yearOfCentury must be in the range [1,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "69" + "'", str7.equals("69"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1123200000L + "'", long9 == 1123200000L);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(intArray35);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(chronology4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant6, (org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property10 = dateTime8.dayOfWeek();
        int int11 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime8);
        boolean boolean12 = dateTime5.isEqualNow();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime5);
        try {
            long long21 = gJChronology13.getDateTimeMillis((int) 'a', 10, 13, (int) (byte) -1, 10, (int) (byte) -1, 86399999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(gJChronology13);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        java.lang.String str6 = delegatedDateTimeField4.getAsShortText((long) (-10));
        long long8 = delegatedDateTimeField4.remainder((long) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField4.getType();
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField4.getAsText(readablePartial10, (int) (short) 100, locale12);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(0L);
        int[] intArray16 = monthDay15.getValues();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        boolean boolean18 = monthDay15.isSupported(dateTimeFieldType17);
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology21 = julianChronology20.withUTC();
        org.joda.time.DateTimeField dateTimeField22 = julianChronology20.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology24 = julianChronology23.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = julianChronology23.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        int int28 = delegatedDateTimeField26.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField29 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology20, (org.joda.time.DateTimeField) delegatedDateTimeField26);
        int int30 = skipDateTimeField29.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay(dateTimeZone32);
        org.joda.time.ReadablePeriod readablePeriod34 = null;
        org.joda.time.MonthDay monthDay36 = monthDay33.withPeriodAdded(readablePeriod34, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay(dateTimeZone38);
        boolean boolean40 = monthDay36.isBefore((org.joda.time.ReadablePartial) monthDay39);
        int int41 = skipDateTimeField29.getMinimumValue((org.joda.time.ReadablePartial) monthDay36);
        int[] intArray42 = monthDay36.getValues();
        try {
            int[] intArray44 = delegatedDateTimeField4.addWrapField((org.joda.time.ReadablePartial) monthDay15, 0, intArray42, 2020);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 40");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "59" + "'", str6.equals("59"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(monthDay36);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(intArray42);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.Instant instant2 = org.joda.time.Instant.now();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant2, (org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.Instant instant6 = instant2.withMillis((long) (short) -1);
        try {
            java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) instant6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        int int5 = delegatedDateTimeField3.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, 2019);
        long long9 = offsetDateTimeField7.roundHalfFloor(0L);
        long long12 = offsetDateTimeField7.add((long) '#', (int) (short) 1);
        long long14 = offsetDateTimeField7.roundCeiling((-100L));
        org.joda.time.DurationField durationField15 = offsetDateTimeField7.getDurationField();
        boolean boolean16 = offsetDateTimeField7.isSupported();
        java.util.Locale locale17 = null;
        int int18 = offsetDateTimeField7.getMaximumShortTextLength(locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField7.getType();
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone24 = julianChronology23.getZone();
        boolean boolean26 = dateTimeZone24.isStandardOffset(100L);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone24);
        org.joda.time.Chronology chronology28 = julianChronology22.withZone(dateTimeZone24);
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay(0L);
        int[] intArray31 = monthDay30.getValues();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = null;
        boolean boolean33 = monthDay30.isSupported(dateTimeFieldType32);
        long long35 = julianChronology22.set((org.joda.time.ReadablePartial) monthDay30, (long) (short) -1);
        boolean boolean36 = monthDay21.isEqual((org.joda.time.ReadablePartial) monthDay30);
        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology39 = julianChronology38.withUTC();
        org.joda.time.DateTimeField dateTimeField40 = julianChronology38.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField41 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField40);
        java.lang.String str42 = delegatedDateTimeField41.toString();
        org.joda.time.chrono.JulianChronology julianChronology43 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology44 = julianChronology43.withUTC();
        org.joda.time.DateTimeField dateTimeField45 = julianChronology43.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField46 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField45);
        int int48 = delegatedDateTimeField46.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField46, 2019);
        long long52 = offsetDateTimeField50.roundHalfFloor(0L);
        long long55 = offsetDateTimeField50.add((long) '#', (int) (short) 1);
        long long57 = offsetDateTimeField50.roundCeiling((-100L));
        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay60 = new org.joda.time.MonthDay(dateTimeZone59);
        org.joda.time.ReadablePeriod readablePeriod61 = null;
        org.joda.time.MonthDay monthDay63 = monthDay60.withPeriodAdded(readablePeriod61, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone65 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay66 = new org.joda.time.MonthDay(dateTimeZone65);
        boolean boolean67 = monthDay63.isBefore((org.joda.time.ReadablePartial) monthDay66);
        int int68 = offsetDateTimeField50.getMaximumValue((org.joda.time.ReadablePartial) monthDay66);
        int[] intArray69 = new int[] {};
        int int70 = delegatedDateTimeField41.getMinimumValue((org.joda.time.ReadablePartial) monthDay66, intArray69);
        try {
            int[] intArray72 = offsetDateTimeField7.set((org.joda.time.ReadablePartial) monthDay30, (int) (short) 10, intArray69, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [2019,2078]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 60035L + "'", long12 == 60035L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1123199999L + "'", long35 == 1123199999L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(julianChronology38);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str42.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertNotNull(julianChronology43);
        org.junit.Assert.assertNotNull(chronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 60035L + "'", long55 == 60035L);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(monthDay63);
        org.junit.Assert.assertNotNull(dateTimeZone65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 2078 + "'", int68 == 2078);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(10);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter0.printTo(appendable3, (long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology6.getZone();
        java.util.TimeZone timeZone8 = dateTimeZone7.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        org.joda.time.DateTime dateTime10 = dateTime3.toDateTime(dateTimeZone9);
        java.util.GregorianCalendar gregorianCalendar11 = dateTime10.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianCalendar11);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = copticChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        try {
            long long10 = copticChronology0.getDateTimeMillis(0, (-7700), 166, (int) (short) 0, 2, (int) (byte) 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -7700 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        long long16 = unsupportedDateTimeField13.add(1123199999L, (long) '#');
        try {
            boolean boolean18 = unsupportedDateTimeField13.isLeap((long) 292278993);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1123234999L + "'", long16 == 1123234999L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime4.withFields((org.joda.time.ReadablePartial) monthDay6);
        org.joda.time.MonthDay monthDay9 = monthDay6.minusMonths((-10));
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology11 = julianChronology10.withUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology10.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField14 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12, dateTimeFieldType13);
        java.lang.String str16 = delegatedDateTimeField14.getAsShortText((long) (-10));
        long long18 = delegatedDateTimeField14.remainder((long) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = delegatedDateTimeField14.getType();
        int int20 = monthDay9.indexOf(dateTimeFieldType19);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType19, 2020, 3600000, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2020 for minuteOfHour must be in the range [3600000,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "59" + "'", str16.equals("59"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology4 = julianChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        int int8 = delegatedDateTimeField6.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, (org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime.Property property14 = dateTime12.year();
        org.joda.time.DateTime dateTime16 = dateTime12.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property17 = dateTime16.yearOfEra();
        java.lang.Object obj18 = null;
        boolean boolean19 = property17.equals(obj18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property17.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, "UTC");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField23 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField6, dateTimeFieldType20);
        long long26 = zeroIsMaxDateTimeField23.add(0L, 1236);
        int int29 = zeroIsMaxDateTimeField23.getDifference((long) 2078, 125820000L);
        long long31 = zeroIsMaxDateTimeField23.roundHalfFloor((long) 100);
        long long34 = zeroIsMaxDateTimeField23.add(0L, (long) 2019);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 74160000L + "'", long26 == 74160000L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-2096) + "'", int29 == (-2096));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 121140000L + "'", long34 == 121140000L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((-349199990L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-349199990) + "'", int1 == (-349199990));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        boolean boolean4 = dateTimeZone2.isStandardOffset(100L);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.Chronology chronology6 = julianChronology0.withZone(dateTimeZone2);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        try {
            int[] intArray10 = julianChronology0.get(readablePeriod7, (long) 59, (long) 1175);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        boolean boolean3 = dateTimeZone1.isStandardOffset(100L);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = dateTime4.withChronology((org.joda.time.Chronology) julianChronology5);
        org.joda.time.DateTime.Property property7 = dateTime6.dayOfWeek();
        java.util.Locale locale9 = null;
        try {
            org.joda.time.DateTime dateTime10 = property7.setCopy("", locale9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) 0);
        try {
            org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) 57600000, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("6/19/�� �:�� �");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"6/19/�� �:�� �\" is malformed at \"/19/�� �:�� �\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(0L, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-52L) + "'", long2 == (-52L));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        try {
            long long8 = copticChronology0.getDateTimeMillis(0, 1970, 960, (int) (short) 0, 2096, (int) (short) 0, 2078);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2096 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology8 = julianChronology7.withUTC();
        java.lang.String str9 = julianChronology7.toString();
        org.joda.time.Chronology chronology10 = julianChronology7.withUTC();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology7.millisOfSecond();
        int int12 = julianChronology7.getMinimumDaysInFirstWeek();
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(2, 0, 9, 1970, 12, 0, 100, (org.joda.time.Chronology) julianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "JulianChronology[UTC]" + "'", str9.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        long long16 = unsupportedDateTimeField13.add((long) (-10), 36);
        boolean boolean17 = unsupportedDateTimeField13.isSupported();
        java.lang.String str18 = unsupportedDateTimeField13.getName();
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((long) (short) -1);
        java.util.Locale locale22 = null;
        try {
            java.lang.String str23 = unsupportedDateTimeField13.getAsText((org.joda.time.ReadablePartial) monthDay20, 3, locale22);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35990L + "'", long16 == 35990L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "yearOfEra" + "'", str18.equals("yearOfEra"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("3");
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime1 = dateTime0.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = copticChronology1.add(readablePeriod2, (long) (byte) -1, 1);
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(0L, (org.joda.time.Chronology) copticChronology1);
        try {
            long long14 = copticChronology1.getDateTimeMillis((-7800), (int) (short) 0, 2078, (int) (short) -1, (int) (short) 1, 960, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology4 = julianChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        int int8 = delegatedDateTimeField6.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        int int10 = skipDateTimeField9.getMinimumValue();
        long long12 = skipDateTimeField9.roundHalfCeiling((long) 816);
        try {
            long long15 = skipDateTimeField9.set((long) (-2096), 2020);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2020 for minuteOfHour must be in the range [1,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime dateTime5 = dateTime2.withEra((int) (byte) 1);
        org.joda.time.DateTime dateTime7 = dateTime5.plusMinutes(1);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        int int13 = dateTime12.getMonthOfYear();
        org.joda.time.DateTime dateTime15 = dateTime12.minusMillis((int) (short) 1);
        try {
            org.joda.time.DateTime dateTime17 = dateTime15.withDayOfMonth((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay(dateTimeZone18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.MonthDay monthDay22 = monthDay19.withPeriodAdded(readablePeriod20, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay(dateTimeZone24);
        boolean boolean26 = monthDay22.isBefore((org.joda.time.ReadablePartial) monthDay25);
        boolean boolean27 = monthDay16.isAfter((org.joda.time.ReadablePartial) monthDay25);
        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology29 = julianChronology28.withUTC();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology28.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField30, dateTimeFieldType31);
        java.lang.String str34 = delegatedDateTimeField32.getAsShortText((long) (-10));
        long long36 = delegatedDateTimeField32.remainder((long) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = delegatedDateTimeField32.getType();
        org.joda.time.ReadablePartial readablePartial38 = null;
        java.util.Locale locale40 = null;
        java.lang.String str41 = delegatedDateTimeField32.getAsText(readablePartial38, (int) (short) 100, locale40);
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology45 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone44);
        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology45);
        org.joda.time.MonthDay monthDay48 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.DateTime dateTime49 = dateTime46.withFields((org.joda.time.ReadablePartial) monthDay48);
        int[] intArray56 = new int[] { (short) 100, (-2078), 36, 4, '#', (byte) 100 };
        int int57 = delegatedDateTimeField32.getMinimumValue((org.joda.time.ReadablePartial) monthDay48, intArray56);
        try {
            int int58 = unsupportedDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) monthDay16, intArray56);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(julianChronology28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "59" + "'", str34.equals("59"));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType37);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "100" + "'", str41.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(buddhistChronology45);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology4 = julianChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        int int8 = delegatedDateTimeField6.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, (org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime.Property property14 = dateTime12.year();
        org.joda.time.DateTime dateTime16 = dateTime12.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property17 = dateTime16.yearOfEra();
        java.lang.Object obj18 = null;
        boolean boolean19 = property17.equals(obj18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property17.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, "UTC");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField23 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField6, dateTimeFieldType20);
        long long26 = zeroIsMaxDateTimeField23.add(0L, 1236);
        long long28 = zeroIsMaxDateTimeField23.roundHalfEven((long) 57600000);
        long long30 = zeroIsMaxDateTimeField23.roundHalfEven((long) 2);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 74160000L + "'", long26 == 74160000L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 57600000L + "'", long28 == 57600000L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime4.withFields((org.joda.time.ReadablePartial) monthDay6);
        org.joda.time.MonthDay monthDay9 = monthDay6.minusMonths((-10));
        try {
            org.joda.time.MonthDay monthDay11 = monthDay6.withMonthOfYear((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(monthDay9);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property13 = dateTime7.millisOfDay();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime7.plus(readablePeriod14);
        org.joda.time.DateTime.Property property16 = dateTime7.dayOfYear();
        org.joda.time.DateTime dateTime18 = dateTime7.withWeekOfWeekyear(4);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getShortName(0L, locale5);
//        int int8 = dateTimeZone3.getOffsetFromLocal(125820000L);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(dateTimeZone7);
        boolean boolean9 = monthDay5.isBefore((org.joda.time.ReadablePartial) monthDay8);
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay(0L);
        int[] intArray12 = monthDay11.getValues();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        boolean boolean14 = monthDay11.isSupported(dateTimeFieldType13);
        boolean boolean15 = monthDay5.isAfter((org.joda.time.ReadablePartial) monthDay11);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType17 = monthDay5.getFieldType(292278993);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 292278993");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology2.getZone();
        org.joda.time.Chronology chronology4 = julianChronology0.withZone(dateTimeZone3);
        org.joda.time.DurationField durationField5 = julianChronology0.minutes();
        java.lang.String str6 = julianChronology0.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "JulianChronology[UTC]" + "'", str6.equals("JulianChronology[UTC]"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology4 = julianChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        int int8 = delegatedDateTimeField6.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        java.util.Locale locale11 = null;
        java.lang.String str12 = skipDateTimeField9.getAsShortText(86399999, locale11);
        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) skipDateTimeField9, 0, (-7700), 0);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "86399999" + "'", str12.equals("86399999"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.lang.Appendable appendable1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology5 = iSOChronology3.withZone(dateTimeZone4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant6, (org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property10 = dateTime8.year();
        org.joda.time.DateTime dateTime12 = dateTime8.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property13 = dateTime12.yearOfEra();
        java.lang.Object obj14 = null;
        boolean boolean15 = property13.equals(obj14);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property13.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "UTC");
        boolean boolean19 = iSOChronology3.equals((java.lang.Object) illegalFieldValueException18);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (short) 1, (org.joda.time.Chronology) iSOChronology3);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        java.lang.String str2 = julianChronology0.toString();
        org.joda.time.Chronology chronology3 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.millisOfSecond();
        int int5 = julianChronology0.getMinimumDaysInFirstWeek();
        java.lang.Object obj6 = null;
        boolean boolean7 = julianChronology0.equals(obj6);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[UTC]" + "'", str2.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, (org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.year();
        org.joda.time.DateTime dateTime7 = dateTime3.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        java.lang.Object obj9 = null;
        boolean boolean10 = property8.equals(obj9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property8.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField13 = buddhistChronology12.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField14 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType11, durationField13);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField15 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField14);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(166, 2097, 166);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.dayOfWeek();
        org.joda.time.DateTime dateTime6 = property4.addToCopy((long) (short) -1);
        org.joda.time.DateTime dateTime8 = property4.addToCopy(0);
        try {
            org.joda.time.DateTime dateTime10 = dateTime8.withMonthOfYear(57600000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.weekyearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale2 = null;
        java.lang.String str5 = defaultNameProvider0.getName(locale2, "9769", "69");
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime dateTime7 = dateTime2.minusHours(816);
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withHourOfDay((-7800));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -7800 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendWeekOfWeekyear((int) (byte) 10);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(chronology4);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, (org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime.Property property7 = dateTime5.year();
        org.joda.time.DateTime dateTime9 = dateTime5.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        java.lang.Object obj11 = null;
        boolean boolean12 = property10.equals(obj11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, "UTC");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType13, 4, 10);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(chronology20);
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant19, (org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime.Property property23 = dateTime21.year();
        org.joda.time.DateTime dateTime25 = dateTime21.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property26 = dateTime25.yearOfEra();
        java.lang.Object obj27 = null;
        boolean boolean28 = property26.equals(obj27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property26.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, "UTC");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder18.appendFixedSignedDecimal(dateTimeFieldType29, 19);
        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology35 = julianChronology34.withUTC();
        org.joda.time.DateTimeField dateTimeField36 = julianChronology34.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36, dateTimeFieldType37);
        org.joda.time.DurationField durationField39 = delegatedDateTimeField38.getRangeDurationField();
        org.joda.time.DurationField durationField40 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long43 = durationField40.subtract(0L, 292278993);
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField44 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType29, durationField39, durationField40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The effective range must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(julianChronology34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-292278993L) + "'", long43 == (-292278993L));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        int int5 = delegatedDateTimeField3.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, 2019);
        long long9 = offsetDateTimeField7.roundHalfFloor(0L);
        long long12 = offsetDateTimeField7.add((long) '#', (int) (short) 1);
        long long14 = offsetDateTimeField7.roundCeiling((-100L));
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.MonthDay monthDay20 = monthDay17.withPeriodAdded(readablePeriod18, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay(dateTimeZone22);
        boolean boolean24 = monthDay20.isBefore((org.joda.time.ReadablePartial) monthDay23);
        int int25 = offsetDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) monthDay23);
        try {
            long long28 = offsetDateTimeField7.set((long) 1236, "DateTimeField[yearOfEra]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"DateTimeField[yearOfEra]\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 60035L + "'", long12 == 60035L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2078 + "'", int25 == 2078);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, (org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.year();
        org.joda.time.DateTime dateTime7 = dateTime3.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        java.lang.Object obj9 = null;
        boolean boolean10 = property8.equals(obj9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, "UTC");
        boolean boolean14 = gJChronology0.equals((java.lang.Object) illegalFieldValueException13);
        try {
            long long19 = gJChronology0.getDateTimeMillis(2, 0, 816, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.lang.Object obj7 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(dateTimeZone9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone9);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(chronology12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(chronology15);
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant14, (org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime.Property property18 = dateTime16.dayOfWeek();
        int int19 = dateTime13.compareTo((org.joda.time.ReadableInstant) dateTime16);
        boolean boolean20 = dateTime13.isEqualNow();
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(obj7, (org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTimeField dateTimeField23 = gJChronology21.clockhourOfDay();
        try {
            org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((int) (short) 1, 2020, (int) (byte) 1, 960, (int) (short) 1, (-10), 48983, (org.joda.time.Chronology) gJChronology21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        long long16 = unsupportedDateTimeField13.add((long) (-10), 36);
        boolean boolean17 = unsupportedDateTimeField13.isSupported();
        java.lang.String str18 = unsupportedDateTimeField13.getName();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay(dateTimeZone20);
        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone20);
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(chronology23);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(chronology26);
        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant25, (org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.DateTime.Property property29 = dateTime27.dayOfWeek();
        int int30 = dateTime24.compareTo((org.joda.time.ReadableInstant) dateTime27);
        boolean boolean31 = dateTime24.isEqualNow();
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20, (org.joda.time.ReadableInstant) dateTime24);
        int int33 = gJChronology32.getMinimumDaysInFirstWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter34.withPivotYear((int) (short) 10);
        boolean boolean37 = gJChronology32.equals((java.lang.Object) dateTimeFormatter34);
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.chrono.JulianChronology julianChronology40 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology41 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone42 = julianChronology41.getZone();
        boolean boolean44 = dateTimeZone42.isStandardOffset(100L);
        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(dateTimeZone42);
        org.joda.time.Chronology chronology46 = julianChronology40.withZone(dateTimeZone42);
        org.joda.time.MonthDay monthDay48 = new org.joda.time.MonthDay(0L);
        int[] intArray49 = monthDay48.getValues();
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = null;
        boolean boolean51 = monthDay48.isSupported(dateTimeFieldType50);
        long long53 = julianChronology40.set((org.joda.time.ReadablePartial) monthDay48, (long) (short) -1);
        boolean boolean54 = monthDay39.isEqual((org.joda.time.ReadablePartial) monthDay48);
        boolean boolean55 = gJChronology32.equals((java.lang.Object) monthDay48);
        java.util.Locale locale56 = null;
        try {
            java.lang.String str57 = unsupportedDateTimeField13.getAsShortText((org.joda.time.ReadablePartial) monthDay48, locale56);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35990L + "'", long16 == 35990L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "yearOfEra" + "'", str18.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(buddhistChronology22);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(julianChronology40);
        org.junit.Assert.assertNotNull(julianChronology41);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(chronology46);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1123199999L + "'", long53 == 1123199999L);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, (int) (byte) 100);
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipUndoDateTimeField4.getAsShortText(0L, locale6);
        long long9 = skipUndoDateTimeField4.roundHalfFloor((long) (-1));
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (-1), (java.lang.Object) 1560630995876L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "69" + "'", str7.equals("69"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1123200000L + "'", long9 == 1123200000L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant1, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, (org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property8 = dateTime6.year();
        org.joda.time.DateTime dateTime10 = dateTime6.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property11 = dateTime10.yearOfEra();
        java.lang.Object obj12 = null;
        boolean boolean13 = property11.equals(obj12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, "UTC");
        int int17 = dateTime2.get(dateTimeFieldType14);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField18 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1970 + "'", int17 == 1970);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = unsupportedDateTimeField13.getType();
        java.util.Locale locale16 = null;
        try {
            java.lang.String str17 = unsupportedDateTimeField13.getAsText((long) '4', locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology7.getZone();
        boolean boolean10 = dateTimeZone8.isStandardOffset(100L);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone8);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((-10), 0, (int) (byte) -1, 1970, (-349199990), 86399999, (int) (short) 100, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology7.getZone();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(86399999, 9, 0, (-2096), 166, (int) (byte) -1, 0, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2096 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, (int) (byte) 100);
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipUndoDateTimeField4.getAsShortText(0L, locale6);
        int int9 = skipUndoDateTimeField4.get((long) (short) 10);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "69" + "'", str7.equals("69"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 70 + "'", int9 == 70);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology4 = julianChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        int int8 = delegatedDateTimeField6.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        int int10 = skipDateTimeField9.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay16 = monthDay13.withPeriodAdded(readablePeriod14, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay(dateTimeZone18);
        boolean boolean20 = monthDay16.isBefore((org.joda.time.ReadablePartial) monthDay19);
        int int21 = skipDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) monthDay16);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        try {
            org.joda.time.MonthDay.Property property23 = monthDay16.property(dateTimeFieldType22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        int int5 = delegatedDateTimeField3.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, 2019);
        long long9 = offsetDateTimeField7.roundHalfFloor(0L);
        long long12 = offsetDateTimeField7.add((long) '#', (int) (short) 1);
        long long14 = offsetDateTimeField7.roundCeiling((-100L));
        org.joda.time.DurationField durationField15 = offsetDateTimeField7.getDurationField();
        org.joda.time.DurationField durationField16 = offsetDateTimeField7.getDurationField();
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField7.getAsShortText(1236, locale18);
        java.lang.String str20 = offsetDateTimeField7.getName();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 60035L + "'", long12 == 60035L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1236" + "'", str19.equals("1236"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "minuteOfHour" + "'", str20.equals("minuteOfHour"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = unsupportedDateTimeField13.getType();
        try {
            java.lang.String str16 = unsupportedDateTimeField13.getAsText((long) 2020);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        boolean boolean3 = dateTimeZone1.isStandardOffset(100L);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        boolean boolean12 = dateTime4.isAfter((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        boolean boolean14 = dateTime4.isSupported(dateTimeFieldType13);
        org.joda.time.DateTime dateTime16 = dateTime4.minusSeconds(86399999);
        int int17 = dateTime4.getCenturyOfEra();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 19 + "'", int17 == 19);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        int int10 = property7.getMinimumValue();
        org.joda.time.Interval interval11 = property7.toInterval();
        org.joda.time.ReadableInterval readableInterval12 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval11);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(interval11);
        org.junit.Assert.assertNotNull(readableInterval12);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(chronology3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, (org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime.Property property6 = dateTime4.dayOfWeek();
        int int7 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime9 = dateTime4.plusMinutes((int) (short) 10);
        org.joda.time.DateTime dateTime11 = dateTime4.plus(74160000L);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = julianChronology1.withUTC();
        java.lang.String str3 = julianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withZone(dateTimeZone4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant6, (org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property10 = dateTime8.dayOfWeek();
        int int11 = dateTime8.getMinuteOfDay();
        org.joda.time.DateTime dateTime13 = dateTime8.minusDays(2000);
        org.joda.time.LocalDateTime localDateTime14 = dateTime13.toLocalDateTime();
        boolean boolean15 = dateTimeZone4.isLocalDateTimeGap(localDateTime14);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 960 + "'", int11 == 960);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getRangeDurationField();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(0L);
        org.joda.time.MonthDay monthDay18 = monthDay16.plusMonths((int) '4');
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology21 = julianChronology20.withUTC();
        org.joda.time.DateTimeField dateTimeField22 = julianChronology20.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22, dateTimeFieldType23);
        java.lang.String str26 = delegatedDateTimeField24.getAsShortText((long) (-10));
        long long28 = delegatedDateTimeField24.remainder((long) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = delegatedDateTimeField24.getType();
        org.joda.time.ReadablePartial readablePartial30 = null;
        java.util.Locale locale32 = null;
        java.lang.String str33 = delegatedDateTimeField24.getAsText(readablePartial30, (int) (short) 100, locale32);
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology37 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone36);
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology37);
        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.DateTime dateTime41 = dateTime38.withFields((org.joda.time.ReadablePartial) monthDay40);
        int[] intArray48 = new int[] { (short) 100, (-2078), 36, 4, '#', (byte) 100 };
        int int49 = delegatedDateTimeField24.getMinimumValue((org.joda.time.ReadablePartial) monthDay40, intArray48);
        try {
            int[] intArray51 = unsupportedDateTimeField13.set((org.joda.time.ReadablePartial) monthDay16, 2, intArray48, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "59" + "'", str26.equals("59"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1L + "'", long28 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(buddhistChronology37);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology4);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.DateTime dateTime8 = dateTime5.withFields((org.joda.time.ReadablePartial) monthDay7);
        org.joda.time.MonthDay monthDay10 = monthDay7.minusMonths((-10));
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology12 = julianChronology11.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = julianChronology11.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField13, dateTimeFieldType14);
        java.lang.String str17 = delegatedDateTimeField15.getAsShortText((long) (-10));
        long long19 = delegatedDateTimeField15.remainder((long) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = delegatedDateTimeField15.getType();
        int int21 = monthDay10.indexOf(dateTimeFieldType20);
        try {
            org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField0, dateTimeFieldType20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "59" + "'", str17.equals("59"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = iSOChronology0.getZone();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone4);
        org.joda.time.Chronology chronology6 = julianChronology2.withZone(dateTimeZone4);
        long long9 = dateTimeZone4.adjustOffset(10L, false);
        org.joda.time.Chronology chronology10 = iSOChronology0.withZone(dateTimeZone4);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("JulianChronology[UTC]", "Sat", 36, 816);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.plus(readableDuration7);
        org.joda.time.DateTime dateTime10 = dateTime8.withSecondOfMinute((int) (short) 10);
        boolean boolean11 = fixedDateTimeZone4.equals((java.lang.Object) (short) 10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(chronology12);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readableDuration14);
        boolean boolean16 = fixedDateTimeZone4.equals((java.lang.Object) dateTime13);
        long long18 = fixedDateTimeZone4.previousTransition((long) (-2078));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-2078L) + "'", long18 == (-2078L));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(816);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildPrinter();
        boolean boolean4 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendClockhourOfHalfday(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder2.appendMillisOfDay(166);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder2.appendFractionOfMinute(86399999, (int) (byte) 100);
        boolean boolean14 = dateTimeFormatterBuilder2.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology3 = iSOChronology1.withZone(dateTimeZone2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, (org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property8 = dateTime6.year();
        org.joda.time.DateTime dateTime10 = dateTime6.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property11 = dateTime10.yearOfEra();
        java.lang.Object obj12 = null;
        boolean boolean13 = property11.equals(obj12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, "UTC");
        boolean boolean17 = iSOChronology1.equals((java.lang.Object) illegalFieldValueException16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 1, (org.joda.time.Chronology) iSOChronology1);
        java.lang.String str19 = iSOChronology1.toString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str19.equals("ISOChronology[America/Los_Angeles]"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        int int5 = delegatedDateTimeField3.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, 2019);
        long long9 = offsetDateTimeField7.roundHalfFloor(0L);
        long long12 = offsetDateTimeField7.add((long) '#', (int) (short) 1);
        long long14 = offsetDateTimeField7.roundCeiling((-100L));
        org.joda.time.DurationField durationField15 = offsetDateTimeField7.getDurationField();
        boolean boolean16 = offsetDateTimeField7.isSupported();
        long long18 = offsetDateTimeField7.roundHalfFloor((long) 10);
        long long21 = offsetDateTimeField7.getDifferenceAsLong(0L, (-100L));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 60035L + "'", long12 == 60035L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property13 = dateTime7.millisOfDay();
        org.joda.time.DurationField durationField14 = property13.getLeapDurationField();
        org.joda.time.DateTime dateTime15 = property13.roundCeilingCopy();
        org.joda.time.DateTime dateTime17 = property13.setCopy("1236");
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        boolean boolean3 = dateTimeZone1.isStandardOffset(100L);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.TimeOfDay timeOfDay5 = dateTime4.toTimeOfDay();
        org.joda.time.DateTime.Property property6 = dateTime4.centuryOfEra();
        org.joda.time.DateTime.Property property7 = dateTime4.dayOfWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(timeOfDay5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime13 = dateTime7.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.dayOfWeek();
        int int5 = dateTime2.getMinuteOfDay();
        java.util.GregorianCalendar gregorianCalendar6 = dateTime2.toGregorianCalendar();
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar6);
        try {
            java.lang.String str9 = monthDay7.toString("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 960 + "'", int5 == 960);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertNotNull(monthDay7);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime6 = property4.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekyear(48983);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology9.getZone();
        boolean boolean12 = dateTimeZone10.isStandardOffset(100L);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.TimeOfDay timeOfDay14 = dateTime13.toTimeOfDay();
        org.joda.time.DateTime.Property property15 = dateTime13.centuryOfEra();
        boolean boolean16 = dateTime6.isAfter((org.joda.time.ReadableInstant) dateTime13);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(timeOfDay14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.dayOfWeek();
        org.joda.time.DurationField durationField5 = property4.getLeapDurationField();
        java.util.Locale locale6 = null;
        int int7 = property4.getMaximumShortTextLength(locale6);
        java.lang.String str8 = property4.getAsText();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Tuesday" + "'", str8.equals("Tuesday"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        long long16 = unsupportedDateTimeField13.add((long) (-10), 36);
        boolean boolean17 = unsupportedDateTimeField13.isSupported();
        java.lang.String str18 = unsupportedDateTimeField13.getName();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology20 = julianChronology19.withUTC();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21, dateTimeFieldType22);
        org.joda.time.DurationField durationField24 = delegatedDateTimeField23.getRangeDurationField();
        int int26 = delegatedDateTimeField23.get((long) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay29 = new org.joda.time.MonthDay(dateTimeZone28);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.MonthDay monthDay32 = monthDay29.withPeriodAdded(readablePeriod30, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay35 = new org.joda.time.MonthDay(dateTimeZone34);
        boolean boolean36 = monthDay32.isBefore((org.joda.time.ReadablePartial) monthDay35);
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay(dateTimeZone38);
        org.joda.time.ReadablePeriod readablePeriod40 = null;
        org.joda.time.MonthDay monthDay42 = monthDay39.withPeriodAdded(readablePeriod40, (int) (byte) 100);
        boolean boolean43 = monthDay35.isBefore((org.joda.time.ReadablePartial) monthDay39);
        org.joda.time.ReadablePeriod readablePeriod44 = null;
        org.joda.time.MonthDay monthDay45 = monthDay35.minus(readablePeriod44);
        int int46 = delegatedDateTimeField23.getMaximumValue((org.joda.time.ReadablePartial) monthDay45);
        int[] intArray52 = new int[] { 960, 3, 6, 960 };
        try {
            int[] intArray54 = unsupportedDateTimeField13.addWrapField((org.joda.time.ReadablePartial) monthDay45, 292278993, intArray52, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35990L + "'", long16 == 35990L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "yearOfEra" + "'", str18.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(monthDay42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(monthDay45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 59 + "'", int46 == 59);
        org.junit.Assert.assertNotNull(intArray52);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendWeekOfWeekyear((int) (byte) 10);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(chronology4);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, (org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime.Property property7 = dateTime5.year();
        org.joda.time.DateTime dateTime9 = dateTime5.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        java.lang.Object obj11 = null;
        boolean boolean12 = property10.equals(obj11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, "UTC");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType13, 4, 10);
        boolean boolean19 = dateTimeFormatterBuilder18.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(816);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildPrinter();
        boolean boolean4 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendClockhourOfHalfday(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder2.appendMillisOfDay(166);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder2.appendSecondOfDay((-26010516));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendWeekOfWeekyear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("59");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        java.lang.String str6 = delegatedDateTimeField4.getAsShortText((long) (-10));
        long long8 = delegatedDateTimeField4.remainder((long) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField4.getType();
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField4.getAsText(readablePartial10, (int) (short) 100, locale12);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology17);
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.DateTime dateTime21 = dateTime18.withFields((org.joda.time.ReadablePartial) monthDay20);
        int[] intArray28 = new int[] { (short) 100, (-2078), 36, 4, '#', (byte) 100 };
        int int29 = delegatedDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay20, intArray28);
        int int30 = monthDay20.getMonthOfYear();
        org.joda.time.chrono.CopticChronology copticChronology32 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        long long36 = copticChronology32.add(readablePeriod33, (long) (byte) -1, 1);
        org.joda.time.MonthDay monthDay37 = new org.joda.time.MonthDay(0L, (org.joda.time.Chronology) copticChronology32);
        org.joda.time.DateTimeField dateTimeField38 = copticChronology32.clockhourOfHalfday();
        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay(0L);
        org.joda.time.MonthDay monthDay42 = monthDay40.plusMonths((int) '4');
        long long44 = copticChronology32.set((org.joda.time.ReadablePartial) monthDay42, (long) 36);
        try {
            org.joda.time.MonthDay monthDay45 = new org.joda.time.MonthDay((java.lang.Object) int30, (org.joda.time.Chronology) copticChronology32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "59" + "'", str6.equals("59"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 12 + "'", int30 == 12);
        org.junit.Assert.assertNotNull(copticChronology32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-1L) + "'", long36 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(monthDay42);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 604800036L + "'", long44 == 604800036L);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology4 = julianChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        int int8 = delegatedDateTimeField6.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, (org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime.Property property14 = dateTime12.year();
        org.joda.time.DateTime dateTime16 = dateTime12.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property17 = dateTime16.yearOfEra();
        java.lang.Object obj18 = null;
        boolean boolean19 = property17.equals(obj18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property17.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, "UTC");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField23 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField6, dateTimeFieldType20);
        java.util.Locale locale25 = null;
        java.lang.String str26 = delegatedDateTimeField6.getAsText(816, locale25);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "816" + "'", str26.equals("816"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(1175, 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter2.getParser();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatter2.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter5.withOffsetParsed();
        try {
            org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.parse("UTC", dateTimeFormatter6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UTC\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getRangeDurationField();
        try {
            long long16 = unsupportedDateTimeField13.roundHalfEven(1123200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNull(durationField14);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property13 = dateTime7.millisOfDay();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime7.plus(readablePeriod14);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(dateTimeZone17);
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone17);
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((java.lang.Object) dateTime7, (org.joda.time.Chronology) buddhistChronology19);
        org.joda.time.MonthDay monthDay22 = monthDay20.plusDays((int) (short) 100);
        try {
            org.joda.time.MonthDay monthDay24 = monthDay20.withMonthOfYear(960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(monthDay22);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = copticChronology0.withUTC();
        int int2 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology0);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = julianChronology1.withUTC();
        java.lang.String str3 = julianChronology1.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withZone(dateTimeZone4);
        java.io.Writer writer6 = null;
        org.joda.time.ReadablePartial readablePartial7 = null;
        try {
            dateTimeFormatter5.printTo(writer6, readablePartial7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology4 = julianChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        int int8 = delegatedDateTimeField6.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, (org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime.Property property14 = dateTime12.year();
        org.joda.time.DateTime dateTime16 = dateTime12.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property17 = dateTime16.yearOfEra();
        java.lang.Object obj18 = null;
        boolean boolean19 = property17.equals(obj18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property17.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, "UTC");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField23 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField6, dateTimeFieldType20);
        long long26 = zeroIsMaxDateTimeField23.add(0L, 1236);
        int int29 = zeroIsMaxDateTimeField23.getDifference(125820000L, 100L);
        java.lang.String str30 = zeroIsMaxDateTimeField23.toString();
        org.joda.time.DurationField durationField31 = zeroIsMaxDateTimeField23.getLeapDurationField();
        java.util.Locale locale33 = null;
        java.lang.String str34 = zeroIsMaxDateTimeField23.getAsShortText(10L, locale33);
        long long36 = zeroIsMaxDateTimeField23.roundHalfCeiling((long) 2020);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 74160000L + "'", long26 == 74160000L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2096 + "'", int29 == 2096);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "DateTimeField[yearOfEra]" + "'", str30.equals("DateTimeField[yearOfEra]"));
        org.junit.Assert.assertNull(durationField31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "60" + "'", str34.equals("60"));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getRangeDurationField();
        org.joda.time.DateTimeField dateTimeField6 = delegatedDateTimeField4.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay(dateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.MonthDay monthDay12 = monthDay9.withPeriodAdded(readablePeriod10, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(dateTimeZone14);
        boolean boolean16 = monthDay12.isBefore((org.joda.time.ReadablePartial) monthDay15);
        int[] intArray22 = new int[] { 960, (byte) 0, 57610, (-7800) };
        try {
            int[] intArray24 = delegatedDateTimeField4.addWrapPartial((org.joda.time.ReadablePartial) monthDay12, 59, intArray22, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 59");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "36");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        long long16 = unsupportedDateTimeField13.add((long) (-10), 36);
        boolean boolean17 = unsupportedDateTimeField13.isSupported();
        java.lang.String str18 = unsupportedDateTimeField13.getName();
        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology20 = julianChronology19.withUTC();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21, dateTimeFieldType22);
        java.lang.String str25 = delegatedDateTimeField23.getAsShortText((long) (-10));
        long long27 = delegatedDateTimeField23.remainder((long) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField23.getType();
        org.joda.time.ReadablePartial readablePartial29 = null;
        java.util.Locale locale31 = null;
        java.lang.String str32 = delegatedDateTimeField23.getAsText(readablePartial29, (int) (short) 100, locale31);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone35);
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology36);
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.DateTime dateTime40 = dateTime37.withFields((org.joda.time.ReadablePartial) monthDay39);
        int[] intArray47 = new int[] { (short) 100, (-2078), 36, 4, '#', (byte) 100 };
        int int48 = delegatedDateTimeField23.getMinimumValue((org.joda.time.ReadablePartial) monthDay39, intArray47);
        org.joda.time.chrono.JulianChronology julianChronology50 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology51 = julianChronology50.withUTC();
        org.joda.time.DateTimeField dateTimeField52 = julianChronology50.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology53 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology54 = julianChronology53.withUTC();
        org.joda.time.DateTimeField dateTimeField55 = julianChronology53.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField56 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField55);
        int int58 = delegatedDateTimeField56.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField59 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology50, (org.joda.time.DateTimeField) delegatedDateTimeField56);
        int int60 = skipDateTimeField59.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay63 = new org.joda.time.MonthDay(dateTimeZone62);
        org.joda.time.ReadablePeriod readablePeriod64 = null;
        org.joda.time.MonthDay monthDay66 = monthDay63.withPeriodAdded(readablePeriod64, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay69 = new org.joda.time.MonthDay(dateTimeZone68);
        boolean boolean70 = monthDay66.isBefore((org.joda.time.ReadablePartial) monthDay69);
        int int71 = skipDateTimeField59.getMinimumValue((org.joda.time.ReadablePartial) monthDay66);
        int[] intArray72 = monthDay66.getValues();
        try {
            int[] intArray74 = unsupportedDateTimeField13.set((org.joda.time.ReadablePartial) monthDay39, (int) '4', intArray72, 816);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35990L + "'", long16 == 35990L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "yearOfEra" + "'", str18.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(julianChronology19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "59" + "'", str25.equals("59"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(buddhistChronology36);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(julianChronology50);
        org.junit.Assert.assertNotNull(chronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(julianChronology53);
        org.junit.Assert.assertNotNull(chronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone62);
        org.junit.Assert.assertNotNull(monthDay66);
        org.junit.Assert.assertNotNull(dateTimeZone68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertNotNull(intArray72);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        long long16 = unsupportedDateTimeField13.add((long) (-10), 36);
        java.util.Locale locale19 = null;
        try {
            long long20 = unsupportedDateTimeField13.set((-32L), "", locale19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35990L + "'", long16 == 35990L);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("59", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style character: 5");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = unsupportedDateTimeField13.getType();
        try {
            long long16 = unsupportedDateTimeField13.remainder(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        int int5 = delegatedDateTimeField3.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, 2019);
        long long9 = offsetDateTimeField7.roundHalfFloor(0L);
        long long12 = offsetDateTimeField7.add((long) '#', (int) (short) 1);
        long long14 = offsetDateTimeField7.roundCeiling((-100L));
        long long17 = offsetDateTimeField7.add(0L, 2097);
        java.util.Locale locale18 = null;
        int int19 = offsetDateTimeField7.getMaximumTextLength(locale18);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 60035L + "'", long12 == 60035L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 125820000L + "'", long17 == 125820000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        try {
            org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (long) (-349199990), (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getRangeDurationField();
        org.joda.time.DateTimeField dateTimeField6 = delegatedDateTimeField4.getWrappedField();
        int int8 = delegatedDateTimeField4.getMaximumValue((long) 36);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 59 + "'", int8 == 59);
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
//        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getShortName(0L, locale5);
//        java.util.TimeZone timeZone7 = dateTimeZone3.toTimeZone();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//        org.junit.Assert.assertNotNull(timeZone7);
//    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = iSOChronology0.getZone();
        boolean boolean3 = dateTimeZone1.isStandardOffset((long) (byte) 10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        int int5 = delegatedDateTimeField3.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, 2019);
        long long9 = offsetDateTimeField7.roundHalfFloor(0L);
        long long12 = offsetDateTimeField7.add((long) '#', (int) (short) 1);
        long long14 = offsetDateTimeField7.roundCeiling((-100L));
        long long16 = offsetDateTimeField7.roundCeiling(0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField7.getType();
        long long20 = offsetDateTimeField7.add(0L, (int) '4');
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 60035L + "'", long12 == 60035L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 3120000L + "'", long20 == 3120000L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        boolean boolean3 = dateTimeZone1.isStandardOffset(100L);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.millisOfDay();
        try {
            long long14 = gregorianChronology5.getDateTimeMillis(2019, 70, 19, 10, 1236, 19, 36);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1236 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property13 = dateTime7.millisOfDay();
        org.joda.time.DateTime dateTime15 = dateTime7.withYearOfCentury((int) (byte) 0);
        org.joda.time.DateTime dateTime18 = dateTime7.withDurationAdded((long) (byte) 100, 36);
        org.joda.time.DateTime dateTime20 = dateTime18.withSecondOfMinute(19);
        try {
            org.joda.time.DateTime dateTime22 = dateTime18.withDayOfYear((-2096));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2096 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("");
        org.junit.Assert.assertNotNull(monthDay1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        boolean boolean3 = dateTimeZone1.isStandardOffset(100L);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime6 = dateTime4.withChronology((org.joda.time.Chronology) julianChronology5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((java.lang.Object) dateTime6);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        int int13 = dateTime7.getDayOfWeek();
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology14.getZone();
        boolean boolean17 = dateTimeZone15.isStandardOffset(100L);
        org.joda.time.DateTime dateTime18 = dateTime7.toDateTime(dateTimeZone15);
        int int19 = dateTime18.getMinuteOfDay();
        org.joda.time.DateTime.Property property20 = dateTime18.millisOfSecond();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(property20);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear((java.lang.Integer) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withPivotYear(1);
        boolean boolean10 = buddhistChronology3.equals((java.lang.Object) 1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfYear();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = julianChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology2.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology6 = julianChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        int int10 = delegatedDateTimeField8.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField8);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = julianChronology15.getZone();
        boolean boolean18 = dateTimeZone16.isStandardOffset(100L);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.Chronology chronology20 = julianChronology14.withZone(dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(0L);
        int[] intArray23 = monthDay22.getValues();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        boolean boolean25 = monthDay22.isSupported(dateTimeFieldType24);
        long long27 = julianChronology14.set((org.joda.time.ReadablePartial) monthDay22, (long) (short) -1);
        boolean boolean28 = monthDay13.isEqual((org.joda.time.ReadablePartial) monthDay22);
        java.util.Locale locale30 = null;
        java.lang.String str31 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay22, (-1), locale30);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipDateTimeField11, (int) '#');
        long long35 = skipDateTimeField11.roundCeiling((long) 48983);
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay38 = new org.joda.time.MonthDay(dateTimeZone37);
        org.joda.time.ReadablePeriod readablePeriod39 = null;
        org.joda.time.MonthDay monthDay41 = monthDay38.withPeriodAdded(readablePeriod39, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay44 = new org.joda.time.MonthDay(dateTimeZone43);
        boolean boolean45 = monthDay41.isBefore((org.joda.time.ReadablePartial) monthDay44);
        org.joda.time.MonthDay monthDay47 = new org.joda.time.MonthDay(0L);
        int[] intArray48 = monthDay47.getValues();
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = null;
        boolean boolean50 = monthDay47.isSupported(dateTimeFieldType49);
        boolean boolean51 = monthDay41.isAfter((org.joda.time.ReadablePartial) monthDay47);
        java.util.Locale locale52 = null;
        try {
            java.lang.String str53 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay41, locale52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfHour' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1123199999L + "'", long27 == 1123199999L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "-1" + "'", str31.equals("-1"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 60000L + "'", long35 == 60000L);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = unsupportedDateTimeField13.getType();
        int int17 = unsupportedDateTimeField13.getDifference((long) 100, (long) 13);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) unsupportedDateTimeField13, 70);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must be supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withPivotYear((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter1.withZone(dateTimeZone7);
        org.joda.time.Instant instant10 = org.joda.time.Instant.parse("19", dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(instant10);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        long long16 = unsupportedDateTimeField13.add(1123199999L, (long) '#');
        long long19 = unsupportedDateTimeField13.add(1123200000L, 0L);
        try {
            int int21 = unsupportedDateTimeField13.getLeapAmount(74160000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1123234999L + "'", long16 == 1123234999L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1123200000L + "'", long19 == 1123200000L);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property13 = dateTime7.millisOfDay();
        org.joda.time.DateTime dateTime15 = dateTime7.plusMillis(0);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime7.getZone();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(chronology3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, (org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime.Property property6 = dateTime4.dayOfWeek();
        int int7 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime4);
        boolean boolean8 = dateTime1.isEqualNow();
        org.joda.time.DateTime.Property property9 = dateTime1.dayOfMonth();
        int int10 = property9.getMinimumValue();
        org.joda.time.DateTime dateTime11 = property9.roundFloorCopy();
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getRangeDurationField();
        java.util.Locale locale15 = null;
        try {
            int int16 = unsupportedDateTimeField13.getMaximumShortTextLength(locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNull(durationField14);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(816);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildPrinter();
        boolean boolean4 = dateTimeFormatterBuilder2.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology4 = julianChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        int int8 = delegatedDateTimeField6.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, (org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime.Property property14 = dateTime12.year();
        org.joda.time.DateTime dateTime16 = dateTime12.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property17 = dateTime16.yearOfEra();
        java.lang.Object obj18 = null;
        boolean boolean19 = property17.equals(obj18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property17.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, "UTC");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField23 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField6, dateTimeFieldType20);
        long long26 = zeroIsMaxDateTimeField23.add(0L, 1236);
        int int29 = zeroIsMaxDateTimeField23.getDifference(125820000L, 100L);
        org.joda.time.ReadablePartial readablePartial30 = null;
        org.joda.time.chrono.JulianChronology julianChronology32 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology33 = julianChronology32.withUTC();
        org.joda.time.DateTimeField dateTimeField34 = julianChronology32.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField34, dateTimeFieldType35);
        java.lang.String str38 = delegatedDateTimeField36.getAsShortText((long) (-10));
        long long40 = delegatedDateTimeField36.remainder((long) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = delegatedDateTimeField36.getType();
        org.joda.time.ReadablePartial readablePartial42 = null;
        java.util.Locale locale44 = null;
        java.lang.String str45 = delegatedDateTimeField36.getAsText(readablePartial42, (int) (short) 100, locale44);
        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology49 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone48);
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology49);
        org.joda.time.MonthDay monthDay52 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.DateTime dateTime53 = dateTime50.withFields((org.joda.time.ReadablePartial) monthDay52);
        int[] intArray60 = new int[] { (short) 100, (-2078), 36, 4, '#', (byte) 100 };
        int int61 = delegatedDateTimeField36.getMinimumValue((org.joda.time.ReadablePartial) monthDay52, intArray60);
        try {
            int[] intArray63 = zeroIsMaxDateTimeField23.addWrapPartial(readablePartial30, (int) '#', intArray60, 86399999);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 74160000L + "'", long26 == 74160000L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2096 + "'", int29 == 2096);
        org.junit.Assert.assertNotNull(julianChronology32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "59" + "'", str38.equals("59"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1L + "'", long40 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "100" + "'", str45.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(buddhistChronology49);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        long long16 = unsupportedDateTimeField13.add((long) (-10), 36);
        boolean boolean17 = unsupportedDateTimeField13.isSupported();
        java.lang.String str18 = unsupportedDateTimeField13.getName();
        try {
            long long20 = unsupportedDateTimeField13.roundHalfCeiling((long) 36);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35990L + "'", long16 == 35990L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "yearOfEra" + "'", str18.equals("yearOfEra"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology4 = julianChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        int int8 = delegatedDateTimeField6.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, (org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime.Property property14 = dateTime12.year();
        org.joda.time.DateTime dateTime16 = dateTime12.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property17 = dateTime16.yearOfEra();
        java.lang.Object obj18 = null;
        boolean boolean19 = property17.equals(obj18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property17.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, "UTC");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField23 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField6, dateTimeFieldType20);
        long long26 = zeroIsMaxDateTimeField23.add(0L, 1236);
        int int29 = zeroIsMaxDateTimeField23.getDifference((long) 2078, 125820000L);
        long long32 = zeroIsMaxDateTimeField23.add((long) 166, (-7800));
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser35 = dateTimeFormatter34.getParser();
        boolean boolean36 = iSOChronology33.equals((java.lang.Object) dateTimeFormatter34);
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology33.yearOfEra();
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.Chronology chronology39 = null;
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(chronology39);
        org.joda.time.Chronology chronology41 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant38, (org.joda.time.ReadableInstant) dateTime40);
        org.joda.time.DateTime.Property property42 = dateTime40.year();
        org.joda.time.DateTime dateTime44 = dateTime40.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property45 = dateTime44.yearOfEra();
        java.lang.Object obj46 = null;
        boolean boolean47 = property45.equals(obj46);
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = property45.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology49 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField50 = buddhistChronology49.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField51 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType48, durationField50);
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = unsupportedDateTimeField51.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField53 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField37, dateTimeFieldType52);
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField54 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField23, dateTimeFieldType52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 74160000L + "'", long26 == 74160000L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-2096) + "'", int29 == (-2096));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-467999834L) + "'", long32 == (-467999834L));
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTimeParser35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertNotNull(buddhistChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        int int5 = delegatedDateTimeField3.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, 2019);
        long long9 = offsetDateTimeField7.roundHalfFloor(0L);
        long long12 = offsetDateTimeField7.add((long) '#', (int) (short) 1);
        long long14 = offsetDateTimeField7.roundCeiling((-100L));
        org.joda.time.DurationField durationField15 = offsetDateTimeField7.getDurationField();
        boolean boolean16 = offsetDateTimeField7.isSupported();
        java.util.Locale locale17 = null;
        int int18 = offsetDateTimeField7.getMaximumShortTextLength(locale17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField7.getType();
        java.util.Locale locale21 = null;
        java.lang.String str22 = offsetDateTimeField7.getAsText((long) (-1), locale21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField7.getAsShortText(36, locale24);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(chronology27);
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant26, (org.joda.time.ReadableInstant) dateTime28);
        org.joda.time.DateTime.Property property30 = dateTime28.year();
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(chronology32);
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant31, (org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.DateTime.Property property35 = dateTime33.year();
        org.joda.time.DateTime dateTime37 = dateTime33.withCenturyOfEra((int) 'a');
        long long38 = property30.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.DateTime.Property property39 = dateTime33.millisOfDay();
        org.joda.time.ReadablePeriod readablePeriod40 = null;
        org.joda.time.DateTime dateTime41 = dateTime33.plus(readablePeriod40);
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay44 = new org.joda.time.MonthDay(dateTimeZone43);
        org.joda.time.chrono.BuddhistChronology buddhistChronology45 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone43);
        org.joda.time.MonthDay monthDay46 = new org.joda.time.MonthDay((java.lang.Object) dateTime33, (org.joda.time.Chronology) buddhistChronology45);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray47 = monthDay46.getFieldTypes();
        org.joda.time.chrono.JulianChronology julianChronology49 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology50 = julianChronology49.withUTC();
        org.joda.time.DateTimeField dateTimeField51 = julianChronology49.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField53 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField51, dateTimeFieldType52);
        org.joda.time.DurationField durationField54 = delegatedDateTimeField53.getRangeDurationField();
        int int56 = delegatedDateTimeField53.get((long) (short) 1);
        boolean boolean58 = delegatedDateTimeField53.isLeap((long) (short) 100);
        org.joda.time.MonthDay monthDay60 = new org.joda.time.MonthDay(0L);
        org.joda.time.MonthDay monthDay62 = monthDay60.plusMonths((int) '4');
        org.joda.time.MonthDay monthDay64 = new org.joda.time.MonthDay(0L);
        int[] intArray65 = monthDay64.getValues();
        int int66 = delegatedDateTimeField53.getMaximumValue((org.joda.time.ReadablePartial) monthDay60, intArray65);
        try {
            int[] intArray68 = offsetDateTimeField7.set((org.joda.time.ReadablePartial) monthDay46, (-10), intArray65, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for minuteOfHour must be in the range [2019,2078]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 60035L + "'", long12 == 60035L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2078" + "'", str22.equals("2078"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "36" + "'", str25.equals("36"));
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(buddhistChronology45);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray47);
        org.junit.Assert.assertNotNull(julianChronology49);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(monthDay62);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 59 + "'", int66 == 59);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType10, "UTC");
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType10, (java.lang.Number) (-1.0f), "UTC");
        java.lang.String str16 = illegalFieldValueException15.getIllegalValueAsString();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1.0" + "'", str16.equals("-1.0"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfYear();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = julianChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology2.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology6 = julianChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        int int10 = delegatedDateTimeField8.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField8);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = julianChronology15.getZone();
        boolean boolean18 = dateTimeZone16.isStandardOffset(100L);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.Chronology chronology20 = julianChronology14.withZone(dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(0L);
        int[] intArray23 = monthDay22.getValues();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        boolean boolean25 = monthDay22.isSupported(dateTimeFieldType24);
        long long27 = julianChronology14.set((org.joda.time.ReadablePartial) monthDay22, (long) (short) -1);
        boolean boolean28 = monthDay13.isEqual((org.joda.time.ReadablePartial) monthDay22);
        java.util.Locale locale30 = null;
        java.lang.String str31 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay22, (-1), locale30);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipDateTimeField11, (int) '#');
        int int35 = skipUndoDateTimeField33.get((long) 9);
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipUndoDateTimeField33.getAsShortText(1970, locale37);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1123199999L + "'", long27 == 1123199999L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "-1" + "'", str31.equals("-1"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1970" + "'", str38.equals("1970"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone2);
        org.joda.time.Chronology chronology4 = julianChronology0.withZone(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology4 = julianChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        int int8 = delegatedDateTimeField6.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, (org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime.Property property14 = dateTime12.year();
        org.joda.time.DateTime dateTime16 = dateTime12.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property17 = dateTime16.yearOfEra();
        java.lang.Object obj18 = null;
        boolean boolean19 = property17.equals(obj18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property17.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, "UTC");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField23 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField6, dateTimeFieldType20);
        long long26 = zeroIsMaxDateTimeField23.add(0L, 1236);
        long long28 = zeroIsMaxDateTimeField23.roundFloor((long) 4);
        try {
            long long31 = zeroIsMaxDateTimeField23.set((long) 3600000, (-26010516));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -26010516 for yearOfEra must be in the range [1,60]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 74160000L + "'", long26 == 74160000L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology3);
        java.lang.String str5 = buddhistChronology3.toString();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "BuddhistChronology[-01:00]" + "'", str5.equals("BuddhistChronology[-01:00]"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology3 = iSOChronology1.withZone(dateTimeZone2);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant4, (org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property8 = dateTime6.year();
        org.joda.time.DateTime dateTime10 = dateTime6.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property11 = dateTime10.yearOfEra();
        java.lang.Object obj12 = null;
        boolean boolean13 = property11.equals(obj12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property11.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, "UTC");
        boolean boolean17 = iSOChronology1.equals((java.lang.Object) illegalFieldValueException16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 1, (org.joda.time.Chronology) iSOChronology1);
        try {
            org.joda.time.DateTime dateTime20 = dateTime18.withWeekOfWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("9719", "ISOChronology[America/Los_Angeles]", (int) (byte) 0, (-2078));
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("100", 2, 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2 for 100 must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = unsupportedDateTimeField13.getType();
        int int17 = unsupportedDateTimeField13.getDifference((long) 100, (long) 13);
        try {
            long long19 = unsupportedDateTimeField13.roundCeiling((long) 57600000);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = copticChronology0.withUTC();
        int int2 = copticChronology0.getMinimumDaysInFirstWeek();
        int int3 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(chronology4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant6, (org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property10 = dateTime8.dayOfWeek();
        int int11 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime8);
        boolean boolean12 = dateTime5.isEqualNow();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        try {
            int[] intArray16 = gJChronology13.get(readablePeriod14, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(gJChronology13);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology4 = julianChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        int int8 = delegatedDateTimeField6.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, (org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime.Property property14 = dateTime12.year();
        org.joda.time.DateTime dateTime16 = dateTime12.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property17 = dateTime16.yearOfEra();
        java.lang.Object obj18 = null;
        boolean boolean19 = property17.equals(obj18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property17.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, "UTC");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField23 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField6, dateTimeFieldType20);
        long long26 = zeroIsMaxDateTimeField23.add(0L, 1236);
        long long28 = zeroIsMaxDateTimeField23.roundHalfCeiling((long) (-26010516));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 74160000L + "'", long26 == 74160000L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-26040000L) + "'", long28 == (-26040000L));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.DurationField durationField3 = julianChronology0.halfdays();
        org.joda.time.DurationField durationField4 = julianChronology0.days();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology5.getZone();
        boolean boolean8 = dateTimeZone6.isStandardOffset(100L);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.Chronology chronology10 = julianChronology0.withZone(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("-1");
        org.junit.Assert.assertNotNull(instant1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        int int5 = delegatedDateTimeField3.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, 2019);
        long long9 = offsetDateTimeField7.roundHalfFloor(0L);
        long long12 = offsetDateTimeField7.add((long) '#', (int) (short) 1);
        long long14 = offsetDateTimeField7.roundCeiling((-100L));
        long long16 = offsetDateTimeField7.roundCeiling(0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField7.getType();
        int int19 = offsetDateTimeField7.getLeapAmount(3599940012L);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 60035L + "'", long12 == 60035L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        long long16 = unsupportedDateTimeField13.add((long) (-10), 36);
        boolean boolean17 = unsupportedDateTimeField13.isSupported();
        try {
            long long19 = unsupportedDateTimeField13.roundHalfCeiling((long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35990L + "'", long16 == 35990L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.dayOfWeek();
        int int5 = property4.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("JulianChronology[UTC]", "Sat", 36, 816);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.plus(readableDuration7);
        org.joda.time.DateTime dateTime10 = dateTime8.withSecondOfMinute((int) (short) 10);
        boolean boolean11 = fixedDateTimeZone4.equals((java.lang.Object) (short) 10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(chronology12);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readableDuration14);
        boolean boolean16 = fixedDateTimeZone4.equals((java.lang.Object) dateTime13);
        boolean boolean17 = fixedDateTimeZone4.isFixed();
        java.lang.String str19 = fixedDateTimeZone4.getNameKey(125820000L);
        int int21 = fixedDateTimeZone4.getStandardOffset((-100L));
        long long23 = fixedDateTimeZone4.previousTransition((-2078L));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Sat" + "'", str19.equals("Sat"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 816 + "'", int21 == 816);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-2078L) + "'", long23 == (-2078L));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getRangeDurationField();
        java.util.Locale locale16 = null;
        try {
            java.lang.String str17 = unsupportedDateTimeField13.getAsText(19, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNull(durationField14);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("JulianChronology[UTC]", "Sat", 36, 816);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.lang.Object obj6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(obj6, chronology8);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (org.joda.time.ReadableInstant) dateTime9);
        java.lang.String str12 = fixedDateTimeZone4.getName((long) 2020);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.036" + "'", str12.equals("+00:00:00.036"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(chronology8);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant7, (org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime.Property property11 = dateTime9.dayOfWeek();
        int int12 = dateTime6.compareTo((org.joda.time.ReadableInstant) dateTime9);
        boolean boolean13 = dateTime6.isEqualNow();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime6);
        int int15 = gJChronology14.getMinimumDaysInFirstWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withPivotYear((int) (short) 10);
        boolean boolean19 = gJChronology14.equals((java.lang.Object) dateTimeFormatter16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter16.withOffsetParsed();
        boolean boolean21 = dateTimeFormatter20.isParser();
        try {
            org.joda.time.Instant instant22 = org.joda.time.Instant.parse("yearOfEra", dateTimeFormatter20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"yearOfEra\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        try {
            org.joda.time.MutableDateTime mutableDateTime4 = dateTimeFormatter2.parseMutableDateTime("Property[centuryOfEra]");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Parsing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime5.plusSeconds(0);
        try {
            org.joda.time.DateTime dateTime9 = dateTime5.withDayOfMonth((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology4 = julianChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        int int8 = delegatedDateTimeField6.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(chronology11);
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant10, (org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime.Property property14 = dateTime12.year();
        org.joda.time.DateTime dateTime16 = dateTime12.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property17 = dateTime16.yearOfEra();
        java.lang.Object obj18 = null;
        boolean boolean19 = property17.equals(obj18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property17.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, "UTC");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField23 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField6, dateTimeFieldType20);
        long long26 = zeroIsMaxDateTimeField23.add(0L, 1236);
        int int29 = zeroIsMaxDateTimeField23.getDifference(125820000L, 100L);
        java.lang.String str30 = zeroIsMaxDateTimeField23.toString();
        org.joda.time.DurationField durationField31 = zeroIsMaxDateTimeField23.getLeapDurationField();
        java.util.Locale locale33 = null;
        java.lang.String str34 = zeroIsMaxDateTimeField23.getAsShortText(10L, locale33);
        java.lang.String str35 = zeroIsMaxDateTimeField23.getName();
        java.util.Locale locale37 = null;
        java.lang.String str38 = zeroIsMaxDateTimeField23.getAsShortText((long) 57610, locale37);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 74160000L + "'", long26 == 74160000L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2096 + "'", int29 == 2096);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "DateTimeField[yearOfEra]" + "'", str30.equals("DateTimeField[yearOfEra]"));
        org.junit.Assert.assertNull(durationField31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "60" + "'", str34.equals("60"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "yearOfEra" + "'", str35.equals("yearOfEra"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "60" + "'", str38.equals("60"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.dayOfWeek();
        int int5 = dateTime2.getMinuteOfDay();
        java.util.GregorianCalendar gregorianCalendar6 = dateTime2.toGregorianCalendar();
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar6);
        try {
            org.joda.time.MonthDay monthDay9 = monthDay7.withMonthOfYear((-349199990));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -349199990 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 960 + "'", int5 == 960);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertNotNull(monthDay7);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(3, 12);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        long long16 = unsupportedDateTimeField13.add((long) (-10), 36);
        boolean boolean17 = unsupportedDateTimeField13.isSupported();
        java.lang.String str18 = unsupportedDateTimeField13.getName();
        try {
            long long21 = unsupportedDateTimeField13.set(3120000L, "DateTimeField[minuteOfHour]");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35990L + "'", long16 == 35990L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "yearOfEra" + "'", str18.equals("yearOfEra"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology6 = julianChronology5.withUTC();
        java.lang.String str7 = julianChronology5.toString();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology5.getZone();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(166, (-2078), 2078, (int) (byte) -1, 1236, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "JulianChronology[UTC]" + "'", str7.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(816);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildPrinter();
        boolean boolean4 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendClockhourOfHalfday(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendLiteral("");
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder2.appendMillisOfDay((-349199990));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = copticChronology0.withUTC();
        int int2 = copticChronology0.getMinimumDaysInFirstWeek();
        int int3 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology0.centuryOfEra();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        long long16 = unsupportedDateTimeField13.add(1123199999L, (long) '#');
        java.util.Locale locale18 = null;
        try {
            java.lang.String str19 = unsupportedDateTimeField13.getAsText(0, locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1123234999L + "'", long16 == 1123234999L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("36", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style character: 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.yearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField2, (int) (byte) 100);
        java.util.Locale locale6 = null;
        java.lang.String str7 = skipUndoDateTimeField4.getAsShortText(0L, locale6);
        org.joda.time.DateTimeField dateTimeField8 = skipUndoDateTimeField4.getWrappedField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "69" + "'", str7.equals("69"));
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("CopticChronology[UTC]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"CopticChronology[UTC]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(chronology9);
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant8, (org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime.Property property12 = dateTime10.year();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(chronology14);
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, (org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime.Property property17 = dateTime15.year();
        org.joda.time.DateTime dateTime19 = dateTime15.withCenturyOfEra((int) 'a');
        long long20 = property12.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime.Property property21 = dateTime15.millisOfDay();
        org.joda.time.DateTime dateTime23 = dateTime15.withYearOfCentury((int) (byte) 0);
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant7, (org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime dateTime25 = dateTime2.toDateTime(chronology24);
        org.joda.time.DateTime.Property property26 = dateTime25.yearOfCentury();
        java.util.Locale locale27 = null;
        java.util.Calendar calendar28 = dateTime25.toCalendar(locale27);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(calendar28);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        long long16 = unsupportedDateTimeField13.add((long) (-10), 36);
        boolean boolean17 = unsupportedDateTimeField13.isSupported();
        java.lang.String str18 = unsupportedDateTimeField13.getName();
        try {
            int int19 = unsupportedDateTimeField13.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35990L + "'", long16 == 35990L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "yearOfEra" + "'", str18.equals("yearOfEra"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readableDuration2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.DateTime dateTime7 = dateTime5.plusSeconds(0);
        org.joda.time.DateTime dateTime9 = dateTime7.plus((long) (-7800));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendWeekOfWeekyear((int) (byte) 10);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(chronology4);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, (org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime.Property property7 = dateTime5.year();
        org.joda.time.DateTime dateTime9 = dateTime5.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        java.lang.Object obj11 = null;
        boolean boolean12 = property10.equals(obj11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, "UTC");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType13, 4, 10);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(chronology20);
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant19, (org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime.Property property23 = dateTime21.year();
        org.joda.time.DateTime dateTime25 = dateTime21.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property26 = dateTime25.yearOfEra();
        java.lang.Object obj27 = null;
        boolean boolean28 = property26.equals(obj27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property26.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, "UTC");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder18.appendFixedSignedDecimal(dateTimeFieldType29, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendDayOfMonth(31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder33.appendTwoDigitWeekyear((-1), false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = unsupportedDateTimeField13.getType();
        try {
            int int15 = unsupportedDateTimeField13.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology4 = julianChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        int int8 = delegatedDateTimeField6.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology11 = julianChronology10.withUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology10.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology14 = julianChronology13.withUTC();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology13.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        int int18 = delegatedDateTimeField16.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField19 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology10, (org.joda.time.DateTimeField) delegatedDateTimeField16);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(chronology21);
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant20, (org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property24 = dateTime22.year();
        org.joda.time.DateTime dateTime26 = dateTime22.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property27 = dateTime26.yearOfEra();
        java.lang.Object obj28 = null;
        boolean boolean29 = property27.equals(obj28);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property27.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, "UTC");
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField33 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField16, dateTimeFieldType30);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField9, dateTimeFieldType30, 100, (int) (byte) -1, (int) (byte) 1);
        java.util.Locale locale39 = null;
        java.lang.String str40 = skipDateTimeField9.getAsText((long) (short) 10, locale39);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "0" + "'", str40.equals("0"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType10, "UTC");
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(chronology14);
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant13, (org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTime.Property property17 = dateTime15.year();
        org.joda.time.DateTime dateTime19 = dateTime15.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property20 = dateTime19.yearOfEra();
        java.lang.Object obj21 = null;
        boolean boolean22 = property20.equals(obj21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property20.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType23, "UTC");
        illegalFieldValueException12.addSuppressed((java.lang.Throwable) illegalFieldValueException25);
        java.lang.Number number27 = illegalFieldValueException12.getUpperBound();
        java.lang.String str28 = illegalFieldValueException12.toString();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNull(number27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"UTC\" for yearOfEra is not supported" + "'", str28.equals("org.joda.time.IllegalFieldValueException: Value \"UTC\" for yearOfEra is not supported"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        boolean boolean3 = dateTimeZone1.isStandardOffset(100L);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology5.getZone();
        int int8 = gregorianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology9 = gregorianChronology5.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.dayOfWeek();
        int int5 = dateTime2.getMinuteOfDay();
        org.joda.time.DateTime dateTime7 = dateTime2.minusDays(2000);
        org.joda.time.LocalDateTime localDateTime8 = dateTime7.toLocalDateTime();
        org.joda.time.Instant instant9 = dateTime7.toInstant();
        org.joda.time.MutableDateTime mutableDateTime10 = instant9.toMutableDateTime();
        org.joda.time.Instant instant13 = instant9.withDurationAdded((-349199990L), (int) (short) 1);
        org.joda.time.DateTime dateTime14 = instant9.toDateTime();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 960 + "'", int5 == 960);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDateTime8);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        int int5 = delegatedDateTimeField3.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, 2019);
        long long9 = offsetDateTimeField7.roundHalfFloor(0L);
        long long12 = offsetDateTimeField7.add((long) '#', (int) (short) 1);
        long long14 = offsetDateTimeField7.roundCeiling((-100L));
        long long16 = offsetDateTimeField7.roundCeiling(0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField7.getType();
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(chronology19);
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant18, (org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime.Property property22 = dateTime20.year();
        org.joda.time.DateTime dateTime24 = dateTime20.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime24.yearOfEra();
        java.lang.Object obj26 = null;
        boolean boolean27 = property25.equals(obj26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property25.getFieldType();
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField29 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 60035L + "'", long12 == 60035L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = copticChronology0.add(readablePeriod1, (long) (byte) -1, 1);
        org.joda.time.DateTimeField dateTimeField5 = copticChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = copticChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        boolean boolean3 = dateTimeZone1.isStandardOffset(100L);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology5.getZone();
        java.lang.String str8 = gregorianChronology5.toString();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology5.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "GregorianChronology[UTC]" + "'", str8.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        java.lang.String str6 = delegatedDateTimeField4.getAsShortText((long) (-10));
        long long8 = delegatedDateTimeField4.remainder((long) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField4.getType();
        org.joda.time.ReadablePartial readablePartial10 = null;
        java.util.Locale locale12 = null;
        java.lang.String str13 = delegatedDateTimeField4.getAsText(readablePartial10, (int) (short) 100, locale12);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology17);
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.DateTime dateTime21 = dateTime18.withFields((org.joda.time.ReadablePartial) monthDay20);
        int[] intArray28 = new int[] { (short) 100, (-2078), 36, 4, '#', (byte) 100 };
        int int29 = delegatedDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay20, intArray28);
        int int30 = monthDay20.getMonthOfYear();
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(chronology32);
        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant31, (org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.DateTime.Property property35 = dateTime33.year();
        org.joda.time.DateTime dateTime37 = dateTime33.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property38 = dateTime37.yearOfEra();
        java.lang.Object obj39 = null;
        boolean boolean40 = property38.equals(obj39);
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = property38.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField43 = buddhistChronology42.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType41, durationField43);
        try {
            org.joda.time.MonthDay.Property property45 = monthDay20.property(dateTimeFieldType41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfEra' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "59" + "'", str6.equals("59"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100" + "'", str13.equals("100"));
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 12 + "'", int30 == 12);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(buddhistChronology42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("3", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Property[yearOfEra]", number1, (java.lang.Number) 3, (java.lang.Number) (short) 10);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(chronology2);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, (org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime.Property property5 = dateTime3.year();
        org.joda.time.DateTime dateTime7 = dateTime3.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfEra();
        java.lang.Object obj9 = null;
        boolean boolean10 = property8.equals(obj9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property8.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, "UTC");
        boolean boolean14 = gJChronology0.equals((java.lang.Object) illegalFieldValueException13);
        illegalFieldValueException13.prependMessage("--12-31");
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        try {
            long long9 = julianChronology0.getDateTimeMillis((-2078), 2096, 57600000, (int) (byte) -1, (int) (short) 10, (-10), 1175);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        long long16 = unsupportedDateTimeField13.add(1123199999L, (long) '#');
        long long19 = unsupportedDateTimeField13.add(1123200000L, 0L);
        try {
            long long21 = unsupportedDateTimeField13.roundCeiling(10L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1123234999L + "'", long16 == 1123234999L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1123200000L + "'", long19 == 1123200000L);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        org.joda.time.DurationField durationField5 = delegatedDateTimeField4.getRangeDurationField();
        int int7 = delegatedDateTimeField4.get((long) (short) 1);
        boolean boolean9 = delegatedDateTimeField4.isLeap((long) (short) 100);
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay(0L);
        org.joda.time.MonthDay monthDay13 = monthDay11.plusMonths((int) '4');
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(0L);
        int[] intArray16 = monthDay15.getValues();
        int int17 = delegatedDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay11, intArray16);
        java.util.Locale locale18 = null;
        int int19 = delegatedDateTimeField4.getMaximumTextLength(locale18);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 59 + "'", int17 == 59);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        int int5 = delegatedDateTimeField3.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, 2019);
        long long9 = offsetDateTimeField7.roundHalfFloor(0L);
        long long12 = offsetDateTimeField7.add((long) '#', (int) (short) 1);
        long long14 = offsetDateTimeField7.roundCeiling((-100L));
        org.joda.time.DurationField durationField15 = offsetDateTimeField7.getDurationField();
        org.joda.time.ReadablePartial readablePartial16 = null;
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology18 = julianChronology17.withUTC();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology17.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19);
        java.lang.String str21 = delegatedDateTimeField20.toString();
        org.joda.time.chrono.JulianChronology julianChronology22 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology23 = julianChronology22.withUTC();
        org.joda.time.DateTimeField dateTimeField24 = julianChronology22.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24);
        int int27 = delegatedDateTimeField25.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField25, 2019);
        long long31 = offsetDateTimeField29.roundHalfFloor(0L);
        long long34 = offsetDateTimeField29.add((long) '#', (int) (short) 1);
        long long36 = offsetDateTimeField29.roundCeiling((-100L));
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay(dateTimeZone38);
        org.joda.time.ReadablePeriod readablePeriod40 = null;
        org.joda.time.MonthDay monthDay42 = monthDay39.withPeriodAdded(readablePeriod40, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay45 = new org.joda.time.MonthDay(dateTimeZone44);
        boolean boolean46 = monthDay42.isBefore((org.joda.time.ReadablePartial) monthDay45);
        int int47 = offsetDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) monthDay45);
        int[] intArray48 = new int[] {};
        int int49 = delegatedDateTimeField20.getMinimumValue((org.joda.time.ReadablePartial) monthDay45, intArray48);
        int int50 = offsetDateTimeField7.getMinimumValue(readablePartial16, intArray48);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 60035L + "'", long12 == 60035L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str21.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertNotNull(julianChronology22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 60035L + "'", long34 == 60035L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(monthDay42);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2078 + "'", int47 == 2078);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2019 + "'", int50 == 2019);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "", "hi!");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "", "");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        boolean boolean4 = dateTimeZone2.isStandardOffset(100L);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.Chronology chronology6 = julianChronology0.withZone(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.millisOfSecond();
        org.joda.time.DurationField durationField8 = julianChronology0.years();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        org.joda.time.DurationField durationField14 = unsupportedDateTimeField13.getRangeDurationField();
        org.joda.time.DurationField durationField15 = unsupportedDateTimeField13.getLeapDurationField();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology19);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.DateTime dateTime23 = dateTime20.withFields((org.joda.time.ReadablePartial) monthDay22);
        org.joda.time.chrono.JulianChronology julianChronology25 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology26 = julianChronology25.withUTC();
        org.joda.time.DateTimeField dateTimeField27 = julianChronology25.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField27);
        java.lang.String str29 = delegatedDateTimeField28.toString();
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology31 = julianChronology30.withUTC();
        org.joda.time.DateTimeField dateTimeField32 = julianChronology30.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField32);
        int int35 = delegatedDateTimeField33.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField33, 2019);
        long long39 = offsetDateTimeField37.roundHalfFloor(0L);
        long long42 = offsetDateTimeField37.add((long) '#', (int) (short) 1);
        long long44 = offsetDateTimeField37.roundCeiling((-100L));
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay47 = new org.joda.time.MonthDay(dateTimeZone46);
        org.joda.time.ReadablePeriod readablePeriod48 = null;
        org.joda.time.MonthDay monthDay50 = monthDay47.withPeriodAdded(readablePeriod48, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay53 = new org.joda.time.MonthDay(dateTimeZone52);
        boolean boolean54 = monthDay50.isBefore((org.joda.time.ReadablePartial) monthDay53);
        int int55 = offsetDateTimeField37.getMaximumValue((org.joda.time.ReadablePartial) monthDay53);
        int[] intArray56 = new int[] {};
        int int57 = delegatedDateTimeField28.getMinimumValue((org.joda.time.ReadablePartial) monthDay53, intArray56);
        try {
            int[] intArray59 = unsupportedDateTimeField13.addWrapField((org.joda.time.ReadablePartial) monthDay22, 13, intArray56, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(julianChronology25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str29.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 60035L + "'", long42 == 60035L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(monthDay50);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2078 + "'", int55 == 2078);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, 41007L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology5.getZone();
        boolean boolean8 = dateTimeZone6.isStandardOffset(100L);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.millisOfDay();
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(3, (int) (short) 10, (int) (short) 10, 19, (int) (byte) 0, (org.joda.time.Chronology) gregorianChronology10);
        try {
            long long20 = gregorianChronology10.getDateTimeMillis(19, 57610, 1970, 816, 48983, 0, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 816 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime dateTime5 = dateTime2.withEra((int) (byte) 1);
        org.joda.time.LocalDate localDate6 = dateTime5.toLocalDate();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property13 = dateTime7.millisOfDay();
        org.joda.time.DateTime dateTime15 = dateTime7.plusMillis(0);
        org.joda.time.DateTime dateTime16 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((java.lang.Object) dateTime16);
        org.joda.time.Chronology chronology18 = monthDay17.getChronology();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(chronology18);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "", "2078");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.util.Locale locale3 = dateTimeFormatter0.getLocale();
        boolean boolean4 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear((int) (short) 10);
        try {
            org.joda.time.MonthDay monthDay4 = org.joda.time.MonthDay.parse("0", dateTimeFormatter3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"0\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(chronology4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant6, (org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property10 = dateTime8.dayOfWeek();
        int int11 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime8);
        boolean boolean12 = dateTime5.isEqualNow();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology13);
        try {
            org.joda.time.DateTime dateTime16 = dateTime14.withDayOfWeek(57610);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57610 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(816);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildPrinter();
        boolean boolean4 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendClockhourOfHalfday(4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendLiteral("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder2.appendMillisOfDay(166);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder2.appendFractionOfMinute(36, 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.DateTimeFormat.shortTime();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.append(dateTimeParser15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.dayOfYear();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = julianChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology2.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology6 = julianChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        int int10 = delegatedDateTimeField8.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField11 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology2, (org.joda.time.DateTimeField) delegatedDateTimeField8);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone16 = julianChronology15.getZone();
        boolean boolean18 = dateTimeZone16.isStandardOffset(100L);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.Chronology chronology20 = julianChronology14.withZone(dateTimeZone16);
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(0L);
        int[] intArray23 = monthDay22.getValues();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        boolean boolean25 = monthDay22.isSupported(dateTimeFieldType24);
        long long27 = julianChronology14.set((org.joda.time.ReadablePartial) monthDay22, (long) (short) -1);
        boolean boolean28 = monthDay13.isEqual((org.joda.time.ReadablePartial) monthDay22);
        java.util.Locale locale30 = null;
        java.lang.String str31 = skipDateTimeField11.getAsShortText((org.joda.time.ReadablePartial) monthDay22, (-1), locale30);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipDateTimeField11, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay36 = new org.joda.time.MonthDay(dateTimeZone35);
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.MonthDay monthDay39 = monthDay36.withPeriodAdded(readablePeriod37, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay42 = new org.joda.time.MonthDay(dateTimeZone41);
        boolean boolean43 = monthDay39.isBefore((org.joda.time.ReadablePartial) monthDay42);
        java.util.Locale locale44 = null;
        try {
            java.lang.String str45 = skipUndoDateTimeField33.getAsText((org.joda.time.ReadablePartial) monthDay39, locale44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfHour' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1123199999L + "'", long27 == 1123199999L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "-1" + "'", str31.equals("-1"));
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(monthDay39);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("yearOfEra");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: r");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1970", (java.lang.Number) (-26010516), (java.lang.Number) 60000L, (java.lang.Number) (short) 10);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DurationField durationField2 = julianChronology0.months();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withHourOfDay(0);
        try {
            org.joda.time.DateTime dateTime8 = dateTime2.withWeekOfWeekyear((-26010516));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -26010516 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        long long16 = unsupportedDateTimeField13.add((long) (-10), 36);
        long long19 = unsupportedDateTimeField13.getDifferenceAsLong((long) 816, (long) (-10));
        boolean boolean20 = unsupportedDateTimeField13.isLenient();
        org.joda.time.ReadablePartial readablePartial21 = null;
        int[] intArray24 = new int[] { 816 };
        try {
            int[] intArray26 = unsupportedDateTimeField13.addWrapPartial(readablePartial21, 86399999, intArray24, 3600000);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35990L + "'", long16 == 35990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        long long16 = unsupportedDateTimeField13.add((long) (-10), 36);
        boolean boolean17 = unsupportedDateTimeField13.isSupported();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) unsupportedDateTimeField13, (int) 'a', 1970, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for yearOfEra must be in the range [1970,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35990L + "'", long16 == 35990L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendWeekOfWeekyear((int) (byte) 10);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(chronology4);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant3, (org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime.Property property7 = dateTime5.year();
        org.joda.time.DateTime dateTime9 = dateTime5.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        java.lang.Object obj11 = null;
        boolean boolean12 = property10.equals(obj11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property10.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType13, "UTC");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType13, 4, 10);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(chronology20);
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant19, (org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime.Property property23 = dateTime21.year();
        org.joda.time.DateTime dateTime25 = dateTime21.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property26 = dateTime25.yearOfEra();
        java.lang.Object obj27 = null;
        boolean boolean28 = property26.equals(obj27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property26.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException31 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, "UTC");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder18.appendFixedSignedDecimal(dateTimeFieldType29, 19);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendDayOfMonth(31);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder35.appendTimeZoneShortName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder35.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMinuteOfDay(816);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildPrinter();
        boolean boolean4 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendClockhourOfHalfday(4);
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = null;
        org.joda.time.format.DateTimeParser[] dateTimeParserArray8 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.append(dateTimePrinter7, dateTimeParserArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parsers supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        boolean boolean3 = dateTimeZone1.isStandardOffset(100L);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime6 = dateTime4.plusMillis(1);
        org.joda.time.DateTime.Property property7 = dateTime6.centuryOfEra();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant4 = instant1.withDurationAdded(readableDuration2, 166);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant4.plus(readableDuration5);
        java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) instant4);
        try {
            org.joda.time.LocalDate localDate9 = dateTimeFormatter0.parseLocalDate("100");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"100\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-14T00:00:00" + "'", str7.equals("1970-01-14T00:00:00"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        boolean boolean3 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter1);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.yearOfEra();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology6 = julianChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology5.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        int int10 = delegatedDateTimeField8.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField8, 2019);
        long long14 = offsetDateTimeField12.roundHalfFloor(0L);
        long long17 = offsetDateTimeField12.add((long) '#', (int) (short) 1);
        long long19 = offsetDateTimeField12.roundCeiling((-100L));
        org.joda.time.DurationField durationField20 = offsetDateTimeField12.getDurationField();
        boolean boolean21 = offsetDateTimeField12.isSupported();
        boolean boolean22 = iSOChronology0.equals((java.lang.Object) boolean21);
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(chronology24);
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant23, (org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime.Property property27 = dateTime25.year();
        org.joda.time.DateTime dateTime29 = dateTime25.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property30 = dateTime29.yearOfEra();
        java.lang.Object obj31 = null;
        boolean boolean32 = property30.equals(obj31);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property30.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField35 = buddhistChronology34.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField36 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType33, durationField35);
        long long39 = unsupportedDateTimeField36.add(1123199999L, (long) '#');
        long long42 = unsupportedDateTimeField36.add(1123200000L, 0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = unsupportedDateTimeField36.getType();
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField45 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeField) unsupportedDateTimeField36, 86399999);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 60035L + "'", long17 == 60035L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(buddhistChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1123234999L + "'", long39 == 1123234999L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1123200000L + "'", long42 == 1123200000L);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("JulianChronology[UTC]", "Sat", 36, 816);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        java.util.Locale locale8 = null;
        java.lang.String str9 = fixedDateTimeZone4.getShortName((long) 31, locale8);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.036" + "'", str9.equals("+00:00:00.036"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("JulianChronology[UTC]", "Sat", 36, 816);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(chronology5);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.plus(readableDuration7);
        org.joda.time.DateTime dateTime10 = dateTime8.withSecondOfMinute((int) (short) 10);
        boolean boolean11 = fixedDateTimeZone4.equals((java.lang.Object) (short) 10);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(chronology12);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readableDuration14);
        boolean boolean16 = fixedDateTimeZone4.equals((java.lang.Object) dateTime13);
        try {
            org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (-7700));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -7700");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("59");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection2);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay(dateTimeZone2);
        org.joda.time.Chronology chronology4 = julianChronology0.withZone(dateTimeZone2);
        try {
            org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone2, 166);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 166");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = copticChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property13 = dateTime7.millisOfDay();
        org.joda.time.DateTime dateTime15 = dateTime7.plusMillis(0);
        org.joda.time.DateTime dateTime16 = dateTime15.withLaterOffsetAtOverlap();
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((java.lang.Object) dateTime16);
        int[] intArray18 = monthDay17.getValues();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology4 = julianChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        int int8 = delegatedDateTimeField6.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        int int10 = skipDateTimeField9.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay16 = monthDay13.withPeriodAdded(readablePeriod14, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay(dateTimeZone18);
        boolean boolean20 = monthDay16.isBefore((org.joda.time.ReadablePartial) monthDay19);
        int int21 = skipDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) monthDay16);
        int int23 = skipDateTimeField9.getMinimumValue((long) (-10));
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay(0L);
        int[] intArray26 = monthDay25.getValues();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = null;
        java.lang.String str28 = monthDay25.toString(dateTimeFormatter27);
        int[] intArray36 = new int[] { (-2096), (-10), ' ', 0, 12, 1175 };
        try {
            int[] intArray38 = skipDateTimeField9.add((org.joda.time.ReadablePartial) monthDay25, (int) '#', intArray36, 86399999);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "--01-01" + "'", str28.equals("--01-01"));
        org.junit.Assert.assertNotNull(intArray36);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property13 = dateTime7.millisOfDay();
        org.joda.time.DurationField durationField14 = property13.getLeapDurationField();
        org.joda.time.DateTime dateTime15 = property13.roundCeilingCopy();
        int int16 = property13.getMinimumValueOverall();
        org.joda.time.DateTime dateTime18 = property13.setCopy("2078");
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(2000);
        boolean boolean3 = dateTimeFormatter2.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology4 = julianChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        int int8 = delegatedDateTimeField6.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        int int10 = skipDateTimeField9.getMinimumValue();
        long long12 = skipDateTimeField9.roundHalfCeiling((long) 816);
        java.util.Locale locale13 = null;
        int int14 = skipDateTimeField9.getMaximumTextLength(locale13);
        try {
            long long17 = skipDateTimeField9.set((long) (-2096), "hi!");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra((int) 'a');
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        java.lang.Object obj8 = null;
        boolean boolean9 = property7.equals(obj8);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property7.getFieldType();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField13 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField12);
        long long16 = unsupportedDateTimeField13.add((long) (-10), 36);
        long long19 = unsupportedDateTimeField13.getDifferenceAsLong((long) 816, (long) (-10));
        boolean boolean20 = unsupportedDateTimeField13.isLenient();
        long long23 = unsupportedDateTimeField13.add((long) 166, (long) 6);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35990L + "'", long16 == 35990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 6166L + "'", long23 == 6166L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology4 = julianChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        int int8 = delegatedDateTimeField6.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        int int10 = skipDateTimeField9.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay16 = monthDay13.withPeriodAdded(readablePeriod14, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay(dateTimeZone18);
        boolean boolean20 = monthDay16.isBefore((org.joda.time.ReadablePartial) monthDay19);
        int int21 = skipDateTimeField9.getMinimumValue((org.joda.time.ReadablePartial) monthDay16);
        int int23 = skipDateTimeField9.getMinimumValue((long) (-10));
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology25 = julianChronology24.withUTC();
        org.joda.time.DateTimeField dateTimeField26 = julianChronology24.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26, dateTimeFieldType27);
        java.lang.String str30 = delegatedDateTimeField28.getAsShortText((long) (-10));
        long long32 = delegatedDateTimeField28.remainder((long) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = delegatedDateTimeField28.getType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField9, dateTimeFieldType33);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "59" + "'", str30.equals("59"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.Chronology chronology6 = copticChronology5.withUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = copticChronology5.getZone();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 100, (int) 'a', 31, 4, 19, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear(1);
        int int5 = dateTimeFormatter2.getDefaultYear();
        org.joda.time.Chronology chronology6 = dateTimeFormatter2.getChronolgy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withPivotYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2000 + "'", int5 == 2000);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("100", 0, 57610, (-10));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for 100 must be in the range [57610,-10]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = copticChronology1.add(readablePeriod2, (long) (byte) -1, 1);
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(0L, (org.joda.time.Chronology) copticChronology1);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology1.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField8 = copticChronology1.minuteOfHour();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property13 = dateTime7.millisOfDay();
        org.joda.time.DateTime dateTime15 = dateTime7.withYearOfCentury((int) (byte) 0);
        org.joda.time.DateTime dateTime18 = dateTime7.withDurationAdded((long) (byte) 100, 36);
        org.joda.time.DateTime dateTime20 = dateTime18.withSecondOfMinute(19);
        org.joda.time.DateTime dateTime22 = dateTime18.minusMinutes(1236);
        int int23 = dateTime18.getHourOfDay();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(dateTimeZone7);
        boolean boolean9 = monthDay5.isBefore((org.joda.time.ReadablePartial) monthDay8);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(dateTimeZone11);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone11);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(chronology14);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(chronology17);
        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant16, (org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime.Property property20 = dateTime18.dayOfWeek();
        int int21 = dateTime15.compareTo((org.joda.time.ReadableInstant) dateTime18);
        boolean boolean22 = dateTime15.isEqualNow();
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.MonthDay monthDay24 = monthDay5.withChronologyRetainFields((org.joda.time.Chronology) gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(monthDay24);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        int int5 = delegatedDateTimeField3.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, 2019);
        long long9 = offsetDateTimeField7.roundHalfFloor(0L);
        long long12 = offsetDateTimeField7.add((long) '#', (int) (short) 1);
        long long14 = offsetDateTimeField7.roundFloor((long) 57600000);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 60035L + "'", long12 == 60035L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 57600000L + "'", long14 == 57600000L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) instant0, (org.joda.time.ReadableInstant) dateTime1);
        org.joda.time.Instant instant4 = instant0.withMillis((long) (short) -1);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant7 = instant0.withDurationAdded(readableDuration5, (int) (short) 10);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant7);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        java.lang.String str2 = dateTimeFormatter0.print((long) 2078);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-01-01T00:00:02Z" + "'", str2.equals("1970-01-01T00:00:02Z"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.lang.Object obj0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(obj0, chronology2);
        org.joda.time.DateTime dateTime5 = dateTime3.withWeekOfWeekyear(3);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology1.getZone();
        boolean boolean4 = dateTimeZone2.isStandardOffset(100L);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.Chronology chronology6 = julianChronology0.withZone(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology0.getZone();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property13 = dateTime7.millisOfDay();
        org.joda.time.DateTime dateTime15 = dateTime7.withMillisOfDay(960);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime7.getZone();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.DateTime dateTime5 = property4.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime6 = property4.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime8 = dateTime6.plusSeconds(3);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology4 = julianChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        int int8 = delegatedDateTimeField6.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField9 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField6);
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone14 = julianChronology13.getZone();
        boolean boolean16 = dateTimeZone14.isStandardOffset(100L);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone14);
        org.joda.time.Chronology chronology18 = julianChronology12.withZone(dateTimeZone14);
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(0L);
        int[] intArray21 = monthDay20.getValues();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        boolean boolean23 = monthDay20.isSupported(dateTimeFieldType22);
        long long25 = julianChronology12.set((org.joda.time.ReadablePartial) monthDay20, (long) (short) -1);
        boolean boolean26 = monthDay11.isEqual((org.joda.time.ReadablePartial) monthDay20);
        java.util.Locale locale28 = null;
        java.lang.String str29 = skipDateTimeField9.getAsShortText((org.joda.time.ReadablePartial) monthDay20, (-1), locale28);
        long long32 = skipDateTimeField9.set(0L, 9);
        int int35 = skipDateTimeField9.getDifference((long) 166, (long) (-26010516));
        long long37 = skipDateTimeField9.roundCeiling((long) 960);
        int int38 = skipDateTimeField9.getMinimumValue();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(julianChronology12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-30326400001L) + "'", long25 == (-30326400001L));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "-1" + "'", str29.equals("-1"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 540000L + "'", long32 == 540000L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 433 + "'", int35 == 433);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 60000L + "'", long37 == 60000L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property13 = dateTime7.millisOfDay();
        org.joda.time.DurationField durationField14 = property13.getLeapDurationField();
        long long15 = property13.remainder();
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(chronology17);
        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant16, (org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime.Property property20 = dateTime18.year();
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(chronology22);
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant21, (org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime.Property property25 = dateTime23.year();
        org.joda.time.DateTime dateTime27 = dateTime23.withCenturyOfEra((int) 'a');
        long long28 = property20.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime.Property property29 = dateTime23.millisOfDay();
        org.joda.time.DurationField durationField30 = property29.getLeapDurationField();
        org.joda.time.DateTime dateTime31 = property29.roundCeilingCopy();
        int int32 = property13.getDifference((org.joda.time.ReadableInstant) dateTime31);
        java.util.GregorianCalendar gregorianCalendar33 = dateTime31.toGregorianCalendar();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(gregorianCalendar33);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-1), (int) (byte) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((long) (short) -1);
        org.joda.time.DateTime dateTime7 = dateTime4.withFields((org.joda.time.ReadablePartial) monthDay6);
        org.joda.time.MonthDay monthDay9 = monthDay6.minusMonths((-10));
        int int10 = monthDay9.getDayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType3);
        java.lang.String str6 = delegatedDateTimeField4.getAsShortText((long) (-10));
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField4, dateTimeFieldType7);
        long long10 = delegatedDateTimeField4.remainder((long) (-349199990));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "59" + "'", str6.equals("59"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(0L, (long) 3600000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3600000L + "'", long2 == 3600000L);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        boolean boolean3 = dateTimeZone1.isStandardOffset(100L);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        boolean boolean12 = dateTime4.isAfter((org.joda.time.ReadableInstant) dateTime11);
        int int13 = dateTime4.getMinuteOfHour();
        org.joda.time.DateTime dateTime15 = dateTime4.minusMonths(10);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        boolean boolean2 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime.Property property4 = dateTime2.year();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant5, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property9 = dateTime7.year();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) 'a');
        long long12 = property4.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime.Property property13 = dateTime7.millisOfDay();
        int int14 = property13.getMaximumValue();
        org.joda.time.DateTimeField dateTimeField15 = property13.getField();
        org.joda.time.DateTime dateTime17 = property13.addToCopy(48983);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 86399999 + "'", int14 == 86399999);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(chronology3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant2, (org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime.Property property6 = dateTime4.dayOfWeek();
        int int7 = dateTime1.compareTo((org.joda.time.ReadableInstant) dateTime4);
        try {
            org.joda.time.DateTime dateTime9 = dateTime4.withDayOfYear(2096);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2096 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant2 = instant0.withMillis((long) ' ');
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = copticChronology1.add(readablePeriod2, (long) (byte) -1, 1);
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(0L, (org.joda.time.Chronology) copticChronology1);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology8 = julianChronology7.withUTC();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology7.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology11 = julianChronology10.withUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology10.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        int int15 = delegatedDateTimeField13.getLeapAmount((long) 36);
        org.joda.time.field.SkipDateTimeField skipDateTimeField16 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology7, (org.joda.time.DateTimeField) delegatedDateTimeField13);
        int int17 = skipDateTimeField16.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(dateTimeZone19);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.MonthDay monthDay23 = monthDay20.withPeriodAdded(readablePeriod21, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay(dateTimeZone25);
        boolean boolean27 = monthDay23.isBefore((org.joda.time.ReadablePartial) monthDay26);
        int int28 = skipDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) monthDay23);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) copticChronology1, (org.joda.time.DateTimeField) skipDateTimeField16);
        org.joda.time.DateTimeField dateTimeField30 = copticChronology1.dayOfYear();
        java.lang.String str31 = copticChronology1.toString();
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "CopticChronology[UTC]" + "'", str31.equals("CopticChronology[UTC]"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        int int5 = delegatedDateTimeField3.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField3, 2019);
        long long9 = offsetDateTimeField7.roundHalfFloor(0L);
        long long12 = offsetDateTimeField7.add((long) '#', (int) (short) 1);
        long long14 = offsetDateTimeField7.roundCeiling((-100L));
        long long17 = offsetDateTimeField7.add(0L, 2097);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology19 = julianChronology18.withUTC();
        org.joda.time.DateTimeField dateTimeField20 = julianChronology18.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        java.lang.String str22 = delegatedDateTimeField21.toString();
        org.joda.time.chrono.JulianChronology julianChronology23 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology24 = julianChronology23.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = julianChronology23.minuteOfHour();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        int int28 = delegatedDateTimeField26.getLeapAmount((long) 36);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField26, 2019);
        long long32 = offsetDateTimeField30.roundHalfFloor(0L);
        long long35 = offsetDateTimeField30.add((long) '#', (int) (short) 1);
        long long37 = offsetDateTimeField30.roundCeiling((-100L));
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay(dateTimeZone39);
        org.joda.time.ReadablePeriod readablePeriod41 = null;
        org.joda.time.MonthDay monthDay43 = monthDay40.withPeriodAdded(readablePeriod41, (int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forOffsetHours((int) 'a');
        org.joda.time.MonthDay monthDay46 = new org.joda.time.MonthDay(dateTimeZone45);
        boolean boolean47 = monthDay43.isBefore((org.joda.time.ReadablePartial) monthDay46);
        int int48 = offsetDateTimeField30.getMaximumValue((org.joda.time.ReadablePartial) monthDay46);
        int[] intArray49 = new int[] {};
        int int50 = delegatedDateTimeField21.getMinimumValue((org.joda.time.ReadablePartial) monthDay46, intArray49);
        int int51 = offsetDateTimeField7.getMaximumValue((org.joda.time.ReadablePartial) monthDay46);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 60035L + "'", long12 == 60035L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 125820000L + "'", long17 == 125820000L);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "DateTimeField[minuteOfHour]" + "'", str22.equals("DateTimeField[minuteOfHour]"));
        org.junit.Assert.assertNotNull(julianChronology23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 60035L + "'", long35 == 60035L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(monthDay43);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2078 + "'", int48 == 2078);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2078 + "'", int51 == 2078);
    }
}

