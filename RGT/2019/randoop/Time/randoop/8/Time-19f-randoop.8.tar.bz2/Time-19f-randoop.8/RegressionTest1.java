import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(47, 0, 2080, 51, (-1), 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 51 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '#');
        int int6 = offsetDateTimeField5.getMaximumValue();
        int int7 = offsetDateTimeField5.getOffset();
        int int8 = offsetDateTimeField5.getMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 86400034 + "'", int6 == 86400034);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 35 + "'", int7 == 35);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 86400034 + "'", int8 == 86400034);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019166");
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis(24);
        org.joda.time.DateTime.Property property7 = dateTime6.year();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendClockhourOfDay((int) 'a');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap11 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendTimeZoneName(strMap11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendMinuteOfHour(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendHalfdayOfDayText();
        boolean boolean16 = property7.equals((java.lang.Object) dateTimeFormatterBuilder14);
        org.joda.time.DateTime dateTime17 = property7.roundHalfCeilingCopy();
        org.joda.time.DurationField durationField18 = property7.getDurationField();
        int int19 = property7.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 292278993 + "'", int19 == 292278993);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 124, (long) 877);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-753L) + "'", long2 == (-753L));
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone3);
//        boolean boolean7 = dateTime5.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
//        long long10 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) 24);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.clockhourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone12 = iSOChronology0.getZone();
//        org.joda.time.DurationField durationField13 = iSOChronology0.weekyears();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560639600024L + "'", long10 == 1560639600024L);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(durationField13);
//    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
//        boolean boolean5 = dateTime3.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
//        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime();
//        org.joda.time.DateTime.Property property8 = dateTime7.era();
//        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType10, 24, 10);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology15 = iSOChronology14.withUTC();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone17);
//        boolean boolean21 = dateTime19.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate22 = dateTime19.toLocalDate();
//        long long24 = iSOChronology14.set((org.joda.time.ReadablePartial) localDate22, (long) 24);
//        long long28 = iSOChronology14.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField29 = iSOChronology14.millis();
//        org.joda.time.DurationField durationField30 = iSOChronology14.years();
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology14.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeUtils.getZone(dateTimeZone33);
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone33);
//        boolean boolean37 = dateTime35.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate38 = dateTime35.toLocalDate();
//        org.joda.time.DateTime dateTime39 = dateTime35.toDateTime();
//        org.joda.time.DateTime.Property property40 = dateTime39.era();
//        org.joda.time.DateTime.Property property41 = dateTime39.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property41.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder32.appendFraction(dateTimeFieldType42, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField50 = new org.joda.time.field.DividedDateTimeField(dateTimeField31, dateTimeFieldType42, (int) (byte) 10);
//        org.joda.time.DurationField durationField51 = dividedDateTimeField50.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField52 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField51);
//        int int55 = unsupportedDateTimeField52.getDifference((long) (byte) -1, 1560664800024L);
//        java.util.Locale locale56 = null;
//        try {
//            int int57 = unsupportedDateTimeField52.getMaximumTextLength(locale56);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560639600024L + "'", long24 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560639610124L + "'", long28 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(durationField51);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField52);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-36126) + "'", int55 == (-36126));
//    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
//        boolean boolean4 = dateTime2.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
//        org.joda.time.DateTime.Property property6 = dateTime2.millisOfSecond();
//        int int7 = dateTime2.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone8);
//        int int11 = dateTime10.getWeekOfWeekyear();
//        boolean boolean12 = dateTime2.equals((java.lang.Object) dateTime10);
//        org.joda.time.DateTime dateTime14 = dateTime10.plusHours((int) (byte) -1);
//        boolean boolean16 = dateTime14.isEqual((-1036800000000000L));
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 7 + "'", int7 == 7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
//        boolean boolean4 = dateTime2.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
//        int int6 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
//        java.util.Date date9 = dateTime2.toDate();
//        org.joda.time.DateTime dateTime11 = dateTime2.minusMonths((int) (byte) -1);
//        boolean boolean12 = dateTime2.isEqualNow();
//        org.joda.time.DateTime.Property property13 = dateTime2.dayOfYear();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(property13);
//    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone3);
//        boolean boolean7 = dateTime5.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
//        long long10 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) 24);
//        long long14 = iSOChronology0.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField15 = iSOChronology0.millis();
//        org.joda.time.DurationField durationField16 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone19);
//        boolean boolean23 = dateTime21.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
//        org.joda.time.DateTime dateTime25 = dateTime21.toDateTime();
//        org.joda.time.DateTime.Property property26 = dateTime25.era();
//        org.joda.time.DateTime.Property property27 = dateTime25.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder18.appendFraction(dateTimeFieldType28, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType28, (int) (byte) 10);
//        org.joda.time.DurationField durationField37 = dividedDateTimeField36.getRangeDurationField();
//        java.lang.String str39 = dividedDateTimeField36.getAsShortText(101L);
//        long long42 = dividedDateTimeField36.add((long) (short) 0, (-28800000L));
//        long long45 = dividedDateTimeField36.add((long) 6, 47);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560639600024L + "'", long10 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560639610124L + "'", long14 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-1036800000000000L) + "'", long42 == (-1036800000000000L));
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1692000006L + "'", long45 == 1692000006L);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale2 = null;
        java.lang.String str5 = defaultNameProvider0.getShortName(locale2, "UTC", "152");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology2 = iSOChronology1.withUTC();
        org.joda.time.DateTimeZone dateTimeZone3 = iSOChronology1.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology1);
        int int5 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2000 + "'", int5 == 2000);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendHourOfDay(86400034);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
//        boolean boolean5 = dateTime3.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
//        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime();
//        org.joda.time.DateTime.Property property8 = dateTime7.era();
//        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType10, 24, 10);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology15 = iSOChronology14.withUTC();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone17);
//        boolean boolean21 = dateTime19.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate22 = dateTime19.toLocalDate();
//        long long24 = iSOChronology14.set((org.joda.time.ReadablePartial) localDate22, (long) 24);
//        long long28 = iSOChronology14.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField29 = iSOChronology14.millis();
//        org.joda.time.DurationField durationField30 = iSOChronology14.years();
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology14.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeUtils.getZone(dateTimeZone33);
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone33);
//        boolean boolean37 = dateTime35.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate38 = dateTime35.toLocalDate();
//        org.joda.time.DateTime dateTime39 = dateTime35.toDateTime();
//        org.joda.time.DateTime.Property property40 = dateTime39.era();
//        org.joda.time.DateTime.Property property41 = dateTime39.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property41.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder32.appendFraction(dateTimeFieldType42, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField50 = new org.joda.time.field.DividedDateTimeField(dateTimeField31, dateTimeFieldType42, (int) (byte) 10);
//        org.joda.time.DurationField durationField51 = dividedDateTimeField50.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField52 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField51);
//        long long55 = durationField51.subtract((long) 292278993, (long) 3);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560639600024L + "'", long24 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560639610124L + "'", long28 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(durationField51);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField52);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 162678993L + "'", long55 == 162678993L);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendPattern("695");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
//        boolean boolean4 = dateTime2.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
//        int int6 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.era();
//        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) iSOChronology9);
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds((int) '4');
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime16 = dateTime13.withPeriodAdded(readablePeriod14, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone18);
//        boolean boolean22 = dateTime20.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate23 = dateTime20.toLocalDate();
//        org.joda.time.DateTime dateTime24 = dateTime20.toDateTime();
//        org.joda.time.DateTime.Property property25 = dateTime24.era();
//        org.joda.time.DateTime.Property property26 = dateTime24.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder17.appendFraction(dateTimeFieldType27, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType27, "2019-06-15T14:37:06.783-07:00");
//        org.joda.time.DateTime.Property property33 = dateTime13.property(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertNotNull(property33);
//    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
//        boolean boolean4 = dateTime2.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
//        int int6 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
//        org.joda.time.DateTime dateTime10 = dateTime2.withMinuteOfHour(1);
//        org.joda.time.DateMidnight dateMidnight11 = dateTime10.toDateMidnight();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateMidnight11);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("1969-12-31T16:00:00.032-08:00", 0, 124, 0, 'a', 2490, (-1), (int) 'a', false, 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder19 = dateTimeZoneBuilder0.addCutover((-1), ' ', (int) (short) 1, 999, (int) (byte) 1, true, 37);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder19);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
//        boolean boolean4 = dateTime2.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
//        int int6 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
//        java.util.Date date9 = dateTime2.toDate();
//        org.joda.time.DateTime dateTime11 = dateTime2.plusYears(1);
//        org.joda.time.Instant instant12 = dateTime2.toInstant();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(instant12);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DurationField durationField8 = property6.getLeapDurationField();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone9);
        boolean boolean13 = dateTime11.isBefore((long) (-1));
        org.joda.time.DateTime dateTime15 = dateTime11.plusMillis((int) (byte) 10);
        org.joda.time.DateTime dateTime17 = dateTime11.minusMonths((int) 'a');
        org.joda.time.DateTime.Property property18 = dateTime17.millisOfDay();
        org.joda.time.DateTime dateTime20 = property18.setCopy((int) '#');
        org.joda.time.DateTime.Property property21 = dateTime20.hourOfDay();
        int int22 = property6.compareTo((org.joda.time.ReadableInstant) dateTime20);
        boolean boolean23 = property6.isLeap();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean6 = dateTime4.isBefore((long) (-1));
        org.joda.time.LocalDate localDate7 = dateTime4.toLocalDate();
        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.minus(readableDuration9);
        org.joda.time.DateTime dateTime11 = dateTime10.withEarlierOffsetAtOverlap();
        boolean boolean12 = dateTime10.isAfterNow();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
//        boolean boolean5 = dateTime3.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
//        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime();
//        org.joda.time.DateTime.Property property8 = dateTime7.era();
//        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType10, 24, 10);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology15 = iSOChronology14.withUTC();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone17);
//        boolean boolean21 = dateTime19.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate22 = dateTime19.toLocalDate();
//        long long24 = iSOChronology14.set((org.joda.time.ReadablePartial) localDate22, (long) 24);
//        long long28 = iSOChronology14.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField29 = iSOChronology14.millis();
//        org.joda.time.DurationField durationField30 = iSOChronology14.years();
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology14.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeUtils.getZone(dateTimeZone33);
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone33);
//        boolean boolean37 = dateTime35.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate38 = dateTime35.toLocalDate();
//        org.joda.time.DateTime dateTime39 = dateTime35.toDateTime();
//        org.joda.time.DateTime.Property property40 = dateTime39.era();
//        org.joda.time.DateTime.Property property41 = dateTime39.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property41.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder32.appendFraction(dateTimeFieldType42, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField50 = new org.joda.time.field.DividedDateTimeField(dateTimeField31, dateTimeFieldType42, (int) (byte) 10);
//        org.joda.time.DurationField durationField51 = dividedDateTimeField50.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField52 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField51);
//        int int55 = unsupportedDateTimeField52.getDifference((long) (byte) -1, 1560664800024L);
//        java.util.Locale locale57 = null;
//        try {
//            java.lang.String str58 = unsupportedDateTimeField52.getAsShortText(124, locale57);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560639600024L + "'", long24 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560639610124L + "'", long28 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(durationField51);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField52);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-36126) + "'", int55 == (-36126));
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
//        boolean boolean4 = dateTime2.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
//        int int6 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.era();
//        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) iSOChronology9);
//        org.joda.time.Chronology chronology12 = iSOChronology9.withUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology9.hourOfHalfday();
//        org.joda.time.DurationField durationField14 = iSOChronology9.seconds();
//        org.joda.time.DurationFieldType durationFieldType15 = null;
//        try {
//            org.joda.time.field.ScaledDurationField scaledDurationField17 = new org.joda.time.field.ScaledDurationField(durationField14, durationFieldType15, (-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone3);
//        boolean boolean7 = dateTime5.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
//        long long10 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) 24);
//        long long14 = iSOChronology0.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField15 = iSOChronology0.millis();
//        org.joda.time.DurationField durationField16 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone19);
//        boolean boolean23 = dateTime21.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
//        org.joda.time.DateTime dateTime25 = dateTime21.toDateTime();
//        org.joda.time.DateTime.Property property26 = dateTime25.era();
//        org.joda.time.DateTime.Property property27 = dateTime25.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder18.appendFraction(dateTimeFieldType28, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType28, (int) (byte) 10);
//        org.joda.time.DurationField durationField37 = dividedDateTimeField36.getRangeDurationField();
//        int int39 = dividedDateTimeField36.getMaximumValue((long) 20);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeUtils.getZone(dateTimeZone42);
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(dateTimeZone42);
//        boolean boolean46 = dateTime44.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate47 = dateTime44.toLocalDate();
//        java.lang.String str48 = dateTimeFormatter41.print((org.joda.time.ReadablePartial) localDate47);
//        java.lang.String str49 = dateTimeFormatter40.print((org.joda.time.ReadablePartial) localDate47);
//        java.util.Locale locale51 = null;
//        java.lang.String str52 = dividedDateTimeField36.getAsText((org.joda.time.ReadablePartial) localDate47, 0, locale51);
//        java.util.Locale locale53 = null;
//        int int54 = dividedDateTimeField36.getMaximumTextLength(locale53);
//        try {
//            long long56 = dividedDateTimeField36.roundHalfFloor(31L);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for clockhourOfHalfday must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560639600024L + "'", long10 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560639610124L + "'", long14 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertNotNull(dateTimeFormatter41);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(localDate47);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "2019-06-15T��:��:��.000" + "'", str48.equals("2019-06-15T��:��:��.000"));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "��" + "'", str49.equals("��"));
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "0" + "'", str52.equals("0"));
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
//        boolean boolean5 = dateTime3.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
//        int int7 = dateTime3.getDayOfWeek();
//        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
//        boolean boolean9 = dateTime3.isSupported(dateTimeFieldType8);
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.era();
//        org.joda.time.DateTime dateTime12 = dateTime3.withChronology((org.joda.time.Chronology) iSOChronology10);
//        org.joda.time.DurationField durationField13 = iSOChronology10.seconds();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(2490L, (org.joda.time.Chronology) iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(durationField13);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        try {
            long long2 = org.joda.time.field.FieldUtils.safeMultiply((-1036795680000000L), 52630);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The calculation caused an overflow: -1036795680000000 * 52630");
        } catch (java.lang.ArithmeticException e) {
        }
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
//        boolean boolean4 = dateTime2.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
//        org.joda.time.DateTime.Property property6 = dateTime2.millisOfSecond();
//        int int7 = dateTime2.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone8);
//        int int11 = dateTime10.getWeekOfWeekyear();
//        boolean boolean12 = dateTime2.equals((java.lang.Object) dateTime10);
//        org.joda.time.DateTime dateTime14 = dateTime10.plusHours((int) (byte) -1);
//        try {
//            org.joda.time.DateTime dateTime16 = dateTime10.withMonthOfYear(2000);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (byte) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone3);
//        boolean boolean7 = dateTime5.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
//        long long10 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) 24);
//        long long14 = iSOChronology0.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField15 = iSOChronology0.millis();
//        org.joda.time.DurationField durationField16 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone19);
//        boolean boolean23 = dateTime21.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
//        org.joda.time.DateTime dateTime25 = dateTime21.toDateTime();
//        org.joda.time.DateTime.Property property26 = dateTime25.era();
//        org.joda.time.DateTime.Property property27 = dateTime25.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder18.appendFraction(dateTimeFieldType28, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType28, (int) (byte) 10);
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = dividedDateTimeField36.getAsShortText(1560634619050L, locale38);
//        java.util.Locale locale41 = null;
//        java.lang.String str42 = dividedDateTimeField36.getAsText((int) (short) -1, locale41);
//        int int43 = dividedDateTimeField36.getDivisor();
//        boolean boolean44 = dividedDateTimeField36.isLenient();
//        int int45 = dividedDateTimeField36.getDivisor();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560639600024L + "'", long10 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560639610124L + "'", long14 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "-1" + "'", str42.equals("-1"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 10 + "'", int43 == 10);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 10 + "'", int45 == 10);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DateTime dateTime9 = property6.addToCopy((int) (byte) 100);
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTimeISO();
        boolean boolean12 = dateTime9.equals((java.lang.Object) 1.0f);
        org.joda.time.DateTime dateTime14 = dateTime9.plusWeeks(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime();
        org.joda.time.DateMidnight dateMidnight7 = dateTime2.toDateMidnight();
        org.joda.time.DateTime dateTime9 = dateTime2.withMillis((long) 14);
        org.joda.time.DateTime dateTime11 = dateTime2.minusWeeks(24);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateMidnight7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray6 = iSOChronology0.get(readablePeriod3, 999L, (long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(2490, 35, 23999999);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2490 + "'", int3 == 2490);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
        org.joda.time.DateTime dateTime8 = dateTime2.minusMonths((int) 'a');
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        org.joda.time.DateTime dateTime11 = property9.setCopy((int) '#');
        org.joda.time.DateTime dateTime13 = property9.addToCopy(19);
        org.joda.time.DateTime dateTime14 = dateTime13.toDateTime();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
        org.joda.time.DateTime dateTime8 = dateTime2.minusMonths((int) 'a');
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        org.joda.time.DateTime dateTime11 = property9.setCopy((int) '#');
        org.joda.time.DateTime dateTime13 = property9.addToCopy(19);
        org.joda.time.DateTime.Property property14 = dateTime13.weekyear();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.plus(readablePeriod15);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
//        boolean boolean5 = dateTime3.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
//        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime();
//        org.joda.time.DateTime.Property property8 = dateTime7.era();
//        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType10, 24, 10);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology15 = iSOChronology14.withUTC();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone17);
//        boolean boolean21 = dateTime19.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate22 = dateTime19.toLocalDate();
//        long long24 = iSOChronology14.set((org.joda.time.ReadablePartial) localDate22, (long) 24);
//        long long28 = iSOChronology14.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField29 = iSOChronology14.millis();
//        org.joda.time.DurationField durationField30 = iSOChronology14.years();
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology14.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeUtils.getZone(dateTimeZone33);
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone33);
//        boolean boolean37 = dateTime35.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate38 = dateTime35.toLocalDate();
//        org.joda.time.DateTime dateTime39 = dateTime35.toDateTime();
//        org.joda.time.DateTime.Property property40 = dateTime39.era();
//        org.joda.time.DateTime.Property property41 = dateTime39.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property41.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder32.appendFraction(dateTimeFieldType42, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField50 = new org.joda.time.field.DividedDateTimeField(dateTimeField31, dateTimeFieldType42, (int) (byte) 10);
//        org.joda.time.DurationField durationField51 = dividedDateTimeField50.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField52 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField51);
//        java.util.Locale locale53 = null;
//        try {
//            int int54 = unsupportedDateTimeField52.getMaximumShortTextLength(locale53);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560639600024L + "'", long24 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560639610124L + "'", long28 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(durationField51);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField52);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean5 = dateTime3.isBefore((long) (-1));
        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType10, 24, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder0.appendHourOfHalfday(877);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder15.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder16.appendYearOfCentury(0, 2);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone3);
//        boolean boolean7 = dateTime5.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
//        long long10 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) 24);
//        long long14 = iSOChronology0.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField15 = iSOChronology0.millis();
//        org.joda.time.DurationField durationField16 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone19);
//        boolean boolean23 = dateTime21.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
//        org.joda.time.DateTime dateTime25 = dateTime21.toDateTime();
//        org.joda.time.DateTime.Property property26 = dateTime25.era();
//        org.joda.time.DateTime.Property property27 = dateTime25.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder18.appendFraction(dateTimeFieldType28, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType28, (int) (byte) 10);
//        org.joda.time.DurationField durationField37 = dividedDateTimeField36.getRangeDurationField();
//        java.lang.String str39 = dividedDateTimeField36.getAsShortText(101L);
//        org.joda.time.DurationField durationField40 = dividedDateTimeField36.getLeapDurationField();
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeUtils.getZone(dateTimeZone41);
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(dateTimeZone41);
//        boolean boolean45 = dateTime43.isBefore((long) (-1));
//        org.joda.time.DateTime dateTime47 = dateTime43.plusMillis((int) (byte) 10);
//        org.joda.time.DateTime dateTime49 = dateTime43.minusMonths((int) 'a');
//        org.joda.time.LocalDate localDate50 = dateTime43.toLocalDate();
//        int int51 = dividedDateTimeField36.getMaximumValue((org.joda.time.ReadablePartial) localDate50);
//        boolean boolean52 = dividedDateTimeField36.isLenient();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560639600024L + "'", long10 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560639610124L + "'", long14 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
//        org.junit.Assert.assertNull(durationField40);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(localDate50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
//        boolean boolean4 = dateTime2.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
//        int int6 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
//        java.util.Date date9 = dateTime2.toDate();
//        org.joda.time.DateTime dateTime11 = dateTime2.minusMonths((int) (byte) -1);
//        org.joda.time.DateTime dateTime12 = dateTime2.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime.Property property13 = dateTime2.weekyear();
//        org.joda.time.DateTime dateTime15 = property13.addWrapFieldToCopy(0);
//        org.joda.time.DateTime dateTime17 = dateTime15.withMinuteOfHour(7);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(10L);
//        java.lang.String str4 = dateTimeZone1.getID();
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str6 = dateTimeZone1.toString();
//        long long9 = dateTimeZone1.convertLocalToUTC((long) 8, true);
//        java.lang.String str10 = dateTimeZone1.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "America/Los_Angeles" + "'", str4.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "America/Los_Angeles" + "'", str6.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28800008L + "'", long9 == 28800008L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "America/Los_Angeles" + "'", str10.equals("America/Los_Angeles"));
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
        org.joda.time.DateTime dateTime8 = dateTime2.minusMonths((int) 'a');
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        org.joda.time.DateTime dateTime11 = dateTime8.plusMonths((int) (byte) 0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfEra();
        org.joda.time.DateTime dateTime13 = dateTime11.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.halfdayOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology3 = iSOChronology2.withUTC();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone5);
//        boolean boolean9 = dateTime7.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate10 = dateTime7.toLocalDate();
//        long long12 = iSOChronology2.set((org.joda.time.ReadablePartial) localDate10, (long) 24);
//        long long16 = iSOChronology2.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField17 = iSOChronology2.millis();
//        org.joda.time.DurationField durationField18 = iSOChronology2.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology2.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone21);
//        boolean boolean25 = dateTime23.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate26 = dateTime23.toLocalDate();
//        org.joda.time.DateTime dateTime27 = dateTime23.toDateTime();
//        org.joda.time.DateTime.Property property28 = dateTime27.era();
//        org.joda.time.DateTime.Property property29 = dateTime27.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder20.appendFraction(dateTimeFieldType30, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField(dateTimeField19, dateTimeFieldType30, (int) (byte) 10);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField1, dateTimeFieldType30);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeUtils.getZone(dateTimeZone41);
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(dateTimeZone41);
//        boolean boolean45 = dateTime43.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate46 = dateTime43.toLocalDate();
//        java.lang.String str47 = dateTimeFormatter40.print((org.joda.time.ReadablePartial) localDate46);
//        int[] intArray53 = new int[] { (byte) 1, 15, 6, 'a', 'a' };
//        int int54 = zeroIsMaxDateTimeField39.getMaximumValue((org.joda.time.ReadablePartial) localDate46, intArray53);
//        int int56 = zeroIsMaxDateTimeField39.getMinimumValue((long) (short) -1);
//        long long58 = zeroIsMaxDateTimeField39.roundCeiling((long) 15);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560639600024L + "'", long12 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560639610124L + "'", long16 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "2019-06-15T��:��:��.000" + "'", str47.equals("2019-06-15T��:��:��.000"));
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2 + "'", int54 == 2);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 43200000L + "'", long58 == 43200000L);
//    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
//        boolean boolean4 = dateTime2.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
//        int int6 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone7);
//        boolean boolean11 = dateTime9.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate12 = dateTime9.toLocalDate();
//        org.joda.time.DateTime dateTime13 = dateTime9.toDateTime();
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime2, (org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime9.toDateTime();
//        org.joda.time.DateTime dateTime17 = dateTime9.withWeekyear((-16));
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfSecond();
        int int7 = property6.getMaximumValueOverall();
        org.joda.time.DateTime dateTime8 = property6.withMinimumValue();
        org.joda.time.DateTime dateTime10 = dateTime8.plusHours(47);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 999 + "'", int7 == 999);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean5 = dateTime3.isBefore((long) (-1));
        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType10, 24, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendLiteral('4');
        boolean boolean16 = dateTimeFormatterBuilder13.canBuildParser();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap17 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder13.appendTimeZoneShortName(strMap17);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap19 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder13.appendTimeZoneShortName(strMap19);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
//        boolean boolean5 = dateTime3.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
//        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime();
//        org.joda.time.DateTime.Property property8 = dateTime7.era();
//        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType10, 24, 10);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology15 = iSOChronology14.withUTC();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone17);
//        boolean boolean21 = dateTime19.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate22 = dateTime19.toLocalDate();
//        long long24 = iSOChronology14.set((org.joda.time.ReadablePartial) localDate22, (long) 24);
//        long long28 = iSOChronology14.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField29 = iSOChronology14.millis();
//        org.joda.time.DurationField durationField30 = iSOChronology14.years();
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology14.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeUtils.getZone(dateTimeZone33);
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone33);
//        boolean boolean37 = dateTime35.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate38 = dateTime35.toLocalDate();
//        org.joda.time.DateTime dateTime39 = dateTime35.toDateTime();
//        org.joda.time.DateTime.Property property40 = dateTime39.era();
//        org.joda.time.DateTime.Property property41 = dateTime39.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property41.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder32.appendFraction(dateTimeFieldType42, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField50 = new org.joda.time.field.DividedDateTimeField(dateTimeField31, dateTimeFieldType42, (int) (byte) 10);
//        org.joda.time.DurationField durationField51 = dividedDateTimeField50.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField52 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField51);
//        int int55 = unsupportedDateTimeField52.getDifference((long) (byte) -1, 1560664800024L);
//        try {
//            java.lang.String str57 = unsupportedDateTimeField52.getAsShortText((-62134790821965L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560639600024L + "'", long24 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560639610124L + "'", long28 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(durationField51);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField52);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-36126) + "'", int55 == (-36126));
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
//        boolean boolean4 = dateTime2.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
//        int int6 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
//        java.util.Date date9 = dateTime2.toDate();
//        org.joda.time.DateTime dateTime11 = dateTime2.minusMinutes((-1));
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime14 = dateTime11.withPeriodAdded(readablePeriod12, 19);
//        int int15 = dateTime14.getDayOfMonth();
//        org.joda.time.DateTime.Property property16 = dateTime14.yearOfCentury();
//        org.joda.time.DateTime.Property property17 = dateTime14.era();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(property17);
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone3);
//        boolean boolean7 = dateTime5.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
//        long long10 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) 24);
//        long long14 = iSOChronology0.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField15 = iSOChronology0.millis();
//        org.joda.time.DurationField durationField16 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone19);
//        boolean boolean23 = dateTime21.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
//        org.joda.time.DateTime dateTime25 = dateTime21.toDateTime();
//        org.joda.time.DateTime.Property property26 = dateTime25.era();
//        org.joda.time.DateTime.Property property27 = dateTime25.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder18.appendFraction(dateTimeFieldType28, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType28, (int) (byte) 10);
//        org.joda.time.DurationField durationField37 = dividedDateTimeField36.getRangeDurationField();
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeUtils.getZone(dateTimeZone38);
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(dateTimeZone38);
//        boolean boolean42 = dateTime40.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate43 = dateTime40.toLocalDate();
//        org.joda.time.DateTime.Property property44 = dateTime40.millisOfSecond();
//        org.joda.time.DateTime.Property property45 = dateTime40.secondOfDay();
//        org.joda.time.LocalDate localDate46 = dateTime40.toLocalDate();
//        java.util.Locale locale48 = null;
//        java.lang.String str49 = dividedDateTimeField36.getAsShortText((org.joda.time.ReadablePartial) localDate46, (int) (short) 0, locale48);
//        org.joda.time.DateTimeFieldType dateTimeFieldType50 = dividedDateTimeField36.getType();
//        int int51 = dividedDateTimeField36.getDivisor();
//        try {
//            long long54 = dividedDateTimeField36.set((long) 8, (int) '4');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for yearOfEra must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560639600024L + "'", long10 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560639610124L + "'", long14 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "0" + "'", str49.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 10 + "'", int51 == 10);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 6);
        org.joda.time.Chronology chronology5 = gregorianChronology4.withUTC();
        org.joda.time.DurationField durationField6 = gregorianChronology4.hours();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone8);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        java.lang.String str11 = dateTimeZone8.getID();
        org.joda.time.Chronology chronology12 = gregorianChronology4.withZone(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology4.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology4.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "America/Los_Angeles" + "'", str11.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
        org.joda.time.DateTime dateTime8 = dateTime2.minusMonths((int) 'a');
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        org.joda.time.DateTime dateTime11 = property9.setCopy((int) '#');
        org.joda.time.DateTime dateTime13 = property9.addToCopy(19);
        org.joda.time.DateTime dateTime15 = property9.addWrapFieldToCopy((int) 'a');
        org.joda.time.DateTime dateTime16 = property9.withMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone2);
//        boolean boolean6 = dateTime4.isBefore((long) (-1));
//        org.joda.time.DateTime dateTime8 = dateTime4.plusMillis(24);
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendClockhourOfDay((int) 'a');
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap13 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendTimeZoneName(strMap13);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder12.appendMinuteOfHour(10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendHalfdayOfDayText();
//        boolean boolean18 = property9.equals((java.lang.Object) dateTimeFormatterBuilder16);
//        org.joda.time.DateTime dateTime19 = property9.roundHalfCeilingCopy();
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone20);
//        boolean boolean24 = dateTime22.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate25 = dateTime22.toLocalDate();
//        org.joda.time.DateTime.Property property26 = dateTime22.millisOfSecond();
//        int int27 = dateTime22.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone28);
//        int int31 = dateTime30.getWeekOfWeekyear();
//        boolean boolean32 = dateTime22.equals((java.lang.Object) dateTime30);
//        org.joda.time.DateTime dateTime34 = dateTime30.plusHours((int) (byte) -1);
//        org.joda.time.DateTime.Property property35 = dateTime30.secondOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.ISODateTimeFormat.yearMonth();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeUtils.getZone(dateTimeZone37);
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime(dateTimeZone37);
//        boolean boolean41 = dateTime39.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate42 = dateTime39.toLocalDate();
//        java.lang.String str43 = dateTimeFormatter36.print((org.joda.time.ReadableInstant) dateTime39);
//        org.joda.time.DateTime dateTime45 = dateTime39.withDayOfMonth(8);
//        int int46 = dateTime30.compareTo((org.joda.time.ReadableInstant) dateTime45);
//        int int47 = property9.getDifference((org.joda.time.ReadableInstant) dateTime45);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime45);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 12 + "'", int27 == 12);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 24 + "'", int31 == 24);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTimeFormatter36);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(localDate42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "2019-06" + "'", str43.equals("2019-06"));
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(10L);
//        java.lang.String str4 = dateTimeZone1.getID();
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str6 = dateTimeZone1.toString();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone7);
//        boolean boolean11 = dateTime9.isBefore((long) (-1));
//        org.joda.time.DateTime dateTime13 = dateTime9.plusMillis((int) (byte) 10);
//        org.joda.time.DateTime dateTime15 = dateTime9.minusMonths((int) 'a');
//        org.joda.time.DateTime.Property property16 = dateTime15.millisOfDay();
//        org.joda.time.DateTime dateTime18 = property16.setCopy((int) '#');
//        org.joda.time.DateTime dateTime20 = dateTime18.withYear(3);
//        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
//        boolean boolean22 = dateTimeZone1.isLocalDateTimeGap(localDateTime21);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "America/Los_Angeles" + "'", str4.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "America/Los_Angeles" + "'", str6.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(localDateTime21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis(24);
        org.joda.time.DateTime.Property property7 = dateTime6.year();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendClockhourOfDay((int) 'a');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap11 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendTimeZoneName(strMap11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendMinuteOfHour(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendHalfdayOfDayText();
        boolean boolean16 = property7.equals((java.lang.Object) dateTimeFormatterBuilder14);
        org.joda.time.DateTime dateTime17 = property7.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime19 = dateTime17.withYearOfEra(35);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfSecond();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime2.minus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        org.joda.time.DateTime dateTime11 = property9.addWrapFieldToCopy(15);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.halfdayOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology3 = iSOChronology2.withUTC();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone5);
//        boolean boolean9 = dateTime7.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate10 = dateTime7.toLocalDate();
//        long long12 = iSOChronology2.set((org.joda.time.ReadablePartial) localDate10, (long) 24);
//        long long16 = iSOChronology2.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField17 = iSOChronology2.millis();
//        org.joda.time.DurationField durationField18 = iSOChronology2.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology2.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone21);
//        boolean boolean25 = dateTime23.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate26 = dateTime23.toLocalDate();
//        org.joda.time.DateTime dateTime27 = dateTime23.toDateTime();
//        org.joda.time.DateTime.Property property28 = dateTime27.era();
//        org.joda.time.DateTime.Property property29 = dateTime27.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder20.appendFraction(dateTimeFieldType30, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField(dateTimeField19, dateTimeFieldType30, (int) (byte) 10);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField1, dateTimeFieldType30);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeUtils.getZone(dateTimeZone41);
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(dateTimeZone41);
//        boolean boolean45 = dateTime43.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate46 = dateTime43.toLocalDate();
//        java.lang.String str47 = dateTimeFormatter40.print((org.joda.time.ReadablePartial) localDate46);
//        int[] intArray53 = new int[] { (byte) 1, 15, 6, 'a', 'a' };
//        int int54 = zeroIsMaxDateTimeField39.getMaximumValue((org.joda.time.ReadablePartial) localDate46, intArray53);
//        java.util.Locale locale55 = null;
//        int int56 = zeroIsMaxDateTimeField39.getMaximumShortTextLength(locale55);
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = zeroIsMaxDateTimeField39.getType();
//        try {
//            long long60 = zeroIsMaxDateTimeField39.set(1116052630L, 8);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 8 for yearOfEra must be in the range [1,2]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560639600024L + "'", long12 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560639610124L + "'", long16 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "2019-06-15T��:��:��.000" + "'", str47.equals("2019-06-15T��:��:��.000"));
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2 + "'", int54 == 2);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType57);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis(24);
        try {
            org.joda.time.DateTime dateTime8 = dateTime6.withDayOfWeek((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean5 = dateTime3.isBefore((long) (-1));
        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType10, 24, 10);
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter17 = dateTimeFormatter16.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder13.append(dateTimePrinter17);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimePrinter17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean5 = dateTime3.isBefore((long) (-1));
        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType10, 24, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder0.appendHourOfHalfday(877);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder0.appendSecondOfMinute(877);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendFractionOfDay(44, 2);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
//        boolean boolean4 = dateTime2.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
//        org.joda.time.DateTime.Property property6 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime7 = property6.getDateTime();
//        java.util.Locale locale8 = null;
//        java.lang.String str9 = property6.getAsText(locale8);
//        org.joda.time.DateTime dateTime11 = property6.setCopy((int) '4');
//        org.joda.time.DateTime dateTime13 = property6.addToCopy((long) (byte) 100);
//        org.joda.time.DateTime dateTime15 = dateTime13.plusDays(124);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "754" + "'", str9.equals("754"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.halfdayOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology3 = iSOChronology2.withUTC();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone5);
//        boolean boolean9 = dateTime7.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate10 = dateTime7.toLocalDate();
//        long long12 = iSOChronology2.set((org.joda.time.ReadablePartial) localDate10, (long) 24);
//        long long16 = iSOChronology2.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField17 = iSOChronology2.millis();
//        org.joda.time.DurationField durationField18 = iSOChronology2.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology2.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone21);
//        boolean boolean25 = dateTime23.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate26 = dateTime23.toLocalDate();
//        org.joda.time.DateTime dateTime27 = dateTime23.toDateTime();
//        org.joda.time.DateTime.Property property28 = dateTime27.era();
//        org.joda.time.DateTime.Property property29 = dateTime27.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder20.appendFraction(dateTimeFieldType30, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField(dateTimeField19, dateTimeFieldType30, (int) (byte) 10);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField1, dateTimeFieldType30);
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeUtils.getZone(dateTimeZone40);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone40);
//        boolean boolean44 = dateTime42.isBefore((long) (-1));
//        org.joda.time.DateTime dateTime46 = dateTime42.plusMillis((int) (byte) 10);
//        org.joda.time.DateTime dateTime48 = dateTime42.minusMonths((int) 'a');
//        org.joda.time.LocalDate localDate49 = dateTime42.toLocalDate();
//        int int50 = zeroIsMaxDateTimeField39.getMinimumValue((org.joda.time.ReadablePartial) localDate49);
//        org.joda.time.DateTimeField dateTimeField51 = zeroIsMaxDateTimeField39.getWrappedField();
//        long long54 = zeroIsMaxDateTimeField39.getDifferenceAsLong(1560639600024L, 28800132L);
//        long long57 = zeroIsMaxDateTimeField39.getDifferenceAsLong((long) (short) 1, 0L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560639600024L + "'", long12 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560639610124L + "'", long16 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(localDate49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 36125L + "'", long54 == 36125L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
//    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone3);
//        boolean boolean7 = dateTime5.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
//        long long10 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) 24);
//        long long14 = iSOChronology0.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField15 = iSOChronology0.millis();
//        org.joda.time.DurationField durationField16 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone19);
//        boolean boolean23 = dateTime21.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
//        org.joda.time.DateTime dateTime25 = dateTime21.toDateTime();
//        org.joda.time.DateTime.Property property26 = dateTime25.era();
//        org.joda.time.DateTime.Property property27 = dateTime25.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder18.appendFraction(dateTimeFieldType28, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType28, (int) (byte) 10);
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = dividedDateTimeField36.getAsShortText(1560634619050L, locale38);
//        org.joda.time.DurationField durationField40 = dividedDateTimeField36.getDurationField();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560639600024L + "'", long10 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560639610124L + "'", long14 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
//        org.junit.Assert.assertNotNull(durationField40);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DateTime dateTime8 = property6.getDateTime();
        org.joda.time.DateTime.Property property9 = dateTime8.dayOfMonth();
        int int10 = dateTime8.getYearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DurationField durationField8 = property6.getLeapDurationField();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone9);
        boolean boolean13 = dateTime11.isBefore((long) (-1));
        org.joda.time.DateTime dateTime15 = dateTime11.plusMillis((int) (byte) 10);
        org.joda.time.DateTime dateTime17 = dateTime11.minusMonths((int) 'a');
        org.joda.time.DateTime.Property property18 = dateTime17.millisOfDay();
        org.joda.time.DateTime dateTime20 = property18.setCopy((int) '#');
        org.joda.time.DateTime.Property property21 = dateTime20.hourOfDay();
        int int22 = property6.compareTo((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime dateTime24 = dateTime20.minusWeeks((-1));
        org.joda.time.DateTime.Property property25 = dateTime24.yearOfEra();
        org.joda.time.DateTime dateTime26 = property25.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime26);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
//        boolean boolean5 = dateTime3.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
//        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime();
//        org.joda.time.DateTime.Property property8 = dateTime7.era();
//        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType10, 24, 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        org.joda.time.format.DateTimePrinter dateTimePrinter15 = dateTimeFormatter14.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.append(dateTimePrinter15);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendMonthOfYearText();
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology19 = iSOChronology18.withUTC();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology18.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone21);
//        boolean boolean25 = dateTime23.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate26 = dateTime23.toLocalDate();
//        long long28 = iSOChronology18.set((org.joda.time.ReadablePartial) localDate26, (long) 24);
//        long long32 = iSOChronology18.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField33 = iSOChronology18.millis();
//        org.joda.time.DurationField durationField34 = iSOChronology18.years();
//        org.joda.time.DateTimeField dateTimeField35 = iSOChronology18.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeUtils.getZone(dateTimeZone37);
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime(dateTimeZone37);
//        boolean boolean41 = dateTime39.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate42 = dateTime39.toLocalDate();
//        org.joda.time.DateTime dateTime43 = dateTime39.toDateTime();
//        org.joda.time.DateTime.Property property44 = dateTime43.era();
//        org.joda.time.DateTime.Property property45 = dateTime43.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder36.appendFraction(dateTimeFieldType46, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException52 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType46, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField54 = new org.joda.time.field.DividedDateTimeField(dateTimeField35, dateTimeFieldType46, (int) (byte) 10);
//        org.joda.time.DurationField durationField55 = dividedDateTimeField54.getRangeDurationField();
//        org.joda.time.DateTimeZone dateTimeZone56 = null;
//        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeUtils.getZone(dateTimeZone56);
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime(dateTimeZone56);
//        boolean boolean60 = dateTime58.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate61 = dateTime58.toLocalDate();
//        org.joda.time.DateTime.Property property62 = dateTime58.millisOfSecond();
//        org.joda.time.DateTime.Property property63 = dateTime58.secondOfDay();
//        org.joda.time.LocalDate localDate64 = dateTime58.toLocalDate();
//        java.util.Locale locale66 = null;
//        java.lang.String str67 = dividedDateTimeField54.getAsShortText((org.joda.time.ReadablePartial) localDate64, (int) (short) 0, locale66);
//        org.joda.time.DateTimeFieldType dateTimeFieldType68 = dividedDateTimeField54.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder71 = dateTimeFormatterBuilder17.appendSignedDecimal(dateTimeFieldType68, 35, (-3));
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimePrinter15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560639600024L + "'", long28 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560639610124L + "'", long32 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(localDate42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
//        org.junit.Assert.assertNotNull(durationField55);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(localDate61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertNotNull(property63);
//        org.junit.Assert.assertNotNull(localDate64);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "0" + "'", str67.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType68);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder71);
//    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.halfdayOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology3 = iSOChronology2.withUTC();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone5);
//        boolean boolean9 = dateTime7.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate10 = dateTime7.toLocalDate();
//        long long12 = iSOChronology2.set((org.joda.time.ReadablePartial) localDate10, (long) 24);
//        long long16 = iSOChronology2.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField17 = iSOChronology2.millis();
//        org.joda.time.DurationField durationField18 = iSOChronology2.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology2.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone21);
//        boolean boolean25 = dateTime23.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate26 = dateTime23.toLocalDate();
//        org.joda.time.DateTime dateTime27 = dateTime23.toDateTime();
//        org.joda.time.DateTime.Property property28 = dateTime27.era();
//        org.joda.time.DateTime.Property property29 = dateTime27.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder20.appendFraction(dateTimeFieldType30, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField(dateTimeField19, dateTimeFieldType30, (int) (byte) 10);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField1, dateTimeFieldType30);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeUtils.getZone(dateTimeZone41);
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(dateTimeZone41);
//        boolean boolean45 = dateTime43.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate46 = dateTime43.toLocalDate();
//        java.lang.String str47 = dateTimeFormatter40.print((org.joda.time.ReadablePartial) localDate46);
//        int[] intArray53 = new int[] { (byte) 1, 15, 6, 'a', 'a' };
//        int int54 = zeroIsMaxDateTimeField39.getMaximumValue((org.joda.time.ReadablePartial) localDate46, intArray53);
//        java.util.Locale locale55 = null;
//        int int56 = zeroIsMaxDateTimeField39.getMaximumShortTextLength(locale55);
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = zeroIsMaxDateTimeField39.getType();
//        long long59 = zeroIsMaxDateTimeField39.roundHalfFloor((-70886L));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560639600024L + "'", long12 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560639610124L + "'", long16 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "2019-06-15T��:��:��.000" + "'", str47.equals("2019-06-15T��:��:��.000"));
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2 + "'", int54 == 2);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldType57);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 0L + "'", long59 == 0L);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("14", 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder3.setFixedSavings("2019-06-15T14:37:06.783-07:00", (int) '4');
        java.io.DataOutput dataOutput8 = null;
        try {
            dateTimeZoneBuilder3.writeTo("GregorianChronology[America/Los_Angeles,mdfw=6]", dataOutput8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
//        boolean boolean4 = dateTime2.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
//        int int6 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
//        java.util.Date date9 = dateTime2.toDate();
//        org.joda.time.DateTime dateTime11 = dateTime2.plusYears(1);
//        org.joda.time.DateTime.Property property12 = dateTime2.minuteOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology14 = iSOChronology13.withUTC();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology13.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone16);
//        boolean boolean20 = dateTime18.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate21 = dateTime18.toLocalDate();
//        long long23 = iSOChronology13.set((org.joda.time.ReadablePartial) localDate21, (long) 24);
//        long long27 = iSOChronology13.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField28 = iSOChronology13.millis();
//        org.joda.time.DurationField durationField29 = iSOChronology13.years();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology13.clockhourOfHalfday();
//        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology32 = iSOChronology31.withUTC();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology31.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeUtils.getZone(dateTimeZone34);
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime(dateTimeZone34);
//        boolean boolean38 = dateTime36.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate39 = dateTime36.toLocalDate();
//        long long41 = iSOChronology31.set((org.joda.time.ReadablePartial) localDate39, (long) 24);
//        long long45 = iSOChronology31.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField46 = iSOChronology31.millis();
//        org.joda.time.DurationField durationField47 = iSOChronology31.years();
//        org.joda.time.DateTimeField dateTimeField48 = iSOChronology31.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone50 = null;
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeUtils.getZone(dateTimeZone50);
//        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime(dateTimeZone50);
//        boolean boolean54 = dateTime52.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate55 = dateTime52.toLocalDate();
//        org.joda.time.DateTime dateTime56 = dateTime52.toDateTime();
//        org.joda.time.DateTime.Property property57 = dateTime56.era();
//        org.joda.time.DateTime.Property property58 = dateTime56.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType59 = property58.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder49.appendFraction(dateTimeFieldType59, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException65 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType59, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField67 = new org.joda.time.field.DividedDateTimeField(dateTimeField48, dateTimeFieldType59, (int) (byte) 10);
//        org.joda.time.DurationField durationField68 = dividedDateTimeField67.getRangeDurationField();
//        java.lang.String str70 = dividedDateTimeField67.getAsShortText(101L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter71 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter72 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.DateTimeZone dateTimeZone73 = null;
//        org.joda.time.DateTimeZone dateTimeZone74 = org.joda.time.DateTimeUtils.getZone(dateTimeZone73);
//        org.joda.time.DateTime dateTime75 = new org.joda.time.DateTime(dateTimeZone73);
//        boolean boolean77 = dateTime75.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate78 = dateTime75.toLocalDate();
//        java.lang.String str79 = dateTimeFormatter72.print((org.joda.time.ReadablePartial) localDate78);
//        java.lang.String str80 = dateTimeFormatter71.print((org.joda.time.ReadablePartial) localDate78);
//        int int81 = dividedDateTimeField67.getMaximumValue((org.joda.time.ReadablePartial) localDate78);
//        long long83 = iSOChronology13.set((org.joda.time.ReadablePartial) localDate78, (long) (-36126));
//        try {
//            org.joda.time.DateTime dateTime84 = new org.joda.time.DateTime((java.lang.Object) property12, (org.joda.time.Chronology) iSOChronology13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.DateTime$Property");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560639600024L + "'", long23 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560639610124L + "'", long27 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(iSOChronology31);
//        org.junit.Assert.assertNotNull(chronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560639600024L + "'", long41 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560639610124L + "'", long45 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField46);
//        org.junit.Assert.assertNotNull(durationField47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTimeFieldType59);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
//        org.junit.Assert.assertNotNull(durationField68);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "0" + "'", str70.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter71);
//        org.junit.Assert.assertNotNull(dateTimeFormatter72);
//        org.junit.Assert.assertNotNull(dateTimeZone74);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertNotNull(localDate78);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "2019-06-15T��:��:��.000" + "'", str79.equals("2019-06-15T��:��:��.000"));
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "��" + "'", str80.equals("��"));
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 1560639563874L + "'", long83 == 1560639563874L);
//    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
//        boolean boolean4 = dateTime2.isBefore((long) (-1));
//        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
//        org.joda.time.DateTime dateTime8 = dateTime2.minusMonths((int) 'a');
//        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
//        org.joda.time.DateTime dateTime11 = property9.setCopy((int) '#');
//        int int12 = dateTime11.getWeekOfWeekyear();
//        org.joda.time.DateTime.Property property13 = dateTime11.hourOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology15 = iSOChronology14.withUTC();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(chronology15);
//        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime.Property property18 = dateTime16.centuryOfEra();
//        int int19 = property13.compareTo((org.joda.time.ReadableInstant) dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(chronology17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone3);
//        boolean boolean7 = dateTime5.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
//        long long10 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) 24);
//        long long14 = iSOChronology0.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField15 = iSOChronology0.millis();
//        org.joda.time.DurationField durationField16 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone19);
//        boolean boolean23 = dateTime21.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
//        org.joda.time.DateTime dateTime25 = dateTime21.toDateTime();
//        org.joda.time.DateTime.Property property26 = dateTime25.era();
//        org.joda.time.DateTime.Property property27 = dateTime25.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder18.appendFraction(dateTimeFieldType28, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType28, (int) (byte) 10);
//        java.util.Locale locale37 = null;
//        int int38 = dividedDateTimeField36.getMaximumShortTextLength(locale37);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560639600024L + "'", long10 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560639610124L + "'", long14 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
//        boolean boolean4 = dateTime2.isBefore((long) (-1));
//        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis(24);
//        org.joda.time.DateTime.Property property7 = dateTime6.year();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendClockhourOfDay((int) 'a');
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap11 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendTimeZoneName(strMap11);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendMinuteOfHour(10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendHalfdayOfDayText();
//        boolean boolean16 = property7.equals((java.lang.Object) dateTimeFormatterBuilder14);
//        org.joda.time.DateTime dateTime17 = property7.roundHalfCeilingCopy();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone18);
//        boolean boolean22 = dateTime20.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate23 = dateTime20.toLocalDate();
//        org.joda.time.DateTime.Property property24 = dateTime20.millisOfSecond();
//        int int25 = dateTime20.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone26 = null;
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeUtils.getZone(dateTimeZone26);
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(dateTimeZone26);
//        int int29 = dateTime28.getWeekOfWeekyear();
//        boolean boolean30 = dateTime20.equals((java.lang.Object) dateTime28);
//        org.joda.time.DateTime dateTime32 = dateTime28.plusHours((int) (byte) -1);
//        org.joda.time.DateTime.Property property33 = dateTime28.secondOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.yearMonth();
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeUtils.getZone(dateTimeZone35);
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone35);
//        boolean boolean39 = dateTime37.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate40 = dateTime37.toLocalDate();
//        java.lang.String str41 = dateTimeFormatter34.print((org.joda.time.ReadableInstant) dateTime37);
//        org.joda.time.DateTime dateTime43 = dateTime37.withDayOfMonth(8);
//        int int44 = dateTime28.compareTo((org.joda.time.ReadableInstant) dateTime43);
//        int int45 = property7.getDifference((org.joda.time.ReadableInstant) dateTime43);
//        try {
//            org.joda.time.DateTime dateTime50 = dateTime43.withTime((-6), (int) (short) 0, 52679099, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -6 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 24 + "'", int29 == 24);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTimeFormatter34);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "2019-06" + "'", str41.equals("2019-06"));
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone3);
//        boolean boolean7 = dateTime5.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
//        long long10 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) 24);
//        long long14 = iSOChronology0.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField15 = iSOChronology0.millis();
//        org.joda.time.DurationField durationField16 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone19);
//        boolean boolean23 = dateTime21.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
//        org.joda.time.DateTime dateTime25 = dateTime21.toDateTime();
//        org.joda.time.DateTime.Property property26 = dateTime25.era();
//        org.joda.time.DateTime.Property property27 = dateTime25.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder18.appendFraction(dateTimeFieldType28, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType28, (int) (byte) 10);
//        org.joda.time.DurationField durationField37 = dividedDateTimeField36.getRangeDurationField();
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeUtils.getZone(dateTimeZone38);
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(dateTimeZone38);
//        boolean boolean42 = dateTime40.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate43 = dateTime40.toLocalDate();
//        org.joda.time.DateTime.Property property44 = dateTime40.millisOfSecond();
//        org.joda.time.DateTime.Property property45 = dateTime40.secondOfDay();
//        org.joda.time.LocalDate localDate46 = dateTime40.toLocalDate();
//        java.util.Locale locale48 = null;
//        java.lang.String str49 = dividedDateTimeField36.getAsShortText((org.joda.time.ReadablePartial) localDate46, (int) (short) 0, locale48);
//        org.joda.time.DateTimeFieldType dateTimeFieldType50 = dividedDateTimeField36.getType();
//        int int51 = dividedDateTimeField36.getDivisor();
//        long long54 = dividedDateTimeField36.addWrapField((long) (short) 1, 4);
//        int int57 = dividedDateTimeField36.getDifference(1L, (long) (short) 1);
//        boolean boolean58 = dividedDateTimeField36.isSupported();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560639600024L + "'", long10 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560639610124L + "'", long14 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "0" + "'", str49.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 10 + "'", int51 == 10);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1L + "'", long54 == 1L);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone3);
//        boolean boolean7 = dateTime5.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
//        long long10 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) 24);
//        long long14 = iSOChronology0.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField15 = iSOChronology0.millis();
//        org.joda.time.DurationField durationField16 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone19);
//        boolean boolean23 = dateTime21.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
//        org.joda.time.DateTime dateTime25 = dateTime21.toDateTime();
//        org.joda.time.DateTime.Property property26 = dateTime25.era();
//        org.joda.time.DateTime.Property property27 = dateTime25.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder18.appendFraction(dateTimeFieldType28, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType28, (int) (byte) 10);
//        org.joda.time.DurationField durationField37 = dividedDateTimeField36.getRangeDurationField();
//        java.lang.String str39 = dividedDateTimeField36.getAsShortText(101L);
//        java.util.Locale locale40 = null;
//        int int41 = dividedDateTimeField36.getMaximumTextLength(locale40);
//        long long44 = dividedDateTimeField36.add(24L, 20);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560639600024L + "'", long10 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560639610124L + "'", long14 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 720000024L + "'", long44 == 720000024L);
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone3);
//        boolean boolean7 = dateTime5.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
//        long long10 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) 24);
//        long long14 = iSOChronology0.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField15 = iSOChronology0.millis();
//        org.joda.time.DurationField durationField16 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone19);
//        boolean boolean23 = dateTime21.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
//        org.joda.time.DateTime dateTime25 = dateTime21.toDateTime();
//        org.joda.time.DateTime.Property property26 = dateTime25.era();
//        org.joda.time.DateTime.Property property27 = dateTime25.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder18.appendFraction(dateTimeFieldType28, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType28, (int) (byte) 10);
//        org.joda.time.DurationField durationField37 = dividedDateTimeField36.getRangeDurationField();
//        int int39 = dividedDateTimeField36.getMaximumValue((long) 20);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeUtils.getZone(dateTimeZone42);
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(dateTimeZone42);
//        boolean boolean46 = dateTime44.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate47 = dateTime44.toLocalDate();
//        java.lang.String str48 = dateTimeFormatter41.print((org.joda.time.ReadablePartial) localDate47);
//        java.lang.String str49 = dateTimeFormatter40.print((org.joda.time.ReadablePartial) localDate47);
//        java.util.Locale locale51 = null;
//        java.lang.String str52 = dividedDateTimeField36.getAsText((org.joda.time.ReadablePartial) localDate47, 0, locale51);
//        try {
//            long long55 = dividedDateTimeField36.set((long) (short) -1, 19);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19 for yearOfEra must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560639600024L + "'", long10 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560639610124L + "'", long14 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertNotNull(dateTimeFormatter41);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(localDate47);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "2019-06-15T��:��:��.000" + "'", str48.equals("2019-06-15T��:��:��.000"));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "��" + "'", str49.equals("��"));
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "0" + "'", str52.equals("0"));
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
//        boolean boolean4 = dateTime2.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
//        org.joda.time.DateTime.Property property6 = dateTime2.millisOfSecond();
//        int int7 = dateTime2.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone8);
//        int int11 = dateTime10.getWeekOfWeekyear();
//        boolean boolean12 = dateTime2.equals((java.lang.Object) dateTime10);
//        org.joda.time.DateTime dateTime14 = dateTime10.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime16 = dateTime14.withWeekyear(35);
//        org.joda.time.DateTime dateTime18 = dateTime14.withYearOfEra(2);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis(24);
        org.joda.time.DateTime.Property property7 = dateTime6.year();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendClockhourOfDay((int) 'a');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap11 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendTimeZoneName(strMap11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendMinuteOfHour(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder14.appendHalfdayOfDayText();
        boolean boolean16 = property7.equals((java.lang.Object) dateTimeFormatterBuilder14);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder14.appendMillisOfDay((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder14.appendLiteral('a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendTwoDigitWeekyear((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder23.appendWeekOfWeekyear((int) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder25.append(dateTimeFormatter26);
        org.joda.time.format.DateTimePrinter dateTimePrinter28 = dateTimeFormatter26.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder20.append(dateTimePrinter28);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder29.appendFractionOfDay(0, 52679099);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimePrinter28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone3);
//        boolean boolean7 = dateTime5.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
//        long long10 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) 24);
//        long long14 = iSOChronology0.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField15 = iSOChronology0.millis();
//        org.joda.time.DurationField durationField16 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone19);
//        boolean boolean23 = dateTime21.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
//        org.joda.time.DateTime dateTime25 = dateTime21.toDateTime();
//        org.joda.time.DateTime.Property property26 = dateTime25.era();
//        org.joda.time.DateTime.Property property27 = dateTime25.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder18.appendFraction(dateTimeFieldType28, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType28, (int) (byte) 10);
//        org.joda.time.DurationField durationField37 = dividedDateTimeField36.getRangeDurationField();
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeUtils.getZone(dateTimeZone38);
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(dateTimeZone38);
//        boolean boolean42 = dateTime40.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate43 = dateTime40.toLocalDate();
//        org.joda.time.DateTime.Property property44 = dateTime40.millisOfSecond();
//        org.joda.time.DateTime.Property property45 = dateTime40.secondOfDay();
//        org.joda.time.LocalDate localDate46 = dateTime40.toLocalDate();
//        java.util.Locale locale48 = null;
//        java.lang.String str49 = dividedDateTimeField36.getAsShortText((org.joda.time.ReadablePartial) localDate46, (int) (short) 0, locale48);
//        org.joda.time.DateTimeFieldType dateTimeFieldType50 = dividedDateTimeField36.getType();
//        int int51 = dividedDateTimeField36.getDivisor();
//        long long54 = dividedDateTimeField36.addWrapField((long) (short) 1, 4);
//        int int57 = dividedDateTimeField36.getDifference(1L, (long) (short) 1);
//        int int59 = dividedDateTimeField36.getMaximumValue((long) 2080);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560639600024L + "'", long10 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560639610124L + "'", long14 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "0" + "'", str49.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 10 + "'", int51 == 10);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1L + "'", long54 == 1L);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone3);
//        boolean boolean7 = dateTime5.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
//        long long10 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) 24);
//        long long14 = iSOChronology0.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField15 = iSOChronology0.millis();
//        long long19 = iSOChronology0.add((long) '#', (long) (byte) -1, 4);
//        java.lang.Object obj20 = null;
//        boolean boolean21 = iSOChronology0.equals(obj20);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560639600024L + "'", long10 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560639610124L + "'", long14 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 31L + "'", long19 == 31L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = iSOChronology0.getZone();
        int int4 = dateTimeZone2.getOffsetFromLocal((-1036795680000000L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-28378000) + "'", int4 == (-28378000));
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
//        boolean boolean4 = dateTime2.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
//        int int6 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.era();
//        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) iSOChronology9);
//        java.lang.String str12 = dateTime11.toString();
//        int int13 = dateTime11.getYearOfEra();
//        int int14 = dateTime11.getMillisOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019-06-15T14:38:16.746-07:00" + "'", str12.equals("2019-06-15T14:38:16.746-07:00"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52696746 + "'", int14 == 52696746);
//    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone3);
//        boolean boolean7 = dateTime5.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
//        long long10 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) 24);
//        long long14 = iSOChronology0.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField15 = iSOChronology0.millis();
//        org.joda.time.DurationField durationField16 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.clockhourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology0.dayOfMonth();
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
//        long long24 = iSOChronology19.getDateTimeMillis((int) (short) 1, (int) (short) 1, (int) (short) 10, (int) '#');
//        org.joda.time.DateTimeField dateTimeField25 = iSOChronology19.dayOfWeek();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeUtils.getZone(dateTimeZone27);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(dateTimeZone27);
//        boolean boolean31 = dateTime29.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
//        int int33 = dateTime29.getDayOfWeek();
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = null;
//        boolean boolean35 = dateTime29.isSupported(dateTimeFieldType34);
//        java.util.Date date36 = dateTime29.toDate();
//        java.lang.String str37 = dateTimeFormatter26.print((org.joda.time.ReadableInstant) dateTime29);
//        int int38 = dateTime29.getDayOfMonth();
//        org.joda.time.DateTime dateTime40 = dateTime29.minus((-25L));
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeUtils.getZone(dateTimeZone42);
//        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(dateTimeZone42);
//        boolean boolean46 = dateTime44.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate47 = dateTime44.toLocalDate();
//        org.joda.time.DateTime dateTime48 = dateTime44.toDateTime();
//        org.joda.time.DateTime.Property property49 = dateTime48.era();
//        org.joda.time.DateTime.Property property50 = dateTime48.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder41.appendFraction(dateTimeFieldType51, 24, 10);
//        int int55 = dateTime40.get(dateTimeFieldType51);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField57 = new org.joda.time.field.RemainderDateTimeField(dateTimeField25, dateTimeFieldType51, 35);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField61 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, dateTimeFieldType51, 50, 44, 7);
//        try {
//            long long64 = offsetDateTimeField61.set((long) 24, 44);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 44 for yearOfEra must be in the range [51,7]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560639600024L + "'", long10 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560639610124L + "'", long14 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-62134790821965L) + "'", long24 == (-62134790821965L));
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "2019166" + "'", str37.equals("2019166"));
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(localDate47);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2019 + "'", int55 == 2019);
//    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone3);
//        boolean boolean7 = dateTime5.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
//        long long10 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) 24);
//        long long14 = iSOChronology0.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField15 = iSOChronology0.millis();
//        org.joda.time.DurationField durationField16 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone19);
//        boolean boolean23 = dateTime21.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
//        org.joda.time.DateTime dateTime25 = dateTime21.toDateTime();
//        org.joda.time.DateTime.Property property26 = dateTime25.era();
//        org.joda.time.DateTime.Property property27 = dateTime25.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder18.appendFraction(dateTimeFieldType28, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType28, (int) (byte) 10);
//        long long39 = dividedDateTimeField36.getDifferenceAsLong((long) (byte) 1, 0L);
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology40.halfdayOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology43 = iSOChronology42.withUTC();
//        org.joda.time.DateTimeField dateTimeField44 = iSOChronology42.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeUtils.getZone(dateTimeZone45);
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(dateTimeZone45);
//        boolean boolean49 = dateTime47.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate50 = dateTime47.toLocalDate();
//        long long52 = iSOChronology42.set((org.joda.time.ReadablePartial) localDate50, (long) 24);
//        long long56 = iSOChronology42.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField57 = iSOChronology42.millis();
//        org.joda.time.DurationField durationField58 = iSOChronology42.years();
//        org.joda.time.DateTimeField dateTimeField59 = iSOChronology42.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone61 = null;
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeUtils.getZone(dateTimeZone61);
//        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime(dateTimeZone61);
//        boolean boolean65 = dateTime63.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate66 = dateTime63.toLocalDate();
//        org.joda.time.DateTime dateTime67 = dateTime63.toDateTime();
//        org.joda.time.DateTime.Property property68 = dateTime67.era();
//        org.joda.time.DateTime.Property property69 = dateTime67.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType70 = property69.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder60.appendFraction(dateTimeFieldType70, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException76 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType70, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField78 = new org.joda.time.field.DividedDateTimeField(dateTimeField59, dateTimeFieldType70, (int) (byte) 10);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField79 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField41, dateTimeFieldType70);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField80 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField36, dateTimeFieldType70);
//        boolean boolean82 = dividedDateTimeField36.isLeap((long) (-3));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560639600024L + "'", long10 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560639610124L + "'", long14 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(iSOChronology42);
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(localDate50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560639600024L + "'", long52 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560639610124L + "'", long56 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField57);
//        org.junit.Assert.assertNotNull(durationField58);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(localDate66);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertNotNull(property69);
//        org.junit.Assert.assertNotNull(dateTimeFieldType70);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean5 = dateTime3.isBefore((long) (-1));
        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType10, 24, 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType10, (java.lang.Number) 10.0f, "1969365");
        org.joda.time.DurationFieldType durationFieldType17 = illegalFieldValueException16.getDurationFieldType();
        java.lang.String str18 = illegalFieldValueException16.getIllegalStringValue();
        org.joda.time.DurationFieldType durationFieldType19 = illegalFieldValueException16.getDurationFieldType();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNull(durationFieldType17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNull(durationFieldType19);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
//        boolean boolean5 = dateTime3.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
//        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime();
//        org.joda.time.DateTime.Property property8 = dateTime7.era();
//        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType10, 24, 10);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology15 = iSOChronology14.withUTC();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone17);
//        boolean boolean21 = dateTime19.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate22 = dateTime19.toLocalDate();
//        long long24 = iSOChronology14.set((org.joda.time.ReadablePartial) localDate22, (long) 24);
//        long long28 = iSOChronology14.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField29 = iSOChronology14.millis();
//        org.joda.time.DurationField durationField30 = iSOChronology14.years();
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology14.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeUtils.getZone(dateTimeZone33);
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone33);
//        boolean boolean37 = dateTime35.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate38 = dateTime35.toLocalDate();
//        org.joda.time.DateTime dateTime39 = dateTime35.toDateTime();
//        org.joda.time.DateTime.Property property40 = dateTime39.era();
//        org.joda.time.DateTime.Property property41 = dateTime39.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property41.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder32.appendFraction(dateTimeFieldType42, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField50 = new org.joda.time.field.DividedDateTimeField(dateTimeField31, dateTimeFieldType42, (int) (byte) 10);
//        org.joda.time.DurationField durationField51 = dividedDateTimeField50.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField52 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField51);
//        try {
//            int int54 = unsupportedDateTimeField52.get(3600000L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560639600024L + "'", long24 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560639610124L + "'", long28 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(durationField51);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField52);
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
//        boolean boolean5 = dateTime3.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
//        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime();
//        org.joda.time.DateTime.Property property8 = dateTime7.era();
//        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType10, 24, 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
//        org.joda.time.format.DateTimePrinter dateTimePrinter15 = dateTimeFormatter14.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.append(dateTimePrinter15);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendMonthOfYearText();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone18);
//        boolean boolean22 = dateTime20.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate23 = dateTime20.toLocalDate();
//        org.joda.time.DateTime.Property property24 = dateTime20.millisOfSecond();
//        java.util.Date date25 = dateTime20.toDate();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeUtils.getZone(dateTimeZone27);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(dateTimeZone27);
//        boolean boolean31 = dateTime29.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate32 = dateTime29.toLocalDate();
//        org.joda.time.DateTime dateTime33 = dateTime29.toDateTime();
//        org.joda.time.DateTime.Property property34 = dateTime33.era();
//        org.joda.time.DateTime.Property property35 = dateTime33.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property35.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder26.appendFraction(dateTimeFieldType36, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.DateTime dateTime44 = dateTime20.withField(dateTimeFieldType36, 24);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, "GregorianChronology[America/Los_Angeles,mdfw=6]");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder16.appendFixedDecimal(dateTimeFieldType36, 6);
//        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology50 = iSOChronology49.withUTC();
//        org.joda.time.DateTimeField dateTimeField51 = iSOChronology49.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone52 = null;
//        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeUtils.getZone(dateTimeZone52);
//        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime(dateTimeZone52);
//        boolean boolean56 = dateTime54.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate57 = dateTime54.toLocalDate();
//        long long59 = iSOChronology49.set((org.joda.time.ReadablePartial) localDate57, (long) 24);
//        long long63 = iSOChronology49.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField64 = iSOChronology49.millis();
//        org.joda.time.DurationField durationField65 = iSOChronology49.years();
//        org.joda.time.DateTimeField dateTimeField66 = iSOChronology49.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone68 = null;
//        org.joda.time.DateTimeZone dateTimeZone69 = org.joda.time.DateTimeUtils.getZone(dateTimeZone68);
//        org.joda.time.DateTime dateTime70 = new org.joda.time.DateTime(dateTimeZone68);
//        boolean boolean72 = dateTime70.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate73 = dateTime70.toLocalDate();
//        org.joda.time.DateTime dateTime74 = dateTime70.toDateTime();
//        org.joda.time.DateTime.Property property75 = dateTime74.era();
//        org.joda.time.DateTime.Property property76 = dateTime74.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType77 = property76.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder80 = dateTimeFormatterBuilder67.appendFraction(dateTimeFieldType77, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException83 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType77, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField85 = new org.joda.time.field.DividedDateTimeField(dateTimeField66, dateTimeFieldType77, (int) (byte) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder86 = dateTimeFormatterBuilder16.appendShortText(dateTimeFieldType77);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder88 = dateTimeFormatterBuilder86.appendTwoDigitYear(7);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTimePrinter15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
//        org.junit.Assert.assertNotNull(iSOChronology49);
//        org.junit.Assert.assertNotNull(chronology50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(localDate57);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560639600024L + "'", long59 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560639610124L + "'", long63 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField64);
//        org.junit.Assert.assertNotNull(durationField65);
//        org.junit.Assert.assertNotNull(dateTimeField66);
//        org.junit.Assert.assertNotNull(dateTimeZone69);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNotNull(localDate73);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(property75);
//        org.junit.Assert.assertNotNull(property76);
//        org.junit.Assert.assertNotNull(dateTimeFieldType77);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder80);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder86);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder88);
//    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
//        boolean boolean4 = dateTime2.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
//        int int6 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone7 = null;
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone7);
//        boolean boolean11 = dateTime9.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate12 = dateTime9.toLocalDate();
//        org.joda.time.DateTime dateTime13 = dateTime9.toDateTime();
//        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime2, (org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTime dateTime15 = dateTime9.toDateTime();
//        org.joda.time.MutableDateTime mutableDateTime16 = dateTime9.toMutableDateTimeISO();
//        java.util.GregorianCalendar gregorianCalendar17 = mutableDateTime16.toGregorianCalendar();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertNotNull(gregorianCalendar17);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(28800124L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology7 = iSOChronology6.withUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = iSOChronology6.getZone();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(52661631, (int) (byte) 1, (int) (byte) 1, (int) (byte) 1, 50, 877, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 877 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfDay(166);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(8);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTimeZoneName(strMap7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendPattern("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendTwoDigitWeekyear((int) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatterBuilder13.toFormatter();
        org.joda.time.format.DateTimeParser dateTimeParser15 = dateTimeFormatter14.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder6.appendOptional(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeParser15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DurationField durationField8 = property6.getLeapDurationField();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone9);
        boolean boolean13 = dateTime11.isBefore((long) (-1));
        org.joda.time.DateTime dateTime15 = dateTime11.plusMillis((int) (byte) 10);
        org.joda.time.DateTime dateTime17 = dateTime11.minusMonths((int) 'a');
        org.joda.time.DateTime.Property property18 = dateTime17.millisOfDay();
        org.joda.time.DateTime dateTime20 = property18.setCopy((int) '#');
        org.joda.time.DateTime.Property property21 = dateTime20.hourOfDay();
        int int22 = property6.compareTo((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime dateTime24 = dateTime20.minusWeeks((-1));
        org.joda.time.DateTime.Property property25 = dateTime24.yearOfEra();
        java.util.Locale locale26 = null;
        java.util.Calendar calendar27 = dateTime24.toCalendar(locale26);
        org.joda.time.DateTime dateTime29 = dateTime24.minusHours(124);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(calendar27);
        org.junit.Assert.assertNotNull(dateTime29);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
//        boolean boolean4 = dateTime2.isBefore((long) (-1));
//        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
//        org.joda.time.DateTime dateTime8 = dateTime2.minusMonths((int) 'a');
//        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
//        org.joda.time.DateTime dateTime11 = property9.setCopy((int) '#');
//        org.joda.time.DateTime.Property property12 = dateTime11.hourOfDay();
//        java.lang.String str13 = property12.getAsText();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone14);
//        boolean boolean18 = dateTime16.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate19 = dateTime16.toLocalDate();
//        org.joda.time.DateTime dateTime20 = dateTime16.toDateTime();
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime20.minus(readableDuration21);
//        long long23 = property12.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.DateTime dateTime25 = dateTime22.withCenturyOfEra(124);
//        org.joda.time.DateTime.Property property26 = dateTime25.minuteOfDay();
//        org.joda.time.DateTime.Property property27 = dateTime25.year();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-70886L) + "'", long23 == (-70886L));
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone5);
        boolean boolean9 = dateTime7.isBefore((long) (-1));
        org.joda.time.LocalDate localDate10 = dateTime7.toLocalDate();
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime();
        org.joda.time.DateTime.Property property12 = dateTime11.era();
        org.joda.time.DateTime.Property property13 = dateTime11.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder4.appendFraction(dateTimeFieldType14, 24, 10);
        boolean boolean18 = dateTimeFormatterBuilder17.canBuildParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        java.util.Locale locale20 = dateTimeFormatter19.getLocale();
        boolean boolean21 = dateTimeFormatter19.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser22 = dateTimeFormatter19.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder17.append(dateTimeParser22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder3.append(dateTimeParser22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNull(locale20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeParser22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
//        boolean boolean4 = dateTime2.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
//        int int6 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.era();
//        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) iSOChronology9);
//        org.joda.time.Chronology chronology12 = iSOChronology9.withUTC();
//        org.joda.time.DurationField durationField13 = iSOChronology9.hours();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology9.monthOfYear();
//        org.joda.time.DurationField durationField15 = iSOChronology9.years();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(durationField15);
//    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
//        boolean boolean5 = dateTime3.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
//        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime();
//        org.joda.time.DateTime.Property property8 = dateTime7.era();
//        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType10, 24, 10);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology15 = iSOChronology14.withUTC();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone17);
//        boolean boolean21 = dateTime19.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate22 = dateTime19.toLocalDate();
//        long long24 = iSOChronology14.set((org.joda.time.ReadablePartial) localDate22, (long) 24);
//        long long28 = iSOChronology14.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField29 = iSOChronology14.millis();
//        org.joda.time.DurationField durationField30 = iSOChronology14.years();
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology14.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeUtils.getZone(dateTimeZone33);
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone33);
//        boolean boolean37 = dateTime35.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate38 = dateTime35.toLocalDate();
//        org.joda.time.DateTime dateTime39 = dateTime35.toDateTime();
//        org.joda.time.DateTime.Property property40 = dateTime39.era();
//        org.joda.time.DateTime.Property property41 = dateTime39.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property41.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder32.appendFraction(dateTimeFieldType42, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField50 = new org.joda.time.field.DividedDateTimeField(dateTimeField31, dateTimeFieldType42, (int) (byte) 10);
//        org.joda.time.DurationField durationField51 = dividedDateTimeField50.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField52 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField51);
//        int int55 = unsupportedDateTimeField52.getDifference((long) (byte) -1, 1560664800024L);
//        long long58 = unsupportedDateTimeField52.add((-1036800000000000L), (int) (short) 100);
//        org.joda.time.DurationField durationField59 = unsupportedDateTimeField52.getDurationField();
//        java.util.Locale locale60 = null;
//        try {
//            int int61 = unsupportedDateTimeField52.getMaximumTextLength(locale60);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560639600024L + "'", long24 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560639610124L + "'", long28 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(durationField51);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField52);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-36126) + "'", int55 == (-36126));
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-1036795680000000L) + "'", long58 == (-1036795680000000L));
//        org.junit.Assert.assertNotNull(durationField59);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitYear(100, false);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        java.util.Locale locale8 = dateTimeFormatter7.getLocale();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.append(dateTimeFormatter7);
        boolean boolean10 = dateTimeFormatter7.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNull(locale8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean5 = dateTime3.isBefore((long) (-1));
        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType10, 24, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendLiteral('4');
        dateTimeFormatterBuilder13.clear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DateTime dateTime9 = property6.addToCopy((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.withZone(dateTimeZone10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone13);
        boolean boolean17 = dateTime15.isBefore((long) (-1));
        org.joda.time.LocalDate localDate18 = dateTime15.toLocalDate();
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime();
        org.joda.time.DateTime.Property property20 = dateTime19.era();
        org.joda.time.DateTime.Property property21 = dateTime19.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder12.appendFraction(dateTimeFieldType22, 24, 10);
        org.joda.time.DateTime.Property property26 = dateTime9.property(dateTimeFieldType22);
        org.joda.time.DateTime.Property property27 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime29 = dateTime9.plusWeeks((int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime29);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
//        boolean boolean4 = dateTime2.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
//        int int6 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
//        java.util.Date date9 = dateTime2.toDate();
//        org.joda.time.DateTime dateTime11 = dateTime2.plusYears(1);
//        org.joda.time.DateTime dateTime13 = dateTime11.withHourOfDay((int) (byte) 0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(chronology1);
        org.joda.time.LocalTime localTime3 = dateTime2.toLocalTime();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(localTime3);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitYear(100, false);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        java.util.Locale locale8 = dateTimeFormatter7.getLocale();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.append(dateTimeFormatter7);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone10);
        boolean boolean14 = dateTime12.isBefore((long) (-1));
        org.joda.time.LocalDate localDate15 = dateTime12.toLocalDate();
        org.joda.time.DateTime dateTime16 = dateTime12.toDateTime();
        org.joda.time.DateTime.Property property17 = dateTime16.era();
        org.joda.time.DateTime.Property property18 = dateTime16.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder9.appendDecimal(dateTimeFieldType19, 2080, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNull(locale8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019166", (java.lang.Number) 1560639610124L, (java.lang.Number) 100.0f, (java.lang.Number) 0.0f);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) 'a');
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMinuteOfHour(10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfWeek((int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.minus(readableDuration7);
        org.joda.time.DateTime dateTime9 = dateTime8.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfEra();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("2019-06-15T14:37:26.480-07:00", "2019-06", 485, 2);
        int int17 = fixedDateTimeZone15.getStandardOffset((long) (byte) 100);
        int int19 = fixedDateTimeZone15.getOffsetFromLocal(32L);
        long long21 = fixedDateTimeZone15.nextTransition(28800000L);
        org.joda.time.DateTime dateTime22 = dateTime9.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DateMidnight dateMidnight23 = dateTime22.toDateMidnight();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        try {
            int int25 = dateMidnight23.get(dateTimeFieldType24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 485 + "'", int19 == 485);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800000L + "'", long21 == 28800000L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateMidnight23);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '#');
//        int int6 = offsetDateTimeField5.getMinimumValue();
//        long long9 = offsetDateTimeField5.add(0L, 292278993);
//        long long11 = offsetDateTimeField5.roundCeiling((-24001900L));
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology13 = iSOChronology12.withUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone15);
//        boolean boolean19 = dateTime17.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
//        long long22 = iSOChronology12.set((org.joda.time.ReadablePartial) localDate20, (long) 24);
//        long long26 = iSOChronology12.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField27 = iSOChronology12.millis();
//        org.joda.time.DurationField durationField28 = iSOChronology12.years();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology12.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone31);
//        boolean boolean35 = dateTime33.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate36 = dateTime33.toLocalDate();
//        org.joda.time.DateTime dateTime37 = dateTime33.toDateTime();
//        org.joda.time.DateTime.Property property38 = dateTime37.era();
//        org.joda.time.DateTime.Property property39 = dateTime37.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property39.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder30.appendFraction(dateTimeFieldType40, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField48 = new org.joda.time.field.DividedDateTimeField(dateTimeField29, dateTimeFieldType40, (int) (byte) 10);
//        org.joda.time.DurationField durationField49 = dividedDateTimeField48.getRangeDurationField();
//        int int51 = dividedDateTimeField48.getMaximumValue((long) 20);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.DateTimeZone dateTimeZone54 = null;
//        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeUtils.getZone(dateTimeZone54);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(dateTimeZone54);
//        boolean boolean58 = dateTime56.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate59 = dateTime56.toLocalDate();
//        java.lang.String str60 = dateTimeFormatter53.print((org.joda.time.ReadablePartial) localDate59);
//        java.lang.String str61 = dateTimeFormatter52.print((org.joda.time.ReadablePartial) localDate59);
//        java.util.Locale locale63 = null;
//        java.lang.String str64 = dividedDateTimeField48.getAsText((org.joda.time.ReadablePartial) localDate59, 0, locale63);
//        java.util.Locale locale66 = null;
//        java.lang.String str67 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) localDate59, 31, locale66);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 292278993L + "'", long9 == 292278993L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-24001900L) + "'", long11 == (-24001900L));
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560639600024L + "'", long22 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560639610124L + "'", long26 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(durationField49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter52);
//        org.junit.Assert.assertNotNull(dateTimeFormatter53);
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(localDate59);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "2019-06-15T��:��:��.000" + "'", str60.equals("2019-06-15T��:��:��.000"));
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "��" + "'", str61.equals("��"));
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "0" + "'", str64.equals("0"));
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "31" + "'", str67.equals("31"));
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone2);
        boolean boolean6 = dateTime4.isBefore((long) (-1));
        org.joda.time.LocalDate localDate7 = dateTime4.toLocalDate();
        org.joda.time.DateTime.Property property8 = dateTime4.millisOfSecond();
        org.joda.time.DateTime.Property property9 = dateTime4.secondOfDay();
        org.joda.time.LocalDate localDate10 = dateTime4.toLocalDate();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDate10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(localDate10);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
//        boolean boolean4 = dateTime2.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
//        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime();
//        org.joda.time.DateTime.Property property7 = dateTime6.era();
//        org.joda.time.DateTime.Property property8 = dateTime6.yearOfEra();
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.halfdayOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology12 = iSOChronology11.withUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone14);
//        boolean boolean18 = dateTime16.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate19 = dateTime16.toLocalDate();
//        long long21 = iSOChronology11.set((org.joda.time.ReadablePartial) localDate19, (long) 24);
//        long long25 = iSOChronology11.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField26 = iSOChronology11.millis();
//        org.joda.time.DurationField durationField27 = iSOChronology11.years();
//        org.joda.time.DateTimeField dateTimeField28 = iSOChronology11.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone30 = null;
//        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeUtils.getZone(dateTimeZone30);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime(dateTimeZone30);
//        boolean boolean34 = dateTime32.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate35 = dateTime32.toLocalDate();
//        org.joda.time.DateTime dateTime36 = dateTime32.toDateTime();
//        org.joda.time.DateTime.Property property37 = dateTime36.era();
//        org.joda.time.DateTime.Property property38 = dateTime36.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder29.appendFraction(dateTimeFieldType39, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException45 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType39, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField47 = new org.joda.time.field.DividedDateTimeField(dateTimeField28, dateTimeFieldType39, (int) (byte) 10);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField48 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField10, dateTimeFieldType39);
//        org.joda.time.DateTimeZone dateTimeZone49 = null;
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeUtils.getZone(dateTimeZone49);
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime(dateTimeZone49);
//        boolean boolean53 = dateTime51.isBefore((long) (-1));
//        org.joda.time.DateTime dateTime55 = dateTime51.plusMillis((int) (byte) 10);
//        org.joda.time.DateTime dateTime57 = dateTime51.minusMonths((int) 'a');
//        org.joda.time.LocalDate localDate58 = dateTime51.toLocalDate();
//        int int59 = zeroIsMaxDateTimeField48.getMinimumValue((org.joda.time.ReadablePartial) localDate58);
//        int int60 = property8.compareTo((org.joda.time.ReadablePartial) localDate58);
//        org.joda.time.DateTime dateTime61 = property8.withMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) ' ', 3);
//        java.util.Locale locale66 = null;
//        java.lang.String str67 = dateTimeZone64.getShortName(0L, locale66);
//        org.joda.time.DateTime dateTime68 = dateTime61.withZone(dateTimeZone64);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560639600024L + "'", long21 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560639610124L + "'", long25 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(localDate58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "+32:03" + "'", str67.equals("+32:03"));
//        org.junit.Assert.assertNotNull(dateTime68);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("14", 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder3.setFixedSavings("2019-06-15T14:37:06.783-07:00", (int) '4');
        java.io.OutputStream outputStream8 = null;
        try {
            dateTimeZoneBuilder6.writeTo("2019", outputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology7 = iSOChronology6.withUTC();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(52630, 0, 1, 77856, 52661631, 8, (org.joda.time.Chronology) iSOChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 77856 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean5 = dateTime3.isBefore((long) (-1));
        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType10, 24, 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType10, (java.lang.Number) 10.0f, "1969365");
        org.joda.time.DurationFieldType durationFieldType17 = illegalFieldValueException16.getDurationFieldType();
        java.lang.String str18 = illegalFieldValueException16.getIllegalStringValue();
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException("152", (java.lang.Number) 1560634618659L, (java.lang.Number) (-1L), (java.lang.Number) 19);
        illegalFieldValueException16.addSuppressed((java.lang.Throwable) illegalFieldValueException23);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNull(durationFieldType17);
        org.junit.Assert.assertNull(str18);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        int int2 = dateTimeZone0.getOffset(readableInstant1);
//        java.lang.String str4 = dateTimeZone0.getShortName(0L);
//        long long6 = dateTimeZone0.convertUTCToLocal((-70886L));
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-70886L) + "'", long6 == (-70886L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '#');
//        int int6 = offsetDateTimeField5.getMinimumValue();
//        long long9 = offsetDateTimeField5.add(0L, 292278993);
//        long long11 = offsetDateTimeField5.roundHalfFloor(1L);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology13 = iSOChronology12.withUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone15);
//        boolean boolean19 = dateTime17.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
//        long long22 = iSOChronology12.set((org.joda.time.ReadablePartial) localDate20, (long) 24);
//        long long26 = iSOChronology12.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField27 = iSOChronology12.millis();
//        org.joda.time.DurationField durationField28 = iSOChronology12.years();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology12.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone31);
//        boolean boolean35 = dateTime33.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate36 = dateTime33.toLocalDate();
//        org.joda.time.DateTime dateTime37 = dateTime33.toDateTime();
//        org.joda.time.DateTime.Property property38 = dateTime37.era();
//        org.joda.time.DateTime.Property property39 = dateTime37.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property39.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder30.appendFraction(dateTimeFieldType40, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField48 = new org.joda.time.field.DividedDateTimeField(dateTimeField29, dateTimeFieldType40, (int) (byte) 10);
//        org.joda.time.DurationField durationField49 = dividedDateTimeField48.getRangeDurationField();
//        int int51 = dividedDateTimeField48.getMaximumValue((long) 20);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.DateTimeZone dateTimeZone54 = null;
//        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeUtils.getZone(dateTimeZone54);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(dateTimeZone54);
//        boolean boolean58 = dateTime56.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate59 = dateTime56.toLocalDate();
//        java.lang.String str60 = dateTimeFormatter53.print((org.joda.time.ReadablePartial) localDate59);
//        java.lang.String str61 = dateTimeFormatter52.print((org.joda.time.ReadablePartial) localDate59);
//        java.util.Locale locale63 = null;
//        java.lang.String str64 = dividedDateTimeField48.getAsText((org.joda.time.ReadablePartial) localDate59, 0, locale63);
//        int int65 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) localDate59);
//        long long67 = offsetDateTimeField5.roundFloor(1560639563874L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 292278993L + "'", long9 == 292278993L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560639600024L + "'", long22 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560639610124L + "'", long26 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(durationField49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter52);
//        org.junit.Assert.assertNotNull(dateTimeFormatter53);
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(localDate59);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "2019-06-15T��:��:��.000" + "'", str60.equals("2019-06-15T��:��:��.000"));
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "��" + "'", str61.equals("��"));
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "0" + "'", str64.equals("0"));
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 35 + "'", int65 == 35);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1560639563874L + "'", long67 == 1560639563874L);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '#');
        int int6 = offsetDateTimeField5.getMinimumValue();
        long long9 = offsetDateTimeField5.add(0L, 292278993);
        long long11 = offsetDateTimeField5.roundCeiling((long) 15);
        long long13 = offsetDateTimeField5.roundHalfFloor((long) ' ');
        int int14 = offsetDateTimeField5.getOffset();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 292278993L + "'", long9 == 292278993L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 15L + "'", long11 == 15L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 32L + "'", long13 == 32L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 35 + "'", int14 == 35);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DateTime dateTime9 = property6.addToCopy((int) (byte) 100);
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTimeISO();
        org.joda.time.DateTime.Property property11 = dateTime10.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DateTime dateTime9 = property6.addToCopy((int) (byte) 100);
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTimeISO();
        org.joda.time.DateTime dateTime12 = dateTime10.minus(2490L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean5 = dateTime3.isBefore((long) (-1));
        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType10, 24, 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType10, (java.lang.Number) 10.0f, "1969365");
        java.lang.Number number17 = illegalFieldValueException16.getLowerBound();
        java.lang.Number number18 = illegalFieldValueException16.getLowerBound();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertNull(number18);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
//        boolean boolean5 = dateTime3.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
//        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime();
//        org.joda.time.DateTime.Property property8 = dateTime7.era();
//        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType10, 24, 10);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology15 = iSOChronology14.withUTC();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone17);
//        boolean boolean21 = dateTime19.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate22 = dateTime19.toLocalDate();
//        long long24 = iSOChronology14.set((org.joda.time.ReadablePartial) localDate22, (long) 24);
//        long long28 = iSOChronology14.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField29 = iSOChronology14.millis();
//        org.joda.time.DurationField durationField30 = iSOChronology14.years();
//        org.joda.time.DateTimeField dateTimeField31 = iSOChronology14.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeUtils.getZone(dateTimeZone33);
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone33);
//        boolean boolean37 = dateTime35.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate38 = dateTime35.toLocalDate();
//        org.joda.time.DateTime dateTime39 = dateTime35.toDateTime();
//        org.joda.time.DateTime.Property property40 = dateTime39.era();
//        org.joda.time.DateTime.Property property41 = dateTime39.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property41.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder32.appendFraction(dateTimeFieldType42, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField50 = new org.joda.time.field.DividedDateTimeField(dateTimeField31, dateTimeFieldType42, (int) (byte) 10);
//        org.joda.time.DurationField durationField51 = dividedDateTimeField50.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField52 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField51);
//        org.joda.time.DurationField durationField53 = unsupportedDateTimeField52.getDurationField();
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560639600024L + "'", long24 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560639610124L + "'", long28 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(durationField51);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField52);
//        org.junit.Assert.assertNotNull(durationField53);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusHours((int) (short) 1);
        org.joda.time.DateTime dateTime6 = dateTime2.withMonthOfYear((int) (byte) 10);
        boolean boolean7 = dateTime2.isAfterNow();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
//        boolean boolean4 = dateTime2.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
//        org.joda.time.DateTime.Property property6 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime8 = dateTime2.plusYears((int) 'a');
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone10);
//        boolean boolean14 = dateTime12.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate15 = dateTime12.toLocalDate();
//        org.joda.time.DateTime.Property property16 = dateTime12.millisOfSecond();
//        int int17 = dateTime12.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone18 = null;
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone18);
//        int int21 = dateTime20.getWeekOfWeekyear();
//        boolean boolean22 = dateTime12.equals((java.lang.Object) dateTime20);
//        org.joda.time.DateTime dateTime24 = dateTime20.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime26 = dateTime24.withWeekyear(35);
//        int int27 = property9.getDifference((org.joda.time.ReadableInstant) dateTime26);
//        org.joda.time.DateTime dateTime28 = property9.roundHalfFloorCopy();
//        int int29 = property9.getMinimumValue();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 24 + "'", int17 == 24);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 24 + "'", int21 == 24);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2080 + "'", int27 == 2080);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-292275054) + "'", int29 == (-292275054));
//    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
//        boolean boolean4 = dateTime2.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
//        int int6 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
//        java.util.Date date9 = dateTime2.toDate();
//        org.joda.time.DateTime dateTime11 = dateTime2.minusMonths((int) (byte) -1);
//        org.joda.time.DateTime dateTime12 = dateTime2.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime.Property property13 = dateTime2.weekyear();
//        int int14 = dateTime2.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 38 + "'", int14 == 38);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "2019-06-15T��:��:��.000");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone3);
//        boolean boolean7 = dateTime5.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
//        long long10 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) 24);
//        long long14 = iSOChronology0.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField15 = iSOChronology0.millis();
//        org.joda.time.DurationField durationField16 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone19);
//        boolean boolean23 = dateTime21.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
//        org.joda.time.DateTime dateTime25 = dateTime21.toDateTime();
//        org.joda.time.DateTime.Property property26 = dateTime25.era();
//        org.joda.time.DateTime.Property property27 = dateTime25.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder18.appendFraction(dateTimeFieldType28, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType28, (int) (byte) 10);
//        long long39 = dividedDateTimeField36.getDifferenceAsLong((long) (byte) 1, 0L);
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology40.halfdayOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology43 = iSOChronology42.withUTC();
//        org.joda.time.DateTimeField dateTimeField44 = iSOChronology42.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeUtils.getZone(dateTimeZone45);
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(dateTimeZone45);
//        boolean boolean49 = dateTime47.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate50 = dateTime47.toLocalDate();
//        long long52 = iSOChronology42.set((org.joda.time.ReadablePartial) localDate50, (long) 24);
//        long long56 = iSOChronology42.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField57 = iSOChronology42.millis();
//        org.joda.time.DurationField durationField58 = iSOChronology42.years();
//        org.joda.time.DateTimeField dateTimeField59 = iSOChronology42.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone61 = null;
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeUtils.getZone(dateTimeZone61);
//        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime(dateTimeZone61);
//        boolean boolean65 = dateTime63.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate66 = dateTime63.toLocalDate();
//        org.joda.time.DateTime dateTime67 = dateTime63.toDateTime();
//        org.joda.time.DateTime.Property property68 = dateTime67.era();
//        org.joda.time.DateTime.Property property69 = dateTime67.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType70 = property69.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder60.appendFraction(dateTimeFieldType70, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException76 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType70, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField78 = new org.joda.time.field.DividedDateTimeField(dateTimeField59, dateTimeFieldType70, (int) (byte) 10);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField79 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField41, dateTimeFieldType70);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField80 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField36, dateTimeFieldType70);
//        long long82 = remainderDateTimeField80.roundCeiling((long) (short) 10);
//        int int83 = remainderDateTimeField80.getDivisor();
//        long long85 = remainderDateTimeField80.roundFloor((long) 3);
//        try {
//            long long88 = remainderDateTimeField80.set(1560664800024L, (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for yearOfEra must be in the range [0,9]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560639600024L + "'", long10 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560639610124L + "'", long14 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(iSOChronology42);
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(localDate50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560639600024L + "'", long52 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560639610124L + "'", long56 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField57);
//        org.junit.Assert.assertNotNull(durationField58);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(localDate66);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertNotNull(property69);
//        org.junit.Assert.assertNotNull(dateTimeFieldType70);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 3600000L + "'", long82 == 3600000L);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 10 + "'", int83 == 10);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 0L + "'", long85 == 0L);
//    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone3);
//        boolean boolean7 = dateTime5.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
//        long long10 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) 24);
//        long long14 = iSOChronology0.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField15 = iSOChronology0.millis();
//        org.joda.time.DurationField durationField16 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone19);
//        boolean boolean23 = dateTime21.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
//        org.joda.time.DateTime dateTime25 = dateTime21.toDateTime();
//        org.joda.time.DateTime.Property property26 = dateTime25.era();
//        org.joda.time.DateTime.Property property27 = dateTime25.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder18.appendFraction(dateTimeFieldType28, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType28, (int) (byte) 10);
//        long long39 = dividedDateTimeField36.getDifferenceAsLong((long) (byte) 1, 0L);
//        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField41 = iSOChronology40.halfdayOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology43 = iSOChronology42.withUTC();
//        org.joda.time.DateTimeField dateTimeField44 = iSOChronology42.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeUtils.getZone(dateTimeZone45);
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(dateTimeZone45);
//        boolean boolean49 = dateTime47.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate50 = dateTime47.toLocalDate();
//        long long52 = iSOChronology42.set((org.joda.time.ReadablePartial) localDate50, (long) 24);
//        long long56 = iSOChronology42.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField57 = iSOChronology42.millis();
//        org.joda.time.DurationField durationField58 = iSOChronology42.years();
//        org.joda.time.DateTimeField dateTimeField59 = iSOChronology42.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone61 = null;
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeUtils.getZone(dateTimeZone61);
//        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime(dateTimeZone61);
//        boolean boolean65 = dateTime63.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate66 = dateTime63.toLocalDate();
//        org.joda.time.DateTime dateTime67 = dateTime63.toDateTime();
//        org.joda.time.DateTime.Property property68 = dateTime67.era();
//        org.joda.time.DateTime.Property property69 = dateTime67.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType70 = property69.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder60.appendFraction(dateTimeFieldType70, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException76 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType70, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField78 = new org.joda.time.field.DividedDateTimeField(dateTimeField59, dateTimeFieldType70, (int) (byte) 10);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField79 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField41, dateTimeFieldType70);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField80 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField36, dateTimeFieldType70);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException82 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType70, "2019-06-15T14:37:09.073-07:00");
//        java.lang.Number number83 = illegalFieldValueException82.getUpperBound();
//        org.joda.time.DurationFieldType durationFieldType84 = illegalFieldValueException82.getDurationFieldType();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560639600024L + "'", long10 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560639610124L + "'", long14 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertNotNull(iSOChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(iSOChronology42);
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(localDate50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560639600024L + "'", long52 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560639610124L + "'", long56 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField57);
//        org.junit.Assert.assertNotNull(durationField58);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(localDate66);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertNotNull(property69);
//        org.junit.Assert.assertNotNull(dateTimeFieldType70);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
//        org.junit.Assert.assertNull(number83);
//        org.junit.Assert.assertNull(durationFieldType84);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendTimeZoneShortName();
        boolean boolean2 = dateTimeFormatterBuilder0.canBuildPrinter();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone3);
//        boolean boolean7 = dateTime5.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
//        long long10 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) 24);
//        long long14 = iSOChronology0.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField15 = iSOChronology0.millis();
//        org.joda.time.DurationField durationField16 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone19);
//        boolean boolean23 = dateTime21.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
//        org.joda.time.DateTime dateTime25 = dateTime21.toDateTime();
//        org.joda.time.DateTime.Property property26 = dateTime25.era();
//        org.joda.time.DateTime.Property property27 = dateTime25.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder18.appendFraction(dateTimeFieldType28, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType28, (int) (byte) 10);
//        org.joda.time.DurationField durationField37 = dividedDateTimeField36.getRangeDurationField();
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeUtils.getZone(dateTimeZone38);
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(dateTimeZone38);
//        boolean boolean42 = dateTime40.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate43 = dateTime40.toLocalDate();
//        org.joda.time.DateTime.Property property44 = dateTime40.millisOfSecond();
//        org.joda.time.DateTime.Property property45 = dateTime40.secondOfDay();
//        org.joda.time.LocalDate localDate46 = dateTime40.toLocalDate();
//        java.util.Locale locale48 = null;
//        java.lang.String str49 = dividedDateTimeField36.getAsShortText((org.joda.time.ReadablePartial) localDate46, (int) (short) 0, locale48);
//        org.joda.time.DateTimeFieldType dateTimeFieldType50 = dividedDateTimeField36.getType();
//        int int51 = dividedDateTimeField36.getDivisor();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField52 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField36);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560639600024L + "'", long10 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560639610124L + "'", long14 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "0" + "'", str49.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 10 + "'", int51 == 10);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '#');
        int int6 = offsetDateTimeField5.getMinimumValue();
        long long9 = offsetDateTimeField5.add(11L, 0);
        boolean boolean11 = offsetDateTimeField5.isLeap((long) 52630);
        long long13 = offsetDateTimeField5.roundHalfEven((long) ' ');
        boolean boolean15 = offsetDateTimeField5.isLeap(11L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 11L + "'", long9 == 11L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 32L + "'", long13 == 32L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
//        boolean boolean4 = dateTime2.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
//        int int6 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
//        java.util.Date date9 = dateTime2.toDate();
//        org.joda.time.DateTime dateTime11 = dateTime2.minusMinutes((-1));
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology13 = iSOChronology12.withUTC();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone15);
//        boolean boolean19 = dateTime17.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
//        long long22 = iSOChronology12.set((org.joda.time.ReadablePartial) localDate20, (long) 24);
//        long long26 = iSOChronology12.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField27 = iSOChronology12.millis();
//        org.joda.time.DurationField durationField28 = iSOChronology12.years();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology12.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeUtils.getZone(dateTimeZone31);
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(dateTimeZone31);
//        boolean boolean35 = dateTime33.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate36 = dateTime33.toLocalDate();
//        org.joda.time.DateTime dateTime37 = dateTime33.toDateTime();
//        org.joda.time.DateTime.Property property38 = dateTime37.era();
//        org.joda.time.DateTime.Property property39 = dateTime37.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property39.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder30.appendFraction(dateTimeFieldType40, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException46 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField48 = new org.joda.time.field.DividedDateTimeField(dateTimeField29, dateTimeFieldType40, (int) (byte) 10);
//        org.joda.time.DurationField durationField49 = dividedDateTimeField48.getRangeDurationField();
//        org.joda.time.DateTimeZone dateTimeZone50 = null;
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeUtils.getZone(dateTimeZone50);
//        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime(dateTimeZone50);
//        boolean boolean54 = dateTime52.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate55 = dateTime52.toLocalDate();
//        org.joda.time.DateTime.Property property56 = dateTime52.millisOfSecond();
//        org.joda.time.DateTime.Property property57 = dateTime52.secondOfDay();
//        org.joda.time.LocalDate localDate58 = dateTime52.toLocalDate();
//        java.util.Locale locale60 = null;
//        java.lang.String str61 = dividedDateTimeField48.getAsShortText((org.joda.time.ReadablePartial) localDate58, (int) (short) 0, locale60);
//        org.joda.time.DateTimeFieldType dateTimeFieldType62 = dividedDateTimeField48.getType();
//        int int63 = dividedDateTimeField48.getDivisor();
//        long long66 = dividedDateTimeField48.addWrapField((long) (short) 1, 4);
//        int int69 = dividedDateTimeField48.getDifference(1L, (long) (short) 1);
//        boolean boolean70 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime2, (java.lang.Object) dividedDateTimeField48);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560639600024L + "'", long22 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560639610124L + "'", long26 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(durationField49);
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(localDate55);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(localDate58);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "0" + "'", str61.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1L + "'", long66 == 1L);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
//        boolean boolean4 = dateTime2.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
//        int int6 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
//        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.era();
//        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) iSOChronology9);
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology9);
//        org.joda.time.DateTime.Property property13 = dateTime12.millisOfSecond();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
        org.joda.time.DateTime dateTime8 = dateTime2.minusMonths((int) 'a');
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        org.joda.time.DateTime dateTime11 = property9.setCopy((int) '#');
        org.joda.time.DateTime dateTime13 = property9.addToCopy(19);
        org.joda.time.DateTime dateTime15 = property9.addWrapFieldToCopy((int) 'a');
        java.util.Date date16 = dateTime15.toDate();
        org.joda.time.DateTime.Property property17 = dateTime15.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(property17);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.halfdayOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology3 = iSOChronology2.withUTC();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone5);
//        boolean boolean9 = dateTime7.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate10 = dateTime7.toLocalDate();
//        long long12 = iSOChronology2.set((org.joda.time.ReadablePartial) localDate10, (long) 24);
//        long long16 = iSOChronology2.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField17 = iSOChronology2.millis();
//        org.joda.time.DurationField durationField18 = iSOChronology2.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology2.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone21);
//        boolean boolean25 = dateTime23.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate26 = dateTime23.toLocalDate();
//        org.joda.time.DateTime dateTime27 = dateTime23.toDateTime();
//        org.joda.time.DateTime.Property property28 = dateTime27.era();
//        org.joda.time.DateTime.Property property29 = dateTime27.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder20.appendFraction(dateTimeFieldType30, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField(dateTimeField19, dateTimeFieldType30, (int) (byte) 10);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField1, dateTimeFieldType30);
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeUtils.getZone(dateTimeZone40);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone40);
//        boolean boolean44 = dateTime42.isBefore((long) (-1));
//        org.joda.time.DateTime dateTime46 = dateTime42.plusMillis((int) (byte) 10);
//        org.joda.time.DateTime dateTime48 = dateTime42.minusMonths((int) 'a');
//        org.joda.time.LocalDate localDate49 = dateTime42.toLocalDate();
//        int int50 = zeroIsMaxDateTimeField39.getMinimumValue((org.joda.time.ReadablePartial) localDate49);
//        org.joda.time.DateTimeField dateTimeField51 = zeroIsMaxDateTimeField39.getWrappedField();
//        long long54 = zeroIsMaxDateTimeField39.add((long) (byte) 0, 2000);
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeUtils.getZone(dateTimeZone55);
//        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime(dateTimeZone55);
//        boolean boolean59 = dateTime57.isBefore((long) (-1));
//        org.joda.time.DateTime dateTime61 = dateTime57.plusMillis((int) (byte) 10);
//        org.joda.time.LocalDate localDate62 = dateTime61.toLocalDate();
//        org.joda.time.chrono.ISOChronology iSOChronology63 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField64 = iSOChronology63.era();
//        org.joda.time.DateTimeZone dateTimeZone65 = null;
//        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeUtils.getZone(dateTimeZone65);
//        org.joda.time.DateTime dateTime67 = new org.joda.time.DateTime(dateTimeZone65);
//        boolean boolean69 = dateTime67.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate70 = dateTime67.toLocalDate();
//        org.joda.time.DateTime.Property property71 = dateTime67.millisOfSecond();
//        org.joda.time.DateTime dateTime72 = property71.getDateTime();
//        org.joda.time.DurationField durationField73 = property71.getLeapDurationField();
//        org.joda.time.DateTimeZone dateTimeZone74 = null;
//        org.joda.time.DateTimeZone dateTimeZone75 = org.joda.time.DateTimeUtils.getZone(dateTimeZone74);
//        org.joda.time.DateTime dateTime76 = new org.joda.time.DateTime(dateTimeZone74);
//        boolean boolean78 = dateTime76.isBefore((long) (-1));
//        org.joda.time.DateTime dateTime80 = dateTime76.plusMillis((int) (byte) 10);
//        org.joda.time.DateTime dateTime82 = dateTime76.minusMonths((int) 'a');
//        org.joda.time.DateTime.Property property83 = dateTime82.millisOfDay();
//        org.joda.time.DateTime dateTime85 = property83.setCopy((int) '#');
//        org.joda.time.DateTime.Property property86 = dateTime85.hourOfDay();
//        int int87 = property71.compareTo((org.joda.time.ReadableInstant) dateTime85);
//        org.joda.time.DateTime dateTime89 = dateTime85.minusWeeks((-1));
//        org.joda.time.DateTime.Property property90 = dateTime89.yearOfEra();
//        org.joda.time.LocalDate localDate91 = dateTime89.toLocalDate();
//        int[] intArray93 = iSOChronology63.get((org.joda.time.ReadablePartial) localDate91, 11L);
//        int int94 = zeroIsMaxDateTimeField39.getMaximumValue((org.joda.time.ReadablePartial) localDate62, intArray93);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560639600024L + "'", long12 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560639610124L + "'", long16 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(localDate49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 86400000000L + "'", long54 == 86400000000L);
//        org.junit.Assert.assertNotNull(dateTimeZone56);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(localDate62);
//        org.junit.Assert.assertNotNull(iSOChronology63);
//        org.junit.Assert.assertNotNull(dateTimeField64);
//        org.junit.Assert.assertNotNull(dateTimeZone66);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertNotNull(localDate70);
//        org.junit.Assert.assertNotNull(property71);
//        org.junit.Assert.assertNotNull(dateTime72);
//        org.junit.Assert.assertNull(durationField73);
//        org.junit.Assert.assertNotNull(dateTimeZone75);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertNotNull(dateTime80);
//        org.junit.Assert.assertNotNull(dateTime82);
//        org.junit.Assert.assertNotNull(property83);
//        org.junit.Assert.assertNotNull(dateTime85);
//        org.junit.Assert.assertNotNull(property86);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
//        org.junit.Assert.assertNotNull(dateTime89);
//        org.junit.Assert.assertNotNull(property90);
//        org.junit.Assert.assertNotNull(localDate91);
//        org.junit.Assert.assertNotNull(intArray93);
//        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 2 + "'", int94 == 2);
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone3);
//        boolean boolean7 = dateTime5.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
//        long long10 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) 24);
//        long long14 = iSOChronology0.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField15 = iSOChronology0.millis();
//        org.joda.time.DurationField durationField16 = iSOChronology0.years();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone19);
//        boolean boolean23 = dateTime21.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
//        org.joda.time.DateTime dateTime25 = dateTime21.toDateTime();
//        org.joda.time.DateTime.Property property26 = dateTime25.era();
//        org.joda.time.DateTime.Property property27 = dateTime25.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder18.appendFraction(dateTimeFieldType28, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType28, (int) (byte) 10);
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = dividedDateTimeField36.getAsShortText(1560634619050L, locale38);
//        java.util.Locale locale41 = null;
//        java.lang.String str42 = dividedDateTimeField36.getAsText((int) (short) -1, locale41);
//        int int43 = dividedDateTimeField36.getDivisor();
//        boolean boolean44 = dividedDateTimeField36.isLenient();
//        long long47 = dividedDateTimeField36.getDifferenceAsLong((long) 50, (long) 999);
//        long long50 = dividedDateTimeField36.addWrapField(28800132L, 10);
//        java.util.Locale locale53 = null;
//        try {
//            long long54 = dividedDateTimeField36.set(43200000L, "448", locale53);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 448 for yearOfEra must be in the range [0,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560639600024L + "'", long10 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560639610124L + "'", long14 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "-1" + "'", str42.equals("-1"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 10 + "'", int43 == 10);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 28800132L + "'", long50 == 28800132L);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.halfdayOfDay();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology3 = iSOChronology2.withUTC();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone5);
//        boolean boolean9 = dateTime7.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate10 = dateTime7.toLocalDate();
//        long long12 = iSOChronology2.set((org.joda.time.ReadablePartial) localDate10, (long) 24);
//        long long16 = iSOChronology2.add(1560639600024L, 101L, (int) (byte) 100);
//        org.joda.time.DurationField durationField17 = iSOChronology2.millis();
//        org.joda.time.DurationField durationField18 = iSOChronology2.years();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology2.clockhourOfHalfday();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone21);
//        boolean boolean25 = dateTime23.isBefore((long) (-1));
//        org.joda.time.LocalDate localDate26 = dateTime23.toLocalDate();
//        org.joda.time.DateTime dateTime27 = dateTime23.toDateTime();
//        org.joda.time.DateTime.Property property28 = dateTime27.era();
//        org.joda.time.DateTime.Property property29 = dateTime27.yearOfEra();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder20.appendFraction(dateTimeFieldType30, 24, 10);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, (java.lang.Number) 10.0f, "1969365");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField(dateTimeField19, dateTimeFieldType30, (int) (byte) 10);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField1, dateTimeFieldType30);
//        org.joda.time.DateTimeZone dateTimeZone40 = null;
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeUtils.getZone(dateTimeZone40);
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone40);
//        boolean boolean44 = dateTime42.isBefore((long) (-1));
//        org.joda.time.DateTime dateTime46 = dateTime42.plusMillis((int) (byte) 10);
//        org.joda.time.DateTime dateTime48 = dateTime42.minusMonths((int) 'a');
//        org.joda.time.LocalDate localDate49 = dateTime42.toLocalDate();
//        int int50 = zeroIsMaxDateTimeField39.getMinimumValue((org.joda.time.ReadablePartial) localDate49);
//        org.joda.time.DateTimeField dateTimeField51 = zeroIsMaxDateTimeField39.getWrappedField();
//        long long53 = zeroIsMaxDateTimeField39.roundHalfEven((long) 3);
//        long long55 = zeroIsMaxDateTimeField39.roundHalfEven(14308682921L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560639600024L + "'", long12 == 1560639600024L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560639610124L + "'", long16 == 1560639610124L);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(localDate49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 14299200000L + "'", long55 == 14299200000L);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis(24);
        org.joda.time.TimeOfDay timeOfDay7 = dateTime2.toTimeOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(timeOfDay7);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(2490L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 1, (long) 124);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 125L + "'", long2 == 125L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 6);
        long long7 = dateTimeZone1.convertLocalToUTC(1560639600024L, false);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        long long11 = cachedDateTimeZone9.previousTransition(28800000L);
        long long13 = cachedDateTimeZone9.nextTransition((long) 37);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560664800024L + "'", long7 == 1560664800024L);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-5756400001L) + "'", long11 == (-5756400001L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9972000000L + "'", long13 == 9972000000L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.ReadableInstant readableInstant0 = null;
        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2490L + "'", long1 == 2490L);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        java.lang.String str4 = dateTimeZone2.getName(10L);
//        java.lang.String str5 = dateTimeZone2.getID();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone2.getShortName((long) (byte) 10, locale7);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter0.withZone(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pacific Standard Time" + "'", str4.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "America/Los_Angeles" + "'", str5.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PST" + "'", str8.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.era();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone5);
        boolean boolean9 = dateTime7.isBefore((long) (-1));
        org.joda.time.LocalDate localDate10 = dateTime7.toLocalDate();
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime();
        org.joda.time.DateTime.Property property12 = dateTime11.era();
        org.joda.time.DateTime.Property property13 = dateTime11.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder4.appendFraction(dateTimeFieldType14, 24, 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, "2019-06-15T14:37:06.783-07:00");
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType14, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must be supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        java.util.Locale locale8 = null;
        java.lang.String str9 = property6.getAsText(locale8);
        org.joda.time.DateTime dateTime10 = property6.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime12 = property6.addToCopy(19);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "490" + "'", str9.equals("490"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        int int6 = dateTime2.getDayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.era();
        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DurationField durationField12 = iSOChronology9.seconds();
        org.joda.time.Chronology chronology13 = iSOChronology9.withUTC();
        org.joda.time.DurationField durationField14 = iSOChronology9.millis();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone3);
        boolean boolean7 = dateTime5.isBefore((long) (-1));
        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
        long long10 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) 24);
        long long14 = iSOChronology0.add(1560639600024L, 101L, (int) (byte) 100);
        org.joda.time.DurationField durationField15 = iSOChronology0.millis();
        org.joda.time.DurationField durationField16 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24L + "'", long10 == 24L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560639610124L + "'", long14 == 1560639610124L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(chronology18);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("2019-06-15T14:37:26.480-07:00", "2019-06", 485, 2);
        int int6 = fixedDateTimeZone4.getStandardOffset((long) (byte) 100);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal(32L);
        java.lang.String str10 = fixedDateTimeZone4.getNameKey(999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 485 + "'", int8 == 485);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06" + "'", str10.equals("2019-06"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.halfdayOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology3 = iSOChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone5);
        boolean boolean9 = dateTime7.isBefore((long) (-1));
        org.joda.time.LocalDate localDate10 = dateTime7.toLocalDate();
        long long12 = iSOChronology2.set((org.joda.time.ReadablePartial) localDate10, (long) 24);
        long long16 = iSOChronology2.add(1560639600024L, 101L, (int) (byte) 100);
        org.joda.time.DurationField durationField17 = iSOChronology2.millis();
        org.joda.time.DurationField durationField18 = iSOChronology2.years();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone21);
        boolean boolean25 = dateTime23.isBefore((long) (-1));
        org.joda.time.LocalDate localDate26 = dateTime23.toLocalDate();
        org.joda.time.DateTime dateTime27 = dateTime23.toDateTime();
        org.joda.time.DateTime.Property property28 = dateTime27.era();
        org.joda.time.DateTime.Property property29 = dateTime27.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder20.appendFraction(dateTimeFieldType30, 24, 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, (java.lang.Number) 10.0f, "1969365");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField(dateTimeField19, dateTimeFieldType30, (int) (byte) 10);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField1, dateTimeFieldType30);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeUtils.getZone(dateTimeZone41);
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(dateTimeZone41);
        boolean boolean45 = dateTime43.isBefore((long) (-1));
        org.joda.time.LocalDate localDate46 = dateTime43.toLocalDate();
        java.lang.String str47 = dateTimeFormatter40.print((org.joda.time.ReadablePartial) localDate46);
        int[] intArray53 = new int[] { (byte) 1, 15, 6, 'a', 'a' };
        int int54 = zeroIsMaxDateTimeField39.getMaximumValue((org.joda.time.ReadablePartial) localDate46, intArray53);
        int int56 = zeroIsMaxDateTimeField39.getMinimumValue((long) (short) -1);
        int int57 = zeroIsMaxDateTimeField39.getMaximumValue();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter58 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter59 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.DateTimeZone dateTimeZone60 = null;
        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeUtils.getZone(dateTimeZone60);
        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime(dateTimeZone60);
        boolean boolean64 = dateTime62.isBefore((long) (-1));
        org.joda.time.LocalDate localDate65 = dateTime62.toLocalDate();
        java.lang.String str66 = dateTimeFormatter59.print((org.joda.time.ReadablePartial) localDate65);
        java.lang.String str67 = dateTimeFormatter58.print((org.joda.time.ReadablePartial) localDate65);
        int int68 = zeroIsMaxDateTimeField39.getMinimumValue((org.joda.time.ReadablePartial) localDate65);
        int int70 = zeroIsMaxDateTimeField39.getMinimumValue(0L);
        int int73 = zeroIsMaxDateTimeField39.getDifference(292278993L, (-1036800000000000L));
        int int74 = zeroIsMaxDateTimeField39.getMaximumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24L + "'", long12 == 24L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560639610124L + "'", long16 == 1560639610124L);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1969-12-31T��:��:��.000" + "'", str47.equals("1969-12-31T��:��:��.000"));
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2 + "'", int54 == 2);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2 + "'", int57 == 2);
        org.junit.Assert.assertNotNull(dateTimeFormatter58);
        org.junit.Assert.assertNotNull(dateTimeFormatter59);
        org.junit.Assert.assertNotNull(dateTimeZone61);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(localDate65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "1969-12-31T��:��:��.000" + "'", str66.equals("1969-12-31T��:��:��.000"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "��" + "'", str67.equals("��"));
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 24000006 + "'", int73 == 24000006);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 2 + "'", int74 == 2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.halfdayOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology3 = iSOChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone5);
        boolean boolean9 = dateTime7.isBefore((long) (-1));
        org.joda.time.LocalDate localDate10 = dateTime7.toLocalDate();
        long long12 = iSOChronology2.set((org.joda.time.ReadablePartial) localDate10, (long) 24);
        long long16 = iSOChronology2.add(1560639600024L, 101L, (int) (byte) 100);
        org.joda.time.DurationField durationField17 = iSOChronology2.millis();
        org.joda.time.DurationField durationField18 = iSOChronology2.years();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone21);
        boolean boolean25 = dateTime23.isBefore((long) (-1));
        org.joda.time.LocalDate localDate26 = dateTime23.toLocalDate();
        org.joda.time.DateTime dateTime27 = dateTime23.toDateTime();
        org.joda.time.DateTime.Property property28 = dateTime27.era();
        org.joda.time.DateTime.Property property29 = dateTime27.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder20.appendFraction(dateTimeFieldType30, 24, 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, (java.lang.Number) 10.0f, "1969365");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField(dateTimeField19, dateTimeFieldType30, (int) (byte) 10);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField1, dateTimeFieldType30);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeUtils.getZone(dateTimeZone41);
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(dateTimeZone41);
        boolean boolean45 = dateTime43.isBefore((long) (-1));
        org.joda.time.LocalDate localDate46 = dateTime43.toLocalDate();
        java.lang.String str47 = dateTimeFormatter40.print((org.joda.time.ReadablePartial) localDate46);
        int[] intArray53 = new int[] { (byte) 1, 15, 6, 'a', 'a' };
        int int54 = zeroIsMaxDateTimeField39.getMaximumValue((org.joda.time.ReadablePartial) localDate46, intArray53);
        java.util.Locale locale55 = null;
        int int56 = zeroIsMaxDateTimeField39.getMaximumShortTextLength(locale55);
        int int59 = zeroIsMaxDateTimeField39.getDifference((long) 24000006, 32L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24L + "'", long12 == 24L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560639610124L + "'", long16 == 1560639610124L);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1969-12-31T��:��:��.000" + "'", str47.equals("1969-12-31T��:��:��.000"));
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2 + "'", int54 == 2);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019166");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("2019166");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("2019166");
        boolean boolean7 = jodaTimePermission3.implies((java.security.Permission) jodaTimePermission6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean5 = dateTime3.isBefore((long) (-1));
        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
        java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter9.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-31T��:��:��.000" + "'", str7.equals("1969-12-31T��:��:��.000"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property7 = dateTime6.era();
        org.joda.time.DateTime.Property property8 = dateTime6.yearOfEra();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.minusHours(20);
        org.joda.time.DateTime dateTime12 = dateTime9.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime13 = dateTime9.toDateTime();
        int int14 = dateTime13.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone3);
        boolean boolean7 = dateTime5.isBefore((long) (-1));
        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
        long long10 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) 24);
        long long14 = iSOChronology0.add(1560639600024L, 101L, (int) (byte) 100);
        org.joda.time.DurationField durationField15 = iSOChronology0.millis();
        org.joda.time.DurationField durationField16 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.ReadablePartial readablePartial18 = null;
        java.util.TimeZone timeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20, 6);
        int int24 = gregorianChronology23.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.Chronology chronology26 = gregorianChronology23.withZone(dateTimeZone25);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology28 = iSOChronology27.withUTC();
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology27.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeUtils.getZone(dateTimeZone30);
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime(dateTimeZone30);
        boolean boolean34 = dateTime32.isBefore((long) (-1));
        org.joda.time.LocalDate localDate35 = dateTime32.toLocalDate();
        long long37 = iSOChronology27.set((org.joda.time.ReadablePartial) localDate35, (long) 24);
        long long41 = iSOChronology27.add(1560639600024L, 101L, (int) (byte) 100);
        org.joda.time.DurationField durationField42 = iSOChronology27.millis();
        org.joda.time.DurationField durationField43 = iSOChronology27.years();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology27.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeUtils.getZone(dateTimeZone46);
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime(dateTimeZone46);
        boolean boolean50 = dateTime48.isBefore((long) (-1));
        org.joda.time.LocalDate localDate51 = dateTime48.toLocalDate();
        org.joda.time.DateTime dateTime52 = dateTime48.toDateTime();
        org.joda.time.DateTime.Property property53 = dateTime52.era();
        org.joda.time.DateTime.Property property54 = dateTime52.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = property54.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder45.appendFraction(dateTimeFieldType55, 24, 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException61 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType55, (java.lang.Number) 10.0f, "1969365");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField63 = new org.joda.time.field.DividedDateTimeField(dateTimeField44, dateTimeFieldType55, (int) (byte) 10);
        org.joda.time.DurationField durationField64 = dividedDateTimeField63.getRangeDurationField();
        java.lang.String str66 = dividedDateTimeField63.getAsShortText(101L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter67 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter68 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.DateTimeZone dateTimeZone69 = null;
        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeUtils.getZone(dateTimeZone69);
        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime(dateTimeZone69);
        boolean boolean73 = dateTime71.isBefore((long) (-1));
        org.joda.time.LocalDate localDate74 = dateTime71.toLocalDate();
        java.lang.String str75 = dateTimeFormatter68.print((org.joda.time.ReadablePartial) localDate74);
        java.lang.String str76 = dateTimeFormatter67.print((org.joda.time.ReadablePartial) localDate74);
        int int77 = dividedDateTimeField63.getMaximumValue((org.joda.time.ReadablePartial) localDate74);
        int[] intArray79 = gregorianChronology23.get((org.joda.time.ReadablePartial) localDate74, 0L);
        try {
            iSOChronology0.validate(readablePartial18, intArray79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24L + "'", long10 == 24L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560639610124L + "'", long14 == 1560639610124L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 24L + "'", long37 == 24L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560639610124L + "'", long41 == 1560639610124L);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertNotNull(durationField64);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "0" + "'", str66.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeFormatter67);
        org.junit.Assert.assertNotNull(dateTimeFormatter68);
        org.junit.Assert.assertNotNull(dateTimeZone70);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(localDate74);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "1969-12-31T��:��:��.000" + "'", str75.equals("1969-12-31T��:��:��.000"));
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "��" + "'", str76.equals("��"));
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
        org.junit.Assert.assertNotNull(intArray79);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        int int2 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        int int6 = dateTime2.getDayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.era();
        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds((int) '4');
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.withPeriodAdded(readablePeriod14, (int) (byte) 10);
        org.joda.time.DateTime.Property property17 = dateTime13.hourOfDay();
        org.joda.time.DateTime dateTime19 = dateTime13.withMillis(1560639610124L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.minus(readableDuration7);
        org.joda.time.DateTime.Property property9 = dateTime8.dayOfMonth();
        org.joda.time.DateTime.Property property10 = dateTime8.weekyear();
        try {
            org.joda.time.DateTime dateTime12 = dateTime8.withSecondOfMinute(2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.halfdayOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology3 = iSOChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone5);
        boolean boolean9 = dateTime7.isBefore((long) (-1));
        org.joda.time.LocalDate localDate10 = dateTime7.toLocalDate();
        long long12 = iSOChronology2.set((org.joda.time.ReadablePartial) localDate10, (long) 24);
        long long16 = iSOChronology2.add(1560639600024L, 101L, (int) (byte) 100);
        org.joda.time.DurationField durationField17 = iSOChronology2.millis();
        org.joda.time.DurationField durationField18 = iSOChronology2.years();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone21);
        boolean boolean25 = dateTime23.isBefore((long) (-1));
        org.joda.time.LocalDate localDate26 = dateTime23.toLocalDate();
        org.joda.time.DateTime dateTime27 = dateTime23.toDateTime();
        org.joda.time.DateTime.Property property28 = dateTime27.era();
        org.joda.time.DateTime.Property property29 = dateTime27.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder20.appendFraction(dateTimeFieldType30, 24, 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, (java.lang.Number) 10.0f, "1969365");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField(dateTimeField19, dateTimeFieldType30, (int) (byte) 10);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField1, dateTimeFieldType30);
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeUtils.getZone(dateTimeZone40);
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone40);
        boolean boolean44 = dateTime42.isBefore((long) (-1));
        org.joda.time.DateTime dateTime46 = dateTime42.plusMillis((int) (byte) 10);
        org.joda.time.DateTime dateTime48 = dateTime42.minusMonths((int) 'a');
        org.joda.time.LocalDate localDate49 = dateTime42.toLocalDate();
        int int50 = zeroIsMaxDateTimeField39.getMinimumValue((org.joda.time.ReadablePartial) localDate49);
        int int53 = zeroIsMaxDateTimeField39.getDifference((long) 35, (long) (short) -1);
        long long56 = zeroIsMaxDateTimeField39.add(0L, (long) 1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24L + "'", long12 == 24L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560639610124L + "'", long16 == 1560639610124L);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 43200000L + "'", long56 == 43200000L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        java.util.Locale locale8 = null;
        java.util.Calendar calendar9 = dateTime7.toCalendar(locale8);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone10);
        boolean boolean14 = dateTime12.isBefore((long) (-1));
        org.joda.time.LocalDate localDate15 = dateTime12.toLocalDate();
        org.joda.time.DateTime.Property property16 = dateTime12.millisOfSecond();
        java.util.Date date17 = dateTime12.toDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone19);
        boolean boolean23 = dateTime21.isBefore((long) (-1));
        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
        org.joda.time.DateTime dateTime25 = dateTime21.toDateTime();
        org.joda.time.DateTime.Property property26 = dateTime25.era();
        org.joda.time.DateTime.Property property27 = dateTime25.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder18.appendFraction(dateTimeFieldType28, 24, 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 10.0f, "1969365");
        org.joda.time.DateTime dateTime36 = dateTime12.withField(dateTimeFieldType28, 24);
        org.joda.time.IllegalFieldValueException illegalFieldValueException38 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, "GregorianChronology[America/Los_Angeles,mdfw=6]");
        boolean boolean39 = dateTime7.isSupported(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(calendar9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Property[year]", "2019166", (int) (short) 0, (int) '4');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str7 = fixedDateTimeZone4.getNameKey((long) 47);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019166" + "'", str7.equals("2019166"));
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(10L);
//        java.lang.String str4 = dateTimeZone1.getID();
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        java.lang.String str7 = dateTimeZone1.getShortName((long) 124);
//        java.lang.String str8 = dateTimeZone1.toString();
//        long long11 = dateTimeZone1.adjustOffset(0L, false);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pacific Standard Time" + "'", str3.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "America/Los_Angeles" + "'", str4.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "America/Los_Angeles" + "'", str8.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("2019-06-15T14:37:26.480-07:00", "2019-06", 485, 2);
        long long6 = fixedDateTimeZone4.previousTransition((long) 77856);
        int int8 = fixedDateTimeZone4.getOffset(1560639563874L);
        java.lang.String str10 = fixedDateTimeZone4.getNameKey((long) 37);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 77856L + "'", long6 == 77856L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 485 + "'", int8 == 485);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019-06" + "'", str10.equals("2019-06"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '#');
        int int6 = offsetDateTimeField5.getMinimumValue();
        long long9 = offsetDateTimeField5.add(11L, 0);
        boolean boolean11 = offsetDateTimeField5.isLeap((long) 52630);
        long long13 = offsetDateTimeField5.roundHalfEven((long) ' ');
        long long15 = offsetDateTimeField5.roundHalfCeiling(0L);
        long long18 = offsetDateTimeField5.add((-1L), 166);
        long long21 = offsetDateTimeField5.add((long) 52661631, (long) 1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 11L + "'", long9 == 11L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 32L + "'", long13 == 32L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 165L + "'", long18 == 165L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 52661632L + "'", long21 == 52661632L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, 6);
        long long8 = dateTimeZone2.convertLocalToUTC(1560639600024L, false);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = cachedDateTimeZone10.getUncachedZone();
        org.joda.time.DateTimeZone dateTimeZone12 = cachedDateTimeZone10.getUncachedZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone10);
        java.lang.Appendable appendable14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone15);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone15);
        boolean boolean19 = dateTime17.isBefore((long) (-1));
        org.joda.time.LocalDate localDate20 = dateTime17.toLocalDate();
        org.joda.time.DateTime.Property property21 = dateTime17.millisOfSecond();
        java.util.Date date22 = dateTime17.toDate();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone24);
        boolean boolean28 = dateTime26.isBefore((long) (-1));
        org.joda.time.LocalDate localDate29 = dateTime26.toLocalDate();
        org.joda.time.DateTime dateTime30 = dateTime26.toDateTime();
        org.joda.time.DateTime.Property property31 = dateTime30.era();
        org.joda.time.DateTime.Property property32 = dateTime30.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder23.appendFraction(dateTimeFieldType33, 24, 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 10.0f, "1969365");
        org.joda.time.DateTime dateTime41 = dateTime17.withField(dateTimeFieldType33, 24);
        try {
            dateTimeFormatter0.printTo(appendable14, (org.joda.time.ReadableInstant) dateTime17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560664800024L + "'", long8 == 1560664800024L);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTime41);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone3);
        boolean boolean7 = dateTime5.isBefore((long) (-1));
        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
        long long10 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) 24);
        long long14 = iSOChronology0.add(1560639600024L, 101L, (int) (byte) 100);
        org.joda.time.DurationField durationField15 = iSOChronology0.millis();
        org.joda.time.DurationField durationField16 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone19);
        boolean boolean23 = dateTime21.isBefore((long) (-1));
        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
        org.joda.time.DateTime dateTime25 = dateTime21.toDateTime();
        org.joda.time.DateTime.Property property26 = dateTime25.era();
        org.joda.time.DateTime.Property property27 = dateTime25.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder18.appendFraction(dateTimeFieldType28, 24, 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 10.0f, "1969365");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType28, (int) (byte) 10);
        org.joda.time.DurationField durationField37 = dividedDateTimeField36.getRangeDurationField();
        java.lang.String str39 = dividedDateTimeField36.getAsShortText(101L);
        org.joda.time.DurationField durationField40 = dividedDateTimeField36.getLeapDurationField();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField41 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField36);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24L + "'", long10 == 24L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560639610124L + "'", long14 == 1560639610124L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0" + "'", str39.equals("0"));
        org.junit.Assert.assertNull(durationField40);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.halfdayOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology3 = iSOChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone5);
        boolean boolean9 = dateTime7.isBefore((long) (-1));
        org.joda.time.LocalDate localDate10 = dateTime7.toLocalDate();
        long long12 = iSOChronology2.set((org.joda.time.ReadablePartial) localDate10, (long) 24);
        long long16 = iSOChronology2.add(1560639600024L, 101L, (int) (byte) 100);
        org.joda.time.DurationField durationField17 = iSOChronology2.millis();
        org.joda.time.DurationField durationField18 = iSOChronology2.years();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone21);
        boolean boolean25 = dateTime23.isBefore((long) (-1));
        org.joda.time.LocalDate localDate26 = dateTime23.toLocalDate();
        org.joda.time.DateTime dateTime27 = dateTime23.toDateTime();
        org.joda.time.DateTime.Property property28 = dateTime27.era();
        org.joda.time.DateTime.Property property29 = dateTime27.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder20.appendFraction(dateTimeFieldType30, 24, 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, (java.lang.Number) 10.0f, "1969365");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField(dateTimeField19, dateTimeFieldType30, (int) (byte) 10);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField1, dateTimeFieldType30);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeUtils.getZone(dateTimeZone41);
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(dateTimeZone41);
        boolean boolean45 = dateTime43.isBefore((long) (-1));
        org.joda.time.LocalDate localDate46 = dateTime43.toLocalDate();
        java.lang.String str47 = dateTimeFormatter40.print((org.joda.time.ReadablePartial) localDate46);
        int[] intArray53 = new int[] { (byte) 1, 15, 6, 'a', 'a' };
        int int54 = zeroIsMaxDateTimeField39.getMaximumValue((org.joda.time.ReadablePartial) localDate46, intArray53);
        long long56 = zeroIsMaxDateTimeField39.roundFloor((-1036795680000000L));
        int int59 = zeroIsMaxDateTimeField39.getDifference(1560664800024L, (long) 10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24L + "'", long12 == 24L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560639610124L + "'", long16 == 1560639610124L);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1969-12-31T��:��:��.000" + "'", str47.equals("1969-12-31T��:��:��.000"));
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2 + "'", int54 == 2);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-1036795680000000L) + "'", long56 == (-1036795680000000L));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 36126 + "'", int59 == 36126);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        int int6 = dateTime2.getDayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.era();
        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.Chronology chronology12 = iSOChronology9.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology9.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology9.minuteOfHour();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.halfdayOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology3 = iSOChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone5);
        boolean boolean9 = dateTime7.isBefore((long) (-1));
        org.joda.time.LocalDate localDate10 = dateTime7.toLocalDate();
        long long12 = iSOChronology2.set((org.joda.time.ReadablePartial) localDate10, (long) 24);
        long long16 = iSOChronology2.add(1560639600024L, 101L, (int) (byte) 100);
        org.joda.time.DurationField durationField17 = iSOChronology2.millis();
        org.joda.time.DurationField durationField18 = iSOChronology2.years();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone21);
        boolean boolean25 = dateTime23.isBefore((long) (-1));
        org.joda.time.LocalDate localDate26 = dateTime23.toLocalDate();
        org.joda.time.DateTime dateTime27 = dateTime23.toDateTime();
        org.joda.time.DateTime.Property property28 = dateTime27.era();
        org.joda.time.DateTime.Property property29 = dateTime27.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder20.appendFraction(dateTimeFieldType30, 24, 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, (java.lang.Number) 10.0f, "1969365");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField(dateTimeField19, dateTimeFieldType30, (int) (byte) 10);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField1, dateTimeFieldType30);
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeUtils.getZone(dateTimeZone40);
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone40);
        boolean boolean44 = dateTime42.isBefore((long) (-1));
        org.joda.time.DateTime dateTime46 = dateTime42.plusMillis((int) (byte) 10);
        org.joda.time.DateTime dateTime48 = dateTime42.minusMonths((int) 'a');
        org.joda.time.LocalDate localDate49 = dateTime42.toLocalDate();
        int int50 = zeroIsMaxDateTimeField39.getMinimumValue((org.joda.time.ReadablePartial) localDate49);
        org.joda.time.DateTimeField dateTimeField51 = zeroIsMaxDateTimeField39.getWrappedField();
        long long53 = zeroIsMaxDateTimeField39.roundHalfEven((long) 3);
        java.util.Locale locale55 = null;
        java.lang.String str56 = zeroIsMaxDateTimeField39.getAsText(56, locale55);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24L + "'", long12 == 24L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560639610124L + "'", long16 == 1560639610124L);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "56" + "'", str56.equals("56"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        boolean boolean2 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter0.getParser();
        java.lang.StringBuffer stringBuffer4 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer4, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeParser3);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean5 = dateTime3.isBefore((long) (-1));
        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType10, 24, 10);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology15 = iSOChronology14.withUTC();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone17);
        boolean boolean21 = dateTime19.isBefore((long) (-1));
        org.joda.time.LocalDate localDate22 = dateTime19.toLocalDate();
        long long24 = iSOChronology14.set((org.joda.time.ReadablePartial) localDate22, (long) 24);
        long long28 = iSOChronology14.add(1560639600024L, 101L, (int) (byte) 100);
        org.joda.time.DurationField durationField29 = iSOChronology14.millis();
        org.joda.time.DurationField durationField30 = iSOChronology14.years();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology14.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeUtils.getZone(dateTimeZone33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone33);
        boolean boolean37 = dateTime35.isBefore((long) (-1));
        org.joda.time.LocalDate localDate38 = dateTime35.toLocalDate();
        org.joda.time.DateTime dateTime39 = dateTime35.toDateTime();
        org.joda.time.DateTime.Property property40 = dateTime39.era();
        org.joda.time.DateTime.Property property41 = dateTime39.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property41.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder32.appendFraction(dateTimeFieldType42, 24, 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, (java.lang.Number) 10.0f, "1969365");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField50 = new org.joda.time.field.DividedDateTimeField(dateTimeField31, dateTimeFieldType42, (int) (byte) 10);
        org.joda.time.DurationField durationField51 = dividedDateTimeField50.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField52 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField51);
        int int55 = unsupportedDateTimeField52.getDifference((long) (byte) -1, 1560664800024L);
        long long58 = unsupportedDateTimeField52.add((-1036800000000000L), (int) (short) 100);
        org.joda.time.DurationField durationField59 = unsupportedDateTimeField52.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType60 = unsupportedDateTimeField52.getType();
        try {
            java.lang.String str62 = unsupportedDateTimeField52.getAsText((long) (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 24L + "'", long24 == 24L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560639610124L + "'", long28 == 1560639610124L);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-36126) + "'", int55 == (-36126));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-1036795680000000L) + "'", long58 == (-1036795680000000L));
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertNotNull(dateTimeFieldType60);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfSecond();
        int int7 = dateTime2.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone8);
        int int11 = dateTime10.getWeekOfWeekyear();
        boolean boolean12 = dateTime2.equals((java.lang.Object) dateTime10);
        org.joda.time.DateTime dateTime14 = dateTime10.plusHours((int) (byte) -1);
        org.joda.time.DateTime.Property property15 = dateTime10.secondOfDay();
        org.joda.time.DateTime dateTime17 = dateTime10.plusSeconds(14);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 6);
        org.joda.time.Chronology chronology5 = gregorianChronology4.withUTC();
        org.joda.time.DurationField durationField6 = gregorianChronology4.hours();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology4.getZone();
        long long11 = dateTimeZone7.convertLocalToUTC(52661632L, true, (-70886L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 81461632L + "'", long11 == 81461632L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        java.util.Locale locale8 = null;
        java.lang.String str9 = property6.getAsText(locale8);
        org.joda.time.DateTime dateTime11 = property6.setCopy((int) '4');
        java.util.Locale locale12 = null;
        java.lang.String str13 = property6.getAsShortText(locale12);
        org.joda.time.DateTime dateTime15 = property6.addToCopy((-28800000));
        org.joda.time.DateTime.Property property16 = dateTime15.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "490" + "'", str9.equals("490"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "490" + "'", str13.equals("490"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '#');
        long long8 = offsetDateTimeField5.addWrapField((long) (byte) 100, 1);
        long long10 = offsetDateTimeField5.roundHalfEven((long) (short) 100);
        boolean boolean11 = offsetDateTimeField5.isLenient();
        boolean boolean13 = offsetDateTimeField5.isLeap((long) 6);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 101L + "'", long8 == 101L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone3);
        boolean boolean7 = dateTime5.isBefore((long) (-1));
        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
        long long10 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) 24);
        long long14 = iSOChronology0.add(1560639600024L, 101L, (int) (byte) 100);
        org.joda.time.DurationField durationField15 = iSOChronology0.millis();
        org.joda.time.DurationField durationField16 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone19);
        boolean boolean23 = dateTime21.isBefore((long) (-1));
        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
        org.joda.time.DateTime dateTime25 = dateTime21.toDateTime();
        org.joda.time.DateTime.Property property26 = dateTime25.era();
        org.joda.time.DateTime.Property property27 = dateTime25.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder18.appendFraction(dateTimeFieldType28, 24, 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 10.0f, "1969365");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType28, (int) (byte) 10);
        long long39 = dividedDateTimeField36.getDifferenceAsLong((long) (byte) 1, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology40.halfdayOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology43 = iSOChronology42.withUTC();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology42.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeUtils.getZone(dateTimeZone45);
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(dateTimeZone45);
        boolean boolean49 = dateTime47.isBefore((long) (-1));
        org.joda.time.LocalDate localDate50 = dateTime47.toLocalDate();
        long long52 = iSOChronology42.set((org.joda.time.ReadablePartial) localDate50, (long) 24);
        long long56 = iSOChronology42.add(1560639600024L, 101L, (int) (byte) 100);
        org.joda.time.DurationField durationField57 = iSOChronology42.millis();
        org.joda.time.DurationField durationField58 = iSOChronology42.years();
        org.joda.time.DateTimeField dateTimeField59 = iSOChronology42.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone61 = null;
        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeUtils.getZone(dateTimeZone61);
        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime(dateTimeZone61);
        boolean boolean65 = dateTime63.isBefore((long) (-1));
        org.joda.time.LocalDate localDate66 = dateTime63.toLocalDate();
        org.joda.time.DateTime dateTime67 = dateTime63.toDateTime();
        org.joda.time.DateTime.Property property68 = dateTime67.era();
        org.joda.time.DateTime.Property property69 = dateTime67.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType70 = property69.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder60.appendFraction(dateTimeFieldType70, 24, 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException76 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType70, (java.lang.Number) 10.0f, "1969365");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField78 = new org.joda.time.field.DividedDateTimeField(dateTimeField59, dateTimeFieldType70, (int) (byte) 10);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField79 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField41, dateTimeFieldType70);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField80 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField36, dateTimeFieldType70);
        long long83 = remainderDateTimeField80.addWrapField((long) ' ', 0);
        java.util.Locale locale84 = null;
        int int85 = remainderDateTimeField80.getMaximumTextLength(locale84);
        try {
            long long88 = remainderDateTimeField80.set(14299200000L, "2019-06-15T21:37:43.321");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-15T21:37:43.321\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24L + "'", long10 == 24L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560639610124L + "'", long14 == 1560639610124L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 24L + "'", long52 == 24L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560639610124L + "'", long56 == 1560639610124L);
        org.junit.Assert.assertNotNull(durationField57);
        org.junit.Assert.assertNotNull(durationField58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeZone62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(localDate66);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(property68);
        org.junit.Assert.assertNotNull(property69);
        org.junit.Assert.assertNotNull(dateTimeFieldType70);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 32L + "'", long83 == 32L);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1 + "'", int85 == 1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '#');
        long long8 = offsetDateTimeField5.addWrapField((long) (byte) 100, 1);
        long long10 = offsetDateTimeField5.roundHalfEven((long) (short) 100);
        boolean boolean12 = offsetDateTimeField5.isLeap(32L);
        org.joda.time.DurationField durationField13 = offsetDateTimeField5.getLeapDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 101L + "'", long8 == 101L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(durationField13);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (-86399934L), 292278993);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        int int6 = dateTime2.getDayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.era();
        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.Chronology chronology12 = iSOChronology9.withUTC();
        org.joda.time.DurationField durationField13 = iSOChronology9.hours();
        try {
            long long21 = iSOChronology9.getDateTimeMillis(56, (int) (short) 100, (int) (byte) 1, 44, 77856, 56, 36126);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 44 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean5 = dateTime3.isBefore((long) (-1));
        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType10, 24, 10);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology15 = iSOChronology14.withUTC();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone17);
        boolean boolean21 = dateTime19.isBefore((long) (-1));
        org.joda.time.LocalDate localDate22 = dateTime19.toLocalDate();
        long long24 = iSOChronology14.set((org.joda.time.ReadablePartial) localDate22, (long) 24);
        long long28 = iSOChronology14.add(1560639600024L, 101L, (int) (byte) 100);
        org.joda.time.DurationField durationField29 = iSOChronology14.millis();
        org.joda.time.DurationField durationField30 = iSOChronology14.years();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology14.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeUtils.getZone(dateTimeZone33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone33);
        boolean boolean37 = dateTime35.isBefore((long) (-1));
        org.joda.time.LocalDate localDate38 = dateTime35.toLocalDate();
        org.joda.time.DateTime dateTime39 = dateTime35.toDateTime();
        org.joda.time.DateTime.Property property40 = dateTime39.era();
        org.joda.time.DateTime.Property property41 = dateTime39.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property41.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder32.appendFraction(dateTimeFieldType42, 24, 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, (java.lang.Number) 10.0f, "1969365");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField50 = new org.joda.time.field.DividedDateTimeField(dateTimeField31, dateTimeFieldType42, (int) (byte) 10);
        org.joda.time.DurationField durationField51 = dividedDateTimeField50.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField52 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField51);
        try {
            long long54 = unsupportedDateTimeField52.roundHalfCeiling(1L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfEra field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 24L + "'", long24 == 24L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560639610124L + "'", long28 == 1560639610124L);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField52);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
//        java.lang.String str8 = dateTimeZone6.getName(10L);
//        java.lang.String str9 = dateTimeZone6.getID();
//        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
//        java.lang.String str11 = dateTimeZone6.toString();
//        long long14 = dateTimeZone6.convertLocalToUTC((long) 8, true);
//        try {
//            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(52696746, 124, 3, 0, (-6), dateTimeZone6);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -6 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Pacific Standard Time" + "'", str8.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(iSOChronology10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "America/Los_Angeles" + "'", str11.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 28800008L + "'", long14 == 28800008L);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '#');
        int int6 = offsetDateTimeField5.getMinimumValue();
        long long9 = offsetDateTimeField5.add(11L, 0);
        boolean boolean11 = offsetDateTimeField5.isLeap((long) 52630);
        long long13 = offsetDateTimeField5.roundHalfEven((long) ' ');
        long long15 = offsetDateTimeField5.roundHalfCeiling(0L);
        long long18 = offsetDateTimeField5.add((-1L), 166);
        long long20 = offsetDateTimeField5.roundFloor((long) 24000006);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 11L + "'", long9 == 11L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 32L + "'", long13 == 32L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 165L + "'", long18 == 165L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 24000006L + "'", long20 == 24000006L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendSecondOfDay(166);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendWeekOfWeekyear((int) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.append(dateTimeFormatter12);
        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatter12.getPrinter();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray15 = new org.joda.time.format.DateTimeParser[] {};
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder6.append(dateTimePrinter14, dateTimeParserArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimePrinter14);
        org.junit.Assert.assertNotNull(dateTimeParserArray15);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone8);
        boolean boolean12 = dateTime10.isBefore((long) (-1));
        org.joda.time.LocalDate localDate13 = dateTime10.toLocalDate();
        int int14 = dateTime10.getDayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        boolean boolean16 = dateTime10.isSupported(dateTimeFieldType15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.era();
        org.joda.time.DateTime dateTime19 = dateTime10.withChronology((org.joda.time.Chronology) iSOChronology17);
        java.lang.String str20 = dateTime19.toString();
        boolean boolean21 = dateTime7.isAfter((org.joda.time.ReadableInstant) dateTime19);
        int int22 = dateTime19.getMinuteOfHour();
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology26 = iSOChronology25.withUTC();
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone28 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone28);
        boolean boolean32 = dateTime30.isBefore((long) (-1));
        org.joda.time.LocalDate localDate33 = dateTime30.toLocalDate();
        long long35 = iSOChronology25.set((org.joda.time.ReadablePartial) localDate33, (long) 24);
        long long39 = iSOChronology25.add(1560639600024L, 101L, (int) (byte) 100);
        org.joda.time.DurationField durationField40 = iSOChronology25.millis();
        org.joda.time.DurationField durationField41 = iSOChronology25.years();
        org.joda.time.DateTimeField dateTimeField42 = iSOChronology25.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeUtils.getZone(dateTimeZone44);
        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime(dateTimeZone44);
        boolean boolean48 = dateTime46.isBefore((long) (-1));
        org.joda.time.LocalDate localDate49 = dateTime46.toLocalDate();
        org.joda.time.DateTime dateTime50 = dateTime46.toDateTime();
        org.joda.time.DateTime.Property property51 = dateTime50.era();
        org.joda.time.DateTime.Property property52 = dateTime50.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType53 = property52.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder43.appendFraction(dateTimeFieldType53, 24, 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException59 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType53, (java.lang.Number) 10.0f, "1969365");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField61 = new org.joda.time.field.DividedDateTimeField(dateTimeField42, dateTimeFieldType53, (int) (byte) 10);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField62 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField24, dateTimeFieldType53);
        org.joda.time.DateTime dateTime64 = dateTime19.withField(dateTimeFieldType53, 2);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969-12-31T16:00:02.490-08:00" + "'", str20.equals("1969-12-31T16:00:02.490-08:00"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 24L + "'", long35 == 24L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560639610124L + "'", long39 == 1560639610124L);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(dateTimeFieldType53);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
        org.junit.Assert.assertNotNull(dateTime64);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("2019-06-15T14:37:26.480-07:00", "2019-06", 485, 2);
//        int int6 = fixedDateTimeZone4.getStandardOffset((long) (byte) 100);
//        int int8 = fixedDateTimeZone4.getOffsetFromLocal(32L);
//        long long10 = fixedDateTimeZone4.nextTransition(28800000L);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        java.lang.String str14 = dateTimeZone12.getName(10L);
//        java.lang.String str15 = dateTimeZone12.getID();
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = dateTimeZone12.getShortName((long) (byte) 10, locale17);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = dateTimeZone12.getName((-28800000L), locale20);
//        long long23 = fixedDateTimeZone4.getMillisKeepLocal(dateTimeZone12, (long) (byte) 100);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 485 + "'", int8 == 485);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800000L + "'", long10 == 28800000L);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Pacific Standard Time" + "'", str14.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "America/Los_Angeles" + "'", str15.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "PST" + "'", str18.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 28800585L + "'", long23 == 28800585L);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
        org.joda.time.DateTime dateTime8 = dateTime2.minusMillis(2019);
        org.joda.time.DateTime dateTime10 = dateTime2.withDayOfMonth(15);
        int int11 = dateTime2.getMinuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 960 + "'", int11 == 960);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.halfdayOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology3 = iSOChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone5);
        boolean boolean9 = dateTime7.isBefore((long) (-1));
        org.joda.time.LocalDate localDate10 = dateTime7.toLocalDate();
        long long12 = iSOChronology2.set((org.joda.time.ReadablePartial) localDate10, (long) 24);
        long long16 = iSOChronology2.add(1560639600024L, 101L, (int) (byte) 100);
        org.joda.time.DurationField durationField17 = iSOChronology2.millis();
        org.joda.time.DurationField durationField18 = iSOChronology2.years();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone21);
        boolean boolean25 = dateTime23.isBefore((long) (-1));
        org.joda.time.LocalDate localDate26 = dateTime23.toLocalDate();
        org.joda.time.DateTime dateTime27 = dateTime23.toDateTime();
        org.joda.time.DateTime.Property property28 = dateTime27.era();
        org.joda.time.DateTime.Property property29 = dateTime27.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder20.appendFraction(dateTimeFieldType30, 24, 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, (java.lang.Number) 10.0f, "1969365");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField(dateTimeField19, dateTimeFieldType30, (int) (byte) 10);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField1, dateTimeFieldType30);
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeUtils.getZone(dateTimeZone40);
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone40);
        boolean boolean44 = dateTime42.isBefore((long) (-1));
        org.joda.time.DateTime dateTime46 = dateTime42.plusMillis((int) (byte) 10);
        org.joda.time.DateTime dateTime48 = dateTime42.minusMonths((int) 'a');
        org.joda.time.LocalDate localDate49 = dateTime42.toLocalDate();
        int int50 = zeroIsMaxDateTimeField39.getMinimumValue((org.joda.time.ReadablePartial) localDate49);
        org.joda.time.DateTimeField dateTimeField51 = zeroIsMaxDateTimeField39.getWrappedField();
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField53 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) zeroIsMaxDateTimeField39, dateTimeFieldType52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24L + "'", long12 == 24L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560639610124L + "'", long16 == 1560639610124L);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(dateTimeField51);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '#');
        int int6 = offsetDateTimeField5.getMinimumValue();
        long long9 = offsetDateTimeField5.add(0L, 292278993);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology11 = iSOChronology10.withUTC();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology10.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) '#');
        int int16 = offsetDateTimeField15.getMinimumValue();
        long long19 = offsetDateTimeField15.add(0L, 292278993);
        long long21 = offsetDateTimeField15.roundHalfFloor(1L);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology23 = iSOChronology22.withUTC();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone25);
        boolean boolean29 = dateTime27.isBefore((long) (-1));
        org.joda.time.LocalDate localDate30 = dateTime27.toLocalDate();
        long long32 = iSOChronology22.set((org.joda.time.ReadablePartial) localDate30, (long) 24);
        long long36 = iSOChronology22.add(1560639600024L, 101L, (int) (byte) 100);
        org.joda.time.DurationField durationField37 = iSOChronology22.millis();
        org.joda.time.DurationField durationField38 = iSOChronology22.years();
        org.joda.time.DateTimeField dateTimeField39 = iSOChronology22.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeUtils.getZone(dateTimeZone41);
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(dateTimeZone41);
        boolean boolean45 = dateTime43.isBefore((long) (-1));
        org.joda.time.LocalDate localDate46 = dateTime43.toLocalDate();
        org.joda.time.DateTime dateTime47 = dateTime43.toDateTime();
        org.joda.time.DateTime.Property property48 = dateTime47.era();
        org.joda.time.DateTime.Property property49 = dateTime47.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType50 = property49.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = dateTimeFormatterBuilder40.appendFraction(dateTimeFieldType50, 24, 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException56 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType50, (java.lang.Number) 10.0f, "1969365");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField58 = new org.joda.time.field.DividedDateTimeField(dateTimeField39, dateTimeFieldType50, (int) (byte) 10);
        org.joda.time.DurationField durationField59 = dividedDateTimeField58.getRangeDurationField();
        int int61 = dividedDateTimeField58.getMaximumValue((long) 20);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter62 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter63 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.DateTimeZone dateTimeZone64 = null;
        org.joda.time.DateTimeZone dateTimeZone65 = org.joda.time.DateTimeUtils.getZone(dateTimeZone64);
        org.joda.time.DateTime dateTime66 = new org.joda.time.DateTime(dateTimeZone64);
        boolean boolean68 = dateTime66.isBefore((long) (-1));
        org.joda.time.LocalDate localDate69 = dateTime66.toLocalDate();
        java.lang.String str70 = dateTimeFormatter63.print((org.joda.time.ReadablePartial) localDate69);
        java.lang.String str71 = dateTimeFormatter62.print((org.joda.time.ReadablePartial) localDate69);
        java.util.Locale locale73 = null;
        java.lang.String str74 = dividedDateTimeField58.getAsText((org.joda.time.ReadablePartial) localDate69, 0, locale73);
        int int75 = offsetDateTimeField15.getMinimumValue((org.joda.time.ReadablePartial) localDate69);
        int int76 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) localDate69);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 292278993L + "'", long9 == 292278993L);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 35 + "'", int16 == 35);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 292278993L + "'", long19 == 292278993L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(localDate30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 24L + "'", long32 == 24L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560639610124L + "'", long36 == 1560639610124L);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(dateTimeFieldType50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder53);
        org.junit.Assert.assertNotNull(durationField59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter62);
        org.junit.Assert.assertNotNull(dateTimeFormatter63);
        org.junit.Assert.assertNotNull(dateTimeZone65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(localDate69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "1969-12-31T��:��:��.000" + "'", str70.equals("1969-12-31T��:��:��.000"));
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "��" + "'", str71.equals("��"));
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "0" + "'", str74.equals("0"));
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 35 + "'", int75 == 35);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 35 + "'", int76 == 35);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(dateTimeZone2);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear(8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendDayOfWeek(10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.lang.String str3 = dateTimeZone1.getName((long) 4);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DateTime dateTime9 = property6.addToCopy((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.withZone(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = dateTime11.plusDays(1);
        org.joda.time.DateTime dateTime14 = dateTime11.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime16 = dateTime11.minusMinutes(52630);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        int int6 = dateTime2.getDayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.era();
        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DurationField durationField12 = iSOChronology9.seconds();
        java.lang.String str13 = iSOChronology9.toString();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology9.monthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ISOChronology[UTC]" + "'", str13.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "2019166");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property7 = dateTime6.era();
        org.joda.time.DateTime.Property property8 = dateTime6.yearOfEra();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.minusSeconds(0);
        java.util.Locale locale12 = null;
        java.util.Calendar calendar13 = dateTime11.toCalendar(locale12);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime16 = dateTime11.withDurationAdded(readableDuration14, 20);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(calendar13);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis((int) (byte) 10);
        org.joda.time.DateTime dateTime8 = dateTime2.minusMonths((int) 'a');
        org.joda.time.DateTime.Property property9 = dateTime8.millisOfDay();
        org.joda.time.DateTime dateTime11 = dateTime8.plusMonths((int) (byte) 0);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfEra();
        org.joda.time.DateTime dateTime13 = property12.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime15 = dateTime13.plus(110L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DateTime dateTime8 = property6.getDateTime();
        org.joda.time.DateTime.Property property9 = dateTime8.dayOfMonth();
        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        int int6 = dateTime2.getDayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.era();
        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.Chronology chronology12 = iSOChronology9.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology9.clockhourOfHalfday();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        try {
            int[] intArray17 = iSOChronology9.get(readablePeriod14, 9972000000L, (long) 999);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 6);
        long long7 = dateTimeZone1.convertLocalToUTC(1560639600024L, false);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        int int11 = cachedDateTimeZone9.getStandardOffset((-950399123L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560639600024L + "'", long7 == 1560639600024L);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("695");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"695/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfDay();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = iSOChronology0.add(readablePeriod3, 101L, 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 101L + "'", long6 == 101L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime8 = dateTime2.plusYears((int) 'a');
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone10);
        boolean boolean14 = dateTime12.isBefore((long) (-1));
        org.joda.time.LocalDate localDate15 = dateTime12.toLocalDate();
        org.joda.time.DateTime.Property property16 = dateTime12.millisOfSecond();
        int int17 = dateTime12.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(dateTimeZone18);
        int int21 = dateTime20.getWeekOfWeekyear();
        boolean boolean22 = dateTime12.equals((java.lang.Object) dateTime20);
        org.joda.time.DateTime dateTime24 = dateTime20.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime26 = dateTime24.withWeekyear(35);
        int int27 = property9.getDifference((org.joda.time.ReadableInstant) dateTime26);
        java.util.Locale locale28 = null;
        int int29 = property9.getMaximumTextLength(locale28);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2031 + "'", int27 == 2031);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 9 + "'", int29 == 9);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("2019-06-15T14:37:26.480-07:00", "2019-06", 485, 2);
        long long6 = fixedDateTimeZone4.previousTransition((long) 77856);
        int int8 = fixedDateTimeZone4.getStandardOffset(1560634619050L);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 124);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 124");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 77856L + "'", long6 == 77856L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (-70886L), 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.DurationField durationField4 = gregorianChronology1.seconds();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean5 = dateTime3.isBefore((long) (-1));
        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType10, 24, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone17);
        boolean boolean21 = dateTime19.isBefore((long) (-1));
        org.joda.time.LocalDate localDate22 = dateTime19.toLocalDate();
        org.joda.time.DateTime dateTime23 = dateTime19.toDateTime();
        org.joda.time.DateTime.Property property24 = dateTime23.era();
        org.joda.time.DateTime.Property property25 = dateTime23.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property25.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder16.appendFraction(dateTimeFieldType26, 24, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder29.appendLiteral('4');
        boolean boolean32 = dateTimeFormatterBuilder29.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder33.appendClockhourOfDay((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder33.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeUtils.getZone(dateTimeZone38);
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(dateTimeZone38);
        boolean boolean42 = dateTime40.isBefore((long) (-1));
        org.joda.time.LocalDate localDate43 = dateTime40.toLocalDate();
        int int44 = dateTime40.getDayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = null;
        boolean boolean46 = dateTime40.isSupported(dateTimeFieldType45);
        java.util.Date date47 = dateTime40.toDate();
        java.lang.String str48 = dateTimeFormatter37.print((org.joda.time.ReadableInstant) dateTime40);
        int int49 = dateTime40.getDayOfMonth();
        org.joda.time.DateTime dateTime51 = dateTime40.minus((-25L));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime(dateTimeZone53);
        boolean boolean57 = dateTime55.isBefore((long) (-1));
        org.joda.time.LocalDate localDate58 = dateTime55.toLocalDate();
        org.joda.time.DateTime dateTime59 = dateTime55.toDateTime();
        org.joda.time.DateTime.Property property60 = dateTime59.era();
        org.joda.time.DateTime.Property property61 = dateTime59.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder52.appendFraction(dateTimeFieldType62, 24, 10);
        int int66 = dateTime51.get(dateTimeFieldType62);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder33.appendText(dateTimeFieldType62);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder70 = dateTimeFormatterBuilder29.appendFraction(dateTimeFieldType62, 0, 47);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder15.appendSignedDecimal(dateTimeFieldType62, (-28800000), 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 4 + "'", int44 == 4);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1970001" + "'", str48.equals("1970001"));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(localDate58);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1970 + "'", int66 == 1970);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder70);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean5 = dateTime3.isBefore((long) (-1));
        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType10, 24, 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter15 = dateTimeFormatter14.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.append(dateTimePrinter15);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendMonthOfYearText();
        boolean boolean18 = dateTimeFormatterBuilder17.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendClockhourOfDay(19);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimePrinter15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.halfdayOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology3 = iSOChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone5);
        boolean boolean9 = dateTime7.isBefore((long) (-1));
        org.joda.time.LocalDate localDate10 = dateTime7.toLocalDate();
        long long12 = iSOChronology2.set((org.joda.time.ReadablePartial) localDate10, (long) 24);
        long long16 = iSOChronology2.add(1560639600024L, 101L, (int) (byte) 100);
        org.joda.time.DurationField durationField17 = iSOChronology2.millis();
        org.joda.time.DurationField durationField18 = iSOChronology2.years();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(dateTimeZone21);
        boolean boolean25 = dateTime23.isBefore((long) (-1));
        org.joda.time.LocalDate localDate26 = dateTime23.toLocalDate();
        org.joda.time.DateTime dateTime27 = dateTime23.toDateTime();
        org.joda.time.DateTime.Property property28 = dateTime27.era();
        org.joda.time.DateTime.Property property29 = dateTime27.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder20.appendFraction(dateTimeFieldType30, 24, 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType30, (java.lang.Number) 10.0f, "1969365");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField38 = new org.joda.time.field.DividedDateTimeField(dateTimeField19, dateTimeFieldType30, (int) (byte) 10);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField1, dateTimeFieldType30);
        org.joda.time.DateTimeZone dateTimeZone40 = null;
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeUtils.getZone(dateTimeZone40);
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone40);
        boolean boolean44 = dateTime42.isBefore((long) (-1));
        org.joda.time.DateTime dateTime46 = dateTime42.plusMillis((int) (byte) 10);
        org.joda.time.DateTime dateTime48 = dateTime42.minusMonths((int) 'a');
        org.joda.time.LocalDate localDate49 = dateTime42.toLocalDate();
        int int50 = zeroIsMaxDateTimeField39.getMinimumValue((org.joda.time.ReadablePartial) localDate49);
        org.joda.time.DateTimeField dateTimeField51 = zeroIsMaxDateTimeField39.getWrappedField();
        long long53 = zeroIsMaxDateTimeField39.roundHalfEven((long) 3);
        java.util.Locale locale55 = null;
        java.lang.String str56 = zeroIsMaxDateTimeField39.getAsText(1560630959050L, locale55);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24L + "'", long12 == 24L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560639610124L + "'", long16 == 1560639610124L);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "1" + "'", str56.equals("1"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone5);
        int int8 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property9 = dateTime7.minuteOfHour();
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime2, (org.joda.time.ReadableInstant) dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("809");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '809' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        java.lang.String str3 = dateTimeZone1.getName(10L);
//        java.lang.String str4 = dateTimeZone1.getID();
//        long long6 = dateTimeZone1.convertUTCToLocal((long) (short) 0);
//        long long10 = dateTimeZone1.convertLocalToUTC((long) 124, false, (long) 14);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.lang.String str13 = cachedDateTimeZone11.getNameKey(0L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 124L + "'", long10 == 124L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UTC" + "'", str13.equals("UTC"));
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        int int6 = dateTime2.getDayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
        java.util.Date date9 = dateTime2.toDate();
        org.joda.time.DateTime dateTime11 = dateTime2.minusMinutes((-1));
        int int12 = dateTime11.getYearOfCentury();
        org.joda.time.DateTime dateTime15 = dateTime11.withDurationAdded((-62134790821965L), (-6));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 70 + "'", int12 == 70);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.secondOfMinute();
        org.joda.time.DurationField durationField5 = iSOChronology0.weekyears();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField8 = new org.joda.time.field.ScaledDurationField(durationField5, durationFieldType6, 22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("951");
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime7 = property6.getDateTime();
        org.joda.time.DateTime dateTime9 = property6.addToCopy((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.withZone(dateTimeZone10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone13);
        boolean boolean17 = dateTime15.isBefore((long) (-1));
        org.joda.time.LocalDate localDate18 = dateTime15.toLocalDate();
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime();
        org.joda.time.DateTime.Property property20 = dateTime19.era();
        org.joda.time.DateTime.Property property21 = dateTime19.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder12.appendFraction(dateTimeFieldType22, 24, 10);
        org.joda.time.DateTime.Property property26 = dateTime9.property(dateTimeFieldType22);
        try {
            org.joda.time.DateTime dateTime28 = dateTime9.withMillisOfSecond((-36126));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -36126 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(property26);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean5 = dateTime3.isBefore((long) (-1));
        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType10, 24, 10);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology15 = iSOChronology14.withUTC();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology14.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone17);
        boolean boolean21 = dateTime19.isBefore((long) (-1));
        org.joda.time.LocalDate localDate22 = dateTime19.toLocalDate();
        long long24 = iSOChronology14.set((org.joda.time.ReadablePartial) localDate22, (long) 24);
        long long28 = iSOChronology14.add(1560639600024L, 101L, (int) (byte) 100);
        org.joda.time.DurationField durationField29 = iSOChronology14.millis();
        org.joda.time.DurationField durationField30 = iSOChronology14.years();
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology14.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeUtils.getZone(dateTimeZone33);
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone33);
        boolean boolean37 = dateTime35.isBefore((long) (-1));
        org.joda.time.LocalDate localDate38 = dateTime35.toLocalDate();
        org.joda.time.DateTime dateTime39 = dateTime35.toDateTime();
        org.joda.time.DateTime.Property property40 = dateTime39.era();
        org.joda.time.DateTime.Property property41 = dateTime39.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property41.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder32.appendFraction(dateTimeFieldType42, 24, 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, (java.lang.Number) 10.0f, "1969365");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField50 = new org.joda.time.field.DividedDateTimeField(dateTimeField31, dateTimeFieldType42, (int) (byte) 10);
        org.joda.time.DurationField durationField51 = dividedDateTimeField50.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField52 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType10, durationField51);
        int int55 = unsupportedDateTimeField52.getDifference((long) (byte) -1, 1560664800024L);
        long long58 = unsupportedDateTimeField52.getDifferenceAsLong((-1036795680000000L), 86400000000L);
        org.joda.time.DurationField durationField59 = unsupportedDateTimeField52.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 24L + "'", long24 == 24L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560639610124L + "'", long28 == 1560639610124L);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
        org.junit.Assert.assertNotNull(durationField51);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-36126) + "'", int55 == (-36126));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-24001900L) + "'", long58 == (-24001900L));
        org.junit.Assert.assertNotNull(durationField59);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime();
        org.joda.time.DateMidnight dateMidnight7 = dateTime2.toDateMidnight();
        org.joda.time.DateTime.Property property8 = dateTime2.centuryOfEra();
        org.joda.time.DateTime.Property property9 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime10 = property9.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateMidnight7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfDay();
        org.joda.time.DurationField durationField3 = iSOChronology0.halfdays();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5, 6);
        long long11 = dateTimeZone5.convertLocalToUTC(1560639600024L, false);
        java.lang.String str12 = dateTimeZone5.toString();
        org.joda.time.Chronology chronology13 = iSOChronology0.withZone(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560639600024L + "'", long11 == 1560639600024L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean5 = dateTime3.isBefore((long) (-1));
        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType10, 24, 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder0.appendHourOfHalfday(877);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder0.appendSecondOfMinute(877);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendPattern("2019-06-16T14:37:20.626-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        int int6 = dateTime2.getDayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        boolean boolean8 = dateTime2.isSupported(dateTimeFieldType7);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.era();
        org.joda.time.DateTime dateTime11 = dateTime2.withChronology((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DurationField durationField12 = iSOChronology9.days();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology9.year();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone1);
        boolean boolean5 = dateTime3.isBefore((long) (-1));
        org.joda.time.LocalDate localDate6 = dateTime3.toLocalDate();
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTime.Property property9 = dateTime7.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendFraction(dateTimeFieldType10, 24, 10);
        org.joda.time.format.DateTimeParser dateTimeParser14 = dateTimeFormatterBuilder13.toParser();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeParser14);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, (int) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        java.lang.String str4 = gregorianChronology3.toString();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[+00:10]" + "'", str4.equals("GregorianChronology[+00:10]"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.DateTime dateTime6 = dateTime2.plusMillis(24);
        boolean boolean8 = dateTime2.isBefore((-28800000L));
        int int9 = dateTime2.getYearOfEra();
        java.util.GregorianCalendar gregorianCalendar10 = dateTime2.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1970 + "'", int9 == 1970);
        org.junit.Assert.assertNotNull(gregorianCalendar10);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.junit.Assert.assertNotNull(iSOChronology1);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone0);
        boolean boolean4 = dateTime2.isBefore((long) (-1));
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property7 = dateTime6.era();
        org.joda.time.DateTime.Property property8 = dateTime6.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property8.getFieldType();
        boolean boolean10 = property8.isLeap();
        org.joda.time.DateTime dateTime11 = property8.roundHalfEvenCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property8.getFieldType();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '#');
        int int6 = offsetDateTimeField5.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone7);
        boolean boolean11 = dateTime9.isBefore((long) (-1));
        org.joda.time.LocalDate localDate12 = dateTime9.toLocalDate();
        int int13 = dateTime9.getDayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
        boolean boolean15 = dateTime9.isSupported(dateTimeFieldType14);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.era();
        org.joda.time.DateTime dateTime18 = dateTime9.withChronology((org.joda.time.Chronology) iSOChronology16);
        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds((int) '4');
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withPeriodAdded(readablePeriod21, (int) (byte) 10);
        org.joda.time.DateTime.Property property24 = dateTime20.hourOfDay();
        org.joda.time.DateTime.Property property25 = dateTime20.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime27 = dateTime20.plus(readablePeriod26);
        org.joda.time.YearMonthDay yearMonthDay28 = dateTime27.toYearMonthDay();
        java.util.Locale locale30 = null;
        java.lang.String str31 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay28, 20, locale30);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(yearMonthDay28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "20" + "'", str31.equals("20"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        boolean boolean2 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter0.getParser();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology5 = iSOChronology4.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone7);
        boolean boolean11 = dateTime9.isBefore((long) (-1));
        org.joda.time.LocalDate localDate12 = dateTime9.toLocalDate();
        long long14 = iSOChronology4.set((org.joda.time.ReadablePartial) localDate12, (long) 24);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology4.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone16 = iSOChronology4.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter0.withZone(dateTimeZone16);
        java.util.Locale locale18 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter0.withLocale(locale18);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeParser3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24L + "'", long14 == 24L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone3);
        boolean boolean7 = dateTime5.isBefore((long) (-1));
        org.joda.time.LocalDate localDate8 = dateTime5.toLocalDate();
        long long10 = iSOChronology0.set((org.joda.time.ReadablePartial) localDate8, (long) 24);
        long long14 = iSOChronology0.add(1560639600024L, 101L, (int) (byte) 100);
        org.joda.time.DurationField durationField15 = iSOChronology0.millis();
        org.joda.time.DurationField durationField16 = iSOChronology0.years();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone19);
        boolean boolean23 = dateTime21.isBefore((long) (-1));
        org.joda.time.LocalDate localDate24 = dateTime21.toLocalDate();
        org.joda.time.DateTime dateTime25 = dateTime21.toDateTime();
        org.joda.time.DateTime.Property property26 = dateTime25.era();
        org.joda.time.DateTime.Property property27 = dateTime25.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = dateTimeFormatterBuilder18.appendFraction(dateTimeFieldType28, 24, 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, (java.lang.Number) 10.0f, "1969365");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(dateTimeField17, dateTimeFieldType28, (int) (byte) 10);
        long long39 = dividedDateTimeField36.getDifferenceAsLong((long) (byte) 1, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology40.halfdayOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology43 = iSOChronology42.withUTC();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology42.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone45 = null;
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeUtils.getZone(dateTimeZone45);
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(dateTimeZone45);
        boolean boolean49 = dateTime47.isBefore((long) (-1));
        org.joda.time.LocalDate localDate50 = dateTime47.toLocalDate();
        long long52 = iSOChronology42.set((org.joda.time.ReadablePartial) localDate50, (long) 24);
        long long56 = iSOChronology42.add(1560639600024L, 101L, (int) (byte) 100);
        org.joda.time.DurationField durationField57 = iSOChronology42.millis();
        org.joda.time.DurationField durationField58 = iSOChronology42.years();
        org.joda.time.DateTimeField dateTimeField59 = iSOChronology42.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.DateTimeZone dateTimeZone61 = null;
        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeUtils.getZone(dateTimeZone61);
        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime(dateTimeZone61);
        boolean boolean65 = dateTime63.isBefore((long) (-1));
        org.joda.time.LocalDate localDate66 = dateTime63.toLocalDate();
        org.joda.time.DateTime dateTime67 = dateTime63.toDateTime();
        org.joda.time.DateTime.Property property68 = dateTime67.era();
        org.joda.time.DateTime.Property property69 = dateTime67.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType70 = property69.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder60.appendFraction(dateTimeFieldType70, 24, 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException76 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType70, (java.lang.Number) 10.0f, "1969365");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField78 = new org.joda.time.field.DividedDateTimeField(dateTimeField59, dateTimeFieldType70, (int) (byte) 10);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField79 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField41, dateTimeFieldType70);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField80 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField36, dateTimeFieldType70);
        long long82 = remainderDateTimeField80.roundCeiling((long) (short) 10);
        int int84 = remainderDateTimeField80.get((long) (-28800000));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24L + "'", long10 == 24L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560639610124L + "'", long14 == 1560639610124L);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder31);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 24L + "'", long52 == 24L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560639610124L + "'", long56 == 1560639610124L);
        org.junit.Assert.assertNotNull(durationField57);
        org.junit.Assert.assertNotNull(durationField58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeZone62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(localDate66);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(property68);
        org.junit.Assert.assertNotNull(property69);
        org.junit.Assert.assertNotNull(dateTimeFieldType70);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 3600000L + "'", long82 == 3600000L);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 4 + "'", int84 == 4);
    }
}

