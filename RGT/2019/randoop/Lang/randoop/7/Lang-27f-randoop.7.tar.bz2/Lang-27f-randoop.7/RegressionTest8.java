import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("io!nio!OCnala MeCoeCnooernio!nio!", "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("java vi...", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concatWith("10.14.3", (java.lang.Object[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny("AVA/XTENSIONS:/USR/LIB/JAVA:.", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java vi..." + "'", str5.equals("java vi..."));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", "1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("44444444444444444444444444444444444444j v  vris v . hje pef ij44444444444444444444444444444444444444", "4444444444444444444444444444444");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.concatWith("sophie", (java.lang.Object[]) strArray6);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("4444444444444444444444444444444", strArray3, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 77 vs 29");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/sophievarsophie/sophiefolderssophie/sophie_sophievsophie/sophie6sophievsophie597sophiezmnsophie4sophie_sophievsophie31sophiecqsophie2sophiensophie2sophiexsophie1sophiensophie4sophiefcsophie0000sophiegnsophie/sophieT" + "'", str7.equals("/sophievarsophie/sophiefolderssophie/sophie_sophievsophie/sophie6sophievsophie597sophiezmnsophie4sophie_sophievsophie31sophiecqsophie2sophiensophie2sophiexsophie1sophiensophie4sophiefcsophie0000sophiegnsophie/sophieT"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("1T1gxqvzv1v171v1", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/", 34);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/USERS/SOPHIEonJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specificatio", "EJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMava virtual ", 58);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/Users/sophie/Documents/defect:/Users/sophie/Documents/defhi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("java virtual machine specificatio", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "j v  virtu l m chine specific tio" + "'", str3.equals("j v  virtu l m chine specific tio"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(":#:#X#:#X#W#:#X#:#X#P", 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(":##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05", "SUN.AWEN");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!", "j", "", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!" + "'", str4.equals("hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("#Java#Virtual#Machine#Specification");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, 53L, (long) 34);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 53L + "'", long3 == 53L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        int[] intArray6 = new int[] { (short) 10, (short) -1, (short) 10, (byte) 1, 3, (short) 100 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        java.lang.CharSequence charSequence5 = null;
        char[] charArray11 = new char[] { ' ', 'a', 'a', '4' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence5, charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ":##################################OracleCorporation", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "JAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATIN", charArray11);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "     noitaroproC elcarO     ", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 18 + "'", int15 == 18);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java#Virtual#Machine#Specification", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/SERS/SOPHIE/IBRAR");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("                                 Java Virtual Machine Specification                                 ", 28, 36);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "         j v  vrIs V . hJe pef IJ         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 8, (double) 10.0f, (double) 57);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.0d + "'", double3 == 57.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("e Specification                                ", "/", 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("en", 126);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("                               ", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("\nhi!\nhi!", "1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("virtual Machine SpecificationJava Virtual Machine", 159);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        int[] intArray5 = new int[] { (byte) 0, ' ', 'a', (short) 100, (byte) 100 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Users/shmAC os x!Users/s");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "USERS/SHMAC OS X!USERS/S" + "'", str1.equals("USERS/SHMAC OS X!USERS/S"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "Java Virtual Machine Specification", (int) '#');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny("Mac4OS4X", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("java virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specification", (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "jAVA vIRTUAL mACHINE sPECIFICATION");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("        /lIBRARY/jAVA/jAVAvIRTU", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0", "!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 43, (float) 28, (float) 11);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 11.0f + "'", float3 == 11.0f);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("US");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("", strArray3);
        java.lang.String[] strArray10 = new java.lang.String[] { "#" };
        java.lang.String[] strArray14 = new java.lang.String[] { "", "hi!", "hi!" };
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray10, strArray14);
        int int16 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("", strArray10);
        int int17 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("\nJava Virtual Machine Specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray10);
        java.lang.String[] strArray18 = null;
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("java virtual machine specification", strArray10, strArray18);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, '#');
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("tionachine specifical ma virtuavaj", strArray3, strArray10);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "java virtual machine specification" + "'", str19.equals("java virtual machine specification"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "#" + "'", str21.equals("#"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "tionachine specifical ma virtuavaj" + "'", str22.equals("tionachine specifical ma virtuavaj"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("\njava virt\nJava Virtual M...al machine specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\njava virt\nJava Virtual M...al machine specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("\njava virt\nJava Virtual M...al machine specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                  /users/sophie");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", 100, 15);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("MIXED MOD:##################################ORACLECORPORATION51.051.051.051.051.051.051.051.051.051.051.05", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("java virtual machine specification");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny("hi!", strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "                                             mixedmode                                              ", 0, 0);
        java.lang.Class<?> wildcardClass8 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("tnemnorivnEscihparGC.twa.nus", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 20);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        byte[] byteArray3 = new byte[] { (byte) 1, (byte) 10, (byte) 10 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 10 + "'", byte4 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(":");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, ":##################################OracleCorporation");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/mixed modvarmixed mod/mixed modfoldersmixed mod/mixed mod_mixed modvmixed mod/mixed mod6mixed modvmixed mod597mixed modzmnmixed mod4mixed mod_mixed modvmixed mod31mixed modcqmixed mod2mixed modnmixed mod2mixed modxmixed mod1mixed modnmixed mod4mixed modfcmixed mod0000mixed modgnmixed mod/mixed modT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        java.lang.String[] strArray5 = new java.lang.String[] { "#" };
        java.lang.String[] strArray9 = new java.lang.String[] { "", "hi!", "hi!" };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray5, strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("", strArray5);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String[] strArray16 = new java.lang.String[] { "#" };
        java.lang.String[] strArray20 = new java.lang.String[] { "", "hi!", "hi!" };
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray16, strArray20);
        java.lang.String[] strArray26 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Hi!", "Hi!", 1);
        int int27 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("hi!", strArray26);
        java.lang.String str28 = org.apache.commons.lang3.StringUtils.replaceEach("java vi...", strArray16, strArray26);
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80.sDK/xONTENTn/.OoE/sRE/LIB/ENDORnED/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80", strArray5, strArray16);
        int int30 = org.apache.commons.lang3.StringUtils.indexOfAny("Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification", strArray16);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "java vi..." + "'", str28.equals("java vi..."));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80.sDK/xONTENTn/.OoE/sRE/LIB/ENDORnED/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80" + "'", str29.equals("/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80.sDK/xONTENTn/.OoE/sRE/LIB/ENDORnED/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sop", "/lIBRARY/jAVA/jAVAvIRTUALmmixed modENTS/hOME/JRE/LIB/ENDORSED");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "", 146, 23);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("hmAC os x!", 0, "JAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATIN");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hmAC os x!" + "'", str3.equals("hmAC os x!"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        double[] doubleArray1 = new double[] { (-1) };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Oracle Corporation");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4', 100, (int) (short) 100);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.Class<?> wildcardClass9 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Oaraclea aCaorporation" + "'", str7.equals("Oaraclea aCaorporation"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(56, (int) 'a', 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9409_1560227539", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                             mixedmode                                                                                                                    ", 31, "Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                             mixedmode                                                                                                                    " + "'", str3.equals("                                             mixedmode                                                                                                                    "));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aSERScSOPHIEcoOCUvENTScDEFECT:", 3, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aSERScSOPHIEcoOCUvENTScDEFECT:" + "'", str3.equals("aSERScSOPHIEcoOCUvENTScDEFECT:"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 10, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("JI fep eJh . V sIrv  v jj v  vrIs V . hJe pef IJ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray10 = new char[] { ' ', 'a', 'a', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence4, charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "         java virtual machine specification         ", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "    e    ", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "MIXED MOD:##################################ORACLECORPORATION51.051.051.051.051.051.051.051.051.051.051.05", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "io!nio!OCnala MeCoeCnooernio!nio!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("ava virtual machine specification", "ORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ava virtual machine specification" + "'", str2.equals("ava virtual machine specification"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("e Specification                                ", 23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "e Specification                                " + "'", str2.equals("e Specification                                "));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...", 116);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("\nJv Virtul Mchin                  /users/sophie Sp                  /users/sophiecif", "mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05", "                                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\nJv Virtul Mchin                  /users/sophie Sp                  /users/sophiecif" + "'", str3.equals("\nJv Virtul Mchin                  /users/sophie Sp                  /users/sophiecif"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Virtual4 4Machine4 4Specification4Java4 4Virtual4 4Machine4 4Specification4Java4 4Virtual4 4Machine4 4Specification4Java4 4Virtual", "ORACL", "Users/shmAC os x!Users/s");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Virtual4 4Machine4 4Specification4Java4 4Virtual4 4Machine4 4Specification4Java4 4Virtual4 4Machine4 4Specification4Java4 4Virtual" + "'", str3.equals("Virtual4 4Machine4 4Specification4Java4 4Virtual4 4Machine4 4Specification4Java4 4Virtual4 4Machine4 4Specification4Java4 4Virtual"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) " ORACLECORPORATIONORACLECOHI!  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " ORACLECORPORATIONORACLECOHI!  " + "'", str1.equals(" ORACLECORPORATIONORACLECOHI!  "));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539", "usJAVA VI...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("\n", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaficeihpos/sresu/                  pS eihpos/sresu/                  nihcaM lautriV ava");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaficeihpos/sresu/                  pS eihpos/sresu/                  nihcaM lautriV ava" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaficeihpos/sresu/                  pS eihpos/sresu/                  nihcaM lautriV ava"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                   /Users/sophie/Documents/defect:/Users/sophie/Documents/defhi!                    ", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("1.7.0_80", 69, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("ual Machine Specification", "mAC os x");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("US", 36);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("java", "C");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java" + "'", str2.equals("java"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("ORACLECORPORATI");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4', 10, 159);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                             ORACLECORPORATIONORACLECOHI!AAAAA", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 116, 0L, (long) 11);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hie_sophievsophie31sophiecqsophie2sophiensophie2sophiexsophie1sophiensophie4sophiefcsophie0000sophiegnsophie/sophieT", "sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie", 35);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05", 34);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("v  v     e", strArray4, strArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "v  v     e" + "'", str11.equals("v  v     e"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(3500, 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3500 + "'", int3 == 3500);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 7L);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("a...", 31);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATIONJAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 10 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "1.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("\nJava Virtual Machine Specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                 ", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "java Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin Scificatin");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("ahi!ahi!", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("JavaVirtualMachineSpecificatio", "/Users/sophie/Documents/defect:/Users/sophie/Documents/defhi!", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("J/BIL/RSU/:SNOISNETX/AVA/YRARBI/METSY/:SNOISNETX/AVA/YRARBI/KROWTE./:SNOISNETX/AVA/YRARBI/:SNOISNETX");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"J/BIL/RSU/:SNOISNETX/AVA/YRARBI/METSY/:SNOISNETX/AVA/YRARBI/KROWTE./:SNOISNETX/AVA/YRARBI/:SNOISNETX\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("//////////", (-1), 14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!", "OracleCorporation");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "OracleCorporation", (int) 'a', (int) (byte) 10);
        java.lang.Class<?> wildcardClass7 = strArray2.getClass();
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.Class<?> wildcardClass9 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("4.80-b11", "ORACLECORPORATION", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   " + "'", str2.equals("   "));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444444444444444444444444444444", "\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", 18);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny("e", strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4444444444444444444444444444444" + "'", str7.equals("4444444444444444444444444444444"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("C", "Java Virtual Machine Specif");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "C" + "'", str2.equals("C"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("     Oracle Corporation     ", (long) 8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "java platform api specificationHTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.C", (java.lang.CharSequence) "\nJava Virtual Machine Sp");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mac OS ", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/", "Mac OS X", 61);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "\nJava Virtual Machine Specificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                   ", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Documents/defect:/Users/sophie/Documents/defhi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defect:/Users/sophie/Documents/defhi!" + "'", str1.equals("/Users/sophie/Documents/defect:/Users/sophie/Documents/defhi!"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("domdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdexime", "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "domdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdexime" + "'", str2.equals("domdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdexime"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "MIXED                     MOD          :##################################          ORACLECORPORATION          51          .          051          .          051          .          051          .          051          .          051          .          051          .          051          .          051          .          051          .          051          .          05", (java.lang.CharSequence) "                                                                                                                                                      24.8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("7.1", 24, 14);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "7.1" + "'", str3.equals("7.1"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("hhi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("SUN.AWT.cgRAPHICSeNVIRONMENT", "JAVA", 135, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JAVA" + "'", str4.equals("JAVA"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("MIXED MOD:##################################ORACLECORP...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MIXED MOD:##################################ORACLECORP.." + "'", str1.equals("MIXED MOD:##################################ORACLECORP.."));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("#Java#Virtual#Machine#Specification", "AC OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#Java#Virtual#Machine#Specification" + "'", str2.equals("#Java#Virtual#Machine#Specification"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                               ", (java.lang.CharSequence) "/SERS/SOPHIE/IBRARY/AVA/XTENSIONS:/IBRARY/AVA/XTENSIONS:/.ETWORK/IBRARY/AVA/XTENSIONS:/YSTEM/IBRARY/AVA/XTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 129 + "'", int2 == 129);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("AC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS X", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AC OS XAC OS XA" + "'", str2.equals("AC OS XAC OS XA"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("e", '4');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concatWith("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80", (java.lang.Object[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny("oracleCorporationMiMiMiMiMiMiMi", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "e" + "'", str5.equals("e"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        int[] intArray6 = new int[] { (short) 10, (short) -1, (short) 10, (byte) 1, 3, (short) 100 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("            x86_64", "java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("/Users/sophie/Documents/defect:", "MIXED                     MOD          :##################################          ORACLECORPORATION          51          .          051          .          051          .          051          .          051          .          051          .          051          .          051          .          051          .          051          .          051          .          05");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("mixed modmixed modmixed ahi!ahi!", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("mixed modmixed modmixed ahi!ahi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed modmixed modmixed ahi!ahi!" + "'", str1.equals("mixed modmixed modmixed ahi!ahi!"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(11.0d, 0.0d, (double) 7);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.0d + "'", double3 == 11.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("\nJava Virtual Machine Specification", '#');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\nJava Virtual Machine Specification" + "'", str3.equals("\nJava Virtual Machine Specification"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("s/sophie/Documents/defect:");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"s/sophie/Documents/defect:\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("Http://java.oracle.com/", ".:avaj/bil/rsu/:snoisnetx/ava/yrarbi/metsy/:snoisnetx/ava/yrarbi/krowte./:snoisnetx/ava/yrarbi/:snoisnetx/ava/yrarbi/eihpos/sres/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Http://java.oracle.com/" + "'", str2.equals("Http://java.oracle.com/"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("j v  virtu l m chine specific tio");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("AC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os x" + "'", str1.equals("ac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os x"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("MIXED MOD:##################################ORACLECORPORATION51.051.051.051.051.051.051.051.051.051.051.05", "/Users/sophie/Documents/defect:/Users/sophie/Documents/defhi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("java vi...", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concatWith("10.14.3", (java.lang.Object[]) strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concatWith("/Users/sop", (java.lang.Object[]) strArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java vi..." + "'", str5.equals("java vi..."));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "java vi..." + "'", str6.equals("java vi..."));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java vi..." + "'", str8.equals("java vi..."));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("jAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjAVAvIRTUALmACHINEsPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        java.lang.String[] strArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny("Oaraclea aCaorporation", strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("                                                                     51.0", 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFICEPs ENIHCAm LAUTRIv AVAj\n", (java.lang.CharSequence) "EJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMava virtual ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4692 + "'", int2 == 4692);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification" + "'", str1.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 57, (double) 1, (double) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.0d + "'", double3 == 57.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                 OracleCorporation                  ", "Java#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("", "a...", 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, 15.0d, (double) 52.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        java.lang.String[] strArray8 = new java.lang.String[] { "#" };
        java.lang.String[] strArray12 = new java.lang.String[] { "", "hi!", "hi!" };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray8, strArray12);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80-b15", "Java Virtual Machine Specification");
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray16);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(":", strArray8, strArray16);
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80-b15", "Java Virtual Machine Specification");
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray21);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.replaceEach("java virtu", strArray8, strArray21);
        int int24 = org.apache.commons.lang3.StringUtils.indexOfAny("\nJava Virtual Machine Specif", strArray8);
        int int25 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("Sun.lwawt.macosx.LWCToolkit", strArray8);
        int int26 = org.apache.commons.lang3.StringUtils.indexOfAny("/Users/sop", strArray8);
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.concatWith("virtual Machine SpecificationJava Virtual Machine", (java.lang.Object[]) strArray8);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.7.0_80-b15" + "'", str17.equals("1.7.0_80-b15"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + ":" + "'", str18.equals(":"));
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1.7.0_80-b15" + "'", str22.equals("1.7.0_80-b15"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "java virtu" + "'", str23.equals("java virtu"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "#" + "'", str27.equals("#"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", 'a');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" + "'", str3.equals("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" + "'", str5.equals("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("Http://java.oracle.com/", 2);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("f");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"f\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tnemnorivnE emitnuR ES )MT(ava" + "'", str1.equals("tnemnorivnE emitnuR ES )MT(ava"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(1, 987, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment", "enenenesun.awt.CGraphicsEnvironment");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "en", (java.lang.CharSequence) " HotSpot(TM) 64-Bit Server VMava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJavaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi!", "OracleCorporation");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "OracleCorporation", (int) 'a', (int) (byte) 10);
        java.lang.Class<?> wildcardClass8 = strArray3.getClass();
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        int int10 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", strArray9);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 93 + "'", int10 == 93);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("\n", 61);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 61 + "'", int2 == 61);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################hie_sophievsophie31sophiecqsophie2sophiensophie2sophiexsophie1sophiensophie4sophiefcsophie0000sophiegnsophie/sophieT", (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3492 + "'", int2 == 3492);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("\nJava Virtual Machine Specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "//////////");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\nJava Virtual Machine Specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("\nJava Virtual Machine Specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("", "US", 100);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.concatWith("Oracle Corporation", (java.lang.Object[]) strArray6);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation", strArray1, strArray8);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation" + "'", str10.equals("                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("         noitacificeps enihcam lautriv avaj         ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        float[] floatArray5 = new float[] { 100L, 170, 2, 35.0f, (byte) -1 };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 170.0f + "'", float6 == 170.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 170.0f + "'", float7 == 170.0f);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("MIXED MO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MIXEDMO" + "'", str1.equals("MIXEDMO"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", 0, 146);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str3.equals("\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05" + "'", str3.equals("mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("j/BIL/RSU/:SNOISNETX/AVA/YRARBI/METSY/:SNOISNETX/AVA/YRARBI/KROWTE./:SNOISNETX/AVA/YRARBI/:SNOISNETX");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...                                 Java Virtual Machine Specificat...", "JAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATIN", 159);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("", "Http://java.oracle.com/");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "sun.awt.CGraphicsEnvironment");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Docume                  /users/sophieMixed modMixed modMixed ahi!ahi!                  /users/sophiemp/run_randoop.pl_9409_156022753", strArray4, strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "/Users/sophie/Docume                  /users/sophieMixed modMixed modMixed ahi!ahi!                  /users/sophiemp/run_randoop.pl_9409_156022753" + "'", str10.equals("/Users/sophie/Docume                  /users/sophieMixed modMixed modMixed ahi!ahi!                  /users/sophiemp/run_randoop.pl_9409_156022753"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        float[] floatArray5 = new float[] { 100L, 170, 2, 35.0f, (byte) -1 };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float12 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float13 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 170.0f + "'", float6 == 170.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 170.0f + "'", float8 == 170.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 170.0f + "'", float9 == 170.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 170.0f + "'", float10 == 170.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + (-1.0f) + "'", float11 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + (-1.0f) + "'", float12 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 170.0f + "'", float13 == 170.0f);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Mac4OS4X", "44444444444444444444444444hmAC os x!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "MIXED MO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Java Vartual Macaana Saacafacataan");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Vartual Macaana Saacafacataan\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("      Mirporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mirporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation" + "'", str1.equals("Mirporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/sophievarsophie/sophiefolderssophie/sophie_sophievsophie/sophie6sophievsophie597sophiezmnsophie4sophie_sophievsophie31sophiecqsophie2sophiensophie2sophiexsophie1sophiensophie4sophiefcsophie0000sophiegnsophie/sophieT", "domdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdexime");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("a\nJava Virtual Machine Specification", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification", 67, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("AC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS X", "http://java.oracle.com/", "10.14.310.14.Mac OS 10.14.310.14.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "AC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS X" + "'", str3.equals("AC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS XAC OS X"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", "Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.0", '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "ORACL", 5, 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defect:");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/LIBRARY/JAVA/JAVAVIRTUALMMIXED MODENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMMIXED MODENTS/HOME/JRE/LIB/ENDORSED" + "'", str1.equals("/LIBRARY/JAVA/JAVAVIRTUALMMIXED MODENTS/HOME/JRE/LIB/ENDORSED"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                                 Java(TM) SE Runtime Envi", "                                                                                                                                       1.7.0_80", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", 3500);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                 Java(TM) SE Runtime Envi" + "'", str4.equals("                                 Java(TM) SE Runtime Envi"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) ":", (java.lang.CharSequence) "########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################hie_sophievsophie31sophiecqsophie2sophiensophie2sophiexsophie1sophiensophie4sophiefcsophie0000sophiegnsophie/sophieT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":", "hi!");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterType("\nJava Virtual Machine Specif");
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("US", strArray3, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 12");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + ":" + "'", str6.equals(":"));
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        double[] doubleArray2 = new double[] { 10L, 28 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 28.0d + "'", double3 == 28.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("\nJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/users/sophieMAC OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) (byte) 1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a\nJava Virtual Machine Specification", "          ", 24);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("EN", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "EN" + "'", str2.equals("EN"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("", "java virtual machine specificationjava virtual machm");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("           v  v     e                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "v  v     e" + "'", str1.equals("v  v     e"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("\nJv Virtul Mchin                  /users/sophie Sp                  /users/sophiecif", (int) '4', (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...                /users/sophiecif" + "'", str3.equals("...                /users/sophiecif"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("OracleCorporationOracleCohi!", "jAVA vIRTUAL mACHINE sPECIFICATION                                                               ", 0);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/USERS/SOPHIEonJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80.sDK/xONTENTn/.OoE/sRE/LIB/ENDORnED/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80", "ejava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmava virtual ");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(":");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":" + "'", str4.equals(":"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "HTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        float[] floatArray1 = new float[] { (short) 100 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 100.0f + "'", float5 == 100.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("\nJava Virtual Machine Specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "4444444444444444444444444444j v  vris v . hje pef ij", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("f", "                            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("ahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!" + "'", str3.equals("ahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!Oracle Corporationahi!ahi!"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 3492, (double) 11.0f, (double) 1.7f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3492.0d + "'", double3 == 3492.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 987, 19);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                    /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                  /users/sophie");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "Java Virtual Machine Specif", 27, 0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Hi!", "Hi!", 1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concatWith(":##################################OracleCorporation", (java.lang.Object[]) strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Hi!" + "'", str5.equals("Hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Hi!" + "'", str6.equals("Hi!"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                              /Us rs/sophi /Docum nts/d f ct:", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                              /Us rs/sophi /Docum nts/d f ct:" + "'", str2.equals("                              /Us rs/sophi /Docum nts/d f ct:"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/SERS/SOPHIE/IBRARY/AVA/XTENSIONS:/IBRARY/AVA/XTENSIONS:/.ETWORK/IBRARY/AVA/XTENSIONS:/YSTEM/IBRARY/AVA/XTENSIONS:/USR/LIB/JAVA:.");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("//////////", strArray2, strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "//////////" + "'", str5.equals("//////////"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "AVA/XTENSIONS:/USR/LIB/JAVA:.", "51b-08_0.7.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", "hhi!");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("44444444444444444444444444444444444444j v  vris v . hje pef ij44444444444444444444444444444444444444", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("/Users/sophie/Documents/defect:", "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("ac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os x", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("...mdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdexime", 0, "java v ...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...mdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdexime" + "'", str3.equals("...mdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdexime"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "s/sophie/Documents/defects4j/tmp/run_randoop.pl_9409");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                                             mixedmode                                              ", 3, 987);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                          mixedmode                                              " + "'", str3.equals("                                          mixedmode                                              "));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        java.lang.String[] strArray2 = new java.lang.String[] { "#" };
        java.lang.String[] strArray6 = new java.lang.String[] { "", "hi!", "hi!" };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray2, strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.Class<?> wildcardClass10 = strArray2.getClass();
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "#" + "'", str8.equals("#"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "#" + "'", str12.equals("#"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong(":", (long) 8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("Mixed modMixed modMixed ahi!ahi!ry/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "                                 ", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("mixed mode");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("     noitaroproC elcarO     ", 3492);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3492 + "'", int2 == 3492);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("aJava Virtual Machine Specification!", "OracleCorporationOracleCohi!aaaaa", "    e    ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Users/sop");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray7 = new char[] { ' ', 'a', 'a', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny("\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 33, (long) 915, (long) 4692);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4692L + "'", long3 == 4692L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("Mixed modMixed modMixed ahi!ahi!ry/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "Mac4OS4X", 33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("      ", "java", "44444444444444444444444444hmAC os x!");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                  /users/sophieMixed modMixed modMixed ahi!ahi!                  /users/sophie", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("\nJava Virtual M...", 57);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("", "                    /lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        double[] doubleArray1 = new double[] { (-1) };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("     88 -8O     ", "Users/sophie/Documents/defect:", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("hhi!", "u");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (short) 1, 0.0d, 126.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 126.0d + "'", double3 == 126.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("...mdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdexime");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 135, 53);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("hOTsPOT(tm) 64-bIT sERVER vmAVA hOTsPOT(tm) 64-bIT sERVE", "ava virtual machine specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("s/sophie/Documents/defects4j/tmp/run_randoop.pl_9409", "mAC os x");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/sophie/Documents/defects4j/tmp/run_randoop.pl_9409" + "'", str2.equals("/sophie/Documents/defects4j/tmp/run_randoop.pl_9409"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/USERS/SOPHIEonJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("ahi!ahi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ahi!ahi!" + "'", str1.equals("ahi!ahi!"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                                                     51.0                                                                                     ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 51.0d + "'", double1.equals(51.0d));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "/USERS/SOPHIEonJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification", (java.lang.CharSequence) "\nJava Virtual Machine Specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/USERS/SOPHIEonJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification" + "'", charSequence2.equals("/USERS/SOPHIEonJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi", "4.80-b11", 7);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("\nJava Virtual Machin                  /users/sophie Sp                  /users/sophiecif", 56, 116);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                /users/sophiecif" + "'", str3.equals("                /users/sophiecif"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80.sDK/xONTENTn/.OoE/sRE/LIB/ENDORnED/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80.sDK/xONTENTn/.OoE/sRE/LIB/ENDORnED/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80" + "'", str1.equals("/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80.sDK/xONTENTn/.OoE/sRE/LIB/ENDORnED/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(987L, (long) 915, 987L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 987L + "'", long3 == 987L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("\nJava Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\nJava Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("\nJava Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "           V  V     E                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("                                              Mac OS X                                              ", "Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("MAC OS ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC OS" + "'", str1.equals("MAC OS"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("JI fep eJh . V sIrv  v j", "\nJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JI fep eJh . V sIrv  v j" + "'", str2.equals("JI fep eJh . V sIrv  v j"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Mix...", (-1), 43);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "." + "'", str3.equals("."));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("JAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATIN", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATIN" + "'", str2.equals("JAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATIN"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("        /lIBRARY/jAVA/jAVAvIRTU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "/sophievarsophie/sophiefolderssophie/sophie_sophievsophie/sophie6sophievsophie597sophiezmnsophie4sophie_sophievsophie31sophiecqsophie2sophiensophie2sophiexsophie1sophiensophie4sophiefcsophie0000sophiegnsophie/sophieT", 159, 49);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/sophievarsophie/sophiefolderssophie/sophie_sophievsophie/sophie6sophievsophie597sophiezmnsophie4sophie_sophievsophie31sophiecqsophie2sophiensophie2sophiexsophie1sophiensophie4sophiefcsophie0000sophiegnsophie/sophieT" + "'", str4.equals("/sophievarsophie/sophiefolderssophie/sophie_sophievsophie/sophie6sophievsophie597sophiezmnsophie4sophie_sophievsophie31sophiecqsophie2sophiensophie2sophiexsophie1sophiensophie4sophiefcsophie0000sophiegnsophie/sophieT"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM104.4144.43Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "\nJava Virtual Machine Specif");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Oracle Corporation");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny("     Oracle Corporation", strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Oracle Corporation" + "'", str4.equals("Oracle Corporation"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         " + "'", str1.equals("Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         "));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("java platform api specificationHTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.C");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA PLATFORM API SPECIFICATIONHTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.C" + "'", str1.equals("JAVA PLATFORM API SPECIFICATIONHTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.C"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("MixedmodMixedmodMixedahi!ahi!MixedmodMixenoitacificepsenihcamlautrivavaj");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 28, 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("USjavavi...javavirtujavavirtujavavirtujavavirtujavavirtujavavirtujavavirtujavavirtujavavir", 49);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("\nJava Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/", 3500);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(".:avaj/bil/rsu/:snoisnetx/ava/yrarbi/metsy/:snoisnetx/ava/yrarbi/krowte./:snoisnetx/ava/yrarbi/:snoisnetx/ava/yrarbi/eihpos/sres/", "1.0", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        char[] charArray7 = new char[] { ' ', 'a', 'a', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Hi!", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ORACLECORPORATIO", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/  ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((-1), 53, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("      Mirporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation", (long) 129);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 129L + "'", long2 == 129L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Users/shmAC os x!Users/s", "#", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("domdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdexime", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "domdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdexime" + "'", str3.equals("domdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdexime"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("\nJava Virtual Machine Specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "Java Virtual Machine Specif");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny("                                                                     51.0                                                                      ", strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("     88 -8O     ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("JI fep eJh . V sIrv  v j");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Smixed/modvarmixed/modSmixed/modfoldersmixed/modSmixed/mod_mixed/modvmixed/modSmixed/mod6mixed/modvmixed/mod597mixed/modzmnmixed/mod4mixed/mod_mixed/modvmixed/mod31mixed/modcqmixed/mod2mixed/modnmixed/mod2mixed/modxmixed/mod1mixed/modnmixed/mod4mixed/modfcmixed/mod0000mixed/modgnmixed/modSmixed/modT", 4692);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Smixed/modvarmixed/modSmixed/modfoldersmixed/modSmixed/mod_mixed/modvmixed/modSmixed/mod6mixed/modvmixed/mod597mixed/modzmnmixed/mod4mixed/mod_mixed/modvmixed/mod31mixed/modcqmixed/mod2mixed/modnmixed/mod2mixed/modxmixed/mod1mixed/modnmixed/mod4mixed/modfcmixed/mod0000mixed/modgnmixed/modSmixed/modT" + "'", str2.equals("Smixed/modvarmixed/modSmixed/modfoldersmixed/modSmixed/mod_mixed/modvmixed/modSmixed/mod6mixed/modvmixed/mod597mixed/modzmnmixed/mod4mixed/mod_mixed/modvmixed/mod31mixed/modcqmixed/mod2mixed/modnmixed/mod2mixed/modxmixed/mod1mixed/modnmixed/mod4mixed/modfcmixed/mod0000mixed/modgnmixed/modSmixed/modT"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "1.7.0_80-b15");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str4.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(15.0d, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 987, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           " + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           "));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("J/BIL/RSU/:SNOISNETX/AVA/YRARBI/METSY/:SNOISNETX/AVA/YRARBI/KROWTE./:SNOISNETX/AVA/YRARBI/:SNOISNETX");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "J/BIL/RSU/:SNOISNETX/AVA/YRARBI/METSY/:SNOISNETX/AVA/YRARBI/KROWTE./:SNOISNETX/AVA/YRARBI/:SNOISNETX" + "'", str1.equals("J/BIL/RSU/:SNOISNETX/AVA/YRARBI/METSY/:SNOISNETX/AVA/YRARBI/KROWTE./:SNOISNETX/AVA/YRARBI/:SNOISNETX"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("              Mac OS               ", "Java#Virtual#Machine#Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "              Mac OS               " + "'", str2.equals("              Mac OS               "));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1.7.0_80", 143);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_80" + "'", str2.equals("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_80"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HotSpot(TM) 64-Bit Server VMava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJavaJ", "\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", 36);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("\nJava Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "noitacificeps enihcam lautr", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie" + "'", str2.equals("sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("hmAC os x!", "Ja/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("MIXED MOD:##################################ORACLECORPORATION51.051.051.051.051.051.051.051.051.051.051.05", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MIXED MOD:##################################ORACLECORPORATION51.051.051.051.051.051.051.051.051.051.051.05" + "'", str2.equals("MIXED MOD:##################################ORACLECORPORATION51.051.051.051.051.051.051.051.051.051.051.05"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "Users/sophie/Documents/defect:", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("ahi!ahi!", (int) '4', (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("s/sophie/Documents/defects4j/tmp/run_randoop.pl_9409");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "s/sophie/Documents/defects4j/tmp/run_randoop.pl_9409" + "'", str1.equals("s/sophie/Documents/defects4j/tmp/run_randoop.pl_9409"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Users/sophie/Documents/defect:", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Users/sophie/Documents/defect:" + "'", str2.equals("Users/sophie/Documents/defect:"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate(":", 35, 3492);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":" + "'", str3.equals(":"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", "MIXED MOD");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("SUN.AWEN", "hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.AWEN" + "'", str2.equals("SUN.AWEN"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("mac OS ", "oRACL");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("x86_64hix86_64hix86_64hix86_64hix86_64hix86_64hix86_64hix86_64hix86_64hix86_64", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64hix86_64hix86_64hix86_64hix86_64hix86_64hix86_64hix86_64hix86_64hix86_64" + "'", str2.equals("x86_64hix86_64hix86_64hix86_64hix86_64hix86_64hix86_64hix86_64hix86_64hix86_64"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("a...", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "..." + "'", str2.equals("..."));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip(" ORACLECORPORATIONORACLECOHI!  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLECORPORATIONORACLECOHI!" + "'", str1.equals("ORACLECORPORATIONORACLECOHI!"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("e Specification                                ", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                " + "'", str2.equals("e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                e Specification                                "));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("\nJava Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 36, "                                                                                                                                       1.7.0_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\nJava Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("\nJava Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        float[] floatArray5 = new float[] { 100L, 170, 2, 35.0f, (byte) -1 };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 170.0f + "'", float6 == 170.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 170.0f + "'", float9 == 170.0f);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("java virtual machine specificatio                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java virtual machine specificatio" + "'", str1.equals("java virtual machine specificatio"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble(":###################################################/Users/sophie/Documents/defect:/Users/sophie/Documents/defhi!                            /Users/sophie/Documents/defect:/Users/sophie/Documents/defhi!:###################################################         java virtual machine specification     /Users/sophie/Documents/defect:/Users/sophie/Documents/defhi!Java#Virtual#Machine#Specification/Users/sophie/Documents/defect:/Users/sophie/Documents/defhi!Users/sophie/Documents/defect:/Users/sophie/Documents/defect:/Users/sophie/Documents/defhi!24.80-b11", 170.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 170.0d + "'", double2 == 170.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 0, 3500);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "Mac OS ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("\nJv Virtul Mchin                  /users/sophie Sp                  /users/sophieci");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("MAC OS ", "########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################hie_sophievsophie31sophiecqsophie2sophiensophie2sophiexsophie1sophiensophie4sophiefcsophie0000sophiegnsophie/sophieT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(" OracleCorporationOracleCohi!  ", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("\nJava4Virtual4Machine4Specificatio", "                                                                                                                                       1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\nJava4Virtual4Machine4Specificatio" + "'", str2.equals("\nJava4Virtual4Machine4Specificatio"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("eihpos/sresU/         java virtual ", 61, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "eihpos/sresU/         java virtual ##########################" + "'", str3.equals("eihpos/sresU/         java virtual ##########################"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFICEPs ENIHCAm LAUTRIv AVAj\n", "ava virtual machine specification", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/USERS/SOPHIEonJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specificatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophieonjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificatio" + "'", str1.equals("/users/sophieonjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificatio"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("TIONACHINE SPECIFICAL MA VIRTUAVAJ", (int) (byte) 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                                                                                                      24.80-b11", "ava virtual machine specification", (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("ATI", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ATI" + "'", str2.equals("ATI"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("...aM lautriV avaJ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("j v  vris v . hje pef ij", "http://java.oracle.com/");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("EJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMava virtual", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(49);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/sers/sophie/ibrary/ava/xtensions:/ibrary/ava/xtensions:/.etwork/ibrary/ava/xtensions:/ystem/ibrary/ava/xtensions:/usr/lib/java:.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("MIXED MOD:##################################ORACLECORP...", "\nJava Virtual M...", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("", "omd");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) -1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("io!nio!OCnala MeCoeCnooernio!nio!", 99, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                 io!nio!OCnala MeCoeCnooernio!nio!                                 " + "'", str3.equals("                                 io!nio!OCnala MeCoeCnooernio!nio!                                 "));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ORACLECORPORATION", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("     ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        short[] shortArray4 = new short[] { (short) 100, (short) 100, (short) 10, (short) 0 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 0 + "'", short8 == (short) 0);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                  ", 20);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                    " + "'", str2.equals("                    "));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                    ", 11L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11L + "'", long2 == 11L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("a", 100, "Mi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMaMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMi" + "'", str3.equals("MiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMaMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMiMi"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("j/BIL/RSU/:SNOISNETX/AVA/YRARBI/METSY/:SNOISNETX/AVA/YRARBI/KROWTE./:SNOISNETX/AVA/YRARBI/:SNOISNETX");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"j/BIL/RSU/:SNOISNETX/AVA/YRARBI/METSY/:SNOISNETX/AVA/YRARBI/KROWTE./:SNOISNETX/AVA/YRARBI/:SNOISNETX\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 49, 52.0d, (double) 4692);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 49.0d + "'", double3 == 49.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Http://java.oracle.com" + "'", str1.equals("Http://java.oracle.com"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) (byte) 100, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 4692, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("...          4444444444444444444444444444444", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...          4444444444444444444444444444444" + "'", str2.equals("...          4444444444444444444444444444444"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Users/sophie/Documents/defect:/Users/sophie/Documents/defhi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 61 + "'", int1 == 61);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "j v  vris v . hje pef ij");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05", 170);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 170 + "'", int2 == 170);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "JavaVirtualMachineSpecificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) (byte) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(":###################################################         java virtual machine specification     ", 143, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444:###################################################         java virtual machine specification     " + "'", str3.equals("4444444444444444444444444444444444444444444:###################################################         java virtual machine specification     "));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("//////////", "                                 Java(TM) SE Runtime Envi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "//////////" + "'", str2.equals("//////////"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        char[] charArray7 = new char[] { ' ', 'a', 'a', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Hi!", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "\nJava Virtual Machin                  /users/sophie Sp                  /users/sophiecif", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Users/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:", 14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Users/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:" + "'", str2.equals("Users/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:fUsers/sophie/Documents/defect:"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween(":", "Java Virtual Machine Specification", "                                                                     51.0                                                                                     ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie" + "'", str2.equals("sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("     88 -8O     ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("ava Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ava Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("HTTP://JAVA.ORACLE.COM/", "                                 Java Virtual Machine Specification                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("104.4144.43", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "                                              Mac OS X                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                            //////////                             ", "Java#", " ORACLECORPORATIONORACLECOHI!  ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                            //////////                             " + "'", str4.equals("                            //////////                             "));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp:" + "'", str2.equals("://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp:"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "                                                                                                              ORACLECORPORATIONORACLECOHI!AAAAA", 57);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("####################...", "/Users/sop");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "mixedmode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        long[] longArray1 = new long[] { 126 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 126L + "'", long2 == 126L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 126L + "'", long3 == 126L);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(":USjava vi...", "JAVA PLATFORM API SPECIFICATIONHTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.C", 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", 35.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray10 = new char[] { ' ', 'a', 'a', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence4, charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "         java virtual machine specification         ", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hie_sophievsophie31sophiecqsophie2sophiensophie2sophiexsophie1sophiensophie4sophiefcsophie0000sophiegnsophie/sophieT", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny("\njava virtual machine specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/sophie/Documents/defects4j/tmp/run_randoop.pl_9409", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 67, (float) 146, (float) 3L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 146.0f + "'", float3 == 146.0f);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("x86_64hix86_64hix86_64hix86_64hix86_64hix86_64hix86_64hix86_64hix86_64hix86_64", "...                /users/sophiecif", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("44444444444444444444444444444444444", 19, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        java.lang.CharSequence charSequence5 = null;
        char[] charArray11 = new char[] { ' ', 'a', 'a', '4' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence5, charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ":###################################################         java virtual machine specification     ", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Mac OS X", charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "jAVA vIRTUAL mACHINE sPECIFICATION                                                               ", charArray11);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny("44444444444444444444444444444444444444j v  vris v . hje pef ij44444444444444444444444444444444444444", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                                                                                                                                                      24.8", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".84                                                                                                                                                      2" + "'", str2.equals(".84                                                                                                                                                      2"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Hi!", "                                 ", "                    /lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Hi!" + "'", str3.equals("Hi!"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("Mac4OS4X", "oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation                                                                51.0", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/sophievarsophie/sophiefolderssophie/sophie_so...", 67, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##################/sophievarsophie/sophiefolderssophie/sophie_so..." + "'", str3.equals("##################/sophievarsophie/sophiefolderssophie/sophie_so..."));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("444444444444444444444444444444444444444444444444444444444444444444444\nJava Virtual Machine Specif", "JavaVirtualMachineSpecificatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444\nJava Virtual Machine Specif" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444\nJava Virtual Machine Specif"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("      ");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("tionachine specifical ma virtuavaj", "", 53);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaafcS ncaM lautV avaJ\n", "sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("            x86_64", "                                                                     51.0                                                                      ", 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/SERS/SOPHIE/IBRAR");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.cprinterjob" + "'", str1.equals("sun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("\nJv Virtul Mchin                  /users/sophie Sp                  /users/sophiecif", (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################hie_sophievsophie31sophiecqsophie2sophiensophie2sophiexsophie1sophiensophie4sophiefcsophie0000sophiegnsophie/sophieT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test394");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("OracleCorporation", "MIXED MOD:##################################ORACLECORP...", 69);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        double[] doubleArray1 = new double[] { (-1) };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.Class<?> wildcardClass12 = doubleArray1.getClass();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "/  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter(".", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "." + "'", str2.equals("."));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        java.lang.CharSequence charSequence5 = null;
        java.lang.CharSequence charSequence7 = null;
        char[] charArray13 = new char[] { ' ', 'a', 'a', '4' };
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#", charArray13);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence7, charArray13);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray13);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone(charSequence5, charArray13);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "j", charArray13);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "\nJava Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray13);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray13);
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray13);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsAny("http://java.oracle.com/", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 100, 4692, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4692 + "'", int3 == 4692);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("Hi!", 11, 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("java virtual machine specificationjava virtual machm", "\nJava Virtual Machine Specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexime", (int) (byte) -1, 57);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("Java HotSpot(TM) 64-Bit Server VM", "         j v  vIs V . J f IJ         ", 57);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("USjavavi...javavirtujavavirtujavavirtujavavirtujavavirtujavavirtujavavirtujavavirtujavavir", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "USjavavi...javavirtujavavirtujavavirtujavavirtujavavirtujavavirtujavavirtujavavirtujavavir" + "'", str2.equals("USjavavi...javavirtujavavirtujavavirtujavavirtujavavirtujavavirtujavavirtujavavirtujavavir"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("AVA/XTENSIONS:/USR/LIB/JAVA:.", "    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    " + "'", str2.equals("    "));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Mac OS ", "ATI", "     noitaroproC elcarO     ", 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Mac OS " + "'", str4.equals("Mac OS "));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                     4444444444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                     4444444444444444444444444444444" + "'", str2.equals("                     4444444444444444444444444444444"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("/mixed modvarmixed mod/mixed modfoldersmixed mod/mixed mod_mixed modvmixed mod/mixed mod6mixed modvmixed mod597mixed modzmnmixed mod4mixed mod_mixed modvmixed mod31mixed modcqmixed mod2mixed modnmixed mod2mixed modxmixed mod1mixed modnmixed mod4mixed modfcmixed mod0000mixed modgnmixed mod/mixed modT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation                                                                51.0", 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("orporation", (int) (short) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "orporation" + "'", str3.equals("orporation"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("444444444444444444444444444444444444444444ORACLECORPORATIO444444444444444444444444444444444444444444", "x86_64hix86_64hix86_64hix86_64hix86_64hix86_64hix86_64hix86_64hix86_64hix86_64", 4692);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("4444444444444444444444444444j v  vris v . hje pef ij");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("ORACLECORPORATIO", "Http://java.oracle.com/", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("java virtual machine specificationjava virtual machm", "hOTsPOT(tm) 64-bIT sERVER vmAVA hOTsPOT(tm) 64-bIT sERVE", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        byte[] byteArray3 = new byte[] { (byte) 100, (byte) 10, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 100 + "'", byte4 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/USERS/SOPHIEonJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("\nJava Virtual Machine Specification", '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "HTTP://JAVA.ORACLE.COM/");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "\nJava Virtual Machine Specification" + "'", str4.equals("\nJava Virtual Machine Specification"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "\nJava Virtual Machine Specification" + "'", str5.equals("\nJava Virtual Machine Specification"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "\nJava Virtual Machine Specification" + "'", str6.equals("\nJava Virtual Machine Specification"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        java.lang.String[] strArray2 = new java.lang.String[] { "#" };
        java.lang.String[] strArray6 = new java.lang.String[] { "", "hi!", "hi!" };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray2, strArray6);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '4');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4hi!4hi!" + "'", str10.equals("4hi!4hi!"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/users/sophieMAC OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) 10, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test425");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                                                                                                              OracleCorporationOracleCohi!aaaaa");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "mixedmod", 14, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 14");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test426");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) -1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test427");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 135, (long) 9, 116L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9L + "'", long3 == 9L);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test428");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("sophie", "ahi!ahi!", (int) (short) -1, 170);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ahi!ahi!" + "'", str4.equals("ahi!ahi!"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test429");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test430");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test431");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "JavaVirtualMachineSpecificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test432");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 mixed mod                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ", "java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test433");
        short[] shortArray4 = new short[] { (short) 100, (short) 100, (short) 10, (short) 0 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test434");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("ep eJh . V sIrv  v j", "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ep eJh . V sIrv  v j" + "'", str2.equals("ep eJh . V sIrv  v j"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test435");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("OracleCorporationOracleCohi!", 93);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!", "Java Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!" + "'", str2.equals("!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("mixedmod", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmod" + "'", str2.equals("mixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmod"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test438");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("                                            ", "           v  v     e                               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test439");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test440");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("     88 -8O     ", "4444444444444444444444444444444444444444444:###################################################         java virtual machine specification     ", 69);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test441");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Mirporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mirporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation" + "'", str1.equals("Mirporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test442");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 61, 987L, (long) 4692);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 61L + "'", long3 == 61L);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test443");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("ahi!ahi!", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " hi! hi!" + "'", str3.equals(" hi! hi!"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test444");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) ".:AVAJ/BIL/RSU/:SNOISNETX/AVA/YRARBI/METSY/:SNOISNETX/AVA/YRARBI/KROWTE./:SNOISNETX/AVA/YRARBI/:SNOISNETX/AVA/YRARBI/EIHPOS/SRES/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test445");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 52.0f, (double) 15L, (double) 135L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 15.0d + "'", double3 == 15.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test446");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("\nJava4Virtual4Machine4Specificatio", 49);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49 + "'", int2 == 49);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test447");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("            x86_64", "", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test448");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("j v  virtu l m chine specific tio", "/sophie/Documents/defects4j/tmp/run_randoop.pl_9409");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test449");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test450");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":", "hi!");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("Java(TM) SE Runtime Environment", '4');
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(":", "\nJava Virtual Machine Specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        int int13 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", strArray12);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("mixed mod", strArray8, strArray12);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("/", strArray4, strArray8);
        int int16 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("\nJv Virtul Mchin                  /users/sophie Sp                  /users/sophieci", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "mixed mod" + "'", str14.equals("mixed mod"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "/" + "'", str15.equals("/"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test451");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1.7.0_80");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test452");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("mixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmod", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmod" + "'", str2.equals("mixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmodmixedmod"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", "ava virtual machine specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test454");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1v171v1vzvqxg1T1", "                                                                                                                                                      24.80-b11", "...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "v7vvzvqxgT" + "'", str3.equals("v7vvzvqxgT"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test455");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("OracleCorporationOracleCohi!aaaaa", "                                                                                                              ORACLECORPORATIONORACLECOHI!AAAAA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test456");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("mixed mod", 0, "ac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os xac os x");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mod" + "'", str3.equals("mixed mod"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test457");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("io!nio!OCnala MeCoeCnooernio!nio!");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "io!nio!OCnala MeCoeCnooernio!nio!" + "'", str2.equals("io!nio!OCnala MeCoeCnooernio!nio!"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("java virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specification", "/sers/sophie/ibrary/ava/xtensions:/ibrary/ava/xtensions:/.etwork/ibrary/ava/xtensions:/ystem/ibrary/ava/xtensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specification" + "'", str2.equals("java virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specification"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test459");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(":", "AVA/XTENSIONS:/USR/LIB/JAVA:.", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test460");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Virtual4 4Machine4 4Specification4Java4 4Virtual4 4Machine4 4Specification4Java4 4Virtual4 4Machine4 4Specification4Java4 4Virtual");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Virtual4 4Machine4 4Specification4Java4 4Virtual4 4Machine4 4Specification4Java4 4Virtual4 4Machine4 4Specification4Java4 4Virtua" + "'", str1.equals("Virtual4 4Machine4 4Specification4Java4 4Virtual4 4Machine4 4Specification4Java4 4Virtual4 4Machine4 4Specification4Java4 4Virtua"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test461");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "44444444444444444444444444444444444", 35);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("Mac OS ", "MixedmodMixedmodMixedahi!ahi!MixedmodMixenoitacificepsenihcamlautrivavaj");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/sophievarsophie/sophiefolderssophie/sophie_sophievsophie/sophie6sophievsophie597sophiezmnsophie4sophie_sophievsophie31sophiecqsophie2sophiensophie2sophiexsophie1sophiensophie4sophiefcsophie0000sophiegnsophie/sophieT", strArray4, strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/sophievarsophie/sophiefolderssophie/sophie_sophievsophie/sophie6sophievsophie597sophiezmnsophie4sophie_sophievsophie31sophiecqsophie2sophiensophie2sophiexsophie1sophiensophie4sophiefcsophie0000sophiegnsophie/sophieT" + "'", str8.equals("/sophievarsophie/sophiefolderssophie/sophie_sophievsophie/sophie6sophievsophie597sophiezmnsophie4sophie_sophievsophie31sophiecqsophie2sophiensophie2sophiexsophie1sophiensophie4sophiefcsophie0000sophiegnsophie/sophieT"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test462");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("", "US", 100);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concatWith("Oracle Corporation", (java.lang.Object[]) strArray5);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny("                     4444444444444444444444444444444", strArray5);
        java.lang.Class<?> wildcardClass10 = strArray5.getClass();
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test463");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("OracleCorporation", "Mixed mod");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test464");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(53.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test465");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "oracleCorporationMiMiMiMiMiMiMi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test466");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("en", "/USERS/SOPHIEonJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specificatio");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en" + "'", str3.equals("en"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test467");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("JAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATIN");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test468");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java(TM) SE Runtime Environment", '4');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concatWith("eihpos/sresU/         java virtual ##########################", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str5.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test469");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                                                                                                                                                      24.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.8" + "'", str1.equals("24.8"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test470");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1.7ual Machine Specification1.7ual Machine Specification1.7ual Machine Specification1.7");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7ualMachineSpecification1.7ualMachineSpecification1.7ualMachineSpecification1.7" + "'", str2.equals("1.7ualMachineSpecification1.7ualMachineSpecification1.7ualMachineSpecification1.7"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test471");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("noitacificeps enihcam lautriv avaj", (long) 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test472");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Mac OS ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test473");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539", (java.lang.CharSequence) "                  /users/sophieMixed modMixed modMixed ahi!ahi!                  /users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test474");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                                                                                                                     \nJava Virtual M...", "####################...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                     \nJava Virtual M..." + "'", str2.equals("                                                                                                                     \nJava Virtual M..."));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test475");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "java vi...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test476");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "7.1", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test477");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 52.0f, (double) 3492, (double) 67.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test478");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "###################################SUN.AWT.cgRAPHICSeNVIRONMEN###################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###################################SUN.AWT.cgRAPHICSeNVIRONMEN###################################" + "'", str1.equals("###################################SUN.AWT.cgRAPHICSeNVIRONMEN###################################"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test479");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("\nJava Virtual Machine Specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "\naJavaa aVirtuala aMachinea aSpecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("\naJavaa aVirtuala aMachinea aSpecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test480");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test481");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("", "                  /USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test482");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("                  /USERS/SOPHIE", "", 14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 14 + "'", int3 == 14);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test483");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Mac OS ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test484");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("...aM lautriV avaJ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test485");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/lIBRARY/jAVA/jAVAvIRTU", (int) (byte) 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTU" + "'", str3.equals("/lIBRARY/jAVA/jAVAvIRTU"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test486");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Ja/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "                    /lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Ja/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("Ja/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test487");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("OracleCorporationOracleCohi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oraclecorporationoraclecohi!" + "'", str1.equals("oraclecorporationoraclecohi!"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test488");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("USjava vi...", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test489");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/lIBRARY/jAVA/jAVAvIRTUALmmixed modENTS/hOME/JRE/LIB/ENDORSED", "                    ", 105, 44);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmmixed modENTS/hOME                    " + "'", str4.equals("/lIBRARY/jAVA/jAVAvIRTUALmmixed modENTS/hOME                    "));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test490");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", charSequence2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test491");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("MAC OS");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: MAC OS is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test492");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Oracle Corporation");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny("     Oracle Corporation", strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:", strArray1, strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:" + "'", str6.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test493");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("java platform api specificationHTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.COM/HTTP://JAVA.ORACLE.C");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test494");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(":", "\nJava Virtual Machine Specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("/USERS/SOPHIE", strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("/sophievarsophie/sophiefolderssophie/sophie_sophievsophie/sophie6sophievsophie597sophiezmnsophie4sophie_sophievsophie31sophiecqsophie2sophiensophie2sophiexsophie1sophiensophie4sophiefcsophie0000sophiegnsophie/sophieT", strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test495");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("\nJava Virtual Machine Specification");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "Virtual4 4Machine4 4Specification4Java4 4Virtual4 4Machine4 4Specification4Java4 4Virtual4 4Machine4 4Specification4Java4 4Virtua", 97, 36);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test496");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80", "    ", "EN", 3492);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80" + "'", str4.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test497");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM", "USjava vi...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM" + "'", str2.equals("Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test498");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("oRACLE cORPORATION", "omd");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test499");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) (byte) -1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test500");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM", "                    ", 3492);
        org.junit.Assert.assertNotNull(strArray3);
    }
}

