import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         ", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mix..." + "'", str2.equals("Mix..."));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 100, (float) 1L, 100.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("\nJava Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 'a');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 4, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("JAVA VIRTUAL MACHINE SPECIFICATION", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED", "mixed mod", 61);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmmixed modENTS/hOME/JRE/LIB/ENDORSED" + "'", str3.equals("/lIBRARY/jAVA/jAVAvIRTUALmmixed modENTS/hOME/JRE/LIB/ENDORSED"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                  /users/sophie", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                  /users/sophie" + "'", str2.equals("                  /users/sophie"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("mac os x", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("", 34, 135);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie" + "'", str1.equals("/users/sophie"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("UTF-8", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/sers/sophie/ibrary/ava/xtensions:/ibrary/ava/xtensions:/.etwork/ibrary/ava/xtensions:/ystem/ibrary/ava/xtensions:/usr/lib/java:.", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 116 + "'", int2 == 116);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        char[] charArray5 = new char[] { '4', ' ', 'a' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API Specification", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        java.lang.String[] strArray3 = new java.lang.String[] { "#" };
        java.lang.String[] strArray7 = new java.lang.String[] { "", "hi!", "hi!" };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, 'a');
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny("                  /users/sophie", strArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ahi!ahi!" + "'", str10.equals("ahi!ahi!"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("444444444444444444444444444444444444444444444444444444444444444444444\nJava Virtual Machine Specif", "              Mac OS               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444\nJava Virtual Machine Specif" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444\nJava Virtual Machine Specif"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("OracleCorporationOracleCohi!", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " OracleCorporationOracleCohi!  " + "'", str2.equals(" OracleCorporationOracleCohi!  "));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("                            //////////                             ", "#\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n##", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("a...", 170);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a..." + "'", str2.equals("a..."));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        java.lang.String[] strArray3 = new java.lang.String[] { "#" };
        java.lang.String[] strArray7 = new java.lang.String[] { "", "hi!", "hi!" };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("", strArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        java.lang.Class<?> wildcardClass11 = strArray3.getClass();
        int int12 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "#" + "'", str10.equals("#"));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) -1, 0, 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 27 + "'", int3 == 27);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("         j v  vrIs V . hJe pef IJ         ", 18, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "ORACLECORPORATI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "hie_sophievsophie31sophiecqsophie2sophiensophie2sophiexsophie1sophiensophie4sophiefcsophie0000sophiegnsophie/sophieT", (java.lang.CharSequence) "Mix...");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "hie_sophievsophie31sophiecqsophie2sophiensophie2sophiexsophie1sophiensophie4sophiefcsophie0000sophiegnsophie/sophieT" + "'", charSequence2.equals("hie_sophievsophie31sophiecqsophie2sophiensophie2sophiexsophie1sophiensophie4sophiefcsophie0000sophiegnsophie/sophieT"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                                 Java Virtual Machine Specification                                ", "", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("J", "1v171v1vzvqxg1T1", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/SERS/SOPHIE/IBRARY/AVA/XTENSIONS:/IBRARY/AVA/XTENSIONS:/.ETWORK/IBRARY/AVA/XTENSIONS:/YSTEM/IBRARY/AVA/XTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Ja/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "oracleCorporationMiMiMiMiMiMiMi");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 170);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("mac os x", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("\nJava Virtual Machine Specif");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specif" + "'", str1.equals("Java Virtual Machine Specif"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "USjava vi...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification", "AVA/XTENSIONS:/USR/LIB/JAVA:.", "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9409_1560227539");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("sophie", "1.7.0_80-b15", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Http://java.oracle.com/", "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("tnemnorivnE emitnuR ES )MT(avaJ", ":###################################################         java virtual machine specification     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tnemnorivnE emitnuR ES )MT(avaJ" + "'", str2.equals("tnemnorivnE emitnuR ES )MT(avaJ"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("oracleCorporationMiMiMiMiMiMiMi", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("444444444444444444444444444444444444444444ORACLECORPORATIO444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444ORACLECORPORATIO444444444444444444444444444444444444444444" + "'", str1.equals("444444444444444444444444444444444444444444ORACLECORPORATIO444444444444444444444444444444444444444444"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("java vi...", "eihpos/sresU/         java virtual ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 10, 3L, 97L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3L + "'", long3 == 3L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (byte) 100, (double) (short) 100, 31.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(100.0f, (float) 6, (float) 2L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "e", (java.lang.CharSequence) "a...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "1v171v1vzvqxg1T1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57 + "'", int2 == 57);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "7.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Mac OS ", 33, "10.14.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.310.14.Mac OS 10.14.310.14." + "'", str3.equals("10.14.310.14.Mac OS 10.14.310.14."));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("M... Virtual \nJava", "\nJava Virtual Machine Sp");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "M... Virtual \nJava" + "'", str2.equals("M... Virtual \nJava"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("a...", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Http://java.oracle.com/" + "'", str1.equals("Http://java.oracle.com/"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("java", "         noitacificeps enihcam lautriv avaj         ", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("24.80-b11", "51b-08_0.7.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/users/sophie", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("Mix...", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                 Java Virtual Machine Specification                                ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                 Java Virtual Machine Specification                                " + "'", str2.equals("                                 Java Virtual Machine Specification                                "));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "     Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/  ", "US", 2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concatWith("/sers/sophie/ibrary/ava/xtensions:/ibrary/ava/xtensions:/.etwork/ibrary/ava/xtensions:/ystem/ibrary/ava/xtensions:/usr/lib/java:.", (java.lang.Object[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/  " + "'", str5.equals("/  "));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("/USERS/SOPHIE", "ORACLECORPORATI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE" + "'", str2.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("sers/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "j v  vrIs V . hJe pef IJ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("AVA/XTENSIONS:/USR/LIB/JAVA:.", "enenenesun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("http://java.oracle.com/", "Hi!");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "http://java.oracle.com/" + "'", str4.equals("http://java.oracle.com/"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) ":##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05" + "'", str1.equals(":##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "/sophievarsophie/sophiefolderssophie/sophie_sophievsophie/sophie6sophievsophie597sophiezmnsophie4sophie_sophievsophie31sophiecqsophie2sophiensophie2sophiexsophie1sophiensophie4sophiefcsophie0000sophiegnsophie/sophieT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("sun.lwawt.macosx.CPrinterJob", "usJAVA VI...", 57, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "usJAVA VI..." + "'", str4.equals("usJAVA VI..."));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("hi!", 4, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi! " + "'", str3.equals("hi! "));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) ":##################################OracleCorporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(18, (int) (short) 1, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("eihpos/sresU/         java virtual ", "MAC OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_156022753", "java Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin Scificatin", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("java virtual machine specification", "/lIBRARY/jAVA/jAVAvIRTUALmmixed modENTS/hOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ava virtual machine specification" + "'", str2.equals("ava virtual machine specification"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("OracleCorporation");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation", "Mi", (int) '4', 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "      Mirporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation" + "'", str4.equals("      Mirporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         ", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 56 + "'", int2 == 56);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("java vi...", "x86_64", "                    /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie");
        java.lang.String[] strArray5 = new java.lang.String[] { "#" };
        java.lang.String[] strArray9 = new java.lang.String[] { "", "hi!", "hi!" };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray5, strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.Class<?> wildcardClass13 = strArray5.getClass();
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray5);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("ORACLECORPORATI", strArray2, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 301 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "#" + "'", str11.equals("#"));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "#" + "'", str14.equals("#"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 14);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) (byte) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) 'a', (int) (short) 1, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("OracleCorporationOracleCohi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "                            //////////                             ", 987);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("oracleCorporationMiMiMiMiMiMiMi", "         noitacificeps enihcam lautriv avaj         ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "mixed mode");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "uSERS/SOPHIE/dOCUMENTS/DEFECT:");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("ual Machine Specification", "Oracle Corporation");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "mac OS ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ual Machine Specification" + "'", str5.equals("ual Machine Specification"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("java Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin Scificatin");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATIN" + "'", str1.equals("JAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATIN"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("nio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!", '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "nio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!" + "'", str3.equals("nio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!OCnala MeCoeCnooernio!nio!"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("EJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMava virtual ", (float) 18);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 18.0f + "'", float2 == 18.0f);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("java virtu", 987);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java virtu" + "'", str2.equals("java virtu"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENT" + "'", str1.equals("SUN.AWT.cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("10.14.310.14.Mac OS 10.14.310.14.", 159);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        long[] longArray6 = new long[] { (byte) -1, 10, (byte) -1, (short) 0, 10, (-1L) };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("x86_64", (int) '#', 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64" + "'", str3.equals("x86_64"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("     Oracle Corporation", "\nJava Virtual Machine Sp");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     Oracle Corporation" + "'", str2.equals("     Oracle Corporation"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "j v  vrIs V . hJe pef IJ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " HotSpot(TM) 64-Bit Server VMava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJavaJ" + "'", str2.equals(" HotSpot(TM) 64-Bit Server VMava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJavaJ"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("\nJava Virtual Machine Specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", "                                 Java Virtual Machine Specificat...");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("MAC OS X", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "uSERS/SOPHIE/dOCUMENTS/DEFECT:", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("4444444444444444444444444444444", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 9, 0.0f, (float) 987);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("java Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin Scificatin", "enenenenenenenenenenenenenen");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin Scificatin" + "'", str2.equals("java Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin Scificatin"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Mi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 135, (long) 9, (long) 57);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 135L + "'", long3 == 135L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "ORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATI", (java.lang.CharSequence) "J");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 915 + "'", int2 == 915);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                                                                                       1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                       1.7.0_80" + "'", str1.equals("                                                                                                                                       1.7.0_80"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("                  /users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                  /USERS/SOPHIE" + "'", str1.equals("                  /USERS/SOPHIE"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Documents/defect:", (float) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("java", "                    /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("              Mac OS               ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("Oracle Corporation", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray8 = new char[] { ' ', 'a', 'a', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence2, charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "         java virtual machine specification         ", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         ", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 23, (long) 11, (long) 97);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 11L + "'", long3 == 11L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM", "en");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("mixedmode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixedmode" + "'", str1.equals("mixedmode"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 143);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                               " + "'", str2.equals("                                                                                                                                               "));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                  /users/sophieMixed modMixed modMixed ahi!ahi!                  /users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("u");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: u is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMEN" + "'", str1.equals("SUN.AWT.cgRAPHICSeNVIRONMEN"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("java", "                  /users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Java(TM) SE Runtime Envi", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                            oracleCorporation", (java.lang.CharSequence) " OracleCorporationOracleCohi!  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53 + "'", int2 == 53);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 0, "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray10 = new char[] { ' ', 'a', 'a', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence4, charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "         java virtual machine specification         ", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "enenenesun.awt.CGraphicsEnvironment", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny("", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "24.80-b11");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("ORACLECORPORATION", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80.sDK/xONTENTn/.OoE/sRE/LIB/ENDORnED/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Users/shmAC os x!Users/s");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("oracleCorporationMiMiMiMiMiMiMi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracleCorporationMiMiMiMiMiMiMi" + "'", str1.equals("oracleCorporationMiMiMiMiMiMiMi"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05", 34);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny("Sun.lwawt.macosx.LWCToolkit", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ":###################################################", "\nJava Virtual Machine Specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                            //////////                             ", "MIXEDMOD:##################################ORACLECORPORATION51.051.051.051.051.051.051.051.051.051.051.05");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MIXEDMOD:##################################ORACLECORPORATION51.051.051.051.051.051.051.051.051.051.051.05" + "'", str2.equals("MIXEDMOD:##################################ORACLECORPORATION51.051.051.051.051.051.051.051.051.051.051.05"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(1L, 67L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("oRACLE cORPORATION", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("mixed mod");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mod" + "'", str1.equals("mixed mod"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("51.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("                                            ", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44 + "'", int2 == 44);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("Users/sophie/Documents/defect:", "JAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATIN", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Hi!", (float) 44);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 44.0f + "'", float2 == 44.0f);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Mixed mod", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", 6);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("java vi...");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("\nJava Vitual Machin Scificatin");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Vitual Machin Scificatin\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("10.14.310.14.Mac OS 10.14.310.14.", "java virtu", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("j v  vrIs V . hJe pef IJ", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("10.14.310.14.Mac OS 10.14.310.14.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.310.14.Mac OS 10.14.310.14." + "'", str1.equals("10.14.310.14.Mac OS 10.14.310.14."));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("                                                                     51.0                                                                      ", "\nJava Vitual Machin Scificatin", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM", '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM" + "'", str3.equals("Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         ", "\nJava Virtual Machine Sp", 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/Users/sophie/Documents/defect:/Users/sophie/Documents/defhi!", "Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "j v  vris v . hje pef ij");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/Users/sophie/Documents/defect:/Users/sophie/Documents/defhi!", "                            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defect:/Users/sophie/Documents/defhi!" + "'", str2.equals("/Users/sophie/Documents/defect:/Users/sophie/Documents/defhi!"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("44444444444444444444444444444444444444j v  vris v . hje pef ij44444444444444444444444444444444444444", "ORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATI");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                                                                                                                                               ", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                               " + "'", str2.equals("                                                                                                                                               "));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Mixed modMixed modMixed ahi!ahi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                              Mac OS X                                              ", 67, "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                              Mac OS X                                              " + "'", str3.equals("                                              Mac OS X                                              "));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("tionachine specifical ma virtuavaj");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TIONACHINE SPECIFICAL MA VIRTUAVAJ" + "'", str1.equals("TIONACHINE SPECIFICAL MA VIRTUAVAJ"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("\nJava Virtual Machine Specification");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/sers/sophie/ibrary/ava/xtensions:/ibrary/ava/xtensions:/.etwork/ibrary/ava/xtensions:/ystem/ibrary/ava/xtensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".:avaj/bil/rsu/:snoisnetx/ava/yrarbi/metsy/:snoisnetx/ava/yrarbi/krowte./:snoisnetx/ava/yrarbi/:snoisnetx/ava/yrarbi/eihpos/sres/" + "'", str1.equals(".:avaj/bil/rsu/:snoisnetx/ava/yrarbi/metsy/:snoisnetx/ava/yrarbi/krowte./:snoisnetx/ava/yrarbi/:snoisnetx/ava/yrarbi/eihpos/sres/"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("TIONACHINE SPECIFICAL MA VIRTUAVAJ", "AVA/XTENSIONS:/USR/LIB/JAVA:.", "", 135);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TIONACHINE SPECIFICAL MA VIRTUAVAJ" + "'", str4.equals("TIONACHINE SPECIFICAL MA VIRTUAVAJ"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("edom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexim", "/Users/sophie/Documents/defect:/Users/sophie/Documents/defhi!", "JAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATIN");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("1.0", "java virtu");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("4444444444444444444444444444j v  vris v . hje pef ij", "1.7ual Machine Specification1.7ual Machine Specification1.7ual Machine Specification1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444j v  vris v . hje pef ij" + "'", str2.equals("4444444444444444444444444444j v  vris v . hje pef ij"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 170, 52.0d, (double) 6);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 170.0d + "'", double3 == 170.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("TIONACHINE SPECIFICAL MA VIRTUAVAJ", "http://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("1.0", "Users/shmAC os x!Users/s");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("domdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdexime", 56, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...mdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdexime" + "'", str3.equals("...mdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdexime"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "         java virtual machine specification         ", "                                 Java Virtual Machine Specification                                 ", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "ORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "      Mirporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "jAVA vIRTUAL mACHINE sPECIFICATION", "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("hi!hi!", "mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05", 18);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!" + "'", str3.equals("hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 143, 0L, (long) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 143L + "'", long3 == 143L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        java.lang.String[] strArray3 = new java.lang.String[] { "#" };
        java.lang.String[] strArray7 = new java.lang.String[] { "", "hi!", "hi!" };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray7);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API Specification");
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("Eihpos/sresU/         java virtual ", strArray7, strArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("ep eJh . V sIrv  v j", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ep eJh . V sIrv  v j" + "'", str2.equals("ep eJh . V sIrv  v j"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        java.lang.String[] strArray4 = new java.lang.String[] { "#" };
        java.lang.String[] strArray8 = new java.lang.String[] { "", "hi!", "hi!" };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.concatWith("java virtual machine specification", (java.lang.Object[]) strArray4);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.startsWithAny("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "#" + "'", str10.equals("#"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("hi!", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!  " + "'", str2.equals("hi!  "));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 27);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27 + "'", int2 == 27);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, 0.0d, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 44, 61.0d, (double) 2.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "44444444444444444444444444444444444444j v  vris v . hje pef ij44444444444444444444444444444444444444", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                 OracleCorporation                  ");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("http://java.oracle.com/");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                 Java Virtual Machine Specification                                 ", strArray2, strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "http://java.oracle.com/" + "'", str5.equals("http://java.oracle.com/"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "                                 Java Virtual Machine Specification                                 " + "'", str6.equals("                                 Java Virtual Machine Specification                                 "));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("OracleCorporationOracleCohi!", "oracleCorporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OracleCorporationOracleCohi!" + "'", str2.equals("OracleCorporationOracleCohi!"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 170.0f, (double) 170, 2.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 170.0d + "'", double3 == 170.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("j", "mixed mod");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("10.14.3");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny("", strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "104.4144.43" + "'", str5.equals("104.4144.43"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "j" + "'", str1.equals("j"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.0", (int) 'a', 24);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(":##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("Java Virtual Machine Specif", "mixedmode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("java", "/sers/sophie/ibrary/ava/xtensions:/ibrary/ava/xtensions:/.etwork/ibrary/ava/xtensions:/ystem/ibrary/ava/xtensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("         j v  vrIs V . hJe pef IJ         ", (int) (byte) -1, 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    " + "'", str3.equals("    "));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("USjava vi...java virtujava virtujava virtujava virtujava virtujava virtujava virtujava virtujava vir");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "USjavavi...javavirtujavavirtujavavirtujavavirtujavavirtujavavirtujavavirtujavavirtujavavir" + "'", str1.equals("USjavavi...javavirtujavavirtujavavirtujavavirtujavavirtujavavirtujavavirtujavavirtujavavir"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80.sDK/xONTENTn/.OoE/sRE/LIB/ENDORnED/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80", 53);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80.sDK/xONTENTn/.OoE/sRE/LIB/ENDORnED/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80" + "'", str2.equals("/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80.sDK/xONTENTn/.OoE/sRE/LIB/ENDORnED/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("ahi!ahi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ahi!ahi!" + "'", str1.equals("ahi!ahi!"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.7.0_80");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited(":##################################OracleCorporation", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":##################################OracleCorporation" + "'", str2.equals(":##################################OracleCorporation"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("Http://java.oracle.com/", "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("Oaraclea aCaorporation", "USjava vi...java virtujava virtujava virtujava virtujava virtujava virtujava virtujava virtujava vir");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("sers/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1.7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9409_1560227539");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9409_1560227539" + "'", str1.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9409_1560227539"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("AVA/XTENSIONS:/USR/LIB/JAVA:.", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation", "Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation" + "'", str2.equals("                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("j", "US", "hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "j" + "'", str3.equals("j"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("domdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdexime", "oracleCorporationMiMiMiMiMiMiMi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        java.lang.String[] strArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny("oracleCorporation", strArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("J", "OracleCorporation");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80-b15", ":###################################################         java virtual machine specification     ", (int) ' ');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "                  /users/sophieMixed modMixed modMixed ahi!ahi!                  /users/sophie");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.7.0_80-b15" + "'", str6.equals("1.7.0_80-b15"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("j v  vrIs V . hJe pef IJ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "j v  vrIs V . hJe pef IJ" + "'", str2.equals("j v  vrIs V . hJe pef IJ"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 0, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/Users/sophie/Documents/defect:/Users/sophie/Documents/defhi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Documents/defect:/Users/sophie/Documents/defhi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("u", 2.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("\nJava Virtual Machine Specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Users/sophie");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "\nJava Vtual Macn Scfaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("\nJava Vtual Macn Scfaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("\nJava Virtual Machine Specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "jAVA vIRTUAL mACHINE sPECIFICATION", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation" + "'", str1.equals("oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation1.7.0_80                                            oracleCorporation"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("MAC OS X", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MAC OS X" + "'", str2.equals("MAC OS X"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("", "                                 Java Virtual Machine Specificat...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "                 OracleCorporation                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concatWith("ep eJh . V sIrv  v j", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str5.equals("\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str6.equals("\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9409_1560227539");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9409_1560227539" + "'", str1.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9409_1560227539"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 915, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 915 + "'", int3 == 915);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("Java Virtual Ma...", "enenenenenenenenenenenenenen", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sers/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 135, "tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sers/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("sers/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("    e    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("444444444444444444444444444444444444444444ORACLECORPORATIO444444444444444444444444444444444444444444", "hi!  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444ORACLECORPORATIO444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444ORACLECORPORATIO444444444444444444444444444444444444444444"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                   /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                    ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("", "JAVA VIRTUAL MACHINE SPECIFICATION", 143);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) ":##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "OracleCorporation", "44444444444444444444444444444444444444j v  vris v . hje pef ij44444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("MIXEDMOD:##################################ORACLECORPORATION51.051.051.051.051.051.051.051.051.051.051.05", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("enenenesun.awt.CGraphicsEnvironment", (double) 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("MIXEDMOD:##################################ORACLECORPORATION51.051.051.051.051.051.051.051.051.051.051.05");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        char[] charArray8 = new char[] { ' ', 'a', 'a', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                 Java Virtual Machine Specification                                 ", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 33 + "'", int11 == 33);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 18 + "'", int12 == 18);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("AVA/XTENSIONS:/USR/LIB/JAVA:.", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      " + "'", str2.equals("      "));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                     4444444444444444444444444444444", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "    " + "'", str1.equals("    "));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("", ":##################################OracleCorporation", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("         noitacificeps enihcam lautriv avaj         ", "/Users/sop");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "         noitacificeps enihcam lautriv avaj         " + "'", str2.equals("         noitacificeps enihcam lautriv avaj         "));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie/Documents/defect:", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_156022753");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defect:" + "'", str2.equals("/Users/sophie/Documents/defect:"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("10.14.310.14.Mac OS 10.14.310.14.", "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.310.14.Mac OS 10.14.310.14." + "'", str2.equals("10.14.310.14.Mac OS 10.14.310.14."));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("\n", "EJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMava virtual ", 61);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("mixedmode", "\nJava Virtual Machine Sp");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        double[] doubleArray4 = new double[] { 1.7d, 170.0d, 11L, 1.0d };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 170.0d + "'", double5 == 170.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Java Platform API Specification", ":USjava vi...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80", "Http://java.oracle.com/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("oracleCorporation", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oracleCorporation" + "'", str3.equals("oracleCorporation"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(56);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Oaraclea aCaorporation");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oaraclea aCaorporation" + "'", str2.equals("Oaraclea aCaorporation"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Users/sophie/Documents/defect:", "/Users/sophie/Documents/defect:");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", 56);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str2.equals("\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Java HotSpot(TM) 64-Bit Server VM", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0", '#');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("Java(TM) SE Runtime Environment", '4');
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(":", "\nJava Virtual Machine Specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        int int13 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", strArray12);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("mixed mod", strArray8, strArray12);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray12);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("M... Virtual \nJava", strArray4, strArray12);
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.split("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05");
        int int21 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("", strArray20);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                  /users/sophie", strArray4, strArray20);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "         java virtual machine specification         ", 915, 31);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "mixed mod" + "'", str14.equals("mixed mod"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + ":" + "'", str15.equals(":"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "M... Virtual \nJava" + "'", str16.equals("M... Virtual \nJava"));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "                  /users/sophie" + "'", str22.equals("                  /users/sophie"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("\nJava Vtual Macn Scfaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("e", "/lIBRARY/jAVA/jAVAvIRTUALmmixed modENTS/hOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("\nJava Virtual Machine Specif");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("\n", strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny(" HotSpot(TM) 64-Bit Server VMava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJavaJ", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification", "OracleCorporation", "/Users/sophie/Documents/defect:/Users/sophie/Documents/defhi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification" + "'", str3.equals("Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Users/shmAC os x!Users/s");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("51b-08_0.7.1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        java.lang.String[] strArray4 = new java.lang.String[] { "#" };
        java.lang.String[] strArray8 = new java.lang.String[] { "", "hi!", "hi!" };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray8);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80-b15", "Java Virtual Machine Specification");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray12);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(":", strArray4, strArray12);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80-b15", "Java Virtual Machine Specification");
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray17);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("java virtu", strArray4, strArray17);
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.stripAll(strArray17);
        java.lang.Class<?> wildcardClass21 = strArray17.getClass();
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.7.0_80-b15" + "'", str13.equals("1.7.0_80-b15"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + ":" + "'", str14.equals(":"));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.7.0_80-b15" + "'", str18.equals("1.7.0_80-b15"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "java virtu" + "'", str19.equals("java virtu"));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie", "domdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdexime");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("\nJava Vtual Macn Scfaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "7.1", "", 57);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "\nJava Vtual Macn Scfaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("\nJava Vtual Macn Scfaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("", "", 44);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                                 Java Virtual Machine Specification                                ", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                 Java Virtual Machine Specification                                " + "'", str2.equals("                                 Java Virtual Machine Specification                                "));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("/sers/sophie/ibrary/ava/xtensions:/ibrary/ava/xtensions:/.etwork/ibrary/ava/xtensions:/ystem/ibrary/ava/xtensions:/usr/lib/java:.", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3500 + "'", int1 == 3500);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str2.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble(":###################################################         java virtual machine specification     ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("        /lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED         ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("10.14.3", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("                            ", "ORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATI", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(".:avaj/bil/rsu/:snoisnetx/ava/yrarbi/metsy/:snoisnetx/ava/yrarbi/krowte./:snoisnetx/ava/yrarbi/:snoisnetx/ava/yrarbi/eihpos/sres/", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Eihpos/sresU/         java virtual ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("USjava vi...java virtujava virtujava virtujava virtujava virtujava virtujava virtujava virtujava vir", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/  ", "US", 2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "OracleCorporationOracleCohi!", 1, 56);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("MAC OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"MAC OS X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("\nJava Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("USjavavi...javavirtujavavirtujavavirtujavavirtujavavirtujavavirtujavavirtujavavirtujavavir", "ava virtual machine specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("java vi...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"java vi...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("JAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATIN");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATIN" + "'", str1.equals("JAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATINJAVA VITUAL MACHIN SCIFICATIN"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("    ", "sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie         java virtual machine specification         sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Hi!", (double) 57);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 57.0d + "'", double2 == 57.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("\nJava Virtual Machine Sp");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80.sDK/xONTENTn/.OoE/sRE/LIB/ENDORnED/aIBRARY/jAwA/jAwAnIRTUALmACHINEn/sDK1.7.0_80", "\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (int) (short) 0);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', 0, 61);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        java.lang.String[] strArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny("sun.lwawt.macosx.CPrinterJob", strArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("...mdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdeximedomdexime", "                              /Users/sophie/Documents/defect:");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("mixed mod", 3500);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 mixed mod                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 mixed mod                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  "));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        java.lang.String[] strArray2 = new java.lang.String[] { "#" };
        java.lang.String[] strArray6 = new java.lang.String[] { "", "hi!", "hi!" };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray2, strArray6);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray11);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("/sers/sophie/ibrary/ava/xtensions:/ibrary/ava/xtensions:/.etwork/ibrary/ava/xtensions:/ystem/ibrary/ava/xtensions:/usr/lib/java:.", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("51.0", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("24.80-b11", 159);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                      24.80-b11" + "'", str2.equals("                                                                                                                                                      24.80-b11"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Mac OS ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("ual Machine Specification", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ual Machine Specification" + "'", str2.equals("ual Machine Specification"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 100, (long) 34, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                  " + "'", str2.equals("                                  "));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("\nJava Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "enenenesun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\nJava Virtual Machin                  /users/sophie Sp                  /users/sophiecif" + "'", str2.equals("\nJava Virtual Machin                  /users/sophie Sp                  /users/sophiecif"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("en", "\nJava Virtual Machine Specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "M... Virtual \nJava", (java.lang.CharSequence) "MIXEDMOD:##################################ORACLECORPORATION51.051.051.051.051.051.051.051.051.051.051.05");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "OracleCorporationOracleCohi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("TIONACHINE SPECIFICAL MA VIRTUAVAJ", "                            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TIONACHINE SPECIFICAL MA VIRTUAVAJ" + "'", str2.equals("TIONACHINE SPECIFICAL MA VIRTUAVAJ"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "tnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("mac OS ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC OS " + "'", str1.equals("MAC OS "));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java" + "'", str1.equals("java"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 3500, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        java.lang.String[] strArray4 = new java.lang.String[] { "#" };
        java.lang.String[] strArray8 = new java.lang.String[] { "", "hi!", "hi!" };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("", strArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray4);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny("ejava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmjava hotspot(tm) 64-bit server vmava virtual ", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "#" + "'", str11.equals("#"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "EJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMava virtual ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", 53);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", (int) (byte) 0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("ual Machine Specification", "Oracle Corporation");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', 5, 987);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("\nJava Vitual Machin Scificatin", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\nJava Vitual Machin Scificatin" + "'", str2.equals("\nJava Vitual Machin Scificatin"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong(":USjava vi...", (long) 53);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 53L + "'", long2 == 53L);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(":###################################################         java virtual machine specification     ", (int) (byte) 0, "jAVA vIRTUAL mACHINE sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":###################################################         java virtual machine specification     " + "'", str3.equals(":###################################################         java virtual machine specification     "));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05" + "'", str1.equals("mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Mixed modMixed modMixed ahi!ahi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concatWith("4444444444444444444444444444444", (java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("\nJava Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("oRACLE cORPORATION", (long) 116);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 116L + "'", long2 == 116L);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("ava virtual machine specification", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("\nJava Virtual Machine Specification");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "Mac OS X");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JavaVirtualMachineSpecification" + "'", str4.equals("JavaVirtualMachineSpecification"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("mixedmode", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                             mixedmode                                              " + "'", str2.equals("                                             mixedmode                                              "));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "        /lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED         ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ava virtual machine specification", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("MAC OS ", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("java", "44444444444444444444444444444444444444j v  vris v . hje pef ij44444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/sers/sophie/ibrary/ava/xtensions:/ibrary/ava/xtensions:/.etwork/ibrary/ava/xtensions:/ystem/ibrary/ava/xtensions:/usr/lib/java:.", "sun.lwawt.macosx.CPrinterJob", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("\njava virtual machine specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "u", "\nJava Virtual M...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\njava virt\nJava Virtual M...al machine specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("\njava virt\nJava Virtual M...al machine specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("java Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin Scificatin", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin Scificatin" + "'", str2.equals("java Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin ScificatinJava Vitual Machin Scificatin"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("OracleCorporationOracleCohi!aaaaa", 143);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                              OracleCorporationOracleCohi!aaaaa" + "'", str2.equals("                                                                                                              OracleCorporationOracleCohi!aaaaa"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification", "\nJava Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("http://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/", "Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/" + "'", str2.equals("://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/mAC os xhttp://java.oracle.com/"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase(".:avaj/bil/rsu/:snoisnetx/ava/yrarbi/metsy/:snoisnetx/ava/yrarbi/krowte./:snoisnetx/ava/yrarbi/:snoisnetx/ava/yrarbi/eihpos/sres/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".:avaj/bil/rsu/:snoisnetx/ava/yrarbi/metsy/:snoisnetx/ava/yrarbi/krowte./:snoisnetx/ava/yrarbi/:snoisnetx/ava/yrarbi/eihpos/sres/" + "'", str1.equals(".:avaj/bil/rsu/:snoisnetx/ava/yrarbi/metsy/:snoisnetx/ava/yrarbi/krowte./:snoisnetx/ava/yrarbi/:snoisnetx/ava/yrarbi/eihpos/sres/"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("     Oracle Corporation");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("USjava vi...java virtujava virtujava virtujava virtujava virtujava virtujava virtujava virtujava vir");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("j");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("JAVA VIRTUAL MACHINE SPECIFICATION", 0, "1.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATION" + "'", str3.equals("JAVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(14, 18, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Virtual Ma...", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Users/sophie/Documents/defect:", "                                             mixedmode                                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Users/sophie/Documents/defect:" + "'", str2.equals("Users/sophie/Documents/defect:"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/SERS/SOPHIE/IBRARY/AVA/XTENSIONS:/IBRARY/AVA/XTENSIONS:/.ETWORK/IBRARY/AVA/XTENSIONS:/YSTEM/IBRARY/AVA/XTENSIONS:/USR/LIB/JAVA:.", 18, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/SERS/SOPHIE/IBRARY/AVA/XTENSIONS:/IBRARY/AVA/XTENSIONS:/.ETWORK/IBRARY/AVA/XTENSIONS:/YSTEM/IBRARY/AVA/XTENSIONS:/USR/LIB/JAVA:." + "'", str3.equals("/SERS/SOPHIE/IBRARY/AVA/XTENSIONS:/IBRARY/AVA/XTENSIONS:/.ETWORK/IBRARY/AVA/XTENSIONS:/YSTEM/IBRARY/AVA/XTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty(" HotSpot(TM) 64-Bit Server VMava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJavaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HotSpot(TM) 64-Bit Server VMava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJavaJ" + "'", str1.equals("HotSpot(TM) 64-Bit Server VMava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJavaJ"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("hi!  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!  " + "'", str1.equals("hi!  "));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "ava virtual machine specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                 Java Virtual Machine Specification                                ", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("1.7.0_80-B15", 61, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", "Mixed modMixed modMixed ahi!ahi!Mixed modMixe         noitacificeps enihcam lautriv avaj         ", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         mixed mod         noitacificeps enihcam lautriv avaj         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 " + "'", str2.equals("                                                                                                 "));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("444444444444444444444444444444444444444444444444444444444444444444444\nJava Virtual Machine Specif", "java", "ep eJh . V sIrv  v j");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444\nJava Virtual Machine Specif" + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444444\nJava Virtual Machine Specif"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9409_1560227539");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("\nJava Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 'a');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "                                             mixedmode                                              ", (int) (short) 0, 53);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", " OracleCorporationOracleCohi!  ", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Hi!", 31, 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("\nJava Vitual Machin Scificatin", "444444444444444444444444444444444444444444444444444444444444444444444\nJava Virtual Machine Specif", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("java vi...", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("hmAC os x!", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/SERS/SOPHIE/IBRARY/AVA/XTENSIONS:/IBRARY/AVA/XTENSIONS:/.ETWORK/IBRARY/AVA/XTENSIONS:/YSTEM/IBRARY/AVA/XTENSIONS:/USR/LIB/JAVA:.", 1, "en");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/SERS/SOPHIE/IBRARY/AVA/XTENSIONS:/IBRARY/AVA/XTENSIONS:/.ETWORK/IBRARY/AVA/XTENSIONS:/YSTEM/IBRARY/AVA/XTENSIONS:/USR/LIB/JAVA:." + "'", str3.equals("/SERS/SOPHIE/IBRARY/AVA/XTENSIONS:/IBRARY/AVA/XTENSIONS:/.ETWORK/IBRARY/AVA/XTENSIONS:/YSTEM/IBRARY/AVA/XTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("Java(TM) SE Runtime Envi", 14);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(".:avaj/bil/rsu/:snoisnetx/ava/yrarbi/metsy/:snoisnetx/ava/yrarbi/krowte./:snoisnetx/ava/yrarbi/:snoisnetx/ava/yrarbi/eihpos/sres/", "24.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie" + "'", str1.equals("/users/sophie"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "MIXEDMOD:##################################ORACLECORPORATION51.051.051.051.051.051.051.051.051.051.051.05");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("         noitacificeps enihcam lautriv avaj         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitacificeps enihcam lautriv avaj" + "'", str1.equals("noitacificeps enihcam lautriv avaj"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                            oracleCorporation", (java.lang.CharSequence) "/Users/sophie/Documents/defect:/Users/sophie/Documents/defhi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("hie_sophievsophie31sophiecqsophie2sophiensophie2sophiexsophie1sophiensophie4sophiefcsophie0000sophiegnsophie/sophieT", (int) (byte) 100);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("", "ORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATI");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("SUN.AWT.cgRAPHICSeNVIRONMEN");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("\nJava Virtual Machin                  /users/sophie Sp                  /users/sophiecifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification", "10.14.310.14.Mac OS 10.14.310.14.", "eihpos/sresU/", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification" + "'", str4.equals("java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "ORACLECORPORATIO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("j v  vrIs V . hJe pef IJ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "tnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode" + "'", str2.equals("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("    ", "ATI", 143);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                                                                                                                       1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("sers/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "oRACLE cORPORATION", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        java.lang.String[] strArray4 = new java.lang.String[] { "#" };
        java.lang.String[] strArray8 = new java.lang.String[] { "", "hi!", "hi!" };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.concatWith("java virtual machine specification", (java.lang.Object[]) strArray4);
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("                  /users/sophieMixed modMixed modMixed ahi!ahi!                  /users/sophie", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "#" + "'", str10.equals("#"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("noitacificeps enihcam lautriv avaj", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitacificeps enihcam lautr" + "'", str2.equals("noitacificeps enihcam lautr"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexime", 135, 915);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("\nJava Virtual Machine Specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "e");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\nJava Virtual Machine Specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("\nJava Virtual Machine Specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("oracleCorporation", "u", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("java vi...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("         j v  vrIs V . hJe pef IJ         ", "OracleCorporationOracleCohi!", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "         j v  vIs V . J f IJ         " + "'", str3.equals("         j v  vIs V . J f IJ         "));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("java vi...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"j\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("USjava vi...", "e");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str1.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/  ", 'a');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("Mixed modMixed modMixed ahi!ahi!", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "#\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n##");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n##" + "'", str1.equals("#\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n##"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/users/sophie");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("ep eJh . V sIrv  v j");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("en", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (byte) 100);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (byte) 100, 100.0d, (double) 44.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                  /users/sophieMixed modMixed modMixed ahi!ahi!                  /users/sophie", (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!", "MIXED MOD:##################################ORACLECORPORATION51.051.051.051.051.051.051.051.051.051.051.05");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!" + "'", str2.equals("hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!mixed mod:##################################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05hi!hi!"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("HotSpot(TM) 64-Bit Server VMava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJavaJ", 56);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HotSpot(TM) 64-Bit Server VMava HotSpot(TM) 64-Bit Serve" + "'", str2.equals("HotSpot(TM) 64-Bit Server VMava HotSpot(TM) 64-Bit Serve"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "\nJava Virtual M...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str2.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Users/shmAC os x!Users/s", "51.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("sers/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 3, 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "s/sophie/Documents/defects4j/tmp/run_randoop.pl_9409" + "'", str3.equals("s/sophie/Documents/defects4j/tmp/run_randoop.pl_9409"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("ORACLECORPORATION");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 100, (float) 24, (float) 135L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 135.0f + "'", float3 == 135.0f);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("1.7ual Machine Specification1.7ual Machine Specification1.7ual Machine Specification1.7", "ORACLECORPORATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                            ", (int) (byte) 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                            " + "'", str3.equals("                            "));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "##############################OracleCorporation51.051.051.051.051.051.051.051.051.051.051.05", "\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36 + "'", int2 == 36);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("OracleCorporation");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concatWith("jAVA vIRTUAL mACHINE sPECIFICATION                                                               ", (java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OracleCorporation" + "'", str3.equals("OracleCorporation"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "OracleCorporation" + "'", str4.equals("OracleCorporation"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                    /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                    /lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED" + "'", str1.equals("                    /lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("4444444444444444444444444444444", 11, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/users/sophie", 135);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie" + "'", str2.equals("/users/sophie"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "dom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom deximedom dexime", 52, 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                 Java Virtual Machine Specification                                ", (java.lang.CharSequence) "ORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATI");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("\nJava Vtual Macn Scfaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaafcS ncaM lautV avaJ\n" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaafcS ncaM lautV avaJ\n"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("mixed mod", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixedmod" + "'", str2.equals("mixedmod"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 97);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("MAC OS ", (float) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray9 = new char[] { ' ', 'a', 'a', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence3, charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\nJava Virtual Machine Specif", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat(".:avaj/bil/rsu/:snoisnetx/ava/yrarbi/metsy/:snoisnetx/ava/yrarbi/krowte./:snoisnetx/ava/yrarbi/:snoisnetx/ava/yrarbi/eihpos/sres/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".:avaj/bil/rsu/:snoisnetx/ava/yrarbi/metsy/:snoisnetx/ava/yrarbi/krowte./:snoisnetx/ava/yrarbi/:snoisnetx/ava/yrarbi/eihpos/sres/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("\nJava Virtual Machine Specifaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(":", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("     Oracle Corporation");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Mix...", 53, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mix...###############################################" + "'", str3.equals("Mix...###############################################"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Hi!", "Hi!", 1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concatWith(":##################################OracleCorporation", (java.lang.Object[]) strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, ' ');
        java.lang.String[] strArray11 = new java.lang.String[] { "#" };
        java.lang.String[] strArray15 = new java.lang.String[] { "", "hi!", "hi!" };
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray11, strArray15);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray11);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("OracleCorporation", strArray5, strArray18);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Hi!" + "'", str6.equals("Hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Hi!" + "'", str8.equals("Hi!"));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "#" + "'", str17.equals("#"));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "OracleCorporation" + "'", str19.equals("OracleCorporation"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("oracleCorporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"oracleCorporation\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("ORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATI", 159, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATI" + "'", str3.equals("ORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATI"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "HotSpot(TM) 64-Bit Server VMava HotSpot(TM) 64-Bit Serve", (java.lang.CharSequence) "tnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "cosx.LWCToolkitawt.maSun.lw");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("1.7.0_80-B15", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        char[] charArray7 = new char[] { '#', '#', ' ', '4', '#' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "OracleCorporation", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny("ORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATIORACLECORPORATI", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("         java virtual machine specification         ", "sers/sophie/Documents/defects4j/tmp/run_randoop.pl_9409_1560227539/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "                                            oracleCorporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "           v  v     e                               " + "'", str3.equals("           v  v     e                               "));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("", "\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("jAVA vIRTUAL mACHINE sPECIFICATION                                                               ", "\nJava Virtual M...", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("Java Platform API Specification", 14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        float[] floatArray1 = new float[] { (byte) -1 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("MIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODE" + "'", str1.equals("MIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODE"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("104.4144.43", "              Mac OS               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Oaraclea aCaorporation", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporation" + "'", str2.equals("Oaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporationOaraclea aCaorporation"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        char[] charArray7 = new char[] { ' ', 'a', 'a', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Hi!", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\njAVA vIRTUAL mACHINE sPECIFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "                                                                                                              OracleCorporationOracleCohi!aaaaa", 0, 170);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("104.4144.43", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }
}

