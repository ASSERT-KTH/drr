import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 10, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) -1, 0.0f, (float) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("44444444444444444444444444444444", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "US", (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Sun.awt.CGraphicsEnvironment", "/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sun.awt.CGraphicsEnvironment" + "'", str2.equals("Sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) 10, 100L, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        int[] intArray2 = new int[] { 1, (byte) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ', 1, (int) (byte) 0);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.5", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100.0", "Mac OS", 30);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java Platform API Specification", (double) 30);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 30.0d + "'", double2 == 30.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("US", " ###a##");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_AIX;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Oracle Corporation", "hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi", 30);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporation" + "'", str3.equals("Oracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporation"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("mixed mode", "-1.040.04100.041.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("US");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_JAVA_1_3;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "US", (java.lang.CharSequence) "UTF-8", 192);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("en", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 6, (int) (byte) -1);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "X86_64", (java.lang.CharSequence[]) strArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str8.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("en", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715", "/moc.elcaro.avaj//:ptth", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64", "100.0", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("HI!", "HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie", 0, "me/jr");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "                                                    sun.awt.CGraphicsEnvironment", "1a-1");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.5", (java.lang.CharSequence) "4444444444444444444444/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/moc.elcaro.avaj//:ptth", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, '4', 192, (int) '#');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) -1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sophie", '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie" + "'", str3.equals("sophie"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Oracle Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Oracle Corporation\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/", (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", 6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 1, (float) (-1L), (float) (-1));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray2 = new char[] {};
        boolean boolean3 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray2);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray2, ' ', (int) (short) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(" ###a##", "4444444444444444444444/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.444444444444444444444", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " ###8##" + "'", str3.equals(" ###8##"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!HI!HI!HI!HI!HusHI!HI!HI!HI!HI!" + "'", str1.equals("!HI!HI!HI!HI!HusHI!HI!HI!HI!HI!"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Oracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporation");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1555 + "'", int1 == 1555);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.min(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("en", "X86_64");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26 + "'", int2 == 26);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_UTIL_PREFS_PREFERENCES_FACTORY;
        org.junit.Assert.assertNull(str0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Mac OS ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "-1.040.04100.041.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.io.File file0 = org.apache.commons.lang3.SystemUtils.getJavaHome();
        org.junit.Assert.assertNotNull(file0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "    sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715", "Mac OS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("    sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.stripAll(strArray0);
        org.junit.Assert.assertNull(strArray1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hi!", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("sun.lwawt.macosx.LWCToolkit", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64", " ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("100.0", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0" + "'", str2.equals("100.0"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "-1404141414-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 51.0f, (double) 0L, (double) Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("14-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        char[] charArray6 = new char[] { ' ', '#', 'a', '#' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "x86_64", charArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "14-1", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + " a#aaa#" + "'", str9.equals(" a#aaa#"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", " ###a##");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("10.14.3", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3" + "'", str3.equals("10.14.3"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi", "hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi", "                                                                                                ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi" + "'", str4.equals("hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "1.5", "4444444444444444444444/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        long[] longArray0 = new long[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, '#', (int) (short) 1, (int) (short) -1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a');
        try {
            long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("14-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "14-1" + "'", str1.equals("14-1"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("x86_64", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64" + "'", str3.equals("x86_64"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("-1.040.04");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.040.04" + "'", str1.equals("-1.040.04"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "X86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("hi!", "1.7");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "00.0", (java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_64", "10.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) " ", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("en", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("    sophie", "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    sophie" + "'", str2.equals("    sophie"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "Oracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporation", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a-1" + "'", str1.equals("1a-1"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64", (java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "-1404141414-1", (java.lang.CharSequence) "1a-1", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/moc.elcaro.avaj//:ptth", "Mac OS", "x86_64");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/mo6.el68ro.8v8j//:ptth" + "'", str3.equals("/mo6.el68ro.8v8j//:ptth"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort(" a#aaa#");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray2 = new java.lang.reflect.GenericDeclaration[] { wildcardClass1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(genericDeclarationArray2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(genericDeclarationArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class org.apache.commons.lang3.JavaVersion" + "'", str3.equals("class org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!", (java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.6", 0, " ###8##");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.6" + "'", str3.equals("1.6"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("-1404141414-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1404141414-1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 10.0f, (double) 4, (double) 1L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                                                    ", "100.0", "1.5");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                    " + "'", str3.equals("                                                    "));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("java virtual machine specification", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " virtual machine specification" + "'", str2.equals(" virtual machine specification"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "Java Vi...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "\n", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.1" + "'", str1.equals("7.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.1"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_MAC;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "                                                                                                ", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(10L, (long) 7, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double[] doubleArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("Mac OS");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("51.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"51.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VM_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str0.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "    sophie", (java.lang.CharSequence) "                              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                    ", (java.lang.CharSequence) "X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("    sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_EXT_DIRS;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str0.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.cprinterjob" + "'", str1.equals("sun.lwawt.macosx.cprinterjob"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("10.14.3", "/mo6.el68ro.8v8j//:ptth", "/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad(" ###8##", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " ###8##" + "'", str2.equals(" ###8##"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "                                                                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, '4', (int) (short) 100, (int) ' ');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "-1404141414-1");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: -1404141414-1");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71." + "'", str1.equals("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71."));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Sun.awt.CGraphicsEnvironment", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Sun. wt.CGr phicsEnvironment" + "'", str3.equals("Sun. wt.CGr phicsEnvironment"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("en", '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', 26, (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("mixed mode", "noitacificeps enihcam lautriv avaj");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", 10, "1a-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie" + "'", str3.equals("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "7.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 99, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Mac OS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS" + "'", str1.equals("Mac OS"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Java Virtual Machine Specification", (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 191);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                              " + "'", str2.equals("                                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                              "));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("    sophie");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Sun. wt.CGr phicsEnvironment", 5, "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Sun. wt.CGr phicsEnvironment" + "'", str3.equals("Sun. wt.CGr phicsEnvironment"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                    ", (java.lang.CharSequence) "/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("51.0                                                                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "                                                    sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52333_1560279715" + "'", str1.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52333_1560279715"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("x86_64", 49, "51.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.051.051.051.051.05x86_6451.051.051.051.051.051" + "'", str3.equals("51.051.051.051.051.05x86_6451.051.051.051.051.051"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.cprinterjob", (java.lang.CharSequence) "Oracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporation", 191);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "x86_64", 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/", "hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi", (int) (short) 1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("java virtual machine specification", strArray1, strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/" + "'", str7.equals("/"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java virtual machine specification" + "'", str8.equals("java virtual machine specification"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "Sun. wt.CGr phicsEnvironment", "me/jre");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("10.14.3", "Oracle Corporation", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3" + "'", str3.equals("10.14.3"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                                    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("10.14.3", (long) 1555);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1555L + "'", long2 == 1555L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " virtual machine specification", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("me/jre", 4, 192);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "re" + "'", str3.equals("re"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim(" ###8##");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###8##" + "'", str1.equals("###8##"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', (int) '4', 100);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp(" ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 2, (long) 100, (long) 1555);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1555L + "'", long3 == 1555L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "10.14.3");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str4.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4444444444444444444444/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.444444444444444444444", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                              ", (java.lang.CharSequence) "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("14-1", "me/jr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "14-1" + "'", str2.equals("14-1"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle corporation" + "'", str1.equals("oracle corporation"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "me/jr", (java.lang.CharSequence) "14-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("me/jr", "1Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "me/j" + "'", str2.equals("me/j"));
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VM_VERSION;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "24.80-b11" + "'", str0.equals("24.80-b11"));
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("US", (int) (byte) 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US" + "'", str3.equals("US"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("51.0                                                                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat(" ###8##");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "14-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 0, 6, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 0, (float) 0L, 10.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("java virtual machine specification", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java virtual machine specification" + "'", str2.equals("java virtual machine specification"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("me/j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "me/j" + "'", str1.equals("me/j"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_RUNTIME_VERSION;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "1.7.0_80-b15" + "'", str0.equals("1.7.0_80-b15"));
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(2, 4, 192);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi", (java.lang.CharSequence) " ###a##");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (short) 100, "###8##");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###8#####8#####8####/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str3.equals("###8#####8#####8####/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 2, 0L, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!" + "'", str2.equals("!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4', (int) (short) 1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715", (java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68 + "'", int2 == 68);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("44444444444444444444444444444444", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate(" virtual machine specification", 100, (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " virtual machine specification" + "'", str3.equals(" virtual machine specification"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                              ", (java.lang.CharSequence) " virtual machine specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7" + "'", str1.equals("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1.7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) (byte) -1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 1555, "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "US", (java.lang.CharSequence) "                                                    ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "44444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str1.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("###8#####8#####8####/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###8#####8#####8####/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("###8#####8#####8####/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("me/jr", 49, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_VM_VENDOR;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Oracle Corporation" + "'", str0.equals("Oracle Corporation"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        short[] shortArray0 = new short[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a', (int) (byte) 100, (-1));
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray0, '#');
        try {
            short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "###8##", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("me/j", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "7.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) -1, 4.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "x86_64", 5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "en", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1.7", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.71.71.71.71.71.71.71.71.71.7" + "'", str2.equals("1.71.71.71.71.71.71.71.71.71.7"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Oracle Corporation", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Or cle Corpor tion" + "'", str3.equals("Or cle Corpor tion"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("    sophie");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.LWCToolkit", 191);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                  sun.lwawt.macosx.LWCToolkit                                                                                  " + "'", str2.equals("                                                                                  sun.lwawt.macosx.LWCToolkit                                                                                  "));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0" + "'", str1.equals("100.0"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "X86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                  sun.lwawt.macosx.LWCToolkit                                                                                  ", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                  sun.lwawt.macosx.LWCToolkit                                                                                  " + "'", str2.equals("                                                                                  sun.lwawt.macosx.LWCToolkit                                                                                  "));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("noitacificeps enihcam lautriv avaj", "!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "noitacificeps enihcam lautriv avaj" + "'", str3.equals("noitacificeps enihcam lautriv avaj"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        char[] charArray3 = new char[] { 'a' };
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "me/jr", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", strArray2, strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "100.0", 30, (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str5.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny(charSequence2, charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi", charArray4);
        java.lang.Class<?> wildcardClass8 = charArray4.getClass();
        java.lang.Class<?> wildcardClass9 = charArray4.getClass();
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                    sun.awt.CGraphicsEnvironment", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 1, (double) (byte) -1, (double) ' ');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                                                                  sun.lwawt.macosx.LWCToolkit                                                                                  ", "1.5", 5);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        long[] longArray4 = new long[] { 5, 4, 26, 2L };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 26L + "'", long5 == 26L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi!", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) '4');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Mac OS ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray0 = new java.lang.reflect.GenericDeclaration[] {};
        java.lang.reflect.GenericDeclaration[][] genericDeclarationArray1 = new java.lang.reflect.GenericDeclaration[][] { genericDeclarationArray0 };
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(genericDeclarationArray1);
        org.junit.Assert.assertNotNull(genericDeclarationArray0);
        org.junit.Assert.assertNotNull(genericDeclarationArray1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                                                    sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("###8#####8#####8####/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###8#####8#####8####/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("###8#####8#####8####/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        short[] shortArray0 = new short[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a', (int) (byte) 100, (-1));
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray0, '#');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray0, '#', (int) (byte) 0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                                                                                                ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("class org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class org.apache.commons.lang3.JavaVersion" + "'", str1.equals("class org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("44444444444444444444444444444444", 5, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4" + "'", str3.equals("4"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("44444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"44444444444444444444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Java Vi...", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi..." + "'", str2.equals("Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi..."));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!", "                                                                                                ", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!" + "'", str3.equals("!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("4444444444444444444444/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.444444444444444444444");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "Java Vi...", 192, (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                              ", "noitacificeps enihcam lautriv avaj");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 100, (float) 68, (float) 26);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 26.0f + "'", float3 == 26.0f);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64", (int) '4');
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat(" ###8##", "44444444444444444444444444444444", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1Oracle Corporation");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 192, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.71.71.71.71.71.71.71.71.71.7", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.71.71.71.71.71.71.71.71.71.7" + "'", str2.equals("1.71.71.71.71.71.71.71.71.71.7"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "!HI!HI!HI!HI!HusHI!HI!HI!HI!HI!", (java.lang.CharSequence) "    sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1." + "'", str1.equals("1."));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("###8##", 0, "me/j");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###8##" + "'", str3.equals("###8##"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.", "10#10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "###8#####8#####8####/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "noitacificeps enihcam lautriv avaj", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 4, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("oracle corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle corporation" + "'", str1.equals("oracle corporation"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed" + "'", str1.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "/Users/sophie", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("100.0", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7", "en");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 6, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str1.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                                                                  sun.lwawt.macosx.LWCToolkit                                                                                  ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                  sun.lwawt.macosx.LWCToolkit                                                                                  " + "'", str2.equals("                                                                                  sun.lwawt.macosx.LWCToolkit                                                                                  "));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1a-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("re", "1Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1Oracle Corporation" + "'", str2.equals("1Oracle Corporation"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", charSequence2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10#10", (int) (byte) 100, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1", (java.lang.CharSequence) "51.0", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("-1404141414-1", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1404141414-1" + "'", str2.equals("-1404141414-1"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "14-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "14-1" + "'", str2.equals("14-1"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 10, 32L, 32L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        double[] doubleArray4 = new double[] { (-1), (short) 0, (byte) 100, 1 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ', (int) (short) 0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.040.04100.041.0" + "'", str7.equals("-1.040.04100.041.0"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "-1404141414-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1404141414-1" + "'", str2.equals("-1404141414-1"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.", (java.lang.CharSequence) "Mac OS ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 296 + "'", int2 == 296);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "UTF-8", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(" ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) " virtual machine specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.", (java.lang.CharSequence) "                                                                                  sun.lwawt.macosx.LWCToolkit                                                                                  ", 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 10 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 10 + "'", byte4 == (byte) 10);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1.7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7.0_80-b15\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("51.0", " ###a##", (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.0" + "'", str3.equals("51.0"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.71.71.71.71.71.71.71.71.71.7" + "'", str1.equals("1.71.71.71.71.71.71.71.71.71.7"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                              ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Sun. wt.CGr phicsEnvironment");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("44444444444444444444444444444444", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("-1404141414-1", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1414-1" + "'", str2.equals("1414-1"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 192, 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 192 + "'", int3 == 192);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) -1, 100.0f, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) Float.POSITIVE_INFINITY, (double) 100L, (double) 30);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi..." + "'", str1.equals("Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi..."));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Java Vi...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Vi...", "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lwawt.macosx.cprinterjob", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 191, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 100, (long) (short) 100, (long) 'a');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64", "                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64" + "'", str2.equals("X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "51.0", charSequence1, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "X86_64", 192);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("sun.lwawt.macosx.LWCToolkit", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "un.lwawt.macosx.LWCToolkit" + "'", str2.equals("un.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("###8#####8#####8####/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/moc.elcaro.avaj//:ptth", 68);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/moc.elcaro.avaj//:ptth" + "'", str2.equals("/moc.elcaro.avaj//:ptth"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) " ###a##", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("51.0                                                                                               ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715", "Sun.awt.CGraphicsEnvironment", "10#10");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1.5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "    sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.71.71.71.71.71.71.71.71.71.7" + "'", str1.equals("1.71.71.71.71.71.71.71.71.71.7"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "1Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Oracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporation" + "'", str1.equals("OracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporation"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi", (int) '4', "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi                 " + "'", str3.equals("hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi                 "));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("51.051.051.051.051.05x86_6451.051.051.051.051.051", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("51.051.051.051.051.05x86_6451.051.051.051.051.051", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.051.051.051.051.05x86_6451.051.051.051.051.051" + "'", str2.equals("51.051.051.051.051.05x86_6451.051.051.051.051.051"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) ":", (java.lang.CharSequence) "51.051.051.051.051.05x86_6451.051.051.051.051.051");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("me/jre", "", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "me/jre" + "'", str3.equals("me/jre"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 0, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/..." + "'", str3.equals("/Users/..."));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sophie", "hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "me/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                              ", (java.lang.CharSequence) "Java Platform API Specification", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10.14.3", 191, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "############################################################################################10.14.3############################################################################################" + "'", str3.equals("############################################################################################10.14.3############################################################################################"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "51.051.051.051.051.05x86_6451.051.051.051.051.051", (java.lang.CharSequence) "re");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                              ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "java virtual machine specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("oracle corporation", "", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "oracle corporation" + "'", str4.equals("oracle corporation"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (float) 192);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 192.0f + "'", float2 == 192.0f);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("51.0                                                                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0                                                                                               " + "'", str1.equals("51.0                                                                                               "));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "US", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 215 + "'", int2 == 215);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/moc.elcaro.avaj//:ptth", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("00.0", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "00.0" + "'", str2.equals("00.0"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull(" a#aaa#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a#aaa#" + "'", str1.equals("a#aaa#"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong(" ###a##");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" ###a##\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "4444444444444444444444/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 98 + "'", int2 == 98);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) '#', (float) (byte) 0, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(" a#aaa#", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Sun.awt.CGraphicsEnvironment", "10#10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sun.awt.CGraphicsEnvironment" + "'", str2.equals("Sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Or cle Corpor tion", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie", 49);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49 + "'", int2 == 49);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/moc.elcaro.avaj//:ptth", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 6);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Sun. wt.CGr phicsEnvironment");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi                 ", strArray4, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 12");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("100.0a0.0a100.0", (float) 32L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/...", 1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/..." + "'", str3.equals("/Users/..."));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid(" virtual machine specification", 99, 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 6L, (double) (short) 1, (double) 4.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.0d + "'", double3 == 6.0d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1Oracle Corporation", "Oracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporation", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1Oracle Corporation" + "'", str3.equals("1Oracle Corporation"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.7");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(1555L, (long) (short) 100, (long) 5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "100.0a0.0a100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/mo6.el68ro.8v8j//:ptth");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 1, 296, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "X86_64", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("me/jre", "44444444444444444444444444444444", "4444444444444444444444/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.444444444444444444444", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "me/jre" + "'", str4.equals("me/jre"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("10#10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10#10" + "'", str1.equals("10#10"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", "1.7.0_80-b15");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "X86_64", 1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                  sun.lwawt.macosx.LWCToolkit                                                                                  ", 296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("-1.040.04");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.040.04" + "'", str1.equals("-1.040.04"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("00.0", "X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64", "Oracle Corporation");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71." + "'", str1.equals("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71."));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween(" ", "/Users/sophie", "4444444444444444444444/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.444444444444444444444");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.71.71.71.71.71.71.71.71.71.7", (double) 32L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "noitacificeps enihcam lautriv avaj", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "me/j", (java.lang.CharSequence) "Sun.awt.CGraphicsEnvironment", 98);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!", "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7", 191);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.", 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi                 ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Mac OS", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS" + "'", str2.equals("Mac OS"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/", "/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("51.051.051.051.051.05x86_6451.051.051.051.051.051", "mixed mode");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 1555);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   "));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7", 'a');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1", (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Sun. wt.CGr phicsEnvironment", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " virtual machine specification", 296);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("7.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.1", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("0#100#0", "http://java.oracle.com/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("HI!", "51.0                                                                                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "51.051.051.051.051.05x86_6451.051.051.051.051.051", (java.lang.CharSequence) "-1.040.04");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("X86_64");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"X86_64\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.6", (int) (short) -1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6" + "'", str3.equals("6"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", "me/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "me/jre" + "'", str2.equals("me/jre"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1." + "'", str1.equals("1."));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7", 'a');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "14-1", (java.lang.CharSequence[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4');
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.7" + "'", str7.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(30.0d, (double) 0L, (double) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        short[] shortArray6 = new short[] { (byte) -1, (byte) 0, (short) 1, (short) 1, (short) 1, (byte) -1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4', 100, 215);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1404141414-1" + "'", str8.equals("-1404141414-1"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.CPrinterJob", 7, "###8#####8#####8####/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "-1404141414-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Mac OS ", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        byte[] byteArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "Oracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporation");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Oracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporation");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 5L, 32.0d, Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("me/jr", "re");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "me/jr" + "'", str2.equals("me/jr"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sun.awt.CGraphicsEnvironment", 1555, "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sun.awt.CGraphicsEnvironment44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sun.awt.CGraphicsEnvironment44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.awt.CGraphicsEnvironment", "", 0);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str4.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Sun.awt.CGraphicsEnvironment", "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sun.awt.CGraphicsEnvironment" + "'", str2.equals("Sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        float[] floatArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("-1.040.04", 191, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                      -1.040.04" + "'", str3.equals("                                                                                                                                                                                      -1.040.04"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi                 ", "class org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                                                    ", (java.lang.CharSequence) "1414-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "a#aaa#", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        double[] doubleArray4 = new double[] { (-1), (short) 0, (byte) 100, 1 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.040.04100.041.0" + "'", str7.equals("-1.040.04100.041.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("x86_64");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"x86_64\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "00.0", (java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Mac OS ", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny(charSequence2, charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray4, '#');
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.io.Serializable[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str4.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) " ", (java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Oracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporation", 296, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporation" + "'", str3.equals("Oracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporation"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi..." + "'", str3.equals("Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi..."));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...", (int) (short) 0, 30);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Vi...Java Vi...Java Vi..." + "'", str3.equals("Java Vi...Java Vi...Java Vi..."));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(Float.POSITIVE_INFINITY, 100.0f, (float) 296);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + Float.POSITIVE_INFINITY + "'", float3 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "OracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporation", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                                                    sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("!HI!HI!HI!HI!HusHI!HI!HI!HI!HI!", "    sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!HI!HI!HI!HI!HusHI!HI!HI!HI!HI!" + "'", str2.equals("!HI!HI!HI!HI!HusHI!HI!HI!HI!HI!"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("hi!", "1.7");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7", (java.lang.CharSequence[]) strArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, ' ', 10, (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!", "", "                                                                                  sun.lwawt.macosx.LWCToolkit                                                                                  ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "                                                                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "/moc.elcaro.avaj//:ptth", 192);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("###8##", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("51.0                                                                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 0, "sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }
}

