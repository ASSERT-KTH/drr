import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("..th");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1a-1");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "java virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Java Vi...Java Vi...Java Vi...aaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) ".el");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(" ", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "# a #");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "100#10#10#1#0", (java.lang.CharSequence) "/u", 122);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7", (java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 26, (long) 68);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 68L + "'", long3 == 68L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "            ", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hUShi!hi!hi!...", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str1 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        long[] longArray3 = new long[] { (short) 0, (byte) 100, 0L };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', (int) (byte) 10, (-1));
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', (int) (short) 10, 0);
        long long14 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Ja                                                                                                                                                                                      -1.040.04");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.6", (int) '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaa1.6aaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaa1.6aaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        char[] charArray5 = new char[] {};
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray5, ' ');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.", charArray5);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed mode", charArray5);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100.0", charArray5);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray5, '#', 6, 30);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/U", (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("hi!", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) '4');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/moc.elcaro.avaj//:ptth", strArray1, strArray6);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/moc.elcaro.avaj//:ptth" + "'", str7.equals("/moc.elcaro.avaj//:ptth"));
        org.junit.Assert.assertNull(strArray8);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("....71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "....71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71." + "'", str1.equals("....71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71."));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "0 1 10 10 100", 3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("oracle corporation", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 0, 0.0f, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("14-1", "javavirtualmachinespecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "14-1" + "'", str2.equals("14-1"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                              ", "100.0a0.0a100.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("4444444444444444444444444444444444444444444444444444", "                                                                                                                                                 104100                                                                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS ", "sun.lwawt.macosx.CPrinterJob", (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Us[as/slsh[/Dlsum[Cs/d[f[sCs4j/Cms/au_asdlls.s _52333_c5602797c5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "###8#####8#####8####/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Ja                                                                                                                                                                                      -1.040.04", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.04Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Ja                                                                                                                                                                                      -1.0" + "'", str2.equals("0.04Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Ja                                                                                                                                                                                      -1.0"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("aaaaaaaaaaaaaa100.0a0.0a100.0", "1.71.71.71.71.71.71.71.71.71.7", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaa100.0a0.0a100.0" + "'", str3.equals("aaaaaaaaaaaaaa100.0a0.0a100.0"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("Mac OS ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("http://java.oracle.com/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(30, (int) '4', 191);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 30 + "'", int3 == 30);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("104100", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "104100" + "'", str2.equals("104100"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("5179720651_33325_lp.poodnr_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"5179720651_33325_lp.poodnr_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Java Virtual Machine Specification", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("0a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!0a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a", 191);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!0a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00..." + "'", str2.equals("0a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!0a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00..."));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444100.0 0.0 100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444100.0 0.0 100.0" + "'", str1.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444100.0 0.0 100.0"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger(".051.051.05x86_6451.051.051.051.051.051");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".05\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "                                                                                  sun.lwawt.macos");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.51.61.51.61.61.7", "Oracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("00.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1.equals(0.0d));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", "pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#pa#aaa#p", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        double[] doubleArray4 = new double[] { (-1), (short) 0, (byte) 100, 1 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.040.04100.041.0" + "'", str7.equals("-1.040.04100.041.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "class [Cclass [C");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "00.0444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("#", 1, "hi!hi!hi!hi!hi!hUShi!hi!hi!...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#" + "'", str3.equals("#"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 68);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ibrary/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("ibrary/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "http://java.oracle.com", (java.lang.CharSequence) "JA1.N");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...", "class org.apache.commons.lang3.JavaVersion", 215);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("###################################", "a");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "100.0 99.0 26.0", (java.lang.CharSequence[]) strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(".el", strArray4, strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + ".el" + "'", str11.equals(".el"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                                                    ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                    " + "'", str2.equals("                                                    "));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10\n", 3, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10\n" + "'", str3.equals("10\n"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Sun. wt.CGr phicsEnvironment");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "      ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("1.31.3", "       ", "-1a0a1a1a1a-1");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("ht...", "1.751.01.71.7", "1.3");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                              ", (java.lang.CharSequence) "-1a100/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 217);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Us[as/slsh[/Dlsum[Cs/d[f[sCs4j/Cms/au_asdlls.s _52333_c5602797c5", (java.lang.CharSequence) "J\nJ\nJ\nJ\nJ\nJ\nJ\nJ\nJ\nJ\nJ\nJ\n1#-");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1 0 100 10 -1", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.8", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.8" + "'", str3.equals("1.8"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("444444444444444444444444444444444444444444444me/j", "##################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1.5 1.6 1.5 1.6 1.6 1.7");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.5 1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("444444444444444444444444444444444444444444444me/j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444me/j" + "'", str1.equals("444444444444444444444444444444444444444444444me/j"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) ".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", (java.lang.CharSequence) "....71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4444444444444444444444444444444444444444444444444444", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sun.awt.CGraphicsEnvironment44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("-1a100/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 16, 26);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "rs/_v/6v597zmn4_v31cq2n2x1" + "'", str3.equals("rs/_v/6v597zmn4_v31cq2n2x1"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("x86_64", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("    sophie", "                                                                                  sun.lwawt.macosx.LWCToolkit                                                                                  ", 30);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.cprinterjob                                                                                                                                                                    ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 23 + "'", int5 == 23);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) (byte) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  .:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ", "-1.040.04100.041.0", 108);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715", "", (int) (short) 10);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "51.0", (java.lang.CharSequence[]) strArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "");
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("OracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporation", "http://java.oracle.com", (int) (byte) 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("#################################################################################################", strArray5, strArray13);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715" + "'", str9.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715"));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "#################################################################################################" + "'", str14.equals("#################################################################################################"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/moc.elcaro.avaj//:ptth", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 6);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                                                                                                                                                                      -1.040.04", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "104104-1410", (java.lang.CharSequence) "0#100#0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "###################################                                                                 ", (java.lang.CharSequence) "6           ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("UN.LWAWT.MACOSX.lwctOOLKIT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "100a10a10a1a0", (java.lang.CharSequence) "4444444444444444444444/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 74 + "'", int2 == 74);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray3, '4', (int) (short) 10, 0);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                    sun.awt.CGraphicsEnvironment", charArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray3, '#', 30, 18);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java Platform API Specification", charArray3);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray3, '#', 49, 10);
        try {
            java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a', 6, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("                                                                          Java Vi...Java Vi...Java Vi...                                                                           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Vi...Java Vi...Java Vi..." + "'", str1.equals("Java Vi...Java Vi...Java Vi..."));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("sun.lw4wt.m4cosx.cprinterjob", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("104104-1410", "-1.040.04100.041.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "104104-1410" + "'", str2.equals("104104-1410"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "                                                              /Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/..");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("en                           ", 215);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en                           " + "'", str2.equals("en                           "));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "-1404141414-1", (java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(29L, (long) 32, (long) 5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort(" ###8##");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("en                            ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 68);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Java Platf", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        float[] floatArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, ' ', (int) ' ', 100);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("mac OS", "/-1a100-1a100-1a100-1a100-1a100-1a100-1a100-1a100-1a100-1a100-1a100-1a100-1a100-1a100-1a100-1a100-1");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("100.0 0.0 100.0Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java ", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "0a100a0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (double) 32L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("       ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification", (java.lang.CharSequence) "0a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!0a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "14-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("-1.0 0.0 100.0 1.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("-1.0a0.0a100.0a1.0", 12, 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".0a1.0" + "'", str3.equals(".0a1.0"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("..th", "444444444", "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "..th" + "'", str3.equals("..th"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "", 23);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        double[] doubleArray4 = new double[] { (-1), (short) 0, (byte) 100, 1 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', (int) (byte) 100, 100);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1.0 0.0 100.0 1.0" + "'", str13.equals("-1.0 0.0 100.0 1.0"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("ht", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ht" + "'", str2.equals("ht"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10#10#-1#10", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1.8");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444444444444444444444/uSERS/SOPHI!TEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Us[as/slsh[/Dlsum[Cs/d[f[sCs4j/Cms/au_asdlls.s _52333_c5602797c5");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1-#1", " ###a##");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        char[] charArray5 = new char[] {};
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray5, ' ');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.", charArray5);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed mode", charArray5);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.5aaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/-1a100-1a100-1a100-1a100-1a100-1a100-1a100-1a100-1a100-1a100-1a100-1a100-1a100-1a100-1a100-1a100-1", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "1.51.61.51.61.61.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Java Vi...Java Vi...Java Vi...aaaaaaaaaaaaaaaaaaa", "0 1 10 10 100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Vi...Java Vi...Java Vi...aaaaaaaaaaaaaaaaaaa" + "'", str2.equals("Java Vi...Java Vi...Java Vi...aaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "J\nJ\nJ\nJ\nJ\nJ\nJ\nJ\nJ\nJ\nJ\nJ\n1#-", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 34, "                                                                                  sun.lwawt.macosx.LWCToolkit                                                                                  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                  " + "'", str3.equals("                                  "));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("7.0", "-1a100");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("UN.LWAWT.MACOSX.lwctOOLKIT", 217);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UN.LWAWT.MACOSX.lwctOOLKIT" + "'", str2.equals("UN.LWAWT.MACOSX.lwctOOLKIT"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "mixed mode", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        int[] intArray2 = new int[] { 1, (byte) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "14-1" + "'", str6.equals("14-1"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        int[] intArray2 = new int[] { 1, (byte) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', 99, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', 3500, (int) '#');
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "14-1" + "'", str5.equals("14-1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        double[] doubleArray4 = new double[] { (-1), (short) 0, (byte) 100, 1 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.040.04100.041.0" + "'", str7.equals("-1.040.04100.041.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1.040.04100.041.0" + "'", str9.equals("-1.040.04100.041.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1.0 0.0 100.0 1.0" + "'", str12.equals("-1.0 0.0 100.0 1.0"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 62);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 10 + "'", byte4 == (byte) 10);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.                                          ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.                                          " + "'", str2.equals("/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.                                          "));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("JA1.N", (int) '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JA1.N##############################" + "'", str3.equals("JA1.N##############################"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("#################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion4 = null;
        try {
            boolean boolean5 = javaVersion0.atLeast(javaVersion4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("############################################################################################10.14.3############################################################################################", "1.31.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "############################################################################################10.14.3############################################################################################" + "'", str2.equals("############################################################################################10.14.3############################################################################################"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("en", "classorg.apache.commons.lang3.JavaVersion");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaa7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("noitacificeps enihcam lautriv avaj");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOITACIFICEPS ENIHCAM LAUTRIV AVAJ" + "'", str1.equals("NOITACIFICEPS ENIHCAM LAUTRIV AVAJ"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("51.051.051.051.051.05x86_6451.051.051.051.051.051", 27);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27 + "'", int2 == 27);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("-1.0 0.0 100.0 1.0", 52, "100.040.04100.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.040.04100.0100.040.04100.0100.-1.0 0.0 100.0 1.0" + "'", str3.equals("100.040.04100.0100.040.04100.0100.-1.0 0.0 100.0 1.0"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "############################################################################################10.14.3############################################################################################", (java.lang.CharSequence) "JA1.N");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "5179720651_33325_lp.poodnr_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5179720651_33325_lp.poodnr_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/" + "'", str2.equals("5179720651_33325_lp.poodnr_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "100.0 99.0 26.0", (java.lang.CharSequence) "                                                                                  sun.lwawt.macos");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(99, (int) (short) 100, 191);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 191 + "'", int3 == 191);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.", 29, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) ".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", ' ');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("hi!", "1.7");
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "00.0", (java.lang.CharSequence[]) strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("10.14.3", strArray4, strArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Or cle Corpor tion", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.14.3" + "'", str10.equals("10.14.3"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        float[] floatArray3 = new float[] { (short) 100, (short) 0, 100L };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ', 10, (int) (short) -1);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("UTF-8", 7, 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "5179720651_33325_lp.poodnr_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat(".051.051.05x86_6451.051.051.051.051.051", "444...", (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051" + "'", str3.equals(".051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "100 10 10 1 0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0-1.0#0.0#100.0#1.0", (java.lang.CharSequence) "  # a #");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java Platf", (java.lang.CharSequence) "                                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                              ", 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "10.14.3");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("hi!", "1.7");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", strArray3, strArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "    sophie");
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "");
        int int14 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                                    sun.awt.CGraphicsEnvironment", (java.lang.CharSequence[]) strArray13);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray13, '4');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str5.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str9.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str11.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str16.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) " ###8##", (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + " ###8##" + "'", charSequence2.equals(" ###8##"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("WT");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ', 98, 10);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100.0", "hi!");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 100, (int) (byte) 100);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "1004104104140");
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "10#10", (java.lang.CharSequence[]) strArray9);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        short[] shortArray2 = new short[] { (short) -1, (short) 100 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "rs/_v/6v597zmn4_v31cq2n2x1", (java.lang.CharSequence) "###8#####8#####8####/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                              /Library/Java/JavaVirtualMachines/jdk1");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", 296L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 296L + "'", long2 == 296L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("###################################                                                                 ", '#');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        double[] doubleArray4 = new double[] { (-1), (short) 0, (byte) 100, 1 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#', 34, 2);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4', 45, 35);
        double double20 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.040.04100.041.0" + "'", str7.equals("-1.040.04100.041.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1.0#0.0#100.0#1.0" + "'", str15.equals("-1.0#0.0#100.0#1.0"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 100.0d + "'", double20 == 100.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 215.0f, (double) 97L, (double) ' ');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 215.0d + "'", double3 == 215.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("7971");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7971" + "'", str1.equals("7971"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", " ###a##");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                                                                                                                                                                                    ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/moc.elcaro.avaj//:ptth");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim(" virtual machine specific");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "virtual machine specific" + "'", str1.equals("virtual machine specific"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://j");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray3, '4', (int) (short) 10, 0);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                    sun.awt.CGraphicsEnvironment", charArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray3, '#', 30, 18);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray3, '4');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://j", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Ja                                                                                                                                                                                      -1.040.04", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) " virtu#l m#chine specific#tion", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        char[] charArray7 = new char[] { ' ', '#', 'a', '#' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "x86_64", charArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a', (int) (byte) 100, (int) (byte) 0);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", charArray7);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.lwawt.macosx.cprinterjob", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1-#1");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        double[] doubleArray4 = new double[] { (-1), (short) 0, (byte) 100, 1 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.040.04100.041.0" + "'", str7.equals("-1.040.04100.041.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte(".051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("US");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/U", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                                                                                                                                                      -1.040.04", (java.lang.CharSequence) "                                                                                                ", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        java.lang.CharSequence charSequence1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("hi!", "1.7");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "00.0", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence1, (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray5, strArray10);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("virtual machine specific", "un.lwawt.macosx.LWCToolkit", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sun.awt.CGraphicsEnvironment44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "virtual machine specific" + "'", str3.equals("virtual machine specific"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("32.0a5.0a99.0", 23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     32.0a5.0a99.0     " + "'", str2.equals("     32.0a5.0a99.0     "));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 68L, 215.0f, (float) 1555);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 68.0f + "'", float3 == 68.0f);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/U");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        int[] intArray1 = new int[] { 1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 6, (int) (short) 1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 3500, (int) ' ');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 0, (float) 1, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) (byte) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 10 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4', 0, 27);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 10 + "'", byte4 == (byte) 10);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "s/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javas/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext", 191, 296);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("##################", "JAVA VIRTUAL MACHINE SPECIFICATIO", "r4", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "##################" + "'", str4.equals("##################"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 26, 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaa100.0a0.0a100.0", (java.lang.CharSequence) "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                          /Users/sophie                                          ", "CLASS [CCLASS [C");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("10.0", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0" + "'", str2.equals("10.0"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Java Vi...", 62);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi..." + "'", str2.equals("Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi..."));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4');
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "104100" + "'", str5.equals("104100"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100.0", "hi!");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, " virtual machine specification");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("4444444444444444444444/uSERS/SOPHI!TEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", strArray2, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 22 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("\n", "6", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n" + "'", str3.equals("\n"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("me/j", "7.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.1");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("portion", "aaaaaaaaaaaaaa100.0a0.0a100.0", "444...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "portion" + "'", str3.equals("portion"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1", "..th", "aaaa7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "en", "javavirtualmachinespecification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.                                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                          .:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/met!ihpos/sresU/" + "'", str1.equals("                                          .:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/met!ihpos/sresU/"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1.8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7", ' ');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "JA1.N##############################", 0, 1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7" + "'", str5.equals("1.7"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.7" + "'", str9.equals("1.7"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Or cle Corpor tion", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Java Vi...", "0410040");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Vi..." + "'", str2.equals("Java Vi..."));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        double[] doubleArray4 = new double[] { (-1), (short) 0, (byte) 100, 1 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ', 2, (int) (short) 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ', (int) 'a', (int) (byte) 0);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_156027971", "10410", 296);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", "0a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!0a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00a100a00...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE" + "'", str2.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray5 = new char[] {};
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray5, ' ');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.", charArray5);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "me/jre", charArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray5, ' ', 68, 16);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        float[] floatArray3 = new float[] { ' ', 5, 99 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "32.0a5.0a99.0" + "'", str5.equals("32.0a5.0a99.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 5.0f + "'", float6 == 5.0f);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        long[] longArray3 = new long[] { (short) 0, (byte) 100, 0L };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', (int) (byte) 10, (-1));
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', (int) (byte) 100, 1);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray3, '4', 32, 7);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(longArray3, '#', (int) (byte) 1, (int) (byte) 1);
        long long21 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long22 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long23 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 100L + "'", long22 == 100L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', 10, 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("7.0 ###8##7.0 ###8##7.0", ".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7.0 ###8##7.0 ###8##7.0" + "'", str2.equals("7.0 ###8##7.0 ###8##7.0"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "# a #  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                              /Library/Java/JavaVirtualMachines/jdk1", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Mac OSMac OSMac OSMac OSMac OSMac OSMac OSMac OSMac OSMac OSMac OSMac OSMac OSMac OSMac OSMac OSMac OSMac OSMac OSMac OSMac OSMac OSMac OSMac OSMac OS", (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("virtual machine specific", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "av", 0, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Ja                                                                                                                                                                                      -1.040.04", "0.04Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Ja                                                                                                                                                                                      -1.0", "1.8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Ja                                                                                                                                                                                      -1.040.04" + "'", str3.equals("Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Ja                                                                                                                                                                                      -1.040.04"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble(".051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Us[as/slsh[/Dlsum[Cs/d[f[sCs4j/Cms/au_asdlls.s _52333_c5602797c5", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Us[4s/slsh[/Dlsum[Cs/d[f[sCs4j/Cms/4u_4sdlls.s _52333_c5602797c5" + "'", str3.equals("/Us[4s/slsh[/Dlsum[Cs/d[f[sCs4j/Cms/4u_4sdlls.s _52333_c5602797c5"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("r4", "1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "r4" + "'", str2.equals("r4"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        short[] shortArray2 = new short[] { (short) -1, (short) 100 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', 179, 35);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        short[] shortArray5 = new short[] { (byte) 100, (byte) 10, (byte) 10, (short) 1, (byte) 0 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ', 0, 5);
        short short15 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short16 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ', 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100a10a10a1a0" + "'", str10.equals("100a10a10a1a0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100 10 10 1 0" + "'", str14.equals("100 10 10 1 0"));
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 0 + "'", short15 == (short) 0);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 0 + "'", short16 == (short) 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                    ", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7" + "'", str1.equals("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("-1a100/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "r4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a100/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("-1a100/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean5 = javaVersion3.atLeast(javaVersion4);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        boolean boolean7 = javaVersion1.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean10 = javaVersion8.atLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean13 = javaVersion11.atLeast(javaVersion12);
        boolean boolean14 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
        boolean boolean15 = javaVersion9.atLeast(javaVersion11);
        boolean boolean16 = javaVersion1.atLeast(javaVersion11);
        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean19 = javaVersion17.atLeast(javaVersion18);
        boolean boolean20 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion17);
        org.apache.commons.lang3.JavaVersion javaVersion21 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean22 = javaVersion17.atLeast(javaVersion21);
        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean24 = javaVersion21.atLeast(javaVersion23);
        boolean boolean25 = javaVersion1.atLeast(javaVersion23);
        org.apache.commons.lang3.JavaVersion javaVersion26 = null;
        try {
            boolean boolean27 = javaVersion1.atLeast(javaVersion26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + javaVersion21 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion21.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("classorg.apache.commons.lang3.JavaVersion", "-1#100");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "h", (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Mac OS X", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X" + "'", str2.equals("X"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1 -1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "en                           ", (java.lang.CharSequence) "#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        int[] intArray2 = new int[] { 1, (byte) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1a-1" + "'", str5.equals("1a-1"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1a-1" + "'", str10.equals("1a-1"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        long[] longArray3 = new long[] { (short) 0, (byte) 100, 0L };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', (int) (byte) 10, (-1));
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', (int) (byte) 100, 1);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.Class<?> wildcardClass13 = longArray3.getClass();
        java.lang.CharSequence charSequence15 = null;
        char[] charArray17 = new char[] {};
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray17);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny(charSequence15, charArray17);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi", charArray17);
        java.lang.Class<?> wildcardClass21 = charArray17.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion22 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion24 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean25 = javaVersion23.atLeast(javaVersion24);
        org.apache.commons.lang3.JavaVersion javaVersion26 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion27 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean28 = javaVersion26.atLeast(javaVersion27);
        boolean boolean29 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion26);
        boolean boolean30 = javaVersion24.atLeast(javaVersion26);
        org.apache.commons.lang3.JavaVersion javaVersion31 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion32 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean33 = javaVersion31.atLeast(javaVersion32);
        org.apache.commons.lang3.JavaVersion javaVersion34 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion35 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean36 = javaVersion34.atLeast(javaVersion35);
        boolean boolean37 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion34);
        boolean boolean38 = javaVersion32.atLeast(javaVersion34);
        boolean boolean39 = javaVersion24.atLeast(javaVersion34);
        java.lang.String str40 = javaVersion34.toString();
        boolean boolean41 = javaVersion22.atLeast(javaVersion34);
        java.lang.Class<?> wildcardClass42 = javaVersion22.getClass();
        java.lang.String[] strArray46 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("x86_64", "                                                                                                ", (int) (byte) 10);
        java.lang.String str50 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray46, '#', 192, 0);
        java.lang.Class<?> wildcardClass51 = strArray46.getClass();
        long[] longArray55 = new long[] { (short) 0, (byte) 100, 0L };
        java.lang.String str59 = org.apache.commons.lang3.StringUtils.join(longArray55, 'a', (int) (byte) 10, (-1));
        java.lang.String str63 = org.apache.commons.lang3.StringUtils.join(longArray55, 'a', (int) (byte) 100, 1);
        long long64 = org.apache.commons.lang3.math.NumberUtils.min(longArray55);
        java.lang.Class<?> wildcardClass65 = longArray55.getClass();
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray66 = new java.lang.reflect.GenericDeclaration[] { wildcardClass13, wildcardClass21, wildcardClass42, wildcardClass51, wildcardClass65 };
        java.lang.reflect.GenericDeclaration[][] genericDeclarationArray67 = new java.lang.reflect.GenericDeclaration[][] { genericDeclarationArray66 };
        java.lang.String str68 = org.apache.commons.lang3.StringUtils.join(genericDeclarationArray67);
        java.lang.String str69 = org.apache.commons.lang3.StringUtils.join(genericDeclarationArray67);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + javaVersion22 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion22.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion24 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion24.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + javaVersion26 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion26.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion27 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion27.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + javaVersion31 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion31.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion32 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion32.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + javaVersion34 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion34.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion35 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion35.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1.6" + "'", str40.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(longArray55);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "" + "'", str59.equals(""));
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "" + "'", str63.equals(""));
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(genericDeclarationArray66);
        org.junit.Assert.assertNotNull(genericDeclarationArray67);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "a#aaa#", 179);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        float[] floatArray4 = new float[] { (-1.0f), 29, 0, 32.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 0, 1553);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 32.0f + "'", float5 == 32.0f);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "51.0                                                                                               ", (java.lang.CharSequence) "14041004104-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                              ", 29, 98);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                 /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j" + "'", str3.equals("                                 /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(10, 68, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 68 + "'", int3 == 68);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence4 = null;
        char[] charArray6 = new char[] {};
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone(charSequence4, charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sun.awt.CGraphicsEnvironment44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a', 192, (-1));
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        double[] doubleArray4 = new double[] { (-1), (short) 0, (byte) 100, 1 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ', 1555, 10);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.040.04100.041.0" + "'", str7.equals("-1.040.04100.041.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0 0.0 100.0 1.0" + "'", str11.equals("-1.0 0.0 100.0 1.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "me/jre", (java.lang.CharSequence) "oracle corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(1555, 0, 215);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1555 + "'", int3 == 1555);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71." + "'", str2.equals("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71."));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble(" x86_64                                                              ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("7ja7ja7ja7ja7ja7ja7ja7ja7ja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7JA7JA7JA7JA7JA7JA7JA7JA7JA" + "'", str1.equals("7JA7JA7JA7JA7JA7JA7JA7JA7JA"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.", "0410040");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1." + "'", str2.equals("1."));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Ja                                                                                                                                                                                      -1.040.04", (java.lang.CharSequence) "aaaaaaaaaaaaaa100.0a0.0a100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1530 + "'", int2 == 1530);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0" + "'", str1.equals("100.0"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "10#100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.6", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.", "\n", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/User\nva:." + "'", str3.equals("/User\nva:."));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(68L, 0L, 97L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("                                                    ", "!HI!HI!HI!HI!HusHI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                    " + "'", str2.equals("                                                    "));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 192.0f, (double) (short) 0, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 192.0d + "'", double3 == 192.0d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "en                           ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "virtual machine specific");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Us[4s/slsh[/Dlsum[Cs/d[f[sCs4j/Cms/4u_4sdlls.s _52333_c5602797c5", "5179720651_33325_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        char[] charArray7 = new char[] { ' ', '#', 'a', '#' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "x86_64", charArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a', (int) (byte) 100, (int) (byte) 0);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", charArray7);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray7, ' ', 6, 0);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "6", (java.lang.CharSequence) "CLASS [CCLASS [C");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 42);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "100.0 99.0 26.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(49.0d, (double) 4.4444447E9f, (double) 27);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 27.0d + "'", double3 == 27.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        long[] longArray3 = new long[] { (short) 0, (byte) 100, 0L };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', (int) (byte) 10, (-1));
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray3, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray3, '#');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(longArray3, '4', 1530, 5);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0410040" + "'", str11.equals("0410040"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0a100a0" + "'", str13.equals("0a100a0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0#100#0" + "'", str15.equals("0#100#0"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0 100 0" + "'", str17.equals("0 100 0"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1.71.71.71.71.71.71.71.71.71.7", 62);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62 + "'", int2 == 62);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"       \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "..th", charSequence1, 99);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("############################################################################################10.14.3############################################################################################", "", 1530);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "############################################################################################10.14.3############################################################################################" + "'", str3.equals("############################################################################################10.14.3############################################################################################"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "OracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporation", 1);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) ".14.3", (java.lang.CharSequence[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "x86_64");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Users/sophie", "Or cle Corpor tion", "0a100a0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("US....71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7", "", 42, 1555);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "US....71.71.71.71.71.71.71.71.71.71.71.71." + "'", str4.equals("US....71.71.71.71.71.71.71.71.71.71.71.71."));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "!HI!HI!HI!HI!HusHI!HI!HI!HI!HI!", "                                                                                                                                                                                      -1.040.04");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) ".051.051.05x86_6451.051.051.051.051.051");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("1 -1", "                                                    sun.awt.cgraphicsenvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1 -1" + "'", str2.equals("1 -1"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("noitacificeps enihcam lautriv avaj");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitacificeps enihcam lautriv avaj" + "'", str1.equals("noitacificeps enihcam lautriv avaj"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Oracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporation", (java.lang.CharSequence) "Oracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("100.0 0.0 100.0", "                                                                          Java Vi...Java Vi...Java Vi...                                                                           ", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_52333_1560279715");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Java Vi...Java Vi...Java Vi...aaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) ".0a1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("       ", "                                                   #################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       " + "'", str2.equals("       "));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        short[] shortArray6 = new short[] { (byte) -1, (byte) 0, (short) 1, (short) 1, (short) 1, (byte) -1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4', 3, 0);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1404141414-1" + "'", str8.equals("-1404141414-1"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 1 + "'", short9 == (short) 1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                                                                                                                                 104100                                                                                                                                                 ", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                 104100                                                                                                                                                 " + "'", str2.equals("                                                                                                                                                 104100                                                                                                                                                 "));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                                ", 108);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                            " + "'", str2.equals("                                                                                                            "));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) -1, (long) 5, 296L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("..th", "Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Ja                                                                                                                                                                                      -1.040.04");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "..th" + "'", str2.equals("..th"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/u");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/U" + "'", str1.equals("/U"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", ".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!", 108);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                      !hi!hi!hi!hi!hUShi!hi!hi!hi!hi!                                       " + "'", str2.equals("                                      !hi!hi!hi!hi!hUShi!hi!hi!hi!hi!                                       "));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("51.0Mac OS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0Mac OS" + "'", str1.equals("51.0Mac OS"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1#-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1#-1" + "'", str1.equals("1#-1"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        int[] intArray2 = new int[] { 1, (byte) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray2, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', 99, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray2, '#', 1555, 2);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray2, 'a');
        int int16 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "14-1" + "'", str5.equals("14-1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1a-1" + "'", str15.equals("1a-1"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("5179720651_33325_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444451.04444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5179720651_33325_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str2.equals("5179720651_33325_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("0.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.0" + "'", str1.equals("0.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.0"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("5179720651_33325_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi                 ", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi                 " + "'", str2.equals("hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi                 "));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "       ", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444100.0 0.0 100.0", 49);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("-1#100", 108, 74);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1#100" + "'", str3.equals("-1#100"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray6 = new char[] {};
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny(charSequence4, charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                    ", charArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray6, '#', 191, 0);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...", charArray6);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                                  sun.lwawt.macos", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("100.0 0.0 100.0Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java ", "en                            ", "                                                                                                                                                 104100                                                                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0 0.0 100.0Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java " + "'", str3.equals("100.0 0.0 100.0Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java "));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("444444444444444444444444444444444444444444444me/j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444me/j" + "'", str1.equals("444444444444444444444444444444444444444444444me/j"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "7.0 ###8##7.0 ###8##7.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("14041004104-1", "1.71.751.0", "Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...", 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "14041004104-1" + "'", str4.equals("14041004104-1"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "java virtual machine specification", (java.lang.CharSequence) "4444444444");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "java virtual machine specification" + "'", charSequence2.equals("java virtual machine specification"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 10, (byte) -1, (byte) 10 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 4, 68);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "104104-1410" + "'", str7.equals("104104-1410"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10#10#-1#10" + "'", str9.equals("10#10#-1#10"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray3, ' ');
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sun.awt.CGraphicsEnvironment44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray3);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray3, ' ', (int) (byte) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Vi...", "-1#100", 30);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                                                                                                                 104100                                                                                                                                                 ", '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                 104100                                                                                                                                                 " + "'", str3.equals("                                                                                                                                                 104100                                                                                                                                                 "));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("NOITACIFICEPS ENIHCAM LAUTRIV AVAJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaaaaaa100.0a0.0a100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaa100.0a0.0a100.0" + "'", str1.equals("aaaaaaaaaaaaaa100.0a0.0a100.0"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        float[] floatArray3 = new float[] { (short) 100, (short) 0, 100L };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ', 10, (int) (short) -1);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#');
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100.0#0.0#100.0" + "'", str10.equals("100.0#0.0#100.0"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "X86_64", (java.lang.CharSequence) "100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        long[] longArray3 = new long[] { (short) 0, (byte) 100, 0L };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', (int) (byte) 10, (-1));
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray3, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray3, '#');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(longArray3, '4');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0410040" + "'", str11.equals("0410040"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0a100a0" + "'", str13.equals("0a100a0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0#100#0" + "'", str15.equals("0#100#0"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0 100 0" + "'", str17.equals("0 100 0"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0410040" + "'", str19.equals("0410040"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sun.awt.CGraphicsEnvironment44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "ht");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "100a10a10a1a0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("4444444444444444444444/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:.", "    sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("4444444444444444444444/Users/sophi!tem/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        java.lang.CharSequence charSequence1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("Mac OS ", "                              ");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence1, (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////Mac OS/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 145 + "'", int6 == 145);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                                            ", (float) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "                              ", (java.lang.CharSequence) "a5");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("444444444444444444444444444444444444444444444me/j", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444me/j" + "'", str2.equals("444444444444444444444444444444444444444444me/j"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                                              /Library/Java/JavaVirtualMachines/jdk1", "aaaaaaaaaaaaaaaaaaaaaaaaaaa5.1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "    sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("me/jr", (int) (short) 0, "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "me/jr" + "'", str3.equals("me/jr"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny(charSequence1, charArray3);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi", charArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray3, '#');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString(".051.051.05x86_6451.051.051.051.051.051", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".051.051.05x86_6451.051.051.051.051.051" + "'", str2.equals(".051.051.05x86_6451.051.051.051.051.051"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        long[] longArray3 = new long[] { (short) 0, (byte) 100, 0L };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', (int) (byte) 10, (-1));
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0a100a0" + "'", str10.equals("0a100a0"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(".../sresU/");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4', 1555, 215);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                                                                                  sun.lwawt.macosx.LWCToolkit                                                                                  ", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("x86_64", ".051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051", "1.5 1.6 1.5 1.6 1.6 1.7");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("-1.040.04", 3500, 108);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.040.04" + "'", str3.equals("-1.040.04"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("-1.0 29.0 0.0 32.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0 29.0 0.0 32.0" + "'", str1.equals("-1.0 29.0 0.0 32.0"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...", "class org.apache.commons.lang3.JavaVersion", 215);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "ttp://java.oracle.com", (java.lang.CharSequence) "444...                                                                                           ", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("-1.0#0.0#100.0#1.0", "     32.0a5.0a99.0     ", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0#0.0#100.0#1.0" + "'", str3.equals("-1.0#0.0#100.0#1.0"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.5", (java.lang.CharSequence) "00.0444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(".051.051.05x86_6451.051.051.051.051.051", "Java HotSpot(TM) 64-Bit Server VM", "java virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specificationjava virtual machine specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".051.051.05x8i_in51.051.051.051.051.051" + "'", str3.equals(".051.051.05x8i_in51.051.051.051.051.051"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 1, (long) '4', (long) 49);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "virtual machine specific", (java.lang.CharSequence) "                                                                                  sun.lwawt.macos");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.71.751.0", "10.14.3                                                                                             ", "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/..");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Sun. wt.CGr phicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.substringsBetween("", "sun.awt.CGraphicsEnvironment", "7971");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "a4a4-a", 192);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0410040", (java.lang.CharSequence[]) strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ', 0, (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444444444444444444444444444444444", "sun.lwawt.macosx.CPrinterJob", 49);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean6 = javaVersion4.atLeast(javaVersion5);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        boolean boolean8 = javaVersion2.atLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean11 = javaVersion9.atLeast(javaVersion10);
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean14 = javaVersion12.atLeast(javaVersion13);
        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        boolean boolean16 = javaVersion10.atLeast(javaVersion12);
        boolean boolean17 = javaVersion2.atLeast(javaVersion12);
        java.lang.String str18 = javaVersion12.toString();
        boolean boolean19 = javaVersion0.atLeast(javaVersion12);
        boolean boolean20 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.6" + "'", str18.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "en                           ", "4444444444444444444444/uSERS/SOPHI!TEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("0.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.0", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.0" + "'", str2.equals(".04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.0"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("r4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "r4" + "'", str1.equals("r4"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        char[] charArray8 = new char[] { ' ', '#', 'a', '#' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "x86_64", charArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a', (int) (byte) 100, (int) (byte) 0);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophiesophie", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "24.80-b11", charArray8);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "ttp://java.oracle.com", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "###################################                                                                 ", (java.lang.CharSequence) "mac OS");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.5 1.6 1.5 1.6 1.6 1.7", " 4#4a4#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5 1.6 1.5 1.6 1.6 1.7" + "'", str2.equals("1.5 1.6 1.5 1.6 1.6 1.7"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                                                                                                                                                                                      -1.040.04", "10.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.310.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                      -1.040.04" + "'", str2.equals("                                                                                                                                                                                      -1.040.04"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("0 1 01 01 001", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("r4", 62);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "r4" + "'", str2.equals("r4"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("6 ...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                  ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        double[] doubleArray4 = new double[] { (-1), (short) 0, (byte) 100, 1 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#', 34, 2);
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double15 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.040.04100.041.0" + "'", str7.equals("-1.040.04100.041.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-1.0a0.0a100.0a1.0" + "'", str17.equals("-1.0a0.0a100.0a1.0"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi!", "1.7");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray3, strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "US....71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////Mac OS/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                                                    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64", ' ');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "44444444444444444444444444444444", (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, " virtual machine specification");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 3500, 296);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64" + "'", str6.equals("X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray4, '4', (int) (short) 10, 0);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                    sun.awt.CGraphicsEnvironment", charArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray4, '#', 30, 18);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java Platform API Specification", charArray4);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray4, '#', 49, 10);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "-1.0 29.0 0.0 32.0", (java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(1.0d, (double) 1.0f, (double) 3);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble(" 4#4a4", 122.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 122.0d + "'", double2 == 122.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("# a #  ", "portion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "# a #  " + "'", str2.equals("# a #  "));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        double[] doubleArray4 = new double[] { (-1), (short) 0, (byte) 100, 1 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.040.04100.041.0" + "'", str7.equals("-1.040.04100.041.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1.040.04100.041.0" + "'", str9.equals("-1.040.04100.041.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.040.04100.041.0" + "'", str14.equals("-1.040.04100.041.0"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 100, (long) 30, (long) 16);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 16L + "'", long3 == 16L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaaaaaaaaaaaaaaaa1.6aaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaa1.6aaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaa1.6aaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                              ", " ###8##", 32);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "                                                          class org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(".051.051.05x86_6451.051.051.051.051.051", '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".051.051.05x86_6451.051.051.051.051.051" + "'", str3.equals(".051.051.05x86_6451.051.051.051.051.051"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "", 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a", '4');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.cprinterjob                                                                                                                                                                    ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 11 + "'", int4 == 11);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                          Java Vi...Java Vi...Java Vi...                                                                           ", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi", 68);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("444444444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"444444444444444444444444444444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray6 = new char[] {};
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny(charSequence4, charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hi", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                    ", charArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray6, '#', 191, 0);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "6", charArray6);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "00.0", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0410040", "Oracle Corporation", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/", "100.0499.0426.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("100.040.04100.0", 0, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100.0#0.0#100.0", "104100");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("51.0                                                                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0                                                                                               " + "'", str1.equals("51.0                                                                                               "));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "javavirtualmachinespecification", "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("J\n", "1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J\n" + "'", str2.equals("J\n"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "                                 /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("hi!", "1.7");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "00.0", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "OracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporation", 1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("/moc.elcaro.avaj//:ptth", strArray7, strArray11);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "class org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/moc.elcaro.avaj//:ptth" + "'", str12.equals("/moc.elcaro.avaj//:ptth"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("100#10#10#1#0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "6           ", (java.lang.CharSequence) "JA1.N", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 3, (float) 97, (float) 68);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("5179720651_33325_lp.poodnr_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/", "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5179720651_33325_lp.poodnr_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/" + "'", str2.equals("5179720651_33325_lp.poodnr_nur/pmt/jstcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 29, 0L, (long) 215);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 215L + "'", long3 == 215L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0#100#0", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "       ", charArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray4, ' ');
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) ".04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.00.04                                                                                                                                                                                      -1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "Mac OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18 + "'", int2 == 18);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "-1.0A0.0A100.0A1.0", (java.lang.CharSequence) " ###a##", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("     32.0a5.0a99.0     ", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("oR CLE cORPOR TION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oR CLE cORPOR TION" + "'", str1.equals("oR CLE cORPOR TION"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(29.0f, 10.0f, (float) 191);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 1, 45, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Us[4s/slsh[/Dlsum[Cs/d[f[sCs4j/Cms/4u_4sdlls.s _52333_c5602797c5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("#################################################", 29, "-1.040.04100.041.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#################################################" + "'", str3.equals("#################################################"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble(".0a1.0", (double) 99L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.0d + "'", double2 == 99.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("Oracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporation" + "'", str1.equals("Oracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracle Corporation"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444451.04444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sun.lw#wt.m#cosx.cprinterjob", "me/jre", 296);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("a4a4-a", "classorg.apache.commons.lang3.JavaVersion", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52333_1560279715");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a4a4-a" + "'", str3.equals("a4a4-a"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 10 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Or cle Corpor tion");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("OracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporationhi!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!hiOracleCorporation", "http://java.oracle.com", (int) (byte) 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray2, strArray6);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.8", 18, "x86_64");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64x86_64x861.8" + "'", str3.equals("x86_64x86_64x861.8"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("00.0", "sun.lwawt.macosx.CPrinterJob", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "!hi!hi!hi!hi!hUShi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1oracle corporation", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("X", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X" + "'", str2.equals("X"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("un.lwawt.macosx.LWCToolkit", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (float) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                              ", (java.lang.CharSequence) "Java Vi...", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 29 + "'", int3 == 29);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("104104-1410", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", (int) (byte) -1, 99);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("#################################################", "                                                                                        -1.040.04");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#################################################" + "'", str2.equals("#################################################"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.awt.CGraphicsEnvironmentaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "444...", (java.lang.CharSequence) "en                            ", 215);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 30 + "'", int3 == 30);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Virtual Machine Specification", "4", 26);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1.3", (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "##################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        long[] longArray3 = new long[] { (short) 0, (byte) 100, 0L };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', (int) (byte) 10, (-1));
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', (int) (byte) 100, 1);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ', 1555, 2);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaa7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja7ja");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) " virtual machine specification", "mac OS");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) ' ', (float) 62, (float) 98);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                                                                        -1.040.04", "1#-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                        -1.040.04" + "'", str2.equals("                                                                                        -1.040.04"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                              ", '#');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, " ");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 62, 179);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 62");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("-1a0a1a1a1a-1", "sun.lwawt.macosx.CPrinterJob", "sun.lwawt.macosx.cprinterjob                                                                                                                                                                    ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("0 1 10 10 100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0 1 10 10 100" + "'", str1.equals("0 1 10 10 100"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1004104104140", "6 ...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("10#10#-1#10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10#10#-1#10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("aaaaaaaaaaaaaa100.0a0.0a100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaa100.0a0.0a100.0" + "'", str1.equals("aaaaaaaaaaaaaa100.0a0.0a100.0"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("                                                    sun.awt.cgraphicsenvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                    SUN.AWT.CGRAPHICSENVIRONMENT" + "'", str1.equals("                                                    SUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "a", (java.lang.CharSequence) ".051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051444....051.051.05x86_6451.051.051.051.051.051");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444sun.awt.CGraphicsEnvironment44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) ' ');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                              ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                              ", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.6");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.6\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "poracle corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        int[] intArray2 = new int[] { 1, (byte) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ', 1, (int) (byte) 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ', 99, (int) ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray2, ' ');
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1 -1" + "'", str13.equals("1 -1"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) -1, (int) ' ', 1553);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1553 + "'", int3 == 1553);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                 /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                 /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray3, '4', (int) (short) 10, 0);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                    sun.awt.CGraphicsEnvironment", charArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray3, '#', 30, 18);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "100.0 0.0 100.0Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java Vi...Java ", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull(" 4#4a4#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4#4a4#" + "'", str1.equals("4#4a4#"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "av");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ht...", "", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 0, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        byte[] byteArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                  ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("10410");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10410L + "'", long1.equals(10410L));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("# a #", "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP", (int) 'a', 11);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "# a #/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP" + "'", str4.equals("# a #/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("100.0 99.0 26.0", "0410040", 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0 99.0 26.00410040100.0 99.0 26.0" + "'", str3.equals("100.0 99.0 26.00410040100.0 99.0 26.0"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("4a4#4 ", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a# " + "'", str2.equals("a# "));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/u", (java.lang.CharSequence) "                                                                                                                                                                                           Java Vi...Java Vi...Java Vi...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("en                           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en" + "'", str1.equals("en"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaaaaaa100.0a0.0a100.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Mac OS ", "                              ");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "1004104104140", 191, 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "7ja7ja7ja7ja7ja7ja7ja7ja7ja");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Mac7ja7ja7ja7ja7ja7ja7ja7ja7jaOS" + "'", str9.equals("Mac7ja7ja7ja7ja7ja7ja7ja7ja7jaOS"));
    }
}

