import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os ", "", 7);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.71.71.71.71.71.71.71.71.71.71.7J/v/ Virtu/l M/chine Specific/tion1.71.71.71.71.71.71.71.71.71.71.7#####################################################################", "BRAMIXED MODE1.7.0_80", (int) (short) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 52, (float) 35, (float) 97L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil", 0, 98);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("JN", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/Library/Java/JavaVirtualMachines/jdk1.7.Oracle Corporation/Library/Java/JavaVirtualMachines/jdk");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.Oracle Corporation/Library/Java/JavaVirtualMachines/jdk" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.Oracle Corporation/Library/Java/JavaVirtualMachines/jdk"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("", "braMixed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Java Virtual Machine Specificationa10HI!10.0a1.7ax86_64aUTF-8aUS", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ava Virtual Machine Specificationa10HI!10.0a1.7ax86_64aUTF-8aUS" + "'", str2.equals("ava Virtual Machine Specificationa10HI!10.0a1.7ax86_64aUTF-8aUS"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(":aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        int[] intArray3 = new int[] { 10, 49, 3 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 49 + "'", int5 == 49);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("sers/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_156022887", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(10L, 64L, (long) 76);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.7JAVA VIRTUAL MACHINE SPECIFICATION1.71.71.71.71.71.71.71.71.71.71.7######################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmpaaaaaas/defects4j/tmp/run_randoop.pl_10501_");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmpaaaaaas/defects4j/tmp/run_randoop.pl_10501_" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmpaaaaaas/defects4j/tmp/run_randoop.pl_10501_"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Javaplatformapispecification", 92);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", "sun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironment", 80);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "braMixed mode", "                             a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "DESRODNE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Ry/J");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "JN");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("java Virtual Machine Specification", "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk...", 98);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("1.7.0_80-b15", strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "#############sers/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("", "oRACLEcORPORATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("J/Documents/defects4j/tmpaaaaaas/defects4j/tmp/run_randoop.pl_10501_ava/Documents/defects4j/tmpaaaaaas/defects4j/tmp/run_randoop.pl_10501_ /Documents/defects4j/tmpaaaaaas/defects4j/tmp/run_randoop.pl_10501_P/Documents/defects4j/tmpaaaaaas/defects4j/tmp/run_randoop.pl_10501_latform/Documents/defects4j/tmpaaaaaas/defects4j/tmp/run_randoop.pl_10501_ /Documents/defects4j/tmpaaaaaas/defects4j/tmp/run_randoop.pl_10501_API/Documents/defects4j/tmpaaaaaas/defects4j/tmp/run_randoop.pl_10501_ /Documents/defects4j/tmpaaaaaas/defects4j/tmp/run_randoop.pl_10501_S/Documents/defects4j/tmpaaaaaas/defects4j/tmp/run_randoop.pl_10501_pecification", (int) (short) 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        char[] charArray2 = new char[] { ' ' };
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("XOd M", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat(":aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java(TM) SE Runtime Environment", "Java Virtual Machine Specification");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str4.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", "orati");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Java Virtual Machine Specificationa/a/a/a/a/a/...", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specificationa/a/a/a/a/a/..." + "'", str2.equals("Java Virtual Machine Specificationa/a/a/a/a/a/..."));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("e Specification", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "Mac OS X");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("BRAMIXED MODE1.7.0_80", "sun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("e Specification", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        int[] intArray0 = new int[] {};
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1717171717171717171717J/I/RVVV//RRM/TVNRRSARTVjVT//VAN1717171717171717171717#####################################################################", "/Library/Java/JavaVirtualMachines/jdk1.7.0eU0.jdk..", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1717171717171717171717J/I/RVVV//RRM/TVNRRSARTVjVT//VAN1717171717171717171717#####################################################################" + "'", str3.equals("1717171717171717171717J/I/RVVV//RRM/TVNRRSARTVjVT//VAN1717171717171717171717#####################################################################"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("X SO c M");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XSOcM" + "'", str1.equals("XSOcM"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        int[] intArray6 = new int[] { (short) -1, (-1), 10, 170, (short) 100, 170 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 170 + "'", int7 == 170);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 170 + "'", int9 == 170);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 170 + "'", int10 == 170);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) ":aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("sun.awt.CGraphicsEnvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"s\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Brary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", "/librry/jv/jvvirtulmchines/jdk1.7.0_80.jdk...", (int) (byte) 10, 634);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Brary/Java/librry/jv/jvvirtulmchines/jdk1.7.0_80.jdk..." + "'", str4.equals("Brary/Java/librry/jv/jvvirtulmchines/jdk1.7.0_80.jdk..."));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("0hi!10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0hi!10.0" + "'", str1.equals("0hi!10.0"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Library/Java/JavaVirtualMachines/jdk1.7.0eU0.jdk..", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0eU0.jdk.." + "'", str3.equals("/Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0eU0.jdk.."));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("en");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"en\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("X SO c M", '4');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X SO c M" + "'", str3.equals("X SO c M"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "X SO c M" + "'", str4.equals("X SO c M"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 0, 58, 67);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Javaplatformapispecification", 7, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Javaplatformapispecification" + "'", str3.equals("Javaplatformapispecification"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(":aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("/Users/sopBrary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedurrent.jar", "1717171717171717171717J/I/RVVV//RRM/TVNRRSARTVjVT//VAN1717171717171717171717#####################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(":", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 80);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Java HotSpot(TM) 6#-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 6#-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 6#-Bit Server VM"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("\n", "A/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "ry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/J");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "O caM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/./a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/./a/a/a/a/a/a/a/a/a/a/a/a/a/ax SO caM", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("en", "10HI!10.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmen", "", "10HI!10.0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) (byte) 10, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 170, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                                                         " + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                                                         "));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mac os ", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0Eu0.JDK...");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', 52, 80);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "Javaplatformapispecification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javaplatformapispecification" + "'", str1.equals("javaplatformapispecification"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("ry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/J", "/Users/sopBra1.7.0_80/Users/sopBra");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sopBra1.7.0_80/Users/sopBra" + "'", str2.equals("/Users/sopBra1.7.0_80/Users/sopBra"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 1, (int) (byte) 10, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("./a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/", "1.71.71.71.71.71.71.71.71.71.71.7J/v/ Virtu/l M/chine Specific/tion1.71.71.71.71.71.71.71.71.71.71.7#####################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment", "UTF-8");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concatWith("/Users/sophie/Documents/defects4j/tmpaaaaaas/defects4j/tmp/run_randoop.pl_10501_", (java.lang.Object[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str4.equals("sun.awt.CGraphicsEnvironment"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str9.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "e Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 634, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) 100, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sophie", ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concatWith("", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sophie" + "'", str4.equals("sophie"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1.71.71.71.71.71.71.71.71.71.71.7Java Virtual Machine Specification1.71.71.71.71.71.71.71.71.71.71.7#####################################################################");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("orporation", 634, "e Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "orporatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specifi" + "'", str3.equals("orporatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specifi"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        java.lang.Object[] objArray1 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.concatWith("", objArray1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 0, (long) 98, 58L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 98L + "'", long3 == 98L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/Library/Java/JavaVirtualMachines/jdk1.7.Oracle Corporation/Library/Java/JavaVirtualMachines/jdk", 80);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tualMachines/jdk" + "'", str2.equals("tualMachines/jdk"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("./a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/", 92, "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun../a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/" + "'", str3.equals("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun../a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.oRACLE cORPORATION/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 1, 80, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 80 + "'", int3 == 80);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("       /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "       /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java       " + "'", str1.equals("       /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java       "));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 58, (long) 52, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/aaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/AAA" + "'", str1.equals("A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/AAA"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 100, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("10Hjn                                                                                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("10hi!10.0");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("", "10hi!10.0");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray5, strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("1.7", strArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray1, strArray8);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        long[] longArray5 = new long[] { (short) 100, (short) -1, 0L, 0, 64 };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Mixed mode                                          ", "Od M");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ixed mode" + "'", str2.equals("ixed mode"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 58, (double) (-1L), (double) 2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 58.0d + "'", double3 == 58.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "", 77);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 49 + "'", int3 == 49);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("       avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/       ", (int) (short) -1, 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray10 = new char[] { 'a', '4', '#', ' ' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "en", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10hi!10.0", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny("XOd M", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Brary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Brary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("Brary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("Java platform api specification", "Ortio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("hOTsPOT(tm) 64-bIT sERVER vm", 67, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("./a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "./A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/" + "'", str1.equals("./A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits(":aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mac os ", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0Eu0.JDK...");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment", "UTF-8");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "sophie");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...", strArray3, strArray9);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk..." + "'", str10.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk..."));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Mixed mode", "    JN");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment", "UTF-8");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_", strArray4, strArray6);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment", "UTF-8");
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray14);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_", strArray12, strArray14);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray12);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java platform api specification", strArray4, strArray12);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_" + "'", str8.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_"));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_" + "'", str16.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_"));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Java platform api specification" + "'", str18.equals("Java platform api specification"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/", 634);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) -1 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("                                  SUN.LWAWT.MACOSX.CPRINTERJOB                                   ", ".desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarb");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("oRACLEcORPORATION");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("./a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("DESRODNE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876", (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1.71.71.71.71.71.71.71.71.71.71.7JAVA VIRTUAL MACHINE SPECIFICATION1.71.71.71.71.71.71.71.71.71.71.7######################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71.7JAVA VIRTUAL MACHINE SPECIFICATION1.71.71.71.71.71.71.71.71.71.71.7######################################################################" + "'", str1.equals("1.71.71.71.71.71.71.71.71.71.71.7JAVA VIRTUAL MACHINE SPECIFICATION1.71.71.71.71.71.71.71.71.71.71.7######################################################################"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/          ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("java Virtual Machine Specification", "Ry/J");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbi", "Mac OS X", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihaaalautriVavaJ/avaJ/yrarbi" + "'", str3.equals("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihaaalautriVavaJ/avaJ/yrarbi"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("Java Virtual Machine Specification", "./a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) (byte) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("OracleCorporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLECORPORATION" + "'", str1.equals("ORACLECORPORATION"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("JAVA(TM) SE RUNTIME ENVIRONMENT", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                                                         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("                                   ", 77, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("       /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java       ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java Virtual Machine Specification" + "'", str1.equals("java Virtual Machine Specification"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sers/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_156022887", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sers/sophie/Documents/defects4j/tmp/run_rndoop.pl_10501_156022887" + "'", str2.equals("sers/sophie/Documents/defects4j/tmp/run_rndoop.pl_10501_156022887"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mixed mod" + "'", str1.equals("Mixed mod"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("sun.lwawt.macosx.CPrinterJob", (int) '#', 92);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "Sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("24.80-b11s");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("java platform api specification");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 64, (double) (byte) 100, 1.7000000476837158d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore(".7", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".7" + "'", str2.equals(".7"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.7Java Virtual Machine pecification1.71.71.71.71.71.71.71.71.71.71.7######################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("          ", "                             a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL", "##########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL" + "'", str2.equals("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("noitaropro", "Java Virtual Machine Specificationa/a/a/a/a/a/...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitaropro" + "'", str2.equals("noitaropro"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironment", "HotSpot(TM) 64-Bit Server VM", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("/Users/sopBra1.7.0_80/Users/sopBra", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                                                         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("RY/J", "sun.lwawt.macosx.cprinterjob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("DESRODNE/BIL/ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("1.7###", "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarb");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 98, (float) 76, 1.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("hOTsPOT(tm) 64-bIT sERVER vm                                  SUN.LWAWT.MACOSX.CPRINTERJOB                                                                     SUN.LWAWT.M", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hOTsPOT(tm) 64-bIT sERVER vm                                  SUN.LWAWT.MACOSX.CPRINTERJOB                                                                     SUN.LWAWT.M" + "'", str2.equals("hOTsPOT(tm) 64-bIT sERVER vm                                  SUN.LWAWT.MACOSX.CPRINTERJOB                                                                     SUN.LWAWT.M"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Java(TM) SE Runtime Environment", "/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/.", "Oracle Corporationdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", 634);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str4.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 10, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/.", 77);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      /a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/.                       " + "'", str2.equals("                      /a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/.                       "));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sopBrary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedurrent.jar", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sopBrary/Java/JavaVirtualMac" + "'", str2.equals("/Users/sopBrary/Java/JavaVirtualMac"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("moRACLEcORPORATION", "1717171717171717171717J/I/RVVV//RRM/TVNRRSARTVjVT//VAN1717171717171717171717#####################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("###################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###################################################################" + "'", str1.equals("###################################################################"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) -1, (float) (byte) -1, (float) 7L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("OracleCorporationOracleCorporationOracleCorpo10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleCorporationOracleCorporationOracleCorpo10.14." + "'", str1.equals("OracleCorporationOracleCorporationOracleCorpo10.14."));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                                  SUN.LWAWT.MACOSX.CPRINTERJOB                                   ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("...kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "1.71.71.71.71.71.71.71.71.71.71.7Java Virtual Machine Specification1.71.71.71.71.71.71.71.71.71.71.7#####################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str2.equals("...kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "ry/J");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/ationachine Specifical Ma VirtuavaJ", "mixedmode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("", "10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("A/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a", "1.71.71.71.71.71.71.71.71.71.71.7Java Virtual Machine pecification1.71.71.71.71.71.71.71.71.71.71.7######################################################################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun../a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/", "          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_", (long) 28);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28L + "'", long2 == 28L);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("x SO caM", "java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("sun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("A/a/...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a/A/..." + "'", str1.equals("a/A/..."));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("RY/J", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0eU0.jdk..", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("X SO c M", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("ORACLECORPORATION");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/./a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/./a/a/a/a/a/a/a/a/a/a/a/a/a/ax SO caM", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.oRACLE cORPORATION/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "SOPHIE", "10Hj");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("", 3, 76);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("10Hjn                                                                                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                  njH01" + "'", str1.equals("                                                                                                  njH01"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                   ", "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL", (int) (byte) 1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', 34, 98);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 34");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("mixedmode", "..._ran...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "X SO caM  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-" + "'", str1.equals("UTF-"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("hOTsPOT(tm) 64-bIT sERVER vm                                  SUN.LWAWT.MACOSX.CPRINTERJOB                                                                     SUN.LWAWT.M", "/lIBRARY/jAVA/jAVAvIRTUALmhttp://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hOTsPOT(tm) 64-bIT sERVER vm                                  SUN.LWAWT.MACOSX.CPRINTERJOB                                                                     SUN.LWAWT.M" + "'", str2.equals("hOTsPOT(tm) 64-bIT sERVER vm                                  SUN.LWAWT.MACOSX.CPRINTERJOB                                                                     SUN.LWAWT.M"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("       avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/       ", "1.7###", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                     X SO caM                       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast(":", "sers/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("java virtual machine specificationa10hi!10.0a1.7ax86_64autf-8aus", "sers/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java virtual machine specificationa10hi!10.0a1.7ax86_64autf-8aus" + "'", str2.equals("java virtual machine specificationa10hi!10.0a1.7ax86_64autf-8aus"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmen", "1.71.71.71.71.71.71.71.71.71.71.7Java Virtual Machine Specification1.71.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("US", "#############sers/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sopBrary/Java/JavaVirtualMac", "DESRODNE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("XSOcM", "n", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "XSOcM" + "'", str3.equals("XSOcM"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3" + "'", str1.equals("10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Java platform api specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mac os ", "BRAMIXED MODE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("java Virtual Machine Specification", (int) '#', "/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java Virtual Machine Specification/" + "'", str3.equals("java Virtual Machine Specification/"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("braMixed mode", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "raMixed mode" + "'", str2.equals("raMixed mode"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("java Virtual Machine Specification", "Mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/ationachine Specifical Ma VirtuavaJ", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "10hi!10.0");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876", '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("ion", strArray3, strArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '#', 77, 64);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ion" + "'", str7.equals("ion"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                     X SO caM                       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("10HI!10.044444444444444444444444444444444444444444444444444444444444444444444", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10HI!10.044444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("10HI!10.044444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "24.80-b11s");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarb");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Java Virtual Machine Specificationa/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/aJava Virtual Machine Specificationa/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/aJava Virtual Machine Specification", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtu" + "'", str2.equals("Java Virtu"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) ":aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmhttp://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                                                                                  njH01", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                        njH01" + "'", str2.equals("                                                                                        njH01"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment", "UTF-8");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "sophie");
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("", strArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                     ", strArray6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("sers/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_156022887");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sers/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_156022887\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("java virtual machine specificationa10hi!10.0a1.7ax86_64autf-8aus", 98, "DESRODNE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl                     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java virtual machine specificationa10hi!10.0a1.7ax86_64autf-8ausDESRODNE/BIL/ERJ/EMOh/STNETNOc/KDJ" + "'", str3.equals("java virtual machine specificationa10hi!10.0a1.7ax86_64autf-8ausDESRODNE/BIL/ERJ/EMOh/STNETNOc/KDJ"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("10Hjn                                                                                                  ", "24.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("       DESRODNE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("10hi!10.0");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("", "10hi!10.0");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray5, strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("a/A/...", strArray2, strArray8);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "a/A/..." + "'", str10.equals("a/A/..."));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "", "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL                     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        char[] charArray4 = new char[] { '4', ' ' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny("                             a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/...", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("10HI!10.", "JAVA VIRTUAL MACHINE SPECIFICATIONA10HI!10.0A1.7AX86_64AUTF-8AUS");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "                                                    ", 77, (int) ' ');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("ORACLECORPORATION", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("DESRODNE/BIL/ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("mac os x", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mac os x" + "'", str2.equals("mac os x"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 2, 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("1.71.71.71.71.71.71.71.71.71.71.##########################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71.##########################################################################################################################################" + "'", str1.equals("1.71.71.71.71.71.71.71.71.71.71.##########################################################################################################################################"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("       avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/       ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("orporatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specifi", "ixed mode", 80);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/AAA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/AAA" + "'", str1.equals("A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/AAA"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("ORACLECORPORATION", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", "mac os ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("icsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmen", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("icsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmen");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"icsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmen\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("71.71.71.71.71.71.71.71.71.71.7#####################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "71.71.71.71.71.71.71.71.71.71.7#####################################################################" + "'", str1.equals("71.71.71.71.71.71.71.71.71.71.7#####################################################################"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("", "sers/sophie/Documents/defects4j/tmp/run_rndoop.pl_10501_156022887", 58);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("sers/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876", "java virtual machine specificationa10hi!10.0a1.7ax86_64autf-8aus");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "10X SO c MhiX SO c M!X SO c M10X SO c M.X SO c M0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/sophie", '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/sophie" + "'", str3.equals("/sophie"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("\n", "10HI!10.0##########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("e Specification", 100, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.7Java Virtual Machine Specification1.71.71.71.71.71.71.71.71.71.71.7######################################################################", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Speci...", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0Eu0.JDK...", "X SO caM  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Speci..." + "'", str3.equals("10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Speci..."));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("                                                    ", "Mixed mod");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", 0, "Mixed mode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str3.equals("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("ORACLECORPORATION", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("hi!", "OracleCorporationOracleCorporationOracleCorpo10.14.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OracleCorporationOracleCorporationOracleCorpo10.14." + "'", str2.equals("OracleCorporationOracleCorporationOracleCorpo10.14."));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("10HI!10.", "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10HI!10." + "'", str3.equals("10HI!10."));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("./a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "./a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/" + "'", str1.equals("./a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "", 54);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("ry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/Jry/J", 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("XSOcM", "A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/AAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "XSOcM" + "'", str2.equals("XSOcM"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.awt.CGraphicsEnvironment", "x SO caM");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("10hi!10.0");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("", "10hi!10.0");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray7, strArray10);
        int int12 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("1.7", strArray10);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk...", strArray3, strArray13);
        java.lang.Class<?> wildcardClass15 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk..." + "'", str14.equals("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk..."));
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("DESRODNE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl                     ", (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("braMixed mode", (int) 'a', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                      /a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/.                       ", "", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarb", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/./a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/./a/a/a/a/a/a/a/a/a/a/a/a/a/ax SO caM", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("O caM", (double) 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                             " + "'", str1.equals("                             "));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 1L);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 98, (long) 2, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(170.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("       /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java       ", 0, 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Java Virtual Machine Specificationa/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATIONA/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/" + "'", str1.equals("JAVA VIRTUAL MACHINE SPECIFICATIONA/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("Java Virtual Machine Specification", 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ".desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarb", "10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Specification10.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("x86_64", "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("10.14.3", "N");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                             uTF-8                              ", (int) (byte) 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                             uTF-8                              " + "'", str3.equals("                             uTF-8                              "));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1.7");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironment", "", "XSOcM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironment" + "'", str3.equals("sun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironment"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) '4', 0.0f, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("X SO caM", "oratio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/", "", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) 0, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Java Virtu", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtu" + "'", str2.equals("Java Virtu"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray10 = new char[] { 'a', '4', '#', ' ' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10hi!10.0", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "#############sers/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ixed mode", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        float[] floatArray1 = new float[] { 0 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("phicsEnvironmentawt.CGraphicsEnvironmentsun.awt.CGraphRY/J");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Users/sopBrary/Java/JavaVirtualMac");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("#############sers/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876", "                                                                                                  njH01");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#############sers/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876" + "'", str2.equals("#############sers/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("n", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n" + "'", str2.equals("n"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("icsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmen", "ixed mode", "ortio");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "icsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmen" + "'", str3.equals("icsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmen"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/", "10.14.3java Virtual Machine Specification10.14.3java Virtual Machine Speci...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.7Java Virtual Machine Specification1.71.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sun.awt.CGraphicsEnvironment", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Max SO c");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("                     X SO caM                       ", "Oracle Corporationdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("orati", "ava Virtual Machine Specificationa10HI!10.0a1.7ax86_64aUTF-8aUS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "orati" + "'", str2.equals("orati"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("X SO c M", (int) (short) -1, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", "/Users/sophie");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize(charSequence0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("Ortio", 15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0Eu0.JDK...", "OracleCorporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.awt.CGraphicsEnvironment", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Od M", "Java platform api specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Od M" + "'", str2.equals("Od M"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("sun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironment", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("                             uTF-8                              ", "BRAMIXED MODE", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.71.71.71.71.71.71.71.71.71.71.7Java Virtual Machine Specification1.71.71.71.71.71.71.71.71.71.71.7#####################################################################", "x SO caM", 10);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71.7JvVirtulhinepeifition1.71.71.71.71.71.71.71.71.71.71.7#####################################################################" + "'", str4.equals("1.71.71.71.71.71.71.71.71.71.71.7JvVirtulhinepeifition1.71.71.71.71.71.71.71.71.71.71.7#####################################################################"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("X SO caM  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"X SO caM  \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("jn                                                                                                  ", 49, "rbiL/aJ/yravaJ/avautriVaMlationdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcacle CorporaOr");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jn                                                                                                  " + "'", str3.equals("jn                                                                                                  "));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "", 92);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("RY/J", "a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(1L, (long) (byte) 100, (long) 92);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihaaalautriVavaJ/avaJ/yrarbi", "mixedmode", 58);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        char[] charArray6 = new char[] { 'a', '4', 'a', '#', '#' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/aaa", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "1.71.71.71.71.71.71.71.71.71.71.7J/I/RVVV/u/RRM/ThVNRRSARTVjVT//VAN1.71.71.71.71.71.71.71.71.71.71.7#####################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("_10501_lp.poodnar_nur/pmt/j4stcefed/saaaaaapmt/j4stcefed/stnemucoD/", 54);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "_10501_lp.poodnar_nur/pmt/j4stcefed/saaaaaapmt/j4stcefed/stnemucoD/" + "'", str2.equals("_10501_lp.poodnar_nur/pmt/j4stcefed/saaaaaapmt/j4stcefed/stnemucoD/"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("jn", "avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("uTF-8", "1.71.71.71.71.71.71.71.71.71.71.7JvVirtulhinepeifition1.71.71.71.71.71.71.71.71.71.71.7#####################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "uTF-8" + "'", str2.equals("uTF-8"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.7J/v/ Virtu/l M/chine Specific/tion1.71.71.71.71.71.71.71.71.71.71.7#####################################################################", (java.lang.CharSequence) "sun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                                                                                                  X SO c M");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("java platform api specification", 92);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, '#', 3, 28);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("./a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("1.7###", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "bUS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.71.71.71.71.71.71.71.71.71.71.7Java Virtual Machine Specification1.71.71.71.71.71.71.71.71.71.71.7#####################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("#############sers/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("10HI!10.", 80);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("                             a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/...", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("./A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b15" + "'", str1.equals("1.7.0_80-b15"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java Virtual Machine Specification", '#');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "1.71.71.71.71.71.71.71.71.71.71.##########################################################################################################################################");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                                                         ", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Java Virtual Machine Specification" + "'", str5.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Users/sophie/Documents/defects4j/tmpaaaaaas/defects4j/tmp/run_randoop.pl_10501_", "/Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0eU0.jdk..", "10HI!10.044444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("e Specification", "A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/AAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "e Specification" + "'", str2.equals("e Specification"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Documents/defects4j/tmpaaaaaas/defects4j/tmp/run_randoop.pl_10501_");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("10HI!10.044444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10HI!10.044444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("10HI!10.044444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.awt.CGraphicsEnvironment", "x SO caM");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("10hi!10.0");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.split("", "10hi!10.0");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray8, strArray11);
        int int13 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("1.7", strArray11);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray11);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk...", strArray4, strArray14);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray14, "uTF-8", (int) ' ', (int) (byte) 0);
        int int20 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("JAVA VIRTUAL MACHINE SPECIFICATIONA/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/", strArray14);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk..." + "'", str15.equals("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk..."));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("71.71.71.71.71.71.71.71.71.71.7#####################################################################", 98);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "71.71.71.71.71.71.71.71.71.71.7#####################################################################" + "'", str2.equals("71.71.71.71.71.71.71.71.71.71.7#####################################################################"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Javaplatformapispecification", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Javaplatformapispecification" + "'", str2.equals("Javaplatformapispecification"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("DESRODNE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl", 98, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaDESRODNE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIlaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaDESRODNE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIlaaaaaaaaaa"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1717171717171717171717J/I/RVVV//RRM/TVNRRSARTVjVT//VAN1717171717171717171717#####################################################################", 567);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1717171717171717171717J/I/RVVV//RRM/TVNRRSARTVjVT//VAN1717171717171717171717#####################################################################" + "'", str2.equals("1717171717171717171717J/I/RVVV//RRM/TVNRRSARTVjVT//VAN1717171717171717171717#####################################################################"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java       ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                     X SO caM                       ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                     X SO caM                       \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast(":aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "sers/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals(":aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MIXED MODE" + "'", str1.equals("MIXED MODE"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 10.0f, (double) 6, (double) 97.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("N", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876", "Mixed mode", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Library/Java/JavaVirtualMachines/jdk1.7.0eU0.jdk..", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0eU0.jdk.." + "'", str2.equals("0eU0.jdk.."));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "MIXEDMODE", (java.lang.CharSequence) "a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Mixed mode                                       ...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str2.equals("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED", "Java Virtual Machine Specificationa/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/aJava Virtual Machine Specificationa/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/aJava Virtual Machine Specification");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "    JN");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "    JN    JNIBRARY    JNjA    JNA    JNjA    JNA    JNIRTUALmACHINE    JN    JN    JNDK1.7.0_80.    JNDK    JN    JNONTENT    JN    JN    JNO    JNE    JN    JNRE    JNLIB    JNENDOR    JNED" + "'", str5.equals("    JN    JNIBRARY    JNjA    JNA    JNjA    JNA    JNIRTUALmACHINE    JN    JN    JNDK1.7.0_80.    JNDK    JN    JNONTENT    JN    JN    JNO    JNE    JN    JNRE    JNLIB    JNENDOR    JNED"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                      /a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/.                       ", (int) (short) 1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                      /a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/.                       " + "'", str3.equals("                      /a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/.                       "));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sopBrary/Java/JavaVirtualMac");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sopBrary/Java/JavaVirtualMac" + "'", str1.equals("/Users/sopBrary/Java/JavaVirtualMac"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("X SO caM  ", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X SO caM  " + "'", str2.equals("X SO caM  "));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("xSOcaM", "sers/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_156022887", 67);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("#############sers/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876", "/Users/sopBrary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedurrent.jar");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "./A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "#############sers/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876" + "'", str4.equals("#############sers/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Java Platform API Specification", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification                                                                     " + "'", str2.equals("Java Platform API Specification                                                                     "));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("hOTsPOT(tm) 64-bIT sERVER vm                                  SUN.LWAWT.MACOSX.CPRINTERJOB                                                                     SUN.LWAWT.M");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("       /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java       ", "hOTsPOT(tm) 64-bIT sERVER vm", 28);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("java Virtual Machine Specification", "51.0", (int) (byte) 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("HotSpot(TM) 64-Bit Server VM", strArray7, strArray11);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("Java(TM) SE Runtime Environment", strArray2, strArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 31 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "HotSpot(TM) 64-Bit Server VM" + "'", str12.equals("HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 69, 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/", 80);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/                                                                               " + "'", str2.equals("/                                                                               "));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("/Users/sopBra1.7.0_80/Users/sopBra", "Brary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("10hi!10.0");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("", "10hi!10.0");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.concatWith("mac os x", (java.lang.Object[]) strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.startsWithAny("X SO c M", strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("...kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", 64, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaa...kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str3.equals("aaaaaaaaaaaa...kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("mac os ", "JN", 80);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("1.7###", "/Users/sopBra1.7.0_80/Users/sopBra");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("sun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironmentsun.4wt.CGr4phicsEnvironment");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("X SO caM  ", "java virtual machine specificationa10hi!10.0a1.7ax86_64autf-8ausDESRODNE/BIL/ERJ/EMOh/STNETNOc/KDJ", "raMixed mode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X SO caM  " + "'", str3.equals("X SO caM  "));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Brary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Brary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("Brary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("rbiL/aJ/yravaJ/avautriVaMlationdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcacle CorporaOr", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rbiL/aJ/yravaJ/avautriVaMlationdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcacle CorporaOr" + "'", str2.equals("rbiL/aJ/yravaJ/avautriVaMlationdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcacle CorporaOr"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("    JN    JNIBRARY    JNjA    JNA    JNjA    JNA    JNIRTUALmACHINE    JN    JN    JNDK1.7.0_80.    JNDK    JN    JNONTENT    JN    JN    JNO    JNE    JN    JNRE    JNLIB    JNENDOR    JNED");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:     JN    JNIBRARY    JNjA    JNA    JNjA    JNA    JNIRTUALmACHINE    JN    JN    JNDK1.7.0_80.    JNDK    JN    JNONTENT    JN    JN    JNO    JNE    JN    JNRE    JNLIB    JNENDOR    JNED is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("DESRODNE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("                                                                                                                                                                  X SO c M", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(100.0f, 80.0f, (float) '#');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("hi!", "US", (-1));
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("OracleCorporation");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie", strArray5, strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.concatWith("", (java.lang.Object[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "/Users/sophie" + "'", str9.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11", "                                   ", 15);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("sun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJobsun.lwwt.mcosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(3L, 58L, 80L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3L + "'", long3 == 3L);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0Eu0.JDK...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 634, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          " + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          "));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(":aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("...kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "/Libr#ry/J#v#/J#v#Virtu#lM#chines/jdk1.7.0eU0.jdk..");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str2.equals("...kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", "sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.lwawt.macosx.CPrinterJo" + "'", str1.equals("Sun.lwawt.macosx.CPrinterJo"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Java HotSpot(TM) 6#-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                  SUN.LWAWT.MACOSX.CPRINTERJOB                                   ", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0Eu0.JDK...", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("0eU0.jdk..", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0eU0.jdk.." + "'", str2.equals("0eU0.jdk.."));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                        njH01", (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Corporation");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle#Corporation" + "'", str3.equals("Oracle#Corporation"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.71.71.71.71.71.71.71.71.71.71.7J/I/RVVV/u/RRM/ThVNRRSARTVjVT//VAN1.71.71.71.71.71.71.71.71.71.71.7#####################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71.7J/I/RVVV/u/RRM/ThVNRRSARTVjVT//VAN1.71.71.71.71.71.71.71.71.71.71.7#####################################################################" + "'", str1.equals("1.71.71.71.71.71.71.71.71.71.71.7J/I/RVVV/u/RRM/ThVNRRSARTVjVT//VAN1.71.71.71.71.71.71.71.71.71.71.7#####################################################################"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("phicsEnvironmentawt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGrasun.", "1.71.71.71.71.71.71.71.71.71.71.7JAVAVIRTUALMACHINESPECIFICATION1.71.71.71.71.71.71.71.71.71.71.7######################################################################", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sopBra1.7.0_80/Users/sopBra", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sopBra1.7.0_80/Users/sopBra" + "'", str2.equals("/Users/sopBra1.7.0_80/Users/sopBra"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.71.71.71.71.71.71.71.71.71.71.7Java Virtual Machine Specification1.71.71.71.71.71.71.71.71.71.71.7", ":aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Ry/J");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbi");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("mixedmode", "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihaaalautriVavaJ/avaJ/yrarbi", "51.0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Library/Java/JavaVirtualMachines/jdk1.7.Oracle Corporation/Library/Java/JavaVirtualMachines/jdk1.7", 4, 49);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/.", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("...kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", 0, "O caM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str3.equals("...kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                                                                        njH01", "mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "njH01" + "'", str2.equals("njH01"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ", "JAVA VIRTUAL MACHINE SPECIFICATIONA/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 3, 97L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("1.7.0_80", "24.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        int[] intArray3 = new int[] { (short) 0, 567, '4' };
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", ":aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "###################################################################");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "Sun.lwawt.macosx.CPrinterJo", (int) (byte) 1, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("1.7.0_80-b15", 58, 76);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk...", 3.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/A/AAA");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/Library/Java/JavaVirtualMachines/jdk1.7.0eU0.jdk...", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "chines/jdk1.7.0eU0.jdk...alMaVirtuava/Javary/Ja/Libr" + "'", str2.equals("chines/jdk1.7.0eU0.jdk...alMaVirtuava/Javary/Ja/Libr"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("/librry/jv/jvvirtulmchines/jdk1.7.0_80.jdk...", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.7.0_80");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Brary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("JAVA(TM) SE RUNTIME ENVIRONMENT", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/lIBRARY/jAVA/jAVAvIRTUALmhttp://java.oracle.com/", "desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil", 58);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("Oracle Corporation", "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun../a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/", 54);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Users/sopBra1.7.0_80/Users/sopBra");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPbRA1.7.0_80/uSERS/SOPbRA" + "'", str1.equals("/uSERS/SOPbRA1.7.0_80/uSERS/SOPbRA"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("       /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java       ", (int) (byte) -1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "       /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java       " + "'", str3.equals("       /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java       "));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironment", "sun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironment", 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironment" + "'", str3.equals("sun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironmentsun.wt.CGrphicsEnvironment"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.71.71.71.71.71.71.71.71.71.71.7JvVirtulhinepeifition1.71.71.71.71.71.71.71.71.71.71.7#####################################################################", "mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os ", "", 34);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71.7JvVirtulhinepeifition1.71.71.71.71.71.71.71.71.71.71.7#####################################################################" + "'", str4.equals("1.71.71.71.71.71.71.71.71.71.71.7JvVirtulhinepeifition1.71.71.71.71.71.71.71.71.71.71.7#####################################################################"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os" + "'", str1.equals("mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str1.equals("kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Documents/defects4j/tmpaaaaaas/defects4j/tmp/run_randoop.pl_10501_", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Documents/defects4j/tmpaaaaaas/defects4j/tmp/run_randoop.pl_10501_" + "'", str2.equals("/Documents/defects4j/tmpaaaaaas/defects4j/tmp/run_randoop.pl_10501_"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/Users/sopBrary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedurrent.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("DESRODNE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl                     ", 92, 54);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...\n/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...", (java.lang.CharSequence) "Mixed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1795 + "'", int2 == 1795);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mac os x", '4');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.Oracle Corporation/Library/Java/JavaVirtualMachines/jdk", "", (int) (byte) 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("JAVA(TM) SE RUNTIME ENVIRONMENT", strArray3, strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "JAVA(TM) SE RUNTIME ENVIRONMENT" + "'", str8.equals("JAVA(TM) SE RUNTIME ENVIRONMENT"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "       DESRODNE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("10.14.3");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("ixed mode", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ixed modeixed modeixed modeixed modeixed modeixed modeixed modeixed modeixed modeixed modeixed modeixed modeixed modeixed modeixed mode" + "'", str2.equals("ixed modeixed modeixed modeixed modeixed modeixed modeixed modeixed modeixed modeixed modeixed modeixed modeixed modeixed modeixed mode"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.awt.CGraphicsEnvironment", "x SO caM");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("10hi!10.0");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.split("", "10hi!10.0");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray8, strArray11);
        int int13 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("1.7", strArray11);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray11);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk...", strArray4, strArray14);
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mac os x", '4');
        java.lang.String[] strArray23 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.Oracle Corporation/Library/Java/JavaVirtualMachines/jdk", "", (int) (byte) 1);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.replaceEach("JAVA(TM) SE RUNTIME ENVIRONMENT", strArray19, strArray23);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray19);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.replaceEach("BRAMIXED MODE1.7.0_80", strArray4, strArray19);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk..." + "'", str15.equals("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk..."));
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "JAVA(TM) SE RUNTIME ENVIRONMENT" + "'", str24.equals("JAVA(TM) SE RUNTIME ENVIRONMENT"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "mac os x" + "'", str25.equals("mac os x"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "BRAMIXED MODE1.7.0_80" + "'", str26.equals("BRAMIXED MODE1.7.0_80"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("SUN.LWAWT.MACOSX.CPRINTERJOB", "Od M", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("       DESRODNE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("    jn", "          desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("Java Virtual Machine Specificationa10HI!10.0a1.7ax86_64aUTF-8aUS", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("UTF-");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Javaplatformapispecification", "", 34);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', 15, (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        char[] charArray1 = new char[] {};
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                   ", charArray1);
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("1.71.71.71.71.71.71.71.71.71.71.7Java Virtual Machine Specification1.71.71.71.71.71.71.71.71.71.71.7#####################################################################", strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "10HI!10.0");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("icsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmen", 92);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "icsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvir" + "'", str2.equals("icsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvir"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("njH01", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          njH01" + "'", str2.equals("          njH01"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "..._ran...", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("/                                                                               ", "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("nEsrrnnE/bcl/Erj/EirH/stnEtnrC/knj.08_0.7.1knj/sEnchcailautrcVavaJ/avaJ/yrarb", (double) 92);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 92.0d + "'", double2 == 92.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "10hi!10.0");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876", '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("ion", strArray3, strArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "orporation", (int) 'a', 58);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ion" + "'", str7.equals("ion"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        char[] charArray8 = new char[] { 'a', '4', '#', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10hi!10.0", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "java(TM) SE Runtime Environment", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.oRAC1.7###/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.oRACL", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 48 + "'", int12 == 48);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment", "UTF-8");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_", strArray4, strArray6);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.71.71.71.71.71.71.71.71.71.71.7J/I/RVVV/u/RRM/ThVNRRSARTVjVT//VAN1.71.71.71.71.71.71.71.71.71.71.7#####################################################################", "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray12);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray12);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", strArray9, strArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 25");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_" + "'", str8.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk.../Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(strArray14);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("sers/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876", "java(TM) SE Runtime Environment", 77);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (long) 48);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 48L + "'", long2 == 48L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("DESRODNE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl                     ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie" + "'", str2.equals("/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie/Users/sophie"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "ava Virtual Machine Specificationa10HI!10.0a1.7ax86_64aUTF-8aUS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 170.0f, (double) 3, (double) '4');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 170.0d + "'", double3 == 170.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("       avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "       avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/       " + "'", str1.equals("       avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/       "));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("oRACLEcORPORATION", "Mixed mode                                          ", "ixed mode");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                             a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/...", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("Java Virtual Machine Specificationa10HI!10.0a1.7ax86_64aUTF-8aUS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("orporatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specifi", "orporatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specificatione Specifi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("hOTsPOT(tm) 64-bIT sERVER vm", "sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "/Library/Java/JavaVirtualMachines/jdk1.7.Oracle Corporation/Library/Java/JavaVirtualMachines/jdk1.7");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("java virtual machine specificationa10hi!10.0a1.7ax86_64autf-8ausDESRODNE/BIL/ERJ/EMOh/STNETNOc/KDJ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"java virtual machine specificationa10hi!10.0a1.7ax86_64autf-8ausDESRODNE/BIL/ERJ/EMOh/STNETNOc/KDJ\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 100, (long) 64, (long) 170);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 64L + "'", long3 == 64L);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a" + "'", str1.equals("/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a/a"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/Users/sophie/Documents/defects4j/tmpaaaaaas/defects4j/tmp/run_randoop.pl_10501_", "                             uTF-8                              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("SOPHIE", 567, 567);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString(".7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".7" + "'", str1.equals(".7"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("", "1.71.71.71.71.71.71.71.71.71.71.7J/I/RVVV/u/RRM/ThVNRRSARTVjVT//VAN1.71.71.71.71.71.71.71.71.71.71.7#####################################################################", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("hi!");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concatWith("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0", (java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0!" + "'", str3.equals("hi51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0!"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10HI!10.0", "");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("HotSpot(TM) 64-Bit Server VM", strArray4);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("1.7.0_80-b15", strArray10);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "#############sers/sophie/Documents/defects4j/tmp/run_randoop.pl_10501_1560228876");
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray10);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.concatWith("Javaplatformapispecification", (java.lang.Object[]) strArray10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os", strArray4, strArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os" + "'", str16.equals("mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os                                    mac os"));
    }
}

