import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("oolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: oolkit is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("##########################################################################################/Library/J");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "32.0#-1.0#", (java.lang.CharSequence) "por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "32.0#-1.0#" + "'", charSequence2.equals("32.0#-1.0#"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Es:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 76);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/randoop-current.jar" + "'", str2.equals("n/randoop-current.jar"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        char[] charArray9 = new char[] {};
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100a0a1a100", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100a0a1a100", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "        ", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1004100", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "32.0 -1.0 -1.0 100.0 100.0", charArray9);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "s/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray9);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                                 aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray9);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "       ", charArray9);
        try {
            java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(charArray9, '4', 22, 59);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 22");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU", 27, "10a1a1a100a100a10");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU" + "'", str3.equals("SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100a0a1a100", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100a0a1a100", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "        ", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1004100", charArray6);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "32.0 -1.0 -1.0 100.0 100.0", charArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray6, ' ', 90, (int) (byte) 10);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ry/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javasrresr6esro2esro2esporation444444444444444444444444", "##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("#                                                                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#                                                                                                " + "'", str1.equals("#                                                                                                "));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("32.0#-1.0#", "", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                            ", 359, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                            " + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                            "));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1", 18, "##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "########1#########" + "'", str3.equals("########1#########"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/" + "'", str1.equals(".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                                       /4                                                 ", (int) (byte) 1, 115);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                      /4                                                 " + "'", str3.equals("                                      /4                                                 "));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "MIXED MODE", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("100#0#1#100", "100#100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#0#1#100" + "'", str2.equals("100#0#1#100"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#class [Ljava.lang.String;eclass", "poration444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 28, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace(" 080   ...     ...   080   ...     ...   080   ...     ...   080", "", "M) SE Runtime En", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + " 080   ...     ...   080   ...     ...   080   ...     ...   080" + "'", str4.equals(" 080   ...     ...   080   ...     ...   080   ...     ...   080"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaa", "x86_6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Es:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/generation/randoop-current.jar" + "'", str2.equals("n/generation/randoop-current.jar"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Java Platform API Specification", "X86_6", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("24.80-b11", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        int[] intArray1 = new int[] { (short) -1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, '4', (int) (short) 100, (int) '4');
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.Class<?> wildcardClass10 = intArray1.getClass();
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', (int) (byte) 1, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 32, 0L, (long) 990);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 990L + "'", long3 == 990L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "100o100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "32.0#-1.0#", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ry/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javasrresr6esro2esro2esporation444444444444444444444444", (java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51411_1560278524");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("oracle Corporation", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ry/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("cle.com/a.oravahttp://j");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 0, (byte) 1, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100a0a1a100" + "'", str6.equals("100a0a1a100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#0#1#100" + "'", str8.equals("100#0#1#100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100#0#1#100" + "'", str11.equals("100#0#1#100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10040414100" + "'", str13.equals("10040414100"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100a0a1a100" + "'", str15.equals("100a0a1a100"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "                  vv");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1#100#0#100#1#0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        double[] doubleArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        short[] shortArray6 = new short[] { (byte) 1, (short) -1, (byte) -1, (short) 10, (short) -1, (byte) 10 };
        short[] shortArray13 = new short[] { (byte) 1, (short) -1, (byte) -1, (short) 10, (short) -1, (byte) 10 };
        short[] shortArray20 = new short[] { (byte) 1, (short) -1, (byte) -1, (short) 10, (short) -1, (byte) 10 };
        short[][] shortArray21 = new short[][] { shortArray6, shortArray13, shortArray20 };
        short[][][] shortArray22 = new short[][][] { shortArray21 };
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(shortArray22);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertNotNull(shortArray13);
        org.junit.Assert.assertNotNull(shortArray20);
        org.junit.Assert.assertNotNull(shortArray21);
        org.junit.Assert.assertNotNull(shortArray22);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(27, 1004100, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 27 + "'", int3 == 27);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/Users/sop100a0a1a100/Users/soph                                       sun.lwawt.macosx.LWCToolki                                                    1.6                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(135, (int) (short) 1, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 135 + "'", int3 == 135);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "class [Ljava.lang.String;#class [Ljava.lang.String;");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 0, (byte) 1, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4', (int) (short) 1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100a0a1a100" + "'", str6.equals("100a0a1a100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#0#1#100" + "'", str8.equals("100#0#1#100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        int[] intArray3 = new int[] { ' ', 'a', (byte) 1 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("p                  ..                  ..           ", "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.05100a0a1a10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "p                  ..                  ..           " + "'", str2.equals("p                  ..                  ..           "));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 990L, (double) 97L, (double) 2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 10, (int) '#', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Java Platform API Specification", (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "m) se rUNTIME eN", "    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("AA");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: AA is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.LWCToolki                                                    1.6", "MIXED MODE");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "                                   sun.lwawt.macosx.LWCToolki                                    ", (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051000110v HotSpot(TM) 64-Bit Server VM", "N/randoop-current.jar");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.substringsBetween("", " ", "32.0");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("noitaroproC elcarO", strArray3, strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "noitaroproC elcarO" + "'", str8.equals("noitaroproC elcarO"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10040414100", "mixed mode", 100);
        java.lang.String[] strArray7 = null;
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("##########################################################################################/Library/J", "Hi!       ", (int) (short) 0);
        int int13 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence[]) strArray12);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray12);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("10.1a.3/Li", strArray7, strArray12);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("2.80-b11", strArray5, strArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "#class [Ljava.lang.String;eclass", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "##########################################################################################/Library/J" + "'", str14.equals("##########################################################################################/Library/J"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10.1a.3/Li" + "'", str15.equals("10.1a.3/Li"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2.80-b11" + "'", str16.equals("2.80-b11"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" ####", "24.80-b11", 135);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/lIBRARY/j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "M) SE Runtime En", (java.lang.CharSequence) "1#100#0#100#1#0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100a0a1a100", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100a0a1a100", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "        ", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...     ...UTF-8UTF-8UTF-8UTF-8", charArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a', 5, (int) (short) -1);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a', (int) (short) 1, 1);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                                                1.6                                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1", "e");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "1#100#0#100#1#0");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "ESRODNE/BIL/ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("sun.awt.CGraphicsEnvironmentsun.awsun.aN/randoop-current.jarsun.awt.CGraphicsEnvironmentsun.awsun.aw");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironmentsun.awsun.aN/randoop-current.jarsun.awt.CGraphicsEnvironmentsun.awsun.aw" + "'", str1.equals("sun.awt.CGraphicsEnvironmentsun.awsun.aN/randoop-current.jarsun.awt.CGraphicsEnvironmentsun.awsun.aw"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/#Users#/#sop#100#a#0#a#1#a#100#/#Users#/#soph#/#Users#/#sop#100#a#0#a#1#a#100#/#Users#/#soph#/#Users#/#sop#100#a#0#a#1#a#100#/#Users#/#soph#/#Users#/#sop#100#a#0#a#1#a#100#/#Users#/#soph#/#Users#/#sop#100#a#0#a#1#a#100#/#Users#/#soph#/#Users#/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/#Users#/#sop#100#a#0#a#1#a#100#/#Users#/#soph#/#Users#/#sop#100#a#0#a#1#a#100#/#Users#/#soph#/#Users#/#sop#100#a#0#a#1#a#100#/#Users#/#soph#/#Users#/#sop#100#a#0#a#1#a#100#/#Users#/#soph#/#Users#/#sop#100#a#0#a#1#a#100#/#Users#/#soph#/#Users#/" + "'", str1.equals("/#Users#/#sop#100#a#0#a#1#a#100#/#Users#/#soph#/#Users#/#sop#100#a#0#a#1#a#100#/#Users#/#soph#/#Users#/#sop#100#a#0#a#1#a#100#/#Users#/#soph#/#Users#/#sop#100#a#0#a#1#a#100#/#Users#/#soph#/#Users#/#sop#100#a#0#a#1#a#100#/#Users#/#soph#/#Users#/"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        short[] shortArray6 = new short[] { (byte) 1, (short) 100, (short) 0, (short) 100, (byte) 1, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 0 + "'", short8 == (short) 0);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("\n", "    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80", "100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "\n" + "'", str4.equals("\n"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1#100#0#100#1#0                                                                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("D2ESRRESR6ESRO2ESRO2ES", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "D2ESRRESR6ESRO2ESRO2ES" + "'", str2.equals("D2ESRRESR6ESRO2ESRO2ES"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "M) SE Runtime En");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100#0#1#10044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                                                 AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) -1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        double[] doubleArray5 = new double[] { ' ', (-1.0f), (-1L), 100, (byte) 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 20, 1);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "32.0a-1.0a-1.0a100.0a100.0" + "'", str8.equals("32.0a-1.0a-1.0a100.0a100.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("M) SE RUNTIME EN", (int) (byte) 1, "##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "M) SE RUNTIME EN" + "'", str3.equals("M) SE RUNTIME EN"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                               /USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51411_1560278524");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100#0#1#100", (java.lang.CharSequence) "                                                                 aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(6, (int) (short) -1, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "    sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) ".7.0_80-B15", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 30 + "'", int3 == 30);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                                       /4                                                 ", "ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...en", "sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                       /4                                                 " + "'", str3.equals("                                       /4                                                 "));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10414141004100410                                                                                   ", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("################################################hi!#################################################", 18, ".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "################################################hi!#################################################" + "'", str3.equals("################################################hi!#################################################"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Hi!       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!" + "'", str1.equals("Hi!"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("1.5", "sun.lwawt.macosx.CPrinterJob                        ", "0");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("    sun");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:     sun is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100o100", (java.lang.CharSequence) "-1a100a-1a1", 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest7.test088");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
//        java.lang.String str1 = javaVersion0.toString();
//        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
//        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
//        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        boolean boolean7 = javaVersion5.atLeast(javaVersion6);
//        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
//        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean10 = javaVersion5.atLeast(javaVersion9);
//        boolean boolean11 = javaVersion0.atLeast(javaVersion9);
//        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
//        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(22, 135, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 135 + "'", int3 == 135);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.8", (java.lang.CharSequence) "                                             100 100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100", (java.lang.CharSequence) ".7.0_80-B15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("...     ...UTF-8UTF-8UTF-8UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...     ...UTF-8UTF-8UTF-8UTF-" + "'", str1.equals("...     ...UTF-8UTF-8UTF-8UTF-"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("m) se rUNTIME eN", "             1.6                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "m) se rUNTIME eN" + "'", str2.equals("m) se rUNTIME eN"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80", "10.04-1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", '#');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB                        ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("x86_64");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "x86_64" + "'", str4.equals("x86_64"));
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern(" 080   ...     ...   080   ...     ...   080   ...     ...   080", "ORACLE CORPORATION", "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " 080   ...     ...   080   ...     ...   080   ...     ...   080" + "'", str3.equals(" 080   ...     ...   080   ...     ...   080   ...     ...   080"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Oracle Corporation", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.String str3 = javaVersion2.toString();
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean6 = javaVersion2.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean9 = javaVersion7.atLeast(javaVersion8);
        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean12 = javaVersion7.atLeast(javaVersion11);
        boolean boolean13 = javaVersion2.atLeast(javaVersion11);
        boolean boolean14 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean15 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str16 = javaVersion2.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7" + "'", str3.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.7" + "'", str16.equals("1.7"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Por000");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "...     ...UTF-8UTF-8UTF-8UTF-", 0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("ed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ed\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("10a1a1a100a100a10", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10a1a1a100" + "'", str2.equals("10a1a1a100"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("sophieaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaeihpos" + "'", str1.equals("aaaaaaaaaaeihpos"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) (byte) 10, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J", 135, "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J" + "'", str3.equals("##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 359, (double) 11L, (double) 21);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 359.0d + "'", double3 == 359.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaeihpos", (java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51.0", charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "x86_64", charArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Hi!       ", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "44444444444444444444444444oolkit", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.05100a0a1a10ava HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence[]) strArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("10414141004100410");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10414141004100410\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "es:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  ", (java.lang.CharSequence) "##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "ry/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray4, ' ');
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaa", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "cle.com/a.oravahttp://j");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        double[] doubleArray2 = new double[] { (byte) 10, (-1.0d) };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.04-1.0" + "'", str5.equals("10.04-1.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a-1.0" + "'", str7.equals("10.0a-1.0"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("0", 7, 115);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        short[] shortArray1 = new short[] { (short) 0 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0" + "'", str5.equals("0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        short[] shortArray2 = new short[] { (short) 1, (byte) 10 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4', (int) (byte) 100, (int) (short) 1);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4', (int) (short) 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 1 + "'", short8 == (short) 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 1 + "'", short9 == (short) 1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("sun.lwawt.macosx.LWCToolki", "eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.Strin10.1a.3/LiString;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;e");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolki" + "'", str2.equals("sun.lwawt.macosx.LWCToolki"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        double[] doubleArray2 = new double[] { (byte) 10, (-1.0d) };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.04-1.0" + "'", str5.equals("10.04-1.0"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1000110044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        float[] floatArray5 = new float[] { 'a', 35.0f, 8, (byte) -1, (byte) 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "97.0#35.0#8.0#-1.0#10.0" + "'", str7.equals("97.0#35.0#8.0#-1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97.0a35.0a8.0a-1.0a10.0" + "'", str9.equals("97.0a35.0a8.0a-1.0a10.0"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 97.0f + "'", float10 == 97.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "97.0a35.0a8.0a-1.0a10.0" + "'", str12.equals("97.0a35.0a8.0a-1.0a10.0"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 30, (float) 2L, (float) 76);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        short[] shortArray6 = new short[] { (byte) 1, (short) 100, (short) 0, (short) 100, (byte) 1, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1#100#0#100#1#0" + "'", str9.equals("1#100#0#100#1#0"));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1a100a0a100a1a0" + "'", str13.equals("1a100a0a100a1a0"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference(" ", "                               /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a" + "'", str2.equals("                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("sun.awt.CGraphicsEnvironmentsun.awt", "32.04-1.04-1.04100.04100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32.04-1.04-1.04100.04100.0" + "'", str2.equals("32.04-1.04-1.04100.04100.0"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "4", 1605, 363);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) (byte) 10, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                                                                       ", (java.lang.CharSequence) "                                                        1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        int[] intArray3 = new int[] { ' ', 'a', (byte) 1 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, '#', 3, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center(".7.0_80-B15", 32, "32.0#-1.0#-1.0#100.0#100.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "32.0#-1.0#.7.0_80-B1532.0#-1.0#-" + "'", str3.equals("32.0#-1.0#.7.0_80-B1532.0#-1.0#-"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 0, (byte) 1, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', (int) (byte) 100, (int) (short) 0);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', 76, 24);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100a0a1a100" + "'", str6.equals("100a0a1a100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#0#1#100" + "'", str8.equals("100#0#1#100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100 0 1 100" + "'", str12.equals("100 0 1 100"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("10a1a1a100", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10a1a1a100" + "'", str2.equals("10a1a1a100"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "                                                                                       32.0#-1.0#", (java.lang.CharSequence) "cosx.LWCToolkitawt.maun.lw", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                                                                             97.0a35.0a8.0a-1.0a10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                             97.0a35.0a8.0a-1.0a10.0" + "'", str1.equals("                                                                             97.0a35.0a8.0a-1.0a10.0"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sun.lwawt.macosx.LWCToolki", "", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("          /Library/J           ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "Hi!       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java Platform API Specification", (int) (short) 10, "aaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification" + "'", str3.equals("Java Platform API Specification"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                                                                                              Hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1.2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("noitaroproC elcarO", (int) (short) 100, (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        int[] intArray3 = new int[] { ' ', 'a', (byte) 1 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "32a97a1" + "'", str8.equals("32a97a1"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mode" + "'", str1.equals("mixed mode"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU", "10.1a.3/Li");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU" + "'", str2.equals("SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                       " + "'", str2.equals("                       "));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...en", 20);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...en" + "'", str2.equals("ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...en"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("p");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("32.0a-1.0a-1.0a100.0a100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "32.0a-1.0a-1.0a100.0a100.0" + "'", str1.equals("32.0a-1.0a-1.0a100.0a100.0"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) -1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("#class [Ljava.lang.String;eclass");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#CLASS [lJAVA.LANG.sTRING;ECLASS" + "'", str1.equals("#CLASS [lJAVA.LANG.sTRING;ECLASS"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("SU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SU" + "'", str1.equals("SU"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("S/J...", "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051000110v HotSpot(TM) 64-Bit Server VM", 15);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("###################################################################################################################################                               /Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a####################################################################################################################################", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "1.51.21.71.71.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        short[] shortArray6 = new short[] { (byte) 10, (byte) 1, (short) 1, (short) 100, (short) 100, (short) 10 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a', 100, 97);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4', 31, 8);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10#1#1#100#100#10" + "'", str9.equals("10#1#1#100#100#10"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.Strin10.1a.3/LiString;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;e", 23, "                               /Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.Strin10.1a.3/LiString;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;e" + "'", str3.equals("eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.Strin10.1a.3/LiString;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;e"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Platform API Specification", "10414141004100410                                                                                   ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                   ", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("################################################hi!#################################################");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                1.6                                                ", (java.lang.CharSequence) "m) se rUNTIME eNV");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("p                  ..                  ..           ", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("001/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrea/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrea/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrea/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre001", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "001/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrea/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrea/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrea/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre001" + "'", str2.equals("001/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrea/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrea/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrea/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre001"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "141004041004140");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80", "0", "           ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    1.7.           _8               1.7.           _8               1.7.           _8               1.7.           _8               1.7.           _8               1.7.           _8               1.7.           _8               1.7.           _8               1.7.           _8               1.7.           _8               1.7.           _8           " + "'", str3.equals("    1.7.           _8               1.7.           _8               1.7.           _8               1.7.           _8               1.7.           _8               1.7.           _8               1.7.           _8               1.7.           _8               1.7.           _8               1.7.           _8               1.7.           _8           "));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "32.0#-1.0#-1.0#100.0#100.0", (java.lang.CharSequence) "3249741", 1004100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "          ", (java.lang.CharSequence) "                                   sun.lwawt.macosx.LWCToolki                                    ", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "hi!       ");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', (int) (byte) 0, (int) (byte) -1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "                  ..");
        boolean boolean12 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) ".7.0_80-b15", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("################################################hi!#################################################", ".0a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "################################################hi!#################################################" + "'", str2.equals("################################################hi!#################################################"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        char[] charArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray0, '4', 32, 78);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                          97.0A35.0A8.0A-1.0A10.0", 10, "       ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                          97.0A35.0A8.0A-1.0A10.0" + "'", str3.equals("                                                                          97.0A35.0A8.0A-1.0A10.0"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "32a97a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.8", (java.lang.CharSequence) "32.04-1.04-1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "#                                                10414141004100410#                                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                  raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:se");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "class [Ljava.lang.String;#class [Ljava.lang.String;");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:se" + "'", str3.equals("class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:se"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "es:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  ", (java.lang.CharSequence) "esr1a10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                             100 100", (int) (short) 10, "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                             100 100" + "'", str3.equals("                                             100 100"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "", (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        int[] intArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 8, (long) 27, 11L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 8L + "'", long3 == 8L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("#                                                10414141004100410#                                                ", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#                                                10414141004100410#                                                " + "'", str2.equals("#                                                10414141004100410#                                                "));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1.51.21.71.71.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.51.21.71.71.7" + "'", str1.equals("1.51.21.71.71.7"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "             1.6                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("3249741", " 100 100  ", 32, 23);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "3249741 100 100  " + "'", str4.equals("3249741 100 100  "));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterType("10.14.3");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("52.0a1.0a6.0a32.0a32.0", strArray2, strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 5");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "              1.7               ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "...     ...UTF-8UTF-8UTF-8UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) '#', 18, 359);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 359 + "'", int3 == 359);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace(" ####Por ####Por ####Por ####Por ####Por ####Por ####Por ####Por ####Por ####");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####Por ####Por ####Por ####Por ####Por ####Por ####Por ####Por ####Por ####" + "'", str1.equals("####Por ####Por ####Por ####Por ####Por ####Por ####Por ####Por ####Por ####"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "\n", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        double[] doubleArray5 = new double[] { ' ', (-1.0f), (-1L), 100, (byte) 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "32.0 -1.0 -1.0 100.0 100.0" + "'", str8.equals("32.0 -1.0 -1.0 100.0 100.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "32.0a-1.0a-1.0a100.0a100.0" + "'", str10.equals("32.0a-1.0a-1.0a100.0a100.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "32.0 -1.0 -1.0 100.0 100.0" + "'", str12.equals("32.0 -1.0 -1.0 100.0 100.0"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        double[] doubleArray5 = new double[] { ' ', (-1.0f), (-1L), 100, (byte) 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        long[] longArray2 = new long[] { 100L, (short) 100 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray2, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a', (int) '4', 18);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1004100" + "'", str5.equals("1004100"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100 100" + "'", str7.equals("100 100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100#100" + "'", str9.equals("100#100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) -1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                             97.0a35.0a8.0a-1.0a10.0", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "4                                                /4                                                 ", (java.lang.CharSequence) "3249741", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("##################################################################################################################\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##################################################################################################################" + "'", str1.equals("##################################################################################################################"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "AA", (java.lang.CharSequence) "   080", 363);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "    1.7.           _8               1.7.           _8               1.7.           _8               1.7.           _8               1.7.           _8               1.7.           _8               1.7.           _8               1.7.           _8               1.7.           _8               1.7.           _8               1.7.           _8           ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sop4                                                                                                   1004                                                                                                   a4                                                                                                   04                                                                                                   a4                                                                                                   14                                                                                                   a4                                                                                                   1004                                                                                                   /4                                                                                                   Users4                                                                                                   /4                                                                                                   soph4                                                                                                   /", ".7.0_80-B15", 8);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                                                                             97.0a35.0a8.0a-1.0a10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 0, (byte) 1, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', (int) (byte) 100, (int) (short) 0);
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "                                                                 aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:                                                                  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100a0a1a100" + "'", str6.equals("100a0a1a100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#0#1#100" + "'", str8.equals("100#0#1#100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100 0 1 100" + "'", str12.equals("100 0 1 100"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) 100 + "'", byte17 == (byte) 100);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        char[] charArray7 = new char[] {};
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "", charArray7);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a', 1, 0);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle Corporation", charArray7);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                       /4                                                 ", charArray7);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) " ", charArray7);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "32a97a1", charArray7);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "es:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  ", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolki", (java.lang.CharSequence) "    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("...     ...UTF-8UTF-8UTF-8UTF-");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) ".LWC...", (java.lang.CharSequence) "a79a23", (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Threshold must not be negative");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("          ", 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Por000                  ..Por000                  ..Por000                  ..Por000                  ..Por000                  ..Por000                  ..Por000                  ..Por000                  ..Por000                  ..Por000                  ..Por000                  ..Por000                  ..Por000                  ..Por000                  ..Por000", 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                  ...", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                  ..." + "'", str2.equals("                  ..."));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...en", (java.lang.CharSequence) "                                                 AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "001a1a0a001");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString(".7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".7.0_80-b15" + "'", str1.equals(".7.0_80-b15"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("    sun", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    sun" + "'", str2.equals("    sun"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str5 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.1" + "'", str5.equals("1.1"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("SUN.LWAWT.MACOSX.cpRINTERjOB                        ", "noitarop", "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "                                                                          97.0A35.0A8.0A-1.0A10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "en                  ", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) 'a', (int) (byte) -1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("", "x86_64", (int) ' ');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.5", (java.lang.CharSequence[]) strArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "rJob", (java.lang.CharSequence[]) strArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        float[] floatArray1 = new float[] { ' ' };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4', (int) ' ', 64);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "32.0" + "'", str3.equals("32.0"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "32.0" + "'", str5.equals("32.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 32.0f + "'", float6 == 32.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 32.0f + "'", float7 == 32.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 32.0f + "'", float8 == 32.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 32.0f + "'", float9 == 32.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 32.0f + "'", float10 == 32.0f);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                                                                                                                       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("100 10 1 10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100 10 1 10" + "'", str1.equals("100 10 1 10"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                                                                            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("32.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "32.0" + "'", str1.equals("32.0"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("########1#########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "########1#########" + "'", str1.equals("########1#########"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a3249741", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("UTF-8");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", "d2esrresr6esro2esro2es", "LWCToolki");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("\n");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "oracle Corporation", (java.lang.CharSequence) " poration444444444444444444444444  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ry/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javasrresr6esro2esro2esporation444444444444444444444444", "100#0#1#10044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 91 + "'", int2 == 91);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("32a97a", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("ry/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javasrresr6esro2esro2esporation444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("sophieaaaaaaaaaa100a0a1a100100a0", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophieaaaaaaaaaa100a0a1a100100a0" + "'", str2.equals("sophieaaaaaaaaaa100a0a1a100100a0"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "              1.7               ", (java.lang.CharSequence) "poration444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "#                                                10414141004100410#                                                ", 17);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("32.0a-1.0a-1.0a100.0a100.0", 17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32.0a-1.0a-1.0a100.0a100.0" + "'", str2.equals("32.0a-1.0a-1.0a100.0a100.0"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "97.0#35.0#8.0#-1.0#10.0", (java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80" + "'", str5.equals("                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000" + "'", str2.equals("por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.Strin10.1a.3/LiString;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;e");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        float[] floatArray6 = new float[] { 52.0f, 2, 5.0f, 3, 'a', 1 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4', 363, 28);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!      /Users/sophie/Library/Java", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("un.lwawt.macosx.LWCToolkit", 76, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "un.lwawt.macosx.LWCToolkit" + "'", str3.equals("un.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("MIXED MODE", "1000110044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1000110044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("1000110044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("10.04-1.0", 359, 20);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "51.0", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        char[] charArray7 = new char[] {};
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100a0a1a100", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100a0a1a100", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "        ", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10040414100", charArray7);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                            ", charArray7);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "d2esrresr6esro2esro2es", charArray7);
        java.lang.Class<?> wildcardClass15 = charArray7.getClass();
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("S/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4', (int) 'a', 0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "        ", "esrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("100#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100#100" + "'", str1.equals("100#100"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble(" 080   ...     ...   080   ...     ...   080   ...     ...   080");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"080   ...     ...   080   ...     ...   080   ...     ...   080\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("N/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "N/randoop-current.ja" + "'", str1.equals("N/randoop-current.ja"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("141004041004140", "                  ...", 100);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "141004041004140" + "'", str5.equals("141004041004140"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        short[] shortArray6 = new short[] { (byte) 10, (byte) 1, (short) 1, (short) 100, (short) 100, (short) 10 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#', (int) ' ', (int) (short) 0);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 1 + "'", short12 == (short) 1);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 100 + "'", short13 == (short) 100);
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 1 + "'", short14 == (short) 1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("#CLASS [lJAVA.LANG.sTRING;ECLASS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#CLASS [lJAVA.LANG.sTRING;ECLASS" + "'", str1.equals("#CLASS [lJAVA.LANG.sTRING;ECLASS"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        long[] longArray2 = new long[] { 100L, (short) 100 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray2, '4', (int) '#', (int) ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ', 10, 0);
        long long16 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004100" + "'", str10.equals("1004100"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("S/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED", '#');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("1#100#0#100#1#0", "");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("oracle Corporation", strArray5, strArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "100a0a1a10", (java.lang.CharSequence[]) strArray8);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "3249741");
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X");
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X");
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.7.0_80-b15", strArray15, strArray17);
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.stripAll(strArray17, "100 0 1 100");
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", strArray8, strArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "oracle Corporation" + "'", str9.equals("oracle Corporation"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1#100#0#100#1#0" + "'", str12.equals("1#100#0#100#1#0"));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.7.0_80-b15" + "'", str18.equals("1.7.0_80-b15"));
        org.junit.Assert.assertNotNull(strArray20);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 1, 31L, (long) 135);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 135L + "'", long3 == 135L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "10a1a1a100a100a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("n/generation/randoop-current.jar", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/generation/randoop-current.jar" + "'", str2.equals("n/generation/randoop-current.jar"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 64.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 64.0f + "'", float3 == 64.0f);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Library/J", charArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray4, '4', (int) (byte) 0, (int) (short) 0);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10#1#1#100#100#10", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/", (java.lang.CharSequence) "Por", 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaaaa", "#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("4444444444444444444444444444444444444444444444444444444444444444444444444440");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "u", (java.lang.CharSequence) "                               /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                              Hi!", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "ESRODNE/BIL/ERJ/EMOH/STNETNOC/KDJ.08_0.7.1KDJ/SENIHCAMLAUTRIVAVAJ/AVAJ/YRARBIL/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 79 + "'", int1 == 79);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "##################################################################################################################\n", (java.lang.CharSequence) "1", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "S/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED", "97.0a35.0a8.0a-1.0a10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        float[] floatArray1 = new float[] { ' ' };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a', 1004100, 32);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "32.0" + "'", str3.equals("32.0"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 32.0f + "'", float4 == 32.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("10 1 1 100 100 10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10 1 1 100 100 10" + "'", str1.equals("10 1 1 100 100 10"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("100#0#1#10044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "1004100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#0#1#10044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("100#0#1#10044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "    1.7.0_80", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("32.0 -1.0 -1.0 100.0 100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "32.0-1.0-1.0100.0100.0" + "'", str1.equals("32.0-1.0-1.0100.0100.0"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/lIBRARY/jaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.05100a0a1a10ava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("24.80-b11", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("          /lIBRARY/j           32.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.041");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          /LIBRARY/J           32.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.041" + "'", str1.equals("          /LIBRARY/J           32.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.041"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Hi!       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("porat.on");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Porat.on" + "'", str1.equals("Porat.on"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("##################################################################################################################\n");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "   ...     ...", "10.14.3/Li");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("32.0a-1.0a-1.0a100.0a100.0", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "32.0a-1.0a-1.0a100.0a100.0" + "'", str3.equals("32.0a-1.0a-1.0a100.0a100.0"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(90L, (long) 1605, 135L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 90L + "'", long3 == 90L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("SUN.LWAWT.MACOSX.cpRINTERjOB                        ", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 27, (float) 32L, (float) 10040414100L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 27.0f + "'", float3 == 27.0f);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("100 100", "##########################################################################################/Library/J");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100 100" + "'", str3.equals("100 100"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51.0", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "x86_64", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/J", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "             1.6                                                ", charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        int[] intArray1 = new int[] { (short) -1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, '4', (int) (short) 100, (int) '4');
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) ".7.0_80-b15", 78);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          " + "'", str1.equals("          "));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "HI!      ", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100", "#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "10.04-1.0", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("n/generation/randoop-current.jar", "10a1a1a100a100a10", ":");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "n/generation/randoop-current.jar" + "'", str3.equals("n/generation/randoop-current.jar"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        int[] intArray1 = new int[] { (short) -1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', 6, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1" + "'", str5.equals("-1"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("cosx.LWCToolkitawt.maun.lw", 115);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lw" + "'", str2.equals("cosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lw"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("un.lwawt.macosx.LWCToolkit", "                                                        1.7.0_80", 90);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("ry/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 31L, (double) 6, (double) 27);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.0d + "'", double3 == 6.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 0, (byte) 1, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100a0a1a100" + "'", str6.equals("100a0a1a100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#0#1#100" + "'", str8.equals("100#0#1#100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 0 + "'", byte11 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100#0#1#100" + "'", str13.equals("100#0#1#100"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sop100a0a1a100/Users/soph", charArray4);
        java.lang.Class<?> wildcardClass8 = charArray4.getClass();
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "001/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrea/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrea/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrea/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre001", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                  ...", "", "32.0#-1.0#");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("LWCToolk", 990, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "LWCToolk4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("LWCToolk4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                               /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524", (java.lang.CharSequence) "100 0 1 100", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "                  raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:se", (java.lang.CharSequence) "rJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.String str1 = javaVersion0.toString();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean7 = javaVersion5.atLeast(javaVersion6);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean10 = javaVersion5.atLeast(javaVersion9);
        boolean boolean11 = javaVersion0.atLeast(javaVersion9);
        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                          44444", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                          44444" + "'", str2.equals("                          44444"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("LWCToolki", "#######aaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "LWCToolki" + "'", str2.equals("LWCToolki"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("S/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSE", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSE" + "'", str2.equals("S/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSE"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000" + "'", str1.equals("por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) " ####");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "7.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("32.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "32.0" + "'", str1.equals("32.0"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("46_68x", "                                                                 aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "46_68x" + "'", str2.equals("46_68x"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        int[] intArray1 = new int[] { 0 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, '#');
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("#########################################################################################hi!       ", "#                                                10414141004100410#                                               ", 90);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#########################################################################################hi!       " + "'", str3.equals("#########################################################################################hi!       "));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                                                                              52.0a1.0a6.0a32.0a32.0", "S/J...hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                              52.0a1.0a6.0a32.0a32.0" + "'", str2.equals("                                                                              52.0a1.0a6.0a32.0a32.0"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("#                                                10414141004100410#                                                ", "1#100#0#100#1#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#                                                10414141004100410#                                                " + "'", str2.equals("#                                                10414141004100410#                                                "));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        char[] charArray10 = new char[] {};
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100a0a1a100", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100a0a1a100", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "        ", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1004100", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "32.0 -1.0 -1.0 100.0 100.0", charArray10);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "s/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray10);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                                 aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray10);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a');
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100 100", charArray10);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmentsun.aw ", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!", "", 0);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a', (int) ' ', 22);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("esrodne/bil/erj/emoH/stnetnoC/kdj.08_0.kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/hie/Library/Java/Exte");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "esrodne/bil/erj/emoH/stnetnoC/kdj.08_0.kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/hie/Library/Java/Exte" + "'", str1.equals("esrodne/bil/erj/emoH/stnetnoC/kdj.08_0.kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/hie/Library/Java/Exte"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        long[] longArray2 = new long[] { 100L, (short) 100 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1004100" + "'", str5.equals("1004100"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100 100" + "'", str7.equals("100 100"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100a100" + "'", str11.equals("100a100"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        int[] intArray1 = new int[] { (short) -1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, '4', (int) (short) 100, (int) '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray1, '4', 23, 2);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" poration444444444444444444444444  ", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 359);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "N/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        double[] doubleArray5 = new double[] { ' ', (-1.0f), (-1L), 100, (byte) 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "32.0 -1.0 -1.0 100.0 100.0" + "'", str8.equals("32.0 -1.0 -1.0 100.0 100.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "32.0 -1.0 -1.0 100.0 100.0" + "'", str11.equals("32.0 -1.0 -1.0 100.0 100.0"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "10.1a.3/Li");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("S/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("-141004-141", "10040414sophieaaaaaaaaaa10040414");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-141004-141" + "'", str2.equals("-141004-141"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        short[] shortArray4 = new short[] { (short) -1, (byte) 100, (short) -1, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray4, '4');
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1a100a-1a1" + "'", str6.equals("-1a100a-1a1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-141004-141" + "'", str8.equals("-141004-141"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("cle.com/a.oravahttp://j");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        long[] longArray2 = new long[] { 100L, (short) 100 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, '#');
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1004100" + "'", str5.equals("1004100"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100#100" + "'", str7.equals("100#100"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "esrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (java.lang.CharSequence) "ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("rJob", "32#97#1", 0, (int) '4');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "32#97#1" + "'", str4.equals("32#97#1"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;class [Cclass [J", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "cosx.LWCToolkitawt.maun.lw");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("aaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sun.lwawt.macosx.CPrinterJob", "a", "/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lw/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_51a11_156027852awt.macosx.CPrinterJob" + "'", str3.equals("sun.lw/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_51a11_156027852awt.macosx.CPrinterJob"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 91, (long) 5, (long) 990);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "", charArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray4, ' ');
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                   sun.lwawt.macosx.LWCToolki                                    ", charArray4);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "por", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                                                                       32.0#-1.0#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:                                                                                        32.0#-1.0# is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) " ####Por ####Por ####Por ####Por ####Por ####Por ####Por ####Por ####Por ####", (java.lang.CharSequence) "Porat.on");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 73 + "'", int2 == 73);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("r##########################################################################################/Library/Jtensions:/System/Library/Java/Extensions:/usr/lib/java", "D2ESRRESR6ESRO2ESRO2ES");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1", (java.lang.CharSequence) "141004041004140");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("U", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "          ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 10, (double) 17, (double) 11);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 17.0d + "'", double3 == 17.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "   080");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str1 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100 10 1 10", "p", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Library/J", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "oracle Corporation", charArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray4, '4');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray4, '4', 32, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 73);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("M) SE RUNTIME EN", "10414141004100410", (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN" + "'", str3.equals("M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("32.0a-1.0a-1.0a100.0a100.0", (double) 31);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 31.0d + "'", double2 == 31.0d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Mac OS X", "1004100", (int) (short) 10);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "es:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  ");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        char[] charArray3 = new char[] {};
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100a0a1a100", charArray3);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                                                    ", charArray3);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray3, '#', 26, 73);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 26");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/4", " ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("cle.com/a.oravahttp://j");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"cle.c\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("e");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "              1.7              ", (java.lang.CharSequence) "ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...en");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "MacOSX", 78, 22);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1a100a0a100a1a0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmentsun.aw", (java.lang.CharSequence) "en                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("n/randoop-current.jar", 5, "###################################################################################################################################                               /Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a####################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "n/randoop-current.jar" + "'", str3.equals("n/randoop-current.jar"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100a0a1a100", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100a0a1a100", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "        ", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...     ...UTF-8UTF-8UTF-8UTF-8", charArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a', 5, (int) (short) -1);
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray6, ' ', 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("-1", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1" + "'", str3.equals("-1"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("D2ESRRESR6ESRO2ESRO2ES", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip(".LWC...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".LWC..." + "'", str1.equals(".LWC..."));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("m) se rUNTIME eNV", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "m) se rUNTIME eNV" + "'", str2.equals("m) se rUNTIME eNV"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Java Platform API Specification", 2);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("          /lIBRARY/j           32.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.041");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/lIBRARY/j           32.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.041" + "'", str1.equals("/lIBRARY/j           32.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.041"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        short[] shortArray6 = new short[] { (byte) 1, (short) 100, (short) 0, (short) 100, (byte) 1, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("D2ESRRESR6ESRO2ESRO2ES", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("HI!      /Users/sophie/Library/Java", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("AA", "a79a23");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AA" + "'", str2.equals("AA"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 1.7f, (double) 59, (double) 31);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 59.0d + "'", double3 == 59.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        long[] longArray2 = new long[] { 100L, (short) 100 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray2, '4', (int) '#', (int) ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        long long15 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004100" + "'", str10.equals("1004100"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1004100" + "'", str14.equals("1004100"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("               ...PORPORPORP", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("a3249741", (int) (short) 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a3249741" + "'", str3.equals("a3249741"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "               ...PORPORPORP", (java.lang.CharSequence) "/#Users#/#sop#100#a#0#a#1#a#100#/#Users#/#soph#/#Users#/#sop#100#a#0#a#1#a#100#/#Users#/#soph#/#Users#/#sop#100#a#0#a#1#a#100#/#Users#/#soph#/#Users#/#sop#100#a#0#a#1#a#100#/#Users#/#soph#/#Users#/#sop#100#a#0#a#1#a#100#/#Users#/#soph#/#Users#/", 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.05100a0a1a10ava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.05100a0a1a10ava HotSpot(TM) 64-Bit Server V" + "'", str1.equals("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.05100a0a1a10ava HotSpot(TM) 64-Bit Server V"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("es:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  ", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "es:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  " + "'", str2.equals("es:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  "));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("esrodne/bil/erj/emoH/stnetnoC/kdj.08_0.kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/hie/Library/Java/Exte", "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "esrodne/bil/erj/emoH/stnetnoC/kdj.08_0.kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/hie/Library/Java/Exte" + "'", str3.equals("esrodne/bil/erj/emoH/stnetnoC/kdj.08_0.kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/hie/Library/Java/Exte"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("N/randoop-current.jar", 90, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "N/randoop-current.jar#####################################################################" + "'", str3.equals("N/randoop-current.jar#####################################################################"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Hi!       ", "/Library/J", (int) (byte) 10);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                                1.6                                                ", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray8 = null;
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("##########################################################################################/Library/J", "Hi!       ", (int) (short) 0);
        int int14 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence[]) strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray13);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("10.1a.3/Li", strArray8, strArray13);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("32.0#-1.0#-1.0#100.0#100.0", strArray5, strArray8);
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, " 100 100 ");
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "##########################################################################################/Library/J" + "'", str15.equals("##########################################################################################/Library/J"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10.1a.3/Li" + "'", str16.equals("10.1a.3/Li"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "32.0#-1.0#-1.0#100.0#100.0" + "'", str17.equals("32.0#-1.0#-1.0#100.0#100.0"));
        org.junit.Assert.assertNotNull(strArray19);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a", (java.lang.CharSequence) "100#100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                               /Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a", (java.lang.CharSequence) "noitarop");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, 135.0f, (float) 22L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "S/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSE", (java.lang.CharSequence) "100a0a1a10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("PORaaaaaaaa", "S/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PORaaaaaaaa" + "'", str2.equals("PORaaaaaaaa"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#" + "'", str1.equals("#"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a" + "'", str2.equals("/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1004041410010040414100100404141001004041410010040414100100404141");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.min(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 115);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                   " + "'", str2.equals("                                                                                                                   "));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                1.6                                                 ", 115);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("#class [Ljava.lang.String;eclass", "2.80-b11", 5);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                1.6                                                 ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140", (java.lang.CharSequence) "                  ..", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("#", "", 100);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "MIXED MODE", (java.lang.CharSequence) "1.51.21.71.71.7", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!", "", 0);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("oolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OOLKIT" + "'", str1.equals("OOLKIT"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "PORaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100a0a1a100", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100a0a1a100", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "        ", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray6);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a', 15, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 15");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("sop4                                                                                                   1004                                                                                                   a4                                                                                                   04                                                                                                   a4                                                                                                   14                                                                                                   a4                                                                                                   1004                                                                                                   /4                                                                                                   Users4                                                                                                   /4                                                                                                   soph4                                                                                                   /", "Hi!       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sop4                                                                                                   1004                                                                                                   a4                                                                                                   04                                                                                                   a4                                                                                                   14                                                                                                   a4                                                                                                   1004                                                                                                   /4                                                                                                   Users4                                                                                                   /4                                                                                                   soph4                                                                                                   /" + "'", str2.equals("sop4                                                                                                   1004                                                                                                   a4                                                                                                   04                                                                                                   a4                                                                                                   14                                                                                                   a4                                                                                                   1004                                                                                                   /4                                                                                                   Users4                                                                                                   /4                                                                                                   soph4                                                                                                   /"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("001a1a0a001");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "001a1a0a001" + "'", str1.equals("001a1a0a001"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "NOITAROP");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        char[] charArray5 = new char[] {};
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51.0", charArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "x86_64", charArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/J", charArray5);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", charArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray5, '4');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "                     ", (java.lang.CharSequence) "100#0#1#100", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 10L, 1.7d, 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.7d + "'", double3 == 1.7d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU" + "'", str1.equals("SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524SU"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J" + "'", str1.equals("##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("aaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        double[] doubleArray5 = new double[] { ' ', (-1.0f), (-1L), 100, (byte) 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4', 21, 0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "32.0 -1.0 -1.0 100.0 100.0" + "'", str8.equals("32.0 -1.0 -1.0 100.0 100.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "32.0a-1.0a-1.0a100.0a100.0" + "'", str10.equals("32.0a-1.0a-1.0a100.0a100.0"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase(" 100 100  ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("##########################################################################################/Library/J");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                                       /4                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/4" + "'", str1.equals("/4"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                     ", "/Users/sop100a0a1a100/Users/soph                                       sun.lwawt.macosx.LWCToolki                                                    1.6                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                     " + "'", str2.equals("                     "));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("esrodne/bil/erj/emoH/stnetnoC/kdj.08_0.kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("7.1", "n/randoop-current.jar", (int) 'a');
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", "", 21);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                                                        1.7.0_80", "1a100a0a100a1a0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                        1.7.0_8" + "'", str2.equals("                                                        1.7.0_8"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("N/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "N/randoop-current.jar" + "'", str1.equals("N/randoop-current.jar"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("#                                                                                                ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "", 27);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/", "4", 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/" + "'", str3.equals("S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "100a0a1a100", (int) 'a');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("##########################################################################################/Library/J", "Hi!       ", (int) (short) 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("               ...", strArray4, strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "               ..." + "'", str9.equals("               ..."));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("51.0", 22, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("por");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                                   sun.lwawt.macosx.LWCToolki                                    ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   sun.lwawt.macosx.LWCToolki                                    " + "'", str2.equals("                                   sun.lwawt.macosx.LWCToolki                                    "));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "aaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 11, (long) (byte) 100, 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        int[] intArray1 = new int[] { (short) -1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 97L, (double) 2.0f, 44444.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 44444.0d + "'", double3 == 44444.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        short[] shortArray4 = new short[] { (short) -1, (byte) 100, (short) -1, (byte) 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a');
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1a100a-1a1" + "'", str6.equals("-1a100a-1a1"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("S/J...", "                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a", (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("97.0a35.0a8.0a-1.0a10.0", 99, 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "97.0a35.0a8.0a-1.0a10.0" + "'", str3.equals("97.0a35.0a8.0a-1.0a10.0"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("################################################hi!#################################################", "                                      /4                                                 ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "1.5", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                  vv");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaa", "", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 0.0f, (double) 0.0f, (double) 363.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 10.0f, (double) 100, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.05100a0a1a10ava HotSpot(TM) 64-Bit Server V", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.05100a0a1a10ava HotSpot(TM) 64-Bit Server V" + "'", str2.equals("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.05100a0a1a10ava HotSpot(TM) 64-Bit Server V"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000", "N/randoop-current.jar#####################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000" + "'", str2.equals("Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("#######aaaaaaaaaaaaaaaaaaaa", (double) 21);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 21.0d + "'", double2 == 21.0d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("M) SE RUNTIME EN");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "m) SE RUNTIME EN" + "'", str1.equals("m) SE RUNTIME EN"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1a100a-1a1", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "##################################################################################################################", (java.lang.CharSequence) "cosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lw", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("...     ...UTF-8UTF-8UTF-8UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...     ...UTF-8UTF-8UTF-8UTF-8" + "'", str1.equals("...     ...UTF-8UTF-8UTF-8UTF-8"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("S/J...hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S/J...hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("S/J...hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        byte[] byteArray0 = new byte[] {};
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "aaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: aaaaaaaaaa");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "                                                                                              Hi!", (java.lang.CharSequence) "...                /Users/sophie...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("un.lwawt.macosx.LWCToolkit", "n/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/randoop-current.jar" + "'", str2.equals("n/randoop-current.jar"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.String str1 = javaVersion0.toString();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        boolean boolean5 = javaVersion0.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str7 = javaVersion6.toString();
        java.lang.String str8 = javaVersion6.toString();
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.String str11 = javaVersion10.toString();
        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion10);
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean14 = javaVersion10.atLeast(javaVersion13);
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean17 = javaVersion15.atLeast(javaVersion16);
        boolean boolean18 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion15);
        org.apache.commons.lang3.JavaVersion javaVersion19 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean20 = javaVersion15.atLeast(javaVersion19);
        boolean boolean21 = javaVersion10.atLeast(javaVersion19);
        org.apache.commons.lang3.JavaVersion javaVersion22 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean23 = javaVersion19.atLeast(javaVersion22);
        boolean boolean24 = javaVersion6.atLeast(javaVersion22);
        boolean boolean25 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion22);
        boolean boolean26 = javaVersion0.atLeast(javaVersion22);
        org.apache.commons.lang3.JavaVersion javaVersion27 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion28 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean29 = javaVersion27.atLeast(javaVersion28);
        boolean boolean30 = javaVersion0.atLeast(javaVersion28);
        java.lang.String str31 = javaVersion28.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.5" + "'", str7.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.5" + "'", str8.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.7" + "'", str11.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + javaVersion19 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion19.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + javaVersion22 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion22.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + javaVersion27 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion27.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion28 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion28.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1.2" + "'", str31.equals("1.2"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("US", 135);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS" + "'", str2.equals("USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                                                                            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51411_1560278524");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie/documents/defects4j/tmp/run_randoop.pl_51411_1560278524" + "'", str1.equals("/users/sophie/documents/defects4j/tmp/run_randoop.pl_51411_1560278524"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Hi!       ", "44444444444444444444444444oolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi!       " + "'", str2.equals("Hi!       "));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("44444", "                       ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "", 97);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "cle.com/a.oravahttp://j");
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "a3249741", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str6.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        long[] longArray5 = new long[] { 990L, 6, 32L, 44444L, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "990a6a32a44444a-1" + "'", str7.equals("990a6a32a44444a-1"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51411_1560278524", "1.8", "SU");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51411_1560278524" + "'", str3.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51411_1560278524"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 " + "'", str2.equals("                                                                                                 "));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140141004041004140");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 2, (float) 141004041004140L, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.41004045E14f + "'", float3 == 1.41004045E14f);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("POR", "N/randoop-current.jar#####################################################################", "ORACLE CORPORATION", 135);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "POR" + "'", str4.equals("POR"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("rJob", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        long[] longArray2 = new long[] { 100L, (short) 100 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, '#');
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1004100" + "'", str5.equals("1004100"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100#100" + "'", str7.equals("100#100"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        long[] longArray2 = new long[] { 100L, (short) 100 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray2, '4', (int) '#', (int) ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        long long14 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004100" + "'", str10.equals("1004100"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100 100" + "'", str13.equals("100 100"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "32.04-1.04-1.0", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("a3249741", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a3249741" + "'", str2.equals("a3249741"));
    }
}

