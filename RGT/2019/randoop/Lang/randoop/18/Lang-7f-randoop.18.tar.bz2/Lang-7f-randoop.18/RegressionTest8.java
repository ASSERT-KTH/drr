import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, ' ', 100, (int) 'a');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", "oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre" + "'", str2.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051000110v HotSpot(TM) 64-Bit Server VM", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" 100 100  ", "sun.awt.CGraphicsEnvironmentsun.awt", 6);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("52.0a1.0a6.0a32.0a32.0", "##########################################################################################/Library/J");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 97, 99);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Users/sop100a0a1a100/Users/soph");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "        ");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sop100a0a1a100/Users/soph" + "'", str3.equals("/Users/sop100a0a1a100/Users/soph"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...en", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...en" + "'", str2.equals("ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...en"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, '#', 7, 20);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        long[] longArray2 = new long[] { 100L, (short) 100 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray2, '4', (int) '#', (int) ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ', 59, 24);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("100a0a1a10", "sop4                                                                        ", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100a0a1a10" + "'", str3.equals("100a0a1a10"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;class [Cclass [J", 6, 21);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...org.apache.comm..." + "'", str3.equals("...org.apache.comm..."));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        int[] intArray1 = new int[] { (short) -1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 10, 22);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1" + "'", str5.equals("-1"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("x86_64");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4');
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "esrodne/bil/erj/emoH/stnetnoC/kdj.08_0.kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/hie/Library/Java/Exte", 31, 73);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 31");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "x86_64" + "'", str4.equals("x86_64"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100a0a1a100", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100a0a1a100", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "        ", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1004100", charArray6);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                 aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        double[] doubleArray5 = new double[] { ' ', (-1.0f), (-1L), 100, (byte) 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 20, 1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4', 64, (int) (byte) -1);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ', 28, 2);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 99, 8);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "32.0a-1.0a-1.0a100.0a100.0" + "'", str8.equals("32.0a-1.0a-1.0a100.0a100.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("10                                                                                                    .                                                                                                    14                                                                                                    .                                                                                                    3", "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 15, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                       .                                                                                                    14                                                                                                    .                                                                                                    3" + "'", str4.equals("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                       .                                                                                                    14                                                                                                    .                                                                                                    3"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("444444");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("S/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED", '#');
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("1#100#0#100#1#0", "");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("oracle Corporation", strArray7, strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", strArray3, strArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "32.0 -1.0 -1.0 100.0 100.0", (java.lang.CharSequence[]) strArray10);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "oracle Corporation" + "'", str11.equals("oracle Corporation"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str12.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("sun.awt.CGraphicsEnvironmentsun.awt", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironmentsun.awt" + "'", str2.equals("sun.awt.CGraphicsEnvironmentsun.awt"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ".7.0_80-B15", 91, 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("oolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 0, (byte) 1, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100a0a1a100" + "'", str6.equals("100a0a1a100"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "##########################################################################################/Library/J", 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "es:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  ", (java.lang.CharSequence) "   ...     ...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 0, (byte) 1, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 26, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 26");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100a0a1a100" + "'", str6.equals("100a0a1a100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#0#1#100" + "'", str8.equals("100#0#1#100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100#0#1#100" + "'", str11.equals("100#0#1#100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10040414100" + "'", str13.equals("10040414100"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "d2esrresr6esro2esro2esporation444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("d2esrresr6esro2esro2es", "#########################################################################################hi!       ", "          /LIBRARY/J           32.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.041");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "d2esrresr6esro2esro2es" + "'", str3.equals("d2esrresr6esro2esro2es"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...en");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "jAVA(tm) se rUNTIME eNVIRONMENT", (java.lang.CharSequence) "ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...en");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                                        1.7.0_80", (java.lang.CharSequence) "141004041004140", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 35, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(52.0d, 11.0d, 359.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.0d + "'", double3 == 11.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("3249741");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        short[] shortArray6 = new short[] { (byte) 1, (short) 100, (short) 0, (short) 100, (byte) 1, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.String str4 = javaVersion3.toString();
        boolean boolean5 = javaVersion1.atLeast(javaVersion3);
        java.lang.String str6 = javaVersion1.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7" + "'", str4.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.2" + "'", str6.equals("1.2"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("s/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "100a0a1a100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a0a1a100" + "'", str2.equals("100a0a1a100"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        int[] intArray1 = new int[] { (short) -1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, '4', (int) (short) 100, (int) '4');
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ');
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 99, 5);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                   sun.lwawt.macosx.LWCToolki                                    ", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   sun.lwawt.macosx.LWCToolki                                    " + "'", str2.equals("                                   sun.lwawt.macosx.LWCToolki                                    "));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:se");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        long[] longArray2 = new long[] { 100L, (short) 100 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray2, '4', 5, 78);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Por", "1004041410010040414100100404141001004041410010040414100100404141", 3);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.Class<?> wildcardClass5 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################", (java.lang.CharSequence) "#                                                10414141004100410#                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase(" 080   ...     ...   080   ...     ...   080   ...     ...   080");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " 080   ...     ...   080   ...     ...   080   ...     ...   080" + "'", str1.equals(" 080   ...     ...   080   ...     ...   080   ...     ...   080"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;e", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[Ljava.lang.String;e [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class eclass" + "'", str2.equals("[Ljava.lang.String;e [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class eclass"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...en", 73, 73);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("51.0", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1.2", 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.3/Li", "10a1a1a100a100a10");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("e", 35, "4444444444444444444444444444444444444444444444444444444444444444444444444440");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "e4444444444444444444444444444444444" + "'", str3.equals("e4444444444444444444444444444444444"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("100#100", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#100" + "'", str2.equals("100#100"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("10.14.3");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "                  ...");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "100a0a1a10");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString(".7.0_80-B15", "e4444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".7.0_80-B15" + "'", str2.equals(".7.0_80-B15"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "001/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrea/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrea/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrea/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre001");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("HI!      ", "sun.awt.CGraphicsEnvironmentsun.awt");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("x86_6", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_6" + "'", str3.equals("x86_6"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "                                             100 100", (java.lang.CharSequence) "0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("MacOSX");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MACOSX" + "'", str1.equals("MACOSX"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("D2ESRRESR6ESRO2ESRO2ES");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "PORaaaaaaaa", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("cosx.LWCToolkitawt.maun.lw", ".7.0_80-b15", "por", 90);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "cosx.LWCToolkitawt.maun.lw" + "'", str4.equals("cosx.LWCToolkitawt.maun.lw"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("X86_6", 11, "5.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X86_65.15.1" + "'", str3.equals("X86_65.15.1"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                                                1.6                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                1.6                                                " + "'", str1.equals("                                                1.6                                                "));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80", "#                                                10414141004100410#                                                ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("ry/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str1.equals("RY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("10414141004100410                                                                                   ", "Es:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(91, 18, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 18 + "'", int3 == 18);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("a79a23", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/Users/sop100a0a1a100/Users/soph                                       sun.lwawt.macosx.LWCToolki                                                    1.6                                                ", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/ldesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/ibrarydesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil//desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/jdesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/avadesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil//desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/jdesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/avadesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/vdesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/irtualdesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/mdesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/achinesdesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil//desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/jdkdesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/1desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/.desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/7desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/.desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/0desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/_desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/80desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/.desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/jdkdesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil//desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/cdesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/ontentsdesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil//desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/hdesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/omedesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil//desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/jredesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil//desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/libdesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil//desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "32#97#1", "por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("UTF-8", "HI!      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("x86_64");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64" + "'", str3.equals("x86_64"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100" + "'", str2.equals("100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        short[] shortArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, ' ', 21, 18);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!       ", "S/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                  ...", (java.lang.CharSequence) "1.1", 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        short[] shortArray2 = new short[] { (short) 1, (byte) 10 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4', (int) (byte) 100, (int) (short) 1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ', (int) '4', (int) (short) -1);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 1 + "'", short12 == (short) 1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.String str1 = javaVersion0.toString();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean6 = javaVersion0.atLeast(javaVersion5);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", (long) 115);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 115L + "'", long2 == 115L);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        short[] shortArray6 = new short[] { (byte) 10, (byte) 1, (short) 1, (short) 100, (short) 100, (short) 10 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10#1#1#100#100#10" + "'", str9.equals("10#1#1#100#100#10"));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 1 + "'", short10 == (short) 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10 1 1 100 100 10" + "'", str12.equals("10 1 1 100 100 10"));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 100 + "'", short13 == (short) 100);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/4", 78);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/4" + "'", str2.equals("/4"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("HI!", "sun.lw/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_51a11_156027852awt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                    hi!", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("32.0 -1.0 -1.0 100.0 100.0", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0 100.0 -1.0 -1.0 32.0" + "'", str2.equals("100.0 100.0 -1.0 -1.0 32.0"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("aaaaaaaaaaaaaaaaaa", "Hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "oracle Corporation", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("sun.awt.CGraphicsEnvironmentsun.aw ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AW " + "'", str1.equals("SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AW "));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("97.0#35.0#8.0#-1.0#10.0", "sop4                                                                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "97.0#35.0#8.0#-1.0#10.0" + "'", str2.equals("97.0#35.0#8.0#-1.0#10.0"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("sun.awt.CGraphicsEnvironmentsun.awt");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.awt.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest8.test093");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("    1.7.0_80");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 22L, 1.00404142E10f, 10.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 64.0f, (double) 64L, 64.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 64.0d + "'", double3 == 64.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "/lIBRARY/j           32.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.041");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        char[] charArray5 = new char[] {};
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51.0", charArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "x86_64", charArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/J", charArray5);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", charArray5);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray5, '4', 3, 90);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("              1.7               ", (int) 'a', "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                              1.7                                                " + "'", str3.equals("                                              1.7                                                "));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.Strin10.1a.3/LiString;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;e");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("1000110044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1000110044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("1000110044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("jAVA(tm) se rUNTIME eNVIRONMENT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 23, (float) 35, (float) '4');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 23.0f + "'", float3 == 23.0f);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                               /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "M) SE RUNTIME EN", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "                                                 AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (java.lang.CharSequence) "class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:se");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 0, (byte) 1, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', (int) (byte) 10, 76);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100a0a1a100" + "'", str6.equals("100a0a1a100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#0#1#100" + "'", str8.equals("100#0#1#100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/Users/sop100a0a1a100/Users/soph");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sop100a0a1a100/Users/soph" + "'", str1.equals("/Users/sop100a0a1a100/Users/soph"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                    1.7.0_80-b15", "oolkit", 99);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                    1.7.0_80-b15" + "'", str3.equals("                    1.7.0_80-b15"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("noitaroproC elcarO", "esrodne/bil/erj/emoH/stnetnoC/kdj.08_0.kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitaroproC elcarO" + "'", str2.equals("noitaroproC elcarO"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber(" 100 100  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort(".0a");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        double[] doubleArray5 = new double[] { ' ', (-1.0f), (-1L), 100, (byte) 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4', 0, 3);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "32.0 -1.0 -1.0 100.0 100.0" + "'", str8.equals("32.0 -1.0 -1.0 100.0 100.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "32.0 -1.0 -1.0 100.0 100.0" + "'", str11.equals("32.0 -1.0 -1.0 100.0 100.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "32.04-1.04-1.0" + "'", str15.equals("32.04-1.04-1.0"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "32.0a-1.0a-1.0a100.0a100.0" + "'", str17.equals("32.0a-1.0a-1.0a100.0a100.0"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("          /LIBRARY/J           32.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.041");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          /LIBRARY/J           32.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.041" + "'", str1.equals("          /LIBRARY/J           32.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.041"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Libr...", (-1), "sun.awt.CGraphicsEnvironmentsun.aw");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Libr..." + "'", str3.equals("/Libr..."));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 76);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("24.80-b11", "##################################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("3249741", "                                                                                                                   ", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3249741" + "'", str3.equals("3249741"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("cosx.LWCToolkitawt.maun.lw", "001a1a0a001", 359);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "1.8", (java.lang.CharSequence) "u");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                               /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524", "sun.lw/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_51a11_156027852awt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                                                1.6                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                               /Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100#0#1#10044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "32.0-1.0-1.0100.0100.0", (java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;class [Cclass [J", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("n/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sop100a0a1a100/Users/soph", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("a");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                       32.0#-1.0#", "001/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrea/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrea/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrea/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre001");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 89 + "'", int2 == 89);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "OOLKIT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("444444");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("S/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED", '#');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("1#100#0#100#1#0", "");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("oracle Corporation", strArray6, strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", strArray2, strArray9);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "sop4                                                                                                   1004                                                                                                   a4                                                                                                   04                                                                                                   a4                                                                                                   14                                                                                                   a4                                                                                                   1004                                                                                                   /4                                                                                                   Users4                                                                                                   /4                                                                                                   soph4                                                                                                   /", 59, 79);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 59");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "oracle Corporation" + "'", str10.equals("oracle Corporation"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str11.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaa", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("              1.7               ", (long) 64);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 64L + "'", long2 == 64L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "sun.awt.CGraphicsEnvironmentsun.awsun.aN/randoop-current.jarsun.awt.CGraphicsEnvironmentsun.awsun.aw", 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 0, (byte) 1, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', 76, (int) (short) 0);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        byte byte19 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte20 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100a0a1a100" + "'", str6.equals("100a0a1a100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#0#1#100" + "'", str8.equals("100#0#1#100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100 0 1 100" + "'", str12.equals("100 0 1 100"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100#0#1#100" + "'", str18.equals("100#0#1#100"));
        org.junit.Assert.assertTrue("'" + byte19 + "' != '" + (byte) 100 + "'", byte19 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte20 + "' != '" + (byte) 0 + "'", byte20 == (byte) 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("rJob");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) ' ', (double) 1L, (double) 7);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "32.0 -1.0 -1.0 100.0 100.0", (java.lang.CharSequence) "cosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lw");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "32.04-1.04-1.0", " ####Por ####Por ####Por ####Por ####Por ####Por ####Por ####Por ####Por ####");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java Platform API Specification", ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java4Platform4API4Specification" + "'", str3.equals("Java4Platform4API4Specification"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        short[] shortArray6 = new short[] { (byte) 1, (short) 100, (short) 0, (short) 100, (byte) 1, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#', 21, 0);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a', 64, 22);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1#100#0#100#1#0" + "'", str9.equals("1#100#0#100#1#0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "141004041004140" + "'", str11.equals("141004041004140"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java HotSpot(TM) 64-Bit Server VM", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str3.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "esrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (-1), 91);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "class [Ljava.lang.String;#class [Ljava.lang.String;", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("aaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "              1.7               ", (java.lang.CharSequence) " ", 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...enende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...en", (java.lang.CharSequence) "aaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("#                                                                                                ", "r##########################################################################################/Library/Jtensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#                                                                                                " + "'", str2.equals("#                                                                                                "));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 64.0f, (double) (short) 10, (double) 7);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 64.0d + "'", double3 == 64.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("              1.7               ", 26, "aa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "              1.7               " + "'", str3.equals("              1.7               "));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaeihpos", (java.lang.CharSequence) "d2esrresr6esro2esro2esporation444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("sop4                                                                        ", "10.04-1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sop4                                                                        " + "'", str2.equals("sop4                                                                        "));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                          44444", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                          44444" + "'", str2.equals("                          44444"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        short[] shortArray6 = new short[] { (byte) 10, (byte) 1, (short) 1, (short) 100, (short) 100, (short) 10 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a', 100, 97);
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short15 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ', 89, 30);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10#1#1#100#100#10" + "'", str9.equals("10#1#1#100#100#10"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 1 + "'", short14 == (short) 1);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 100 + "'", short15 == (short) 100);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "10414141004100410", (java.lang.CharSequence) "aa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("                                                                 AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                 AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("                                                                 AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt.CGraphicsEnvironment", '4');
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("444444", strArray3, strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "444444" + "'", str5.equals("444444"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Por000                  ..Por000                  ..Por000                  ..Por000                  ..Por000                  ..Por000                  ..Por000                  ..Por000                  ..Por000                  ..Por000                  ..Por000                  ..Por000                  ..Por000                  ..Por000                  ..Por000");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##################" + "'", str2.equals("##################"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt.CGraphicsEnvironment", '4');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("24.80-b11");
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "444444", (java.lang.CharSequence[]) strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray8);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1004041410010040414100100404141001004041410010040414100100404141", strArray4, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 6");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("10414141004100410", "aaaaaaaaaaeihpos");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10414141004100410" + "'", str2.equals("10414141004100410"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        long[] longArray2 = new long[] { 100L, (short) 100 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray2, '#');
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100a100" + "'", str6.equals("100a100"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100#100" + "'", str9.equals("100#100"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("    sun.lwawt.macosx.CPrinterJob", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                            ", " ####Por ####Por ####Por ####Por ####Por ####Por ####Por ####Por ####Por ####");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("    sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(59, 1, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 59 + "'", int3 == 59);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("d2esrresr6esro2esro2esporation444444444444444444444444");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "32.04-1.04-1.04100.04100.0", 21, 5);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1a100a0a100a1a0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "0", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        double[] doubleArray5 = new double[] { ' ', (-1.0f), (-1L), 100, (byte) 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ', (int) (byte) 100, (int) ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double15 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double16 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "32.04-1.04-1.04100.04100.0" + "'", str13.equals("32.04-1.04-1.04100.04100.0"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15 == 100.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.0d + "'", double16 == 100.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("porat.on", "##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J##########################################################################################/Library/J", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("jAVA(tm) se rUNTIME eNVIRONMENT", 23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA(tm) se rUNTIME eNVIRONMENT" + "'", str2.equals("jAVA(tm) se rUNTIME eNVIRONMENT"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        java.lang.String[] strArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("S/J...", "10040414100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                 AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (java.lang.CharSequence) "hi!       ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80" + "'", str1.equals("                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a1.7.0_80"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Virtual Machine Specification", "10.1a.3/Li", 8);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                  raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:se");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(":", strArray4, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 8 vs 19");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("US");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast(".LWCToolki", "aaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".LWCToolki" + "'", str2.equals(".LWCToolki"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        short[] shortArray2 = new short[] { (short) 1, (byte) 10 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4', (int) (byte) 100, (int) (short) 1);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 1 + "'", short8 == (short) 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 10 + "'", short9 == (short) 10);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("e4444444444444444444444444444444444", "       ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("100a100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100a100" + "'", str1.equals("100a100"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        float[] floatArray5 = new float[] { 'a', 35.0f, 8, (byte) -1, (byte) 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "97.0#35.0#8.0#-1.0#10.0" + "'", str7.equals("97.0#35.0#8.0#-1.0#10.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 97.0f + "'", float8 == 97.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 97.0f + "'", float9 == 97.0f);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "Hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/lIBRARY/j");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "100 0 1 ", (java.lang.CharSequence) "Hi!       ", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        float[] floatArray1 = new float[] { ' ' };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "32.0" + "'", str3.equals("32.0"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 32.0f + "'", float4 == 32.0f);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "32.0" + "'", str6.equals("32.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 32.0f + "'", float7 == 32.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 32.0f + "'", float8 == 32.0f);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Oracle Corporation", "/Users/sop100a0a1a100/Users/soph", "#######aaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "O#acl# Ca#aa#atian" + "'", str3.equals("O#acl# Ca#aa#atian"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#                                                                                                ");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaaaaa", "sophie", "[Ljava.lang.String;e [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class eclass");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "S/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 0, (byte) 1, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', (int) (short) 0, (int) (byte) 0);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100a0a1a100" + "'", str6.equals("100a0a1a100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#0#1#100" + "'", str8.equals("100#0#1#100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 100 + "'", byte15 == (byte) 100);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100100404141001004041410010040414100", (java.lang.CharSequence) "141004041004140");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("32.0#-1.0#", ".LWC...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("10.14.3", (int) (short) 0, 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10." + "'", str3.equals("10."));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("PORaaaaaaaa", 64, " ####Por ####Por ####Por ####Por ####Por ####Por ####Por ####Por ####Por ####");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " ####Por ####Por ####Por #PORaaaaaaaa ####Por ####Por ####Por ##" + "'", str3.equals(" ####Por ####Por ####Por #PORaaaaaaaa ####Por ####Por ####Por ##"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        short[] shortArray6 = new short[] { (byte) 1, (short) 100, (short) 0, (short) 100, (byte) 1, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short13 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a', (int) '4', (int) (short) 0);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#', (int) (byte) 100, (int) (short) -1);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1#100#0#100#1#0" + "'", str9.equals("1#100#0#100#1#0"));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 0 + "'", short13 == (short) 0);
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 0 + "'", short14 == (short) 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " ####", (java.lang.CharSequence) "                    1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("52.0a1.0a6.0a32.0a32.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.23a0.23a0.6a0.1a0.25" + "'", str1.equals("0.23a0.23a0.6a0.1a0.25"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "100a0a1a100", (java.lang.CharSequence) "AA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "                                             sun.lwawt.macosx.LWCToolki                                                    1.6                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "PORaaaaaaaa", (java.lang.CharSequence) "hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("52.0a1.0a6.0a32.0a32.0", "X86_6");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "U", (int) ' ', 0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "           ", (java.lang.CharSequence) "/lIBRARY/j           32.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.041");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "           ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("X86_65.15.1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 28, 99);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 32, (long) 5, (long) 78);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aa", "", 15);
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("-1", strArray4, strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1" + "'", str6.equals("-1"));
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("sun.awt.CGraphicsEnvironmentsun.awt");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", "r##########################################################################################/Library/Jtensions:/System/Library/Java/Extensions:/usr/lib/java", "################################################hi!#################################################", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X" + "'", str4.equals("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        char[] charArray10 = new char[] {};
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100a0a1a100", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100a0a1a100", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "        ", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1004100", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "32.0 -1.0 -1.0 100.0 100.0", charArray10);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "s/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray10);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                                 aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray10);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a');
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100 100", charArray10);
        java.lang.Class<?> wildcardClass22 = charArray10.getClass();
        boolean boolean23 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...     ...", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 59, 21);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                       /4                                                 ", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/4" + "'", str2.equals("/4"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "M) SE RUNTIME EN", (java.lang.CharSequence) "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("en                  ", 32, 30);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        char[] charArray8 = new char[] {};
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100a0a1a100", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100a0a1a100", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "        ", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10040414100", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                            ", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "d2esrresr6esro2esro2es", charArray8);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "class [Ljava.lang.String;#class [Ljava.lang.String;", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 135L, (double) 90, (double) 1004100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 90.0d + "'", double3 == 90.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        byte[] byteArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "#########################################################################################hi!       ", "##################################################################################################################\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("sophieaaaaaaaaaa", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophieaaaaaaaaaa" + "'", str2.equals("sophieaaaaaaaaaa"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000", "US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("M) SE Runtime En");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "M) SE Runtime En" + "'", str1.equals("M) SE Runtime En"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 0, 0, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "           ", (java.lang.CharSequence) "10a1a1a100a100a10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Hi!", (java.lang.CharSequence) "noitarop");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        double[] doubleArray5 = new double[] { ' ', (-1.0f), (-1L), 100, (byte) 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ', (int) (byte) 100, (int) ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4', 32, 78);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "32.04-1.04-1.04100.04100.0" + "'", str13.equals("32.04-1.04-1.04100.04100.0"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(91, 2, 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        float[] floatArray6 = new float[] { 52.0f, 2, 5.0f, 3, 'a', 1 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a', 97, 28);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4', 22, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 22");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        double[] doubleArray5 = new double[] { ' ', (-1.0f), (-1L), 100, (byte) 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "32.0 -1.0 -1.0 100.0 100.0" + "'", str8.equals("32.0 -1.0 -1.0 100.0 100.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "32.04-1.04-1.04100.04100.0" + "'", str11.equals("32.04-1.04-1.04100.04100.0"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("M) SE Runtime En", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 32);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("##################", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "######" + "'", str2.equals("######"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        long[] longArray2 = new long[] { 100L, (short) 100 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.Class<?> wildcardClass6 = longArray2.getClass();
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1004100" + "'", str8.equals("1004100"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("100 10 1 10");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 73, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                         " + "'", str3.equals("                                                                         "));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        short[] shortArray2 = new short[] { (short) 1, (byte) 10 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4', (int) (byte) 100, (int) (short) 1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ', (int) '4', (int) (short) -1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1a10" + "'", str13.equals("1a10"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("5.1", "S/J...", 24);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "5.1" + "'", str3.equals("5.1"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("32.0 -1.0 -1.0 100.0 100.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "HI!      ", (java.lang.CharSequence) "Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000Por000");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "http://java.oracle.com/", "aaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "", charArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a', 1, 0);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre", charArray4);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                   ", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "#", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "NOITAROP", (java.lang.CharSequence) "USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("p                  ..                  ..           ", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                  raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:se", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                  raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:se" + "'", str2.equals("                  raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:se"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("iL/3.a1.01", "sions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 11);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                             sun.lwawt.macosx.LWCToolki                                                    1.6                                                ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 174 + "'", int5 == 174);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        char[] charArray7 = new char[] {};
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100a0a1a100", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100a0a1a100", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "        ", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1004100", charArray7);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "32.0 -1.0 -1.0 100.0 100.0", charArray7);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "s/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray7);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray7, '#');
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a", "cle.com/a.oravahttp://j");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a" + "'", str2.equals("/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaa", "                     ");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                               /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                               /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a" + "'", str3.equals("                               /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("    sun");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun" + "'", str1.equals("sun"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "...                /Users/sophie...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("sun.lwawt.macosx.LWCToolki");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolki" + "'", str1.equals("sun.lwawt.macosx.LWCToolki"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.05100a0a1a10ava HotSpot(TM) 64-Bit Server V", "sun");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.05100a0a1a10ava HotSpot(TM) 64-Bit Server V" + "'", str2.equals("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.05100a0a1a10ava HotSpot(TM) 64-Bit Server V"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Mc OS X", "46_68x");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mc OS X" + "'", str3.equals("Mc OS X"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        long[] longArray2 = new long[] { 100L, (short) 100 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray2, '4', (int) '#', (int) ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        long long15 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004100" + "'", str10.equals("1004100"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1004100" + "'", str14.equals("1004100"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "aaaaaaaaaaa", (java.lang.CharSequence) "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("M) SE RUNTIME EN");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "M) SE RUNTIME EN" + "'", str1.equals("M) SE RUNTIME EN"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("...class [Ljava.lang.String;eclass [Ljava.lang.Strin10.1a.3/LiString;ecla...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...class [Ljava.lang.String;eclass [Ljava.lang.Strin10.1a.3/LiString;ecla..." + "'", str1.equals("...class [Ljava.lang.String;eclass [Ljava.lang.Strin10.1a.3/LiString;ecla..."));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("       ", 22);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       " + "'", str2.equals("       "));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 135L, (float) 7, (float) 100L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 7.0f + "'", float3 == 7.0f);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10040414100", "sophie");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "p", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        double[] doubleArray5 = new double[] { ' ', (-1.0f), (-1L), 100, (byte) 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "32.0a-1.0a-1.0a100.0a100.0" + "'", str10.equals("32.0a-1.0a-1.0a100.0a100.0"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "          /LIBRARY/J           32.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.041", (java.lang.CharSequence) "RY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 5, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("U", "por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000                  ..por000");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("24.80-b11");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "", (java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "24 . 80 - b 11" + "'", str5.equals("24 . 80 - b 11"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                            ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("    sun.lwawt.macosx.CPrinterJob", "                                             100 100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                                              1.7                                                ", "                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a", "hi!", 73);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                              1.7                                                " + "'", str4.equals("                                              1.7                                                "));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444                            ", (java.lang.CharSequence) "MACOSX", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("de...", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 26);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) -1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                      /4                                                 ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("p");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("cle.com/a.oravahttp://j", "                                                                 AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80" + "'", str3.equals("    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sop100a0a1a100/Users/soph", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaaaaaaaaaa", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("a", "##########################################################################################/Library/J");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "X86_6", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                  ..");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                  .." + "'", str1.equals("                  .."));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.1", "", "esrodne/bil/erj/emoH/stnetnoC/kdj.08_0.kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.1" + "'", str3.equals("1.1"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                  ..", "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.05100a0a1a10ava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "S/J...hie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4", "es:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 59);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "                                      /4                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Virtual Machine Specification", "", (int) (short) 1);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("SUN.AWT.cgRAPHICSeNVIRONMENTSUN.AW ", "5.1", 18);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.AWT.5.1SUN.AW " + "'", str3.equals("SUN.AWT.5.1SUN.AW "));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "VNe EMITNUr es )m", (java.lang.CharSequence) "VNe EMITNUr es )m", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#CLASS [lJAVA.LANG.sTRING;ECLASS", (java.lang.CharSequence) "##aaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaaaaaaaaaaa", "aaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("ed", "", "HI!       ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(76, 100, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        double[] doubleArray5 = new double[] { ' ', (-1.0f), (-1L), 100, (byte) 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "32.0 -1.0 -1.0 100.0 100.0" + "'", str8.equals("32.0 -1.0 -1.0 100.0 100.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "32.04-1.04-1.04100.04100.0" + "'", str11.equals("32.04-1.04-1.04100.04100.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "32.0a-1.0a-1.0a100.0a100.0" + "'", str13.equals("32.0a-1.0a-1.0a100.0a100.0"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        java.lang.CharSequence[] charSequenceArray4 = new java.lang.CharSequence[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "", charSequenceArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "hi!", charSequenceArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequenceArray4);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charSequenceArray4);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524", charSequenceArray4);
        org.junit.Assert.assertNotNull(charSequenceArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                                                                                                                       ", "          /Library/J           ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.String str4 = javaVersion3.toString();
        boolean boolean5 = javaVersion1.atLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str7 = javaVersion6.toString();
        java.lang.String str8 = javaVersion6.toString();
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.String str11 = javaVersion10.toString();
        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion10);
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean14 = javaVersion10.atLeast(javaVersion13);
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean17 = javaVersion15.atLeast(javaVersion16);
        boolean boolean18 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion15);
        org.apache.commons.lang3.JavaVersion javaVersion19 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean20 = javaVersion15.atLeast(javaVersion19);
        boolean boolean21 = javaVersion10.atLeast(javaVersion19);
        org.apache.commons.lang3.JavaVersion javaVersion22 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean23 = javaVersion19.atLeast(javaVersion22);
        boolean boolean24 = javaVersion6.atLeast(javaVersion22);
        boolean boolean25 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion22);
        boolean boolean26 = javaVersion3.atLeast(javaVersion22);
        java.lang.String str27 = javaVersion22.toString();
        java.lang.String str28 = javaVersion22.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7" + "'", str4.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.5" + "'", str7.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.5" + "'", str8.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.7" + "'", str11.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + javaVersion19 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion19.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + javaVersion22 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion22.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1.2" + "'", str27.equals("1.2"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1.2" + "'", str28.equals("1.2"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits(".LWCToolki");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("cosx.LWCToolkitawt.maun.lw", "aa", "##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "cosx.LWCToolkitawt.maun.lw" + "'", str3.equals("cosx.LWCToolkitawt.maun.lw"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        long[] longArray2 = new long[] { 100L, (short) 100 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray2, '4', (int) '#', (int) ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004100" + "'", str10.equals("1004100"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100 100" + "'", str13.equals("100 100"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100 100" + "'", str15.equals("100 100"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("                                                        1.7.0_8", "###################################################################################################################################                               /Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a####################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                        1.7.0_8" + "'", str2.equals("                                                        1.7.0_8"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                              /users/sophie/documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                  ..");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                  .." + "'", str1.equals("                  .."));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("e4444444444444444444444444444444444", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "e4444444444444444444444444444444444" + "'", str3.equals("e4444444444444444444444444444444444"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 73);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                         " + "'", str2.equals("                                                                         "));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        double[] doubleArray5 = new double[] { ' ', (-1.0f), (-1L), 100, (byte) 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "32.0 -1.0 -1.0 100.0 100.0" + "'", str8.equals("32.0 -1.0 -1.0 100.0 100.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("        ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        int[] intArray1 = new int[] { (short) -1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, '4', (int) (short) 100, (int) '4');
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', 78, 11);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "100 10 1 10", (java.lang.CharSequence) "          /Library/J           ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "                  raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:se", (java.lang.CharSequence) "eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.Strin10.1a.3/LiString;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;e", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 0, (byte) 1, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4', 15, 5);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        byte byte18 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100a0a1a100" + "'", str6.equals("100a0a1a100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#0#1#100" + "'", str8.equals("100#0#1#100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100#0#1#100" + "'", str11.equals("100#0#1#100"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100#0#1#100" + "'", str17.equals("100#0#1#100"));
        org.junit.Assert.assertTrue("'" + byte18 + "' != '" + (byte) 100 + "'", byte18 == (byte) 100);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "444444", (java.lang.CharSequence) "Oracle Corporation", (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Threshold must not be negative");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("    1.7.0_80");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("32.0-1.0-1.0100.0100.0", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32.0-1.0-1.0100.0100.0" + "'", str2.equals("32.0-1.0-1.0100.0100.0"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("32.0a-1.0a-1.0a100.0a100.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10040414100", "sophie");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "Java(TM) SE Runtime Environment", 31, 0);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironmentsun.aw ", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("32a97a1");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32a97a1" + "'", str2.equals("32a97a1"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1000110044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                                                                             97.0a35.0a8.0a-1.0a10.0", 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        int[] intArray3 = new int[] { ' ', 'a', (byte) 1 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.Class<?> wildcardClass8 = intArray3.getClass();
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', (int) (short) 1, 363);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "32a97a1" + "'", str7.equals("32a97a1"));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("-141004-141", "aa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-141004-141" + "'", str2.equals("-141004-141"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "0.23a0.23a0.6a0.1a0.25");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "444444", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaa", 1605);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("x86_6", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 990);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1#100#0#100#1#0", "", 17, 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1#100#0#100#1#0" + "'", str4.equals("1#100#0#100#1#0"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        double[] doubleArray5 = new double[] { ' ', (-1.0f), (-1L), 100, (byte) 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4', 0, 3);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ', 10, 359);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "32.0 -1.0 -1.0 100.0 100.0" + "'", str8.equals("32.0 -1.0 -1.0 100.0 100.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "32.0 -1.0 -1.0 100.0 100.0" + "'", str11.equals("32.0 -1.0 -1.0 100.0 100.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "32.04-1.04-1.0" + "'", str15.equals("32.04-1.04-1.0"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "32.0#-1.0#-1.0#100.0#100.0" + "'", str17.equals("32.0#-1.0#-1.0#100.0#100.0"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "[Ljava.lang.String;e [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class eclass", (java.lang.CharSequence) "aaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        double[] doubleArray5 = new double[] { ' ', (-1.0f), (-1L), 100, (byte) 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 20, 1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4', 64, (int) (byte) -1);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "32.0a-1.0a-1.0a100.0a100.0" + "'", str8.equals("32.0a-1.0a-1.0a100.0a100.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "32.0a-1.0a-1.0a100.0a100.0" + "'", str18.equals("32.0a-1.0a-1.0a100.0a100.0"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "32.04-1.04-1.04100.04100.0" + "'", str20.equals("32.04-1.04-1.04100.04100.0"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray5 = new char[] {};
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny(charSequence2, charArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10414141004100410", charArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray5, '#', 11, 11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "97.0#35.0#8.0#-1.0#10.0", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1#100#0#100#1#0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("SU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        org.apache.commons.lang3.JavaVersion javaVersion0 = null;
        try {
            boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        short[] shortArray6 = new short[] { (byte) 10, (byte) 1, (short) 1, (short) 100, (short) 100, (short) 10 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a', 100, 97);
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short15 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short16 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short17 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10#1#1#100#100#10" + "'", str9.equals("10#1#1#100#100#10"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 1 + "'", short14 == (short) 1);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 100 + "'", short15 == (short) 100);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 100 + "'", short16 == (short) 100);
        org.junit.Assert.assertTrue("'" + short17 + "' != '" + (short) 100 + "'", short17 == (short) 100);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1410", (java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "990a6a32a44444a-1", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("    sun.lwawt.macosx.CPrinterJob", 1004100, " 080   ...     ...   080   ...     ...   080   ...     ...   080");
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("U", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                    hi!", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "                    ", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironmentsun.awsun.aN/randoop-current.jarsun.awt.CGraphicsEnvironmentsun.awsun.aw", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "", 97);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "LWCToolki");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str5.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java Virtual Machine Specification", (double) 59);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 59.0d + "'", double2 == 59.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        short[] shortArray6 = new short[] { (byte) 10, (byte) 1, (short) 1, (short) 100, (short) 100, (short) 10 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        short short13 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short14 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10#1#1#100#100#10" + "'", str9.equals("10#1#1#100#100#10"));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 1 + "'", short10 == (short) 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10 1 1 100 100 10" + "'", str12.equals("10 1 1 100 100 10"));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 1 + "'", short13 == (short) 1);
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 100 + "'", short14 == (short) 100);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10#1#1#100#100#10" + "'", str16.equals("10#1#1#100#100#10"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph", (java.lang.CharSequence) "10 1 1 100 100 10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                  vv", "#                                                                                                ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("4                                                                                                   ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4                                                                                                   " + "'", str2.equals("4                                                                                                   "));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace(".0a", "", "32.0a-1.0a-1.0a100.0a100.0", 18);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ".0a" + "'", str4.equals(".0a"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("oolkit", "141004041004140                                                                                  ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 5L, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        short[] shortArray6 = new short[] { (byte) 10, (byte) 1, (short) 1, (short) 100, (short) 100, (short) 10 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#', (int) ' ', (int) (short) 0);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4', 0, 0);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 1 + "'", short12 == (short) 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10414141004100410" + "'", str18.equals("10414141004100410"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN" + "'", str1.equals("M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("#########################################################################################hi!       ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"########################################################################################hi!       \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Libr...", (java.lang.CharSequence) "4444444444444444444                                   sun.lwawt.macosx.LWCToolki                                    4444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("aaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "MIXED MODE", (java.lang.CharSequence) "                                      /4                                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                               /USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51411_1560278524");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "cosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lwcosx.LWCToolkitawt.maun.lw", (java.lang.CharSequence) "class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;class [Ljava.lang.String;#class [Ljava.lang.String;raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:se");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("100", ".7.0_80-B15");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("O#acl# Ca#aa#atian", "eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;e");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "O#acl# Ca#aa#atian" + "'", str2.equals("O#acl# Ca#aa#atian"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "10 1 1 100 100 10", " poration444444444444444444444444  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 59, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        short[] shortArray4 = new short[] { (byte) -1, (byte) -1, (byte) 1, (short) 10 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 10 + "'", short5 == (short) 10);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                1.6                                                ", ".7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                    1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "S/J...", (java.lang.CharSequence) "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.05100a0a1a10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 132 + "'", int2 == 132);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;eclass [Ljava.lang.String;#class [Ljava.lang.String;e", 21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "eclass [Ljava.lang.St" + "'", str2.equals("eclass [Ljava.lang.St"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("3249741 100 100  ", "S/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3249741 100 100  " + "'", str2.equals("3249741 100 100  "));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence) "32.04-1.04-1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...ende...en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("10a1a1a100", "cosx.LWCToolkitawt.maun.lw", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("          /Library/J           ", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          /Library/J           " + "'", str2.equals("          /Library/J           "));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("########1#########");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test394");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 0, (byte) 1, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 79, 26);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100a0a1a100" + "'", str6.equals("100a0a1a100"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray2 = null;
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("porat.on", strArray1, strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "porat.on" + "'", str3.equals("porat.on"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "10a1a1a100", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "un.lwawt.macosx.LWCToolkit", "noitaroproC elcarO");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("AaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.05100a0a1a10ava HotSpot(TM) 64-Bit Server V", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("1#100#0#100#1#0                                                                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1#100#0#100#1#0                                                                                  " + "'", str1.equals("1#100#0#100#1#0                                                                                  "));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        short[] shortArray6 = new short[] { (byte) 10, (byte) 1, (short) 1, (short) 100, (short) 100, (short) 10 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#', (int) ' ', (int) (short) 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        short short16 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10a1a1a100a100a10" + "'", str13.equals("10a1a1a100a100a10"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10a1a1a100a100a10" + "'", str15.equals("10a1a1a100a100a10"));
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 1 + "'", short16 == (short) 1);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10 1 1 100 100 10" + "'", str18.equals("10 1 1 100 100 10"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/ldesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/ibrarydesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil//desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/jdesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/avadesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil//desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/jdesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/avadesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/vdesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/irtualdesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/mdesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/achinesdesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil//desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/jdkdesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/1desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/.desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/7desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/.desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/0desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/_desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/80desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/.desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/jdkdesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil//desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/cdesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/ontentsdesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil//desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/hdesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/omedesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil//desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/jredesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil//desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/libdesrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil//desrodne/bil/erj/emoh/stnetnoc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/endorsed", (java.lang.CharSequence) "97.0a35.0a8.0a-1.0a10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("n/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "raj.tnerruc-poodnar/n" + "'", str1.equals("raj.tnerruc-poodnar/n"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolki", (java.lang.CharSequence) "              1.7               ", 1605);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph/Users/sop100a0a1a100/Users/soph");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH" + "'", str1.equals("/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH/USERS/SOP100A0A1A100/USERS/SOPH"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("...     ...", "e4444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...     ..." + "'", str2.equals("...     ..."));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("S/J...", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S/J..." + "'", str2.equals("S/J..."));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        short[] shortArray2 = new short[] { (short) 1, (byte) 10 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4', (int) (byte) 100, (int) (short) 1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ', (int) '4', (int) (short) -1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4');
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1410" + "'", str13.equals("1410"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1410" + "'", str15.equals("1410"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "          /lIBRARY/j           32.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.041", (java.lang.CharSequence) "          /LIBRARY/J           32.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.04100.04100.032.04-1.04-1.041");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaa", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("esrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "esrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str2.equals("esrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.awt.CGraphicsEnvironmentsun.aw ", ".LWC...", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN10414141004100410M) SE RUNTIME EN", (java.lang.CharSequence) "raj.tnerruc-poodnar/n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 0, (byte) 1, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', (int) (short) 0, (int) (byte) 0);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', 20, (int) (byte) 0);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100a0a1a100" + "'", str6.equals("100a0a1a100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#0#1#100" + "'", str8.equals("100#0#1#100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100a0a1a100" + "'", str20.equals("100a0a1a100"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ', 0, (int) (short) 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("-1", "e", 0);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(":", "poration");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, ' ', 21, (int) (byte) -1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!       ", strArray5, strArray8);
        java.lang.Class<?> wildcardClass14 = strArray5.getClass();
        boolean boolean15 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "jAVA(tm) se rUNTIME eNVIRONMENT", (java.lang.CharSequence[]) strArray5);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, 'a', 31, 174);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 31");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!       " + "'", str13.equals("hi!       "));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                               /Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                               /Users/sophie/Documents/defects#j/tmp/run_r#ndoop.pl_51#11_156027852#" + "'", str3.equals("                               /Users/sophie/Documents/defects#j/tmp/run_r#ndoop.pl_51#11_156027852#"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase(" ####");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " ####" + "'", str1.equals(" ####"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("ed", "32.0#-1.0#.7.0_80-B1532.0#-1.0#-", "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ed" + "'", str3.equals("ed"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100 0 1 100", "Java HotSpot(TM) 64-Bit Server VM", 7);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong(".7.0_80-B15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".7.0_80-B15\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1.7.0_80", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("44444444444444444444444444oolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test425");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) ".LWCToolki", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test426");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                  ..", 15, "10.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                  .." + "'", str3.equals("                  .."));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test427");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1000110044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test428");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "jAVA(tm) se rUNTIME eNVIRONMENT", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test429");
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100a0a1a100", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100a0a1a100", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "        ", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1004100", charArray6);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "m) se rUNTIME eNV", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test430");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray11 = new char[] {};
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100a0a1a100", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100a0a1a100", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "        ", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1004100", charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "32.0 -1.0 -1.0 100.0 100.0", charArray11);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "s/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray11);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                                 aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray11);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray11);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray11);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test431");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("###################################################################################################################################                               /Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a####################################################################################################################################", ".0a", 3);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test432");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("n/generation/randoop-current.jar", "...                /Users/sophie...", "sun.awt.CGraphicsEnvironmentsun.aw ", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "n/generation/randoop-current.jar" + "'", str4.equals("n/generation/randoop-current.jar"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test433");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("32.0#-1.0#-1.0#100.0#100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "32.0#-1.0#-1.0#100.0#100.0" + "'", str1.equals("32.0#-1.0#-1.0#100.0#100.0"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test434");
        char[] charArray3 = new char[] {};
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "", charArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray3, ' ');
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Mac OS X", charArray3);
        java.lang.Class<?> wildcardClass9 = charArray3.getClass();
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test435");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "un.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test436");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1004041410010040414100100404141001004041410010040414100100404141");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + Float.POSITIVE_INFINITY + "'", float1.equals(Float.POSITIVE_INFINITY));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test437");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("sun.awt.CGraphicsEnvironmentsun.aw ", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test438");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "ry/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test439");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("esrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test440");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "U");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test441");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("          ", "en                  ", "esrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51411_1560278524", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ocuments/defects4j/tmp/run_randoop.pl_51411_1560278524" + "'", str2.equals("ocuments/defects4j/tmp/run_randoop.pl_51411_1560278524"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test443");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("5.1", 76, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444445.14444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444445.14444444444444444444444444444444444444"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test444");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("          /Library/J           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/J" + "'", str1.equals("/Library/J"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test445");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle Corporation" + "'", str1.equals("oracle Corporation"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test446");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                1.6                                                 ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test447");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "PORaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("SUN.LWAWT.MACOSX.cpRINTERjOB                        ", "                                                                            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjOB                        " + "'", str2.equals("SUN.LWAWT.MACOSX.cpRINTERjOB                        "));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test449");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("x86_6", 11, "1.8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.8x86_61.8" + "'", str3.equals("1.8x86_61.8"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test450");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "#                                                                                                ", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironmentsun.awsun.aN/randoop-current.jarsun.awt.CGraphicsEnvironmentsun.awsun.aw");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test451");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HTTP://JAVA.ORACLE.COM/" + "'", str1.equals("HTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test452");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1a100a0a100a1a0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a100a0a100a1a0" + "'", str1.equals("1a100a0a100a1a0"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test453");
        long[] longArray2 = new long[] { 100L, (short) 100 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1004100" + "'", str5.equals("1004100"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test454");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051000110v HotSpot(TM) 64-Bit Server VM", 99);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test455");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a", 8, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a" + "'", str3.equals("/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test456");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 1605, (long) 97, (long) 18);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 18L + "'", long3 == 18L);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test457");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test458");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.05100a0a1a10ava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test459");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.0a-1.0", "class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.String;class [Cclass [J", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("               ...PORPORPORP", "AaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("AaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaAaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test461");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("hi!", "sop4                                                                                                   1004                                                                                                   a4                                                                                                   04                                                                                                   a4                                                                                                   14                                                                                                   a4                                                                                                   1004                                                                                                   /4                                                                                                   Users4                                                                                                   /4                                                                                                   soph4                                                                                                   /");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test463");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defectsaj/tmp/run_randoop.pl_51a11_156027852a", (java.lang.CharSequence) "r##########################################################################################/Library/Jtensions:/System/Library/Java/Extensions:/usr/lib/java", 99);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test464");
        char[] charArray7 = new char[] { '#', '4', 'a', ' ', 'a', 'a' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################/library/j##########################################################################################", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "52.0a1.0a6.0a32.0a32.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test466");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 1605, "/Users/sop100a0a1a100/Users/soph");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar                  Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test467");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("sun.lwawt.macosx.CPrinterJob", "                  vv");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test468");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(1004100, 21, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("0.23a0.23a0.6a0.1a0.25", "e");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.23a0.23a0.6a0.1a0.25" + "'", str2.equals("0.23a0.23a0.6a0.1a0.25"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test470");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "SU", (java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33 + "'", int2 == 33);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test471");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80    1.7.0_80", (java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test472");
        float[] floatArray5 = new float[] { 'a', 35.0f, 8, (byte) -1, (byte) 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        float float12 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a', 1004100, 11);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "97.0#35.0#8.0#-1.0#10.0" + "'", str7.equals("97.0#35.0#8.0#-1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97.0a35.0a8.0a-1.0a10.0" + "'", str9.equals("97.0a35.0a8.0a-1.0a10.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "97.0#35.0#8.0#-1.0#10.0" + "'", str11.equals("97.0#35.0#8.0#-1.0#10.0"));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + (-1.0f) + "'", float12 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test473");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Ldesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/ibrarydesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Jdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/avadesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Jdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/avadesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Vdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/irtualdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Mdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/achinesdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/jdkdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/1desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/.desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/7desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/.desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/0desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/_desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/80desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/.desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/jdkdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Cdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/ontentsdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/Hdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/omedesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/jredesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/libdesrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL//desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/endorsed", "-1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test474");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 5.0f, 0.0d, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/", "1#100#0#100#1#0                                                                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/" + "'", str2.equals("S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/4S/JDK1.7.0_80.JDK/cONTENTS/hOME/S/JDK1.7.0_80.JDK/cONTENTS/hOME/"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test476");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", " ####", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test477");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("aaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Aaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("Aaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test478");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                    1.7.0_80-b15", (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test479");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("24.80-b11", 17.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 17.0d + "'", double2 == 17.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test480");
        int[] intArray3 = new int[] { ' ', 'a', (byte) 1 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "32#97#1" + "'", str6.equals("32#97#1"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test481");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                             sun.lwawt.macosx.LWCToolki                                                    1.6                                                ", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test482");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.51.21.71.71.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.51.21.71.71.7" + "'", str1.equals("1.51.21.71.71.7"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test483");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("32.0#-1.0#.7.0_80-B1532.0#-1.0#-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test484");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Por", 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test485");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("class [Ljava.lang.String;class [Ljava.lang.String;");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"class [Ljava.lang.String;class [Ljava.lang.String;\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test486");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.4", "USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test487");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                                 AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                 AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str2.equals("                                                                 AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("4444444444444444444444444444444444445.14444444444444444444444444444444444444", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444445.14444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444445.14444444444444444444444444444444444444"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test489");
        byte[] byteArray4 = new byte[] { (byte) 100, (byte) 0, (byte) 1, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', (int) (byte) 100, (int) (short) 0);
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "S/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: S/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100a0a1a100" + "'", str6.equals("100a0a1a100"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#0#1#100" + "'", str8.equals("100#0#1#100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100 0 1 100" + "'", str12.equals("100 0 1 100"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) 100 + "'", byte17 == (byte) 100);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test490");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("de...", "                                                                                                                   ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test491");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "46_68x", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1#100#0#100#1#0                                                                                  ", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                  " + "'", str2.equals("                                                                  "));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test493");
        long[] longArray2 = new long[] { 100L, (short) 100 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray2, '4', (int) '#', (int) ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        java.lang.Class<?> wildcardClass15 = longArray2.getClass();
        long long16 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long17 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004100" + "'", str10.equals("1004100"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1004100" + "'", str14.equals("1004100"));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test494");
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "", charArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray4, ' ');
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Mac OS X", charArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray4, '4', 0, 0);
        java.lang.Class<?> wildcardClass14 = charArray4.getClass();
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                  raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:se", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }
}

